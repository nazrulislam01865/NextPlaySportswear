<?php

app('router')->setCompiledRoutes(
    array (
  'compiled' => 
  array (
    0 => false,
    1 => 
    array (
      '/api/integrations/flowtrack/catalog/categories' => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'generated::wZqXgnVqJD4H8Sny',
          ),
          1 => NULL,
          2 => 
          array (
            'GET' => 0,
            'HEAD' => 1,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      '/api/integrations/flowtrack/catalog/products' => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'generated::pt8mTKT6hr6yyMfu',
          ),
          1 => NULL,
          2 => 
          array (
            'GET' => 0,
            'HEAD' => 1,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      '/api/integrations/flowtrack/catalog/customers' => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'generated::EO0sQ4mYUWlz0jNj',
          ),
          1 => NULL,
          2 => 
          array (
            'GET' => 0,
            'HEAD' => 1,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      '/api/integrations/flowtrack/bulk-orders' => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'generated::SsOnjmf9jUwdDi5k',
          ),
          1 => NULL,
          2 => 
          array (
            'POST' => 0,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      '/api/integrations/flowtrack/orders/from-flowtrack' => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'generated::iOJ7SenCuv4EjTTV',
          ),
          1 => NULL,
          2 => 
          array (
            'POST' => 0,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      '/api/integrations/flowtrack/branding' => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'generated::FJmCmozy8s8Y7SNk',
          ),
          1 => NULL,
          2 => 
          array (
            'GET' => 0,
            'HEAD' => 1,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      '/api/integrations/flowtrack/artwork-proofs' => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'generated::HimCZQFKUPnhD2wW',
          ),
          1 => NULL,
          2 => 
          array (
            'POST' => 0,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      '/up' => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'generated::d6gKHo5XrW8Q61sP',
          ),
          1 => NULL,
          2 => 
          array (
            'GET' => 0,
            'HEAD' => 1,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      '/webhooks/stripe' => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'webhooks.stripe',
          ),
          1 => NULL,
          2 => 
          array (
            'POST' => 0,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      '/' => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'home',
          ),
          1 => NULL,
          2 => 
          array (
            'GET' => 0,
            'HEAD' => 1,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      '/homepage/latest-products' => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'home.latest-products',
          ),
          1 => NULL,
          2 => 
          array (
            'GET' => 0,
            'HEAD' => 1,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      '/sitemap.xml' => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'sitemap',
          ),
          1 => NULL,
          2 => 
          array (
            'GET' => 0,
            'HEAD' => 1,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      '/products/visitor-activity' => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'products.visitor-activity',
          ),
          1 => NULL,
          2 => 
          array (
            'POST' => 0,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      '/about-us' => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'about',
          ),
          1 => NULL,
          2 => 
          array (
            'GET' => 0,
            'HEAD' => 1,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      '/contact-us' => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'contact',
          ),
          1 => NULL,
          2 => 
          array (
            'GET' => 0,
            'HEAD' => 1,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
        1 => 
        array (
          0 => 
          array (
            '_route' => 'contact.store',
          ),
          1 => NULL,
          2 => 
          array (
            'POST' => 0,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      '/newsletter' => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'newsletter.store',
          ),
          1 => NULL,
          2 => 
          array (
            'POST' => 0,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      '/help-center' => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'faq',
          ),
          1 => NULL,
          2 => 
          array (
            'GET' => 0,
            'HEAD' => 1,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      '/testimonials' => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'testimonials.index',
          ),
          1 => NULL,
          2 => 
          array (
            'GET' => 0,
            'HEAD' => 1,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      '/how-to-order' => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'how-to-order',
          ),
          1 => NULL,
          2 => 
          array (
            'GET' => 0,
            'HEAD' => 1,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      '/size-guide' => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'size-guide',
          ),
          1 => NULL,
          2 => 
          array (
            'GET' => 0,
            'HEAD' => 1,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      '/artwork-guidelines' => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'artwork-guidelines',
          ),
          1 => NULL,
          2 => 
          array (
            'GET' => 0,
            'HEAD' => 1,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      '/customization-guide' => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'customization-guide',
          ),
          1 => NULL,
          2 => 
          array (
            'GET' => 0,
            'HEAD' => 1,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      '/bulk-team-ordering' => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'bulk-ordering',
          ),
          1 => NULL,
          2 => 
          array (
            'GET' => 0,
            'HEAD' => 1,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      '/bulk-quote' => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'quote.request',
          ),
          1 => NULL,
          2 => 
          array (
            'GET' => 0,
            'HEAD' => 1,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
        1 => 
        array (
          0 => 
          array (
            '_route' => 'quote.request.store',
          ),
          1 => NULL,
          2 => 
          array (
            'POST' => 0,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      '/bulk-quote/track' => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'quote.guest.track',
          ),
          1 => NULL,
          2 => 
          array (
            'GET' => 0,
            'HEAD' => 1,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
        1 => 
        array (
          0 => 
          array (
            '_route' => 'quote.guest.lookup',
          ),
          1 => NULL,
          2 => 
          array (
            'POST' => 0,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      '/shipping-delivery' => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'shipping',
          ),
          1 => NULL,
          2 => 
          array (
            'GET' => 0,
            'HEAD' => 1,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      '/sustainability' => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'sustainability',
          ),
          1 => NULL,
          2 => 
          array (
            'GET' => 0,
            'HEAD' => 1,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      '/returns-refunds-exchanges' => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'returns',
          ),
          1 => NULL,
          2 => 
          array (
            'GET' => 0,
            'HEAD' => 1,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      '/payment-information' => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'payment-information',
          ),
          1 => NULL,
          2 => 
          array (
            'GET' => 0,
            'HEAD' => 1,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      '/privacy-policy' => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'privacy',
          ),
          1 => NULL,
          2 => 
          array (
            'GET' => 0,
            'HEAD' => 1,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      '/terms-conditions' => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'terms',
          ),
          1 => NULL,
          2 => 
          array (
            'GET' => 0,
            'HEAD' => 1,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      '/cookie-policy' => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'cookies',
          ),
          1 => NULL,
          2 => 
          array (
            'GET' => 0,
            'HEAD' => 1,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      '/accessibility' => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'accessibility',
          ),
          1 => NULL,
          2 => 
          array (
            'GET' => 0,
            'HEAD' => 1,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      '/about' => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'generated::TmikGhq4CfJLNLRb',
          ),
          1 => NULL,
          2 => 
          array (
            'GET' => 0,
            'HEAD' => 1,
            'POST' => 2,
            'PUT' => 3,
            'PATCH' => 4,
            'DELETE' => 5,
            'OPTIONS' => 6,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      '/contact' => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'generated::mLRRPFz02HhGoWWx',
          ),
          1 => NULL,
          2 => 
          array (
            'GET' => 0,
            'HEAD' => 1,
            'POST' => 2,
            'PUT' => 3,
            'PATCH' => 4,
            'DELETE' => 5,
            'OPTIONS' => 6,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      '/faq' => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'generated::srLUzAxZM00g5Ov8',
          ),
          1 => NULL,
          2 => 
          array (
            'GET' => 0,
            'HEAD' => 1,
            'POST' => 2,
            'PUT' => 3,
            'PATCH' => 4,
            'DELETE' => 5,
            'OPTIONS' => 6,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      '/help' => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'generated::fnWuKrBT0k5OXhFf',
          ),
          1 => NULL,
          2 => 
          array (
            'GET' => 0,
            'HEAD' => 1,
            'POST' => 2,
            'PUT' => 3,
            'PATCH' => 4,
            'DELETE' => 5,
            'OPTIONS' => 6,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      '/shipping' => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'generated::OLCEuHaGyr27tnkS',
          ),
          1 => NULL,
          2 => 
          array (
            'GET' => 0,
            'HEAD' => 1,
            'POST' => 2,
            'PUT' => 3,
            'PATCH' => 4,
            'DELETE' => 5,
            'OPTIONS' => 6,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      '/returns' => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'generated::IrBCmyABD70rq2MK',
          ),
          1 => NULL,
          2 => 
          array (
            'GET' => 0,
            'HEAD' => 1,
            'POST' => 2,
            'PUT' => 3,
            'PATCH' => 4,
            'DELETE' => 5,
            'OPTIONS' => 6,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      '/privacy' => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'generated::oCHOdAuCpIXEnM2f',
          ),
          1 => NULL,
          2 => 
          array (
            'GET' => 0,
            'HEAD' => 1,
            'POST' => 2,
            'PUT' => 3,
            'PATCH' => 4,
            'DELETE' => 5,
            'OPTIONS' => 6,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      '/terms' => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'generated::OB9tfvae8bb1KgDb',
          ),
          1 => NULL,
          2 => 
          array (
            'GET' => 0,
            'HEAD' => 1,
            'POST' => 2,
            'PUT' => 3,
            'PATCH' => 4,
            'DELETE' => 5,
            'OPTIONS' => 6,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      '/cookies' => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'generated::yfT3dURg3fL15Awu',
          ),
          1 => NULL,
          2 => 
          array (
            'GET' => 0,
            'HEAD' => 1,
            'POST' => 2,
            'PUT' => 3,
            'PATCH' => 4,
            'DELETE' => 5,
            'OPTIONS' => 6,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      '/accessibility-statement' => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'generated::YX5QHxsmehzvodQe',
          ),
          1 => NULL,
          2 => 
          array (
            'GET' => 0,
            'HEAD' => 1,
            'POST' => 2,
            'PUT' => 3,
            'PATCH' => 4,
            'DELETE' => 5,
            'OPTIONS' => 6,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      '/admin/login' => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'admin.login',
          ),
          1 => NULL,
          2 => 
          array (
            'GET' => 0,
            'HEAD' => 1,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
        1 => 
        array (
          0 => 
          array (
            '_route' => 'admin.login.store',
          ),
          1 => NULL,
          2 => 
          array (
            'POST' => 0,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      '/admin' => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'admin.dashboard',
          ),
          1 => NULL,
          2 => 
          array (
            'GET' => 0,
            'HEAD' => 1,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      '/admin/logout' => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'admin.logout',
          ),
          1 => NULL,
          2 => 
          array (
            'POST' => 0,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      '/admin/notifications' => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'admin.notifications.index',
          ),
          1 => NULL,
          2 => 
          array (
            'GET' => 0,
            'HEAD' => 1,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      '/admin/notifications/feed' => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'admin.notifications.feed',
          ),
          1 => NULL,
          2 => 
          array (
            'GET' => 0,
            'HEAD' => 1,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      '/admin/notifications/read-all' => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'admin.notifications.read-all',
          ),
          1 => NULL,
          2 => 
          array (
            'POST' => 0,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      '/admin/notifications/pusher/auth' => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'admin.notifications.pusher-auth',
          ),
          1 => NULL,
          2 => 
          array (
            'POST' => 0,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      '/admin/newsletter-subscribers' => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'admin.newsletter-subscribers.index',
          ),
          1 => NULL,
          2 => 
          array (
            'GET' => 0,
            'HEAD' => 1,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      '/admin/newsletter-subscribers/export' => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'admin.newsletter-subscribers.export',
          ),
          1 => NULL,
          2 => 
          array (
            'GET' => 0,
            'HEAD' => 1,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      '/admin/media-library' => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'admin.media-library.index',
          ),
          1 => NULL,
          2 => 
          array (
            'GET' => 0,
            'HEAD' => 1,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
        1 => 
        array (
          0 => 
          array (
            '_route' => 'admin.media-library.store',
          ),
          1 => NULL,
          2 => 
          array (
            'POST' => 0,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      '/admin/media-library/upload' => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'admin.media-library.upload',
          ),
          1 => NULL,
          2 => 
          array (
            'GET' => 0,
            'HEAD' => 1,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      '/admin/storefront-branding' => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'admin.storefront-branding.edit',
          ),
          1 => NULL,
          2 => 
          array (
            'GET' => 0,
            'HEAD' => 1,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
        1 => 
        array (
          0 => 
          array (
            '_route' => 'admin.storefront-branding.update',
          ),
          1 => NULL,
          2 => 
          array (
            'PUT' => 0,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      '/admin/product-detail-controls' => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'admin.product-detail-controls.edit',
          ),
          1 => NULL,
          2 => 
          array (
            'GET' => 0,
            'HEAD' => 1,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
        1 => 
        array (
          0 => 
          array (
            '_route' => 'admin.product-detail-controls.update',
          ),
          1 => NULL,
          2 => 
          array (
            'PUT' => 0,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      '/admin/about-page' => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'admin.about-page.edit',
          ),
          1 => NULL,
          2 => 
          array (
            'GET' => 0,
            'HEAD' => 1,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
        1 => 
        array (
          0 => 
          array (
            '_route' => 'admin.about-page.update',
          ),
          1 => NULL,
          2 => 
          array (
            'PUT' => 0,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      '/admin/shipping-delivery-page' => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'admin.shipping-delivery-page.edit',
          ),
          1 => NULL,
          2 => 
          array (
            'GET' => 0,
            'HEAD' => 1,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
        1 => 
        array (
          0 => 
          array (
            '_route' => 'admin.shipping-delivery-page.update',
          ),
          1 => NULL,
          2 => 
          array (
            'PUT' => 0,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      '/admin/sustainability-page' => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'admin.sustainability-page.edit',
          ),
          1 => NULL,
          2 => 
          array (
            'GET' => 0,
            'HEAD' => 1,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
        1 => 
        array (
          0 => 
          array (
            '_route' => 'admin.sustainability-page.update',
          ),
          1 => NULL,
          2 => 
          array (
            'PUT' => 0,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      '/admin/email-customization' => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'admin.email-customization.index',
          ),
          1 => NULL,
          2 => 
          array (
            'GET' => 0,
            'HEAD' => 1,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      '/admin/email-customization/templates' => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'admin.email-customization.templates.index',
          ),
          1 => NULL,
          2 => 
          array (
            'GET' => 0,
            'HEAD' => 1,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
        1 => 
        array (
          0 => 
          array (
            '_route' => 'admin.email-customization.templates.store',
          ),
          1 => NULL,
          2 => 
          array (
            'POST' => 0,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      '/admin/email-customization/templates/create' => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'admin.email-customization.templates.create',
          ),
          1 => NULL,
          2 => 
          array (
            'GET' => 0,
            'HEAD' => 1,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      '/admin/email-customization/branding' => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'admin.email-customization.branding.edit',
          ),
          1 => NULL,
          2 => 
          array (
            'GET' => 0,
            'HEAD' => 1,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
        1 => 
        array (
          0 => 
          array (
            '_route' => 'admin.email-customization.branding.update',
          ),
          1 => NULL,
          2 => 
          array (
            'PUT' => 0,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      '/admin/homepage' => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'admin.homepage.sections.index',
          ),
          1 => NULL,
          2 => 
          array (
            'GET' => 0,
            'HEAD' => 1,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      '/admin/homepage-slides' => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'admin.homepage-slides.index',
          ),
          1 => NULL,
          2 => 
          array (
            'GET' => 0,
            'HEAD' => 1,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
        1 => 
        array (
          0 => 
          array (
            '_route' => 'admin.homepage-slides.store',
          ),
          1 => NULL,
          2 => 
          array (
            'POST' => 0,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      '/admin/homepage-slides/create' => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'admin.homepage-slides.create',
          ),
          1 => NULL,
          2 => 
          array (
            'GET' => 0,
            'HEAD' => 1,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      '/admin/products/stats' => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'admin.products.stats',
          ),
          1 => NULL,
          2 => 
          array (
            'GET' => 0,
            'HEAD' => 1,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      '/admin/products/search-suggestions' => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'admin.products.suggestions',
          ),
          1 => NULL,
          2 => 
          array (
            'GET' => 0,
            'HEAD' => 1,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      '/admin/products/bulk' => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'admin.products.bulk',
          ),
          1 => NULL,
          2 => 
          array (
            'POST' => 0,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      '/admin/products' => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'admin.products.index',
          ),
          1 => NULL,
          2 => 
          array (
            'GET' => 0,
            'HEAD' => 1,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
        1 => 
        array (
          0 => 
          array (
            '_route' => 'admin.products.store',
          ),
          1 => NULL,
          2 => 
          array (
            'POST' => 0,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      '/admin/products/create' => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'admin.products.create',
          ),
          1 => NULL,
          2 => 
          array (
            'GET' => 0,
            'HEAD' => 1,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      '/admin/categories/catalog-banner' => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'admin.categories.catalog-banner.update',
          ),
          1 => NULL,
          2 => 
          array (
            'PUT' => 0,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      '/admin/categories/bulk' => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'admin.categories.bulk',
          ),
          1 => NULL,
          2 => 
          array (
            'POST' => 0,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      '/admin/categories/export' => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'admin.categories.export',
          ),
          1 => NULL,
          2 => 
          array (
            'GET' => 0,
            'HEAD' => 1,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      '/admin/categories/import' => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'admin.categories.import',
          ),
          1 => NULL,
          2 => 
          array (
            'POST' => 0,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      '/admin/categories-ordering' => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'admin.categories.ordering',
          ),
          1 => NULL,
          2 => 
          array (
            'GET' => 0,
            'HEAD' => 1,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
        1 => 
        array (
          0 => 
          array (
            '_route' => 'admin.categories.ordering.update',
          ),
          1 => NULL,
          2 => 
          array (
            'PUT' => 0,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      '/admin/categories/products/sync-legacy' => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'admin.categories.products.sync-legacy',
          ),
          1 => NULL,
          2 => 
          array (
            'POST' => 0,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      '/admin/categories' => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'admin.categories.index',
          ),
          1 => NULL,
          2 => 
          array (
            'GET' => 0,
            'HEAD' => 1,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
        1 => 
        array (
          0 => 
          array (
            '_route' => 'admin.categories.store',
          ),
          1 => NULL,
          2 => 
          array (
            'POST' => 0,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      '/admin/categories/create' => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'admin.categories.create',
          ),
          1 => NULL,
          2 => 
          array (
            'GET' => 0,
            'HEAD' => 1,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      '/admin/attributes' => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'admin.attributes.index',
          ),
          1 => NULL,
          2 => 
          array (
            'GET' => 0,
            'HEAD' => 1,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
        1 => 
        array (
          0 => 
          array (
            '_route' => 'admin.attributes.store',
          ),
          1 => NULL,
          2 => 
          array (
            'POST' => 0,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      '/admin/attributes/create' => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'admin.attributes.create',
          ),
          1 => NULL,
          2 => 
          array (
            'GET' => 0,
            'HEAD' => 1,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      '/admin/jersey-customization-options' => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'admin.jersey-customization-options.index',
          ),
          1 => NULL,
          2 => 
          array (
            'GET' => 0,
            'HEAD' => 1,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
        1 => 
        array (
          0 => 
          array (
            '_route' => 'admin.jersey-customization-options.store',
          ),
          1 => NULL,
          2 => 
          array (
            'POST' => 0,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      '/admin/jersey-customization-options/create' => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'admin.jersey-customization-options.create',
          ),
          1 => NULL,
          2 => 
          array (
            'GET' => 0,
            'HEAD' => 1,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      '/admin/world-cup-customization-options' => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'admin.world-cup-customization-options.index',
          ),
          1 => NULL,
          2 => 
          array (
            'GET' => 0,
            'HEAD' => 1,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
        1 => 
        array (
          0 => 
          array (
            '_route' => 'admin.world-cup-customization-options.store',
          ),
          1 => NULL,
          2 => 
          array (
            'POST' => 0,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      '/admin/world-cup-customization-options/create' => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'admin.world-cup-customization-options.create',
          ),
          1 => NULL,
          2 => 
          array (
            'GET' => 0,
            'HEAD' => 1,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      '/admin/training-vest-customization-options/size-groups/create' => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'admin.training-vest-size-option-groups.create',
          ),
          1 => NULL,
          2 => 
          array (
            'GET' => 0,
            'HEAD' => 1,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      '/admin/training-vest-customization-options/size-groups' => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'admin.training-vest-size-option-groups.store',
          ),
          1 => NULL,
          2 => 
          array (
            'POST' => 0,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      '/admin/training-vest-customization-options' => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'admin.training-vest-customization-options.index',
          ),
          1 => NULL,
          2 => 
          array (
            'GET' => 0,
            'HEAD' => 1,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
        1 => 
        array (
          0 => 
          array (
            '_route' => 'admin.training-vest-customization-options.store',
          ),
          1 => NULL,
          2 => 
          array (
            'POST' => 0,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      '/admin/training-vest-customization-options/create' => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'admin.training-vest-customization-options.create',
          ),
          1 => NULL,
          2 => 
          array (
            'GET' => 0,
            'HEAD' => 1,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      '/admin/size-option-groups' => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'admin.size-option-groups.index',
          ),
          1 => NULL,
          2 => 
          array (
            'GET' => 0,
            'HEAD' => 1,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
        1 => 
        array (
          0 => 
          array (
            '_route' => 'admin.size-option-groups.store',
          ),
          1 => NULL,
          2 => 
          array (
            'POST' => 0,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      '/admin/size-option-groups/create' => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'admin.size-option-groups.create',
          ),
          1 => NULL,
          2 => 
          array (
            'GET' => 0,
            'HEAD' => 1,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      '/admin/menus' => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'admin.menus.index',
          ),
          1 => NULL,
          2 => 
          array (
            'GET' => 0,
            'HEAD' => 1,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
        1 => 
        array (
          0 => 
          array (
            '_route' => 'admin.menus.store',
          ),
          1 => NULL,
          2 => 
          array (
            'POST' => 0,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      '/admin/menus/create' => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'admin.menus.create',
          ),
          1 => NULL,
          2 => 
          array (
            'GET' => 0,
            'HEAD' => 1,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      '/admin/promotions/sales' => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'admin.promotions.sales.index',
          ),
          1 => NULL,
          2 => 
          array (
            'GET' => 0,
            'HEAD' => 1,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
        1 => 
        array (
          0 => 
          array (
            '_route' => 'admin.promotions.sales.store',
          ),
          1 => NULL,
          2 => 
          array (
            'POST' => 0,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      '/admin/promotions/sales/options' => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'admin.promotions.sales.options',
          ),
          1 => NULL,
          2 => 
          array (
            'GET' => 0,
            'HEAD' => 1,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      '/admin/promotions/sales/create' => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'admin.promotions.sales.create',
          ),
          1 => NULL,
          2 => 
          array (
            'GET' => 0,
            'HEAD' => 1,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      '/admin/promotions/banners' => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'admin.promotions.banners.index',
          ),
          1 => NULL,
          2 => 
          array (
            'GET' => 0,
            'HEAD' => 1,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
        1 => 
        array (
          0 => 
          array (
            '_route' => 'admin.promotions.banners.store',
          ),
          1 => NULL,
          2 => 
          array (
            'POST' => 0,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      '/admin/time-zones' => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'admin.time-zones.index',
          ),
          1 => NULL,
          2 => 
          array (
            'GET' => 0,
            'HEAD' => 1,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
        1 => 
        array (
          0 => 
          array (
            '_route' => 'admin.time-zones.store',
          ),
          1 => NULL,
          2 => 
          array (
            'POST' => 0,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      '/admin/time-zones/create' => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'admin.time-zones.create',
          ),
          1 => NULL,
          2 => 
          array (
            'GET' => 0,
            'HEAD' => 1,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      '/admin/coupons' => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'admin.coupons.index',
          ),
          1 => NULL,
          2 => 
          array (
            'GET' => 0,
            'HEAD' => 1,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
        1 => 
        array (
          0 => 
          array (
            '_route' => 'admin.coupons.store',
          ),
          1 => NULL,
          2 => 
          array (
            'POST' => 0,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      '/admin/coupons/create' => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'admin.coupons.create',
          ),
          1 => NULL,
          2 => 
          array (
            'GET' => 0,
            'HEAD' => 1,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      '/admin/rural-area-surcharges/import/start' => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'admin.rural-area-surcharges.import.start',
          ),
          1 => NULL,
          2 => 
          array (
            'POST' => 0,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      '/admin/rural-area-surcharges/import/chunk' => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'admin.rural-area-surcharges.import.chunk',
          ),
          1 => NULL,
          2 => 
          array (
            'POST' => 0,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      '/admin/rural-area-surcharges/import/finish' => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'admin.rural-area-surcharges.import.finish',
          ),
          1 => NULL,
          2 => 
          array (
            'POST' => 0,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      '/admin/rural-area-surcharges' => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'admin.rural-area-surcharges.index',
          ),
          1 => NULL,
          2 => 
          array (
            'GET' => 0,
            'HEAD' => 1,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
        1 => 
        array (
          0 => 
          array (
            '_route' => 'admin.rural-area-surcharges.store',
          ),
          1 => NULL,
          2 => 
          array (
            'POST' => 0,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      '/admin/rural-area-surcharges/create' => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'admin.rural-area-surcharges.create',
          ),
          1 => NULL,
          2 => 
          array (
            'GET' => 0,
            'HEAD' => 1,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      '/admin/production-methods' => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'admin.production-methods.index',
          ),
          1 => NULL,
          2 => 
          array (
            'GET' => 0,
            'HEAD' => 1,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
        1 => 
        array (
          0 => 
          array (
            '_route' => 'admin.production-methods.store',
          ),
          1 => NULL,
          2 => 
          array (
            'POST' => 0,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      '/admin/production-methods/create' => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'admin.production-methods.create',
          ),
          1 => NULL,
          2 => 
          array (
            'GET' => 0,
            'HEAD' => 1,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      '/admin/shipping-methods' => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'admin.shipping-methods.index',
          ),
          1 => NULL,
          2 => 
          array (
            'GET' => 0,
            'HEAD' => 1,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
        1 => 
        array (
          0 => 
          array (
            '_route' => 'admin.shipping-methods.store',
          ),
          1 => NULL,
          2 => 
          array (
            'POST' => 0,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      '/admin/shipping-methods/create' => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'admin.shipping-methods.create',
          ),
          1 => NULL,
          2 => 
          array (
            'GET' => 0,
            'HEAD' => 1,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      '/admin/holiday-calendars' => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'admin.holiday-calendars.index',
          ),
          1 => NULL,
          2 => 
          array (
            'GET' => 0,
            'HEAD' => 1,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
        1 => 
        array (
          0 => 
          array (
            '_route' => 'admin.holiday-calendars.store',
          ),
          1 => NULL,
          2 => 
          array (
            'POST' => 0,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      '/admin/holiday-calendars/create' => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'admin.holiday-calendars.create',
          ),
          1 => NULL,
          2 => 
          array (
            'GET' => 0,
            'HEAD' => 1,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      '/admin/faqs' => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'admin.faqs.index',
          ),
          1 => NULL,
          2 => 
          array (
            'GET' => 0,
            'HEAD' => 1,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
        1 => 
        array (
          0 => 
          array (
            '_route' => 'admin.faqs.store',
          ),
          1 => NULL,
          2 => 
          array (
            'POST' => 0,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      '/admin/faqs/create' => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'admin.faqs.create',
          ),
          1 => NULL,
          2 => 
          array (
            'GET' => 0,
            'HEAD' => 1,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      '/admin/genders' => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'admin.genders.index',
          ),
          1 => NULL,
          2 => 
          array (
            'GET' => 0,
            'HEAD' => 1,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
        1 => 
        array (
          0 => 
          array (
            '_route' => 'admin.genders.store',
          ),
          1 => NULL,
          2 => 
          array (
            'POST' => 0,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      '/admin/genders/create' => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'admin.genders.create',
          ),
          1 => NULL,
          2 => 
          array (
            'GET' => 0,
            'HEAD' => 1,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      '/admin/country-calling-codes/quick-store' => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'admin.country-calling-codes.quick-store',
          ),
          1 => NULL,
          2 => 
          array (
            'POST' => 0,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      '/admin/country-calling-codes' => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'admin.country-calling-codes.index',
          ),
          1 => NULL,
          2 => 
          array (
            'GET' => 0,
            'HEAD' => 1,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
        1 => 
        array (
          0 => 
          array (
            '_route' => 'admin.country-calling-codes.store',
          ),
          1 => NULL,
          2 => 
          array (
            'POST' => 0,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      '/admin/country-calling-codes/create' => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'admin.country-calling-codes.create',
          ),
          1 => NULL,
          2 => 
          array (
            'GET' => 0,
            'HEAD' => 1,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      '/admin/bulk-quote-budget-ranges' => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'admin.bulk-quote-budget-ranges.index',
          ),
          1 => NULL,
          2 => 
          array (
            'GET' => 0,
            'HEAD' => 1,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
        1 => 
        array (
          0 => 
          array (
            '_route' => 'admin.bulk-quote-budget-ranges.store',
          ),
          1 => NULL,
          2 => 
          array (
            'POST' => 0,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      '/admin/bulk-quote-budget-ranges/create' => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'admin.bulk-quote-budget-ranges.create',
          ),
          1 => NULL,
          2 => 
          array (
            'GET' => 0,
            'HEAD' => 1,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      '/admin/payment-methods' => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'admin.payment-methods.index',
          ),
          1 => NULL,
          2 => 
          array (
            'GET' => 0,
            'HEAD' => 1,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
        1 => 
        array (
          0 => 
          array (
            '_route' => 'admin.payment-methods.store',
          ),
          1 => NULL,
          2 => 
          array (
            'POST' => 0,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      '/admin/payment-methods/create' => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'admin.payment-methods.create',
          ),
          1 => NULL,
          2 => 
          array (
            'GET' => 0,
            'HEAD' => 1,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      '/admin/reward-program' => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'admin.reward-program.edit',
          ),
          1 => NULL,
          2 => 
          array (
            'GET' => 0,
            'HEAD' => 1,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
        1 => 
        array (
          0 => 
          array (
            '_route' => 'admin.reward-program.update',
          ),
          1 => NULL,
          2 => 
          array (
            'PUT' => 0,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      '/admin/customers' => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'admin.customers.index',
          ),
          1 => NULL,
          2 => 
          array (
            'GET' => 0,
            'HEAD' => 1,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      '/admin/users' => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'admin.users.index',
          ),
          1 => NULL,
          2 => 
          array (
            'GET' => 0,
            'HEAD' => 1,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
        1 => 
        array (
          0 => 
          array (
            '_route' => 'admin.users.store',
          ),
          1 => NULL,
          2 => 
          array (
            'POST' => 0,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      '/admin/role-matrix' => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'admin.role-matrix.index',
          ),
          1 => NULL,
          2 => 
          array (
            'GET' => 0,
            'HEAD' => 1,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
        1 => 
        array (
          0 => 
          array (
            '_route' => 'admin.role-matrix.update',
          ),
          1 => NULL,
          2 => 
          array (
            'POST' => 0,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      '/admin/role-matrix/roles' => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'admin.role-matrix.roles.store',
          ),
          1 => NULL,
          2 => 
          array (
            'POST' => 0,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      '/admin/bulk-quotes' => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'admin.bulk-quotes.index',
          ),
          1 => NULL,
          2 => 
          array (
            'GET' => 0,
            'HEAD' => 1,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      '/admin/artwork-approvals' => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'admin.artwork-approvals.index',
          ),
          1 => NULL,
          2 => 
          array (
            'GET' => 0,
            'HEAD' => 1,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      '/admin/orders' => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'admin.orders.index',
          ),
          1 => NULL,
          2 => 
          array (
            'GET' => 0,
            'HEAD' => 1,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      '/admin/returns' => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'admin.returns.index',
          ),
          1 => NULL,
          2 => 
          array (
            'GET' => 0,
            'HEAD' => 1,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      '/login' => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'login',
          ),
          1 => NULL,
          2 => 
          array (
            'GET' => 0,
            'HEAD' => 1,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
        1 => 
        array (
          0 => 
          array (
            '_route' => 'login.store',
          ),
          1 => NULL,
          2 => 
          array (
            'POST' => 0,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      '/register' => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'register',
          ),
          1 => NULL,
          2 => 
          array (
            'GET' => 0,
            'HEAD' => 1,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
        1 => 
        array (
          0 => 
          array (
            '_route' => 'register.store',
          ),
          1 => NULL,
          2 => 
          array (
            'POST' => 0,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      '/forgot-password' => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'password.request',
          ),
          1 => NULL,
          2 => 
          array (
            'GET' => 0,
            'HEAD' => 1,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
        1 => 
        array (
          0 => 
          array (
            '_route' => 'password.email',
          ),
          1 => NULL,
          2 => 
          array (
            'POST' => 0,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      '/reset-password' => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'password.store',
          ),
          1 => NULL,
          2 => 
          array (
            'POST' => 0,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      '/email/verify' => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'verification.notice',
          ),
          1 => NULL,
          2 => 
          array (
            'GET' => 0,
            'HEAD' => 1,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      '/email/verified' => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'verification.success',
          ),
          1 => NULL,
          2 => 
          array (
            'GET' => 0,
            'HEAD' => 1,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      '/email/verification-notification' => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'verification.send',
          ),
          1 => NULL,
          2 => 
          array (
            'POST' => 0,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      '/logout' => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'logout',
          ),
          1 => NULL,
          2 => 
          array (
            'POST' => 0,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      '/account' => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'account.dashboard',
          ),
          1 => NULL,
          2 => 
          array (
            'GET' => 0,
            'HEAD' => 1,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      '/account/rewards' => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'account.rewards',
          ),
          1 => NULL,
          2 => 
          array (
            'GET' => 0,
            'HEAD' => 1,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      '/account/refer-a-friend' => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'account.referrals',
          ),
          1 => NULL,
          2 => 
          array (
            'GET' => 0,
            'HEAD' => 1,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      '/account/profile' => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'account.profile.edit',
          ),
          1 => NULL,
          2 => 
          array (
            'GET' => 0,
            'HEAD' => 1,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
        1 => 
        array (
          0 => 
          array (
            '_route' => 'account.profile.update',
          ),
          1 => NULL,
          2 => 
          array (
            'PATCH' => 0,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      '/account/password' => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'account.password.update',
          ),
          1 => NULL,
          2 => 
          array (
            'PATCH' => 0,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      '/account/addresses' => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'account.addresses.index',
          ),
          1 => NULL,
          2 => 
          array (
            'GET' => 0,
            'HEAD' => 1,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
        1 => 
        array (
          0 => 
          array (
            '_route' => 'account.addresses.store',
          ),
          1 => NULL,
          2 => 
          array (
            'POST' => 0,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      '/account/payment-methods' => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'account.payment-methods.index',
          ),
          1 => NULL,
          2 => 
          array (
            'GET' => 0,
            'HEAD' => 1,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      '/account/bulk-quotes' => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'account.bulk-quotes.index',
          ),
          1 => NULL,
          2 => 
          array (
            'GET' => 0,
            'HEAD' => 1,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      '/account/artwork-approvals' => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'account.artwork.index',
          ),
          1 => NULL,
          2 => 
          array (
            'GET' => 0,
            'HEAD' => 1,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      '/account/orders' => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'account.orders.dashboard',
          ),
          1 => NULL,
          2 => 
          array (
            'GET' => 0,
            'HEAD' => 1,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      '/account/orders/history' => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'account.orders.index',
          ),
          1 => NULL,
          2 => 
          array (
            'GET' => 0,
            'HEAD' => 1,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      '/account/returns' => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'account.returns.index',
          ),
          1 => NULL,
          2 => 
          array (
            'GET' => 0,
            'HEAD' => 1,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      '/account/order-downloads' => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'account.downloads.index',
          ),
          1 => NULL,
          2 => 
          array (
            'GET' => 0,
            'HEAD' => 1,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      '/categories' => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'categories.index',
          ),
          1 => NULL,
          2 => 
          array (
            'GET' => 0,
            'HEAD' => 1,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      '/sale' => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'sale.index',
          ),
          1 => NULL,
          2 => 
          array (
            'GET' => 0,
            'HEAD' => 1,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      '/products' => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'products.index',
          ),
          1 => NULL,
          2 => 
          array (
            'GET' => 0,
            'HEAD' => 1,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      '/products/search-suggestions' => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'products.suggestions',
          ),
          1 => NULL,
          2 => 
          array (
            'GET' => 0,
            'HEAD' => 1,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      '/wishlist' => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'wishlist.index',
          ),
          1 => NULL,
          2 => 
          array (
            'GET' => 0,
            'HEAD' => 1,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      '/wishlist/guest-products' => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'wishlist.guest-products',
          ),
          1 => NULL,
          2 => 
          array (
            'POST' => 0,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      '/wishlist/status' => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'wishlist.status',
          ),
          1 => NULL,
          2 => 
          array (
            'GET' => 0,
            'HEAD' => 1,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      '/wishlist/preview' => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'wishlist.preview',
          ),
          1 => NULL,
          2 => 
          array (
            'GET' => 0,
            'HEAD' => 1,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      '/quote-request' => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'generated::mQEEzSBaNqo3s8MN',
          ),
          1 => NULL,
          2 => 
          array (
            'GET' => 0,
            'HEAD' => 1,
            'POST' => 2,
            'PUT' => 3,
            'PATCH' => 4,
            'DELETE' => 5,
            'OPTIONS' => 6,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      '/cart' => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'cart.index',
          ),
          1 => NULL,
          2 => 
          array (
            'GET' => 0,
            'HEAD' => 1,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      '/cart/items' => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'cart.items.store',
          ),
          1 => NULL,
          2 => 
          array (
            'POST' => 0,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      '/cart/coupon' => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'cart.coupon.apply',
          ),
          1 => NULL,
          2 => 
          array (
            'POST' => 0,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
        1 => 
        array (
          0 => 
          array (
            '_route' => 'cart.coupon.destroy',
          ),
          1 => NULL,
          2 => 
          array (
            'DELETE' => 0,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      '/cart/rewards' => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'cart.rewards.apply',
          ),
          1 => NULL,
          2 => 
          array (
            'POST' => 0,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
        1 => 
        array (
          0 => 
          array (
            '_route' => 'cart.rewards.destroy',
          ),
          1 => NULL,
          2 => 
          array (
            'DELETE' => 0,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      '/order-confirmation' => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'order.confirmation',
          ),
          1 => NULL,
          2 => 
          array (
            'GET' => 0,
            'HEAD' => 1,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      '/payment/success' => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'payment.success',
          ),
          1 => NULL,
          2 => 
          array (
            'GET' => 0,
            'HEAD' => 1,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      '/payment/failed' => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'payment.failed',
          ),
          1 => NULL,
          2 => 
          array (
            'GET' => 0,
            'HEAD' => 1,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      '/order-details' => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'orders.details.legacy',
          ),
          1 => NULL,
          2 => 
          array (
            'GET' => 0,
            'HEAD' => 1,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      '/track-order' => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'orders.track',
          ),
          1 => NULL,
          2 => 
          array (
            'GET' => 0,
            'HEAD' => 1,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
        1 => 
        array (
          0 => 
          array (
            '_route' => 'orders.track.lookup',
          ),
          1 => NULL,
          2 => 
          array (
            'POST' => 0,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      '/invoice-download' => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'orders.invoice.legacy',
          ),
          1 => NULL,
          2 => 
          array (
            'GET' => 0,
            'HEAD' => 1,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      '/checkout/referral' => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'checkout.referral',
          ),
          1 => NULL,
          2 => 
          array (
            'GET' => 0,
            'HEAD' => 1,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
        1 => 
        array (
          0 => 
          array (
            '_route' => 'checkout.referral.store',
          ),
          1 => NULL,
          2 => 
          array (
            'POST' => 0,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      '/checkout' => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'checkout.index',
          ),
          1 => NULL,
          2 => 
          array (
            'GET' => 0,
            'HEAD' => 1,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      '/checkout/information' => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'checkout.information',
          ),
          1 => NULL,
          2 => 
          array (
            'GET' => 0,
            'HEAD' => 1,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
        1 => 
        array (
          0 => 
          array (
            '_route' => 'checkout.information.store',
          ),
          1 => NULL,
          2 => 
          array (
            'POST' => 0,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      '/checkout/shipping-address' => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'checkout.shipping-address',
          ),
          1 => NULL,
          2 => 
          array (
            'GET' => 0,
            'HEAD' => 1,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
        1 => 
        array (
          0 => 
          array (
            '_route' => 'checkout.shipping-address.store',
          ),
          1 => NULL,
          2 => 
          array (
            'POST' => 0,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      '/checkout/billing-address' => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'checkout.billing-address',
          ),
          1 => NULL,
          2 => 
          array (
            'GET' => 0,
            'HEAD' => 1,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
        1 => 
        array (
          0 => 
          array (
            '_route' => 'checkout.billing-address.store',
          ),
          1 => NULL,
          2 => 
          array (
            'POST' => 0,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      '/checkout/shipping-method' => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'checkout.shipping-method',
          ),
          1 => NULL,
          2 => 
          array (
            'GET' => 0,
            'HEAD' => 1,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
        1 => 
        array (
          0 => 
          array (
            '_route' => 'checkout.shipping-method.store',
          ),
          1 => NULL,
          2 => 
          array (
            'POST' => 0,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      '/checkout/payment-method' => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'checkout.payment-method',
          ),
          1 => NULL,
          2 => 
          array (
            'GET' => 0,
            'HEAD' => 1,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
        1 => 
        array (
          0 => 
          array (
            '_route' => 'checkout.payment-method.store',
          ),
          1 => NULL,
          2 => 
          array (
            'POST' => 0,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      '/checkout/review' => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'checkout.review',
          ),
          1 => NULL,
          2 => 
          array (
            'GET' => 0,
            'HEAD' => 1,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
        1 => 
        array (
          0 => 
          array (
            '_route' => 'checkout.review.store',
          ),
          1 => NULL,
          2 => 
          array (
            'POST' => 0,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      '/checkout/place-order' => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'checkout.place-order',
          ),
          1 => NULL,
          2 => 
          array (
            'GET' => 0,
            'HEAD' => 1,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
        1 => 
        array (
          0 => 
          array (
            '_route' => 'checkout.place-order.submit',
          ),
          1 => NULL,
          2 => 
          array (
            'POST' => 0,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      '/checkout/success' => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'checkout.success',
          ),
          1 => NULL,
          2 => 
          array (
            'GET' => 0,
            'HEAD' => 1,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
    ),
    2 => 
    array (
      0 => '{^(?|/a(?|pi/integrations/flowtrack/(?|order(?|s/([A-Za-z0-9_-]+)/progress(*:76)|\\-items/([0-9]+)/artworks/([0-9]+)(*:117))|bulk\\-quotes/(?|([0-9]+)/files/([0-9]+)(*:165)|([0-9]+)/attachment(*:192)|([0-9]+)/published\\-files/([0-9]+)(*:234)|([0-9]+)/offer\\-files(*:263)|([0-9]+)/messages(*:288)|([0-9]+)/task\\-progress(*:319))|catalog/(?|c(?|ategories/([0-9]+)(*:361)|ustomers/([0-9]+)(?|(*:389)))|products/([0-9]+)(?|(*:419)))|artwork\\-proofs/(?|([0-9]+)/staff\\-messages(*:472)|([0-9]+)/reference(*:498)))|dmin/(?|notifications/([^/]++)/read(*:543)|m(?|e(?|dia\\-library/([^/]++)(?|(*:583)|/(?|download(*:603)|preview(*:618)))|nus/([^/]++)(?|/edit(*:648)|(*:656)))|odule/(orders|inventory|discounts|content|shipping|payments)(*:726))|email\\-customization/templates/([^/]++)(?|/(?|edit(*:785)|duplicate(*:802)|visibility(?|(*:823))|preview(*:839)|send\\-test(*:857))|(*:866))|ho(?|mepage(?|/sections/([^/]++)(?|(*:910))|\\-slides/([^/]++)(?|/(?|toggle(*:949)|edit(*:961))|(*:970)))|liday\\-calendars/([^/]++)(?|/(?|toggle\\-status(*:1026)|edit(*:1039))|(*:1049)))|p(?|ro(?|duct(?|s/([^/]++)(?|/(?|duplicate(*:1102)|edit(*:1115))|(*:1125))|ion\\-methods/([^/]++)(?|/edit(*:1164)|(*:1173)))|motions/(?|sales/([^/]++)(?|/edit(*:1217)|(*:1226))|banners/(?|([^/]++)(?|(*:1258))|reorder(*:1275))))|ayment\\-methods/([^/]++)(?|/edit(*:1319)|(*:1328)))|c(?|ategories/([^/]++)(?|/(?|duplicate(*:1377)|products(?|(*:1397)|/([^/]++)(*:1415))|edit(*:1429))|(*:1439))|ou(?|pons/([^/]++)(?|/edit(*:1475)|(*:1484))|ntry\\-calling\\-codes/([^/]++)(?|/edit(*:1531)|(*:1540)))|ustomers/([^/]++)(?|(*:1571)|/(?|suspend(*:1591)|re(?|activate(*:1613)|wards(?|(*:1630))))))|a(?|ttributes/([^/]++)(?|/edit(*:1674)|(*:1683))|rtwork\\-preferences/([^/]++)(?|(*:1724)|/(?|create(*:1743)|([^/]++)(?|/edit(*:1768)|(*:1777)))|(*:1788)))|jersey\\-customization\\-options/(?|type/([^/]++)(?|(*:1849)|/import\\-fabrics(*:1874))|([^/]++)(?|/edit(*:1900)|(*:1909)))|world\\-cup\\-customization\\-options/(?|type/([^/]++)(*:1971)|([^/]++)(?|/edit(*:1996)|(*:2005)))|t(?|raining\\-vest\\-customization\\-options/(?|type/([^/]++)(*:2074)|size\\-groups/([^/]++)(?|/edit(*:2112)|(*:2121))|([^/]++)(?|/edit(*:2147)|(*:2156)))|ime\\-zones/([^/]++)(?|/edit(*:2194)|(*:2203)))|s(?|ize\\-option\\-groups/([^/]++)(?|/edit(*:2254)|(*:2263))|hipping\\-methods/([^/]++)(?|/edit(*:2306)|(*:2315)))|r(?|ural\\-area\\-surcharges/([^/]++)(?|/edit(*:2369)|(*:2378))|eturns/([^/]++)(?|(*:2406)|/attachments/([^/]++)(*:2436)|(*:2445)))|faqs/([^/]++)(?|/edit(*:2477)|(*:2486))|genders/([^/]++)(?|/edit(*:2520)|(*:2529))|bulk\\-quote(?|\\-budget\\-ranges/([^/]++)(?|/edit(*:2586)|(*:2595))|s/([^/]++)(?|(*:2618)|/(?|attachment(*:2641)|retry\\-sync(*:2661)|publish(*:2677)|message(*:2693)|file/([^/]++)(*:2715))|(*:2725)))|users/([^/]++)(*:2750)|orders/([^/]++)(?|(*:2777)|/(?|a(?|rtwork\\-proofs(?|(*:2811)|/([^/]++)/(?|file(*:2837)|reply(*:2851)))|pprove(*:2868))|items/([^/]++)/artwork/([0-9]+)(*:2909)|re(?|try\\-sync(*:2932)|quests/([^/]++)(*:2956))|shipments(?|(*:2978)|/([^/]++)(*:2996))|downloads(?|(*:3018)|/([^/]++)(*:3036)))|(*:3047)))|ccount/(?|a(?|ddresses/([^/]++)(?|/default(*:3100)|(*:3109))|rtwork\\-approvals/([^/]++)(?|(*:3148)|/(?|re(?|quest\\-changes(?|(*:3183))|ject(*:3197))|approve(?|(*:3217)|d(*:3227))|message(*:3244)|file(*:3257))))|payment\\-methods/([^/]++)(?|/default(*:3305)|(*:3314))|bulk\\-quotes/([^/]++)(?|(*:3348)|/(?|changes(?|(*:3371))|message(*:3388)|decision(*:3405)|file/([^/]++)(*:3427)))|order(?|s/([^/]++)(?|(*:3459)|/(?|pay(?|(*:3478))|re(?|t(?|ry\\-payment(*:3508)|urn\\-request(?|(*:3532)))|order(?|(*:3551)))|c(?|ancel\\-request(?|(*:3583))|hange\\-request(?|(*:3610)))|shipments(?|(*:3633)|/([^/]++)(*:3651))|invoice(?|(*:3671)|/download(*:3689))|exchange\\-request(?|(*:3719))))|\\-downloads/([^/]++)(*:3751))|re(?|turn(?|s/([^/]++)(*:3783)|\\-attachments/([^/]++)(*:3814))|funds/([^/]++)(*:3838))|credit\\-notes/([^/]++)(?|(*:3873)|/download(*:3891))))|/p(?|ayments/([a-z0-9-]+)/return(*:3935)|roduct(?|/([^/]++)(*:3962)|s/([^/]++)(*:3981)))|/re(?|ferral/([A-Za-z0-9_-]+)(*:4021)|set\\-password/([^/]++)(*:4052))|/media/(.*)(*:4073)|/bulk\\-quote/track/([^/]++)(?|/(?|submitted(*:4125)|review(*:4140)|changes(?|(*:4159))|message(*:4176)|decision(*:4193)|file/([^/]++)(*:4215))|(*:4225))|/email/verify/([^/]++)/([^/]++)(*:4266)|/ca(?|tegory/([a-z0-9-]+)(*:4300)|rt/items/([^/]++)(?|/(?|artwork/([0-9]+)(*:4349)|options(*:4365))|(*:4375)))|/wishlist/products/([^/]++)(*:4413)|/orders/([A-Za-z0-9\\-]+)(*:4446)|/invoice/([A-Za-z0-9\\-]+)(*:4480)|/storage/(.*)(?|(*:4505)))/?$}sDu',
    ),
    3 => 
    array (
      76 => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'api.flowtrack.orders.progress',
          ),
          1 => 
          array (
            0 => 'orderNumber',
          ),
          2 => 
          array (
            'POST' => 0,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      117 => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'api.flowtrack.order-items.artwork',
          ),
          1 => 
          array (
            0 => 'orderItem',
            1 => 'index',
          ),
          2 => 
          array (
            'GET' => 0,
            'HEAD' => 1,
          ),
          3 => NULL,
          4 => false,
          5 => true,
          6 => NULL,
        ),
      ),
      165 => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'generated::gEtRTxrt7DdU7kQJ',
          ),
          1 => 
          array (
            0 => 'bulkQuote',
            1 => 'file',
          ),
          2 => 
          array (
            'GET' => 0,
            'HEAD' => 1,
          ),
          3 => NULL,
          4 => false,
          5 => true,
          6 => NULL,
        ),
      ),
      192 => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'api.flowtrack.bulk-quotes.attachment',
          ),
          1 => 
          array (
            0 => 'bulkQuote',
          ),
          2 => 
          array (
            'GET' => 0,
            'HEAD' => 1,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      234 => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'generated::LpQ2d8y9QrkrRqkI',
          ),
          1 => 
          array (
            0 => 'bulkQuote',
            1 => 'file',
          ),
          2 => 
          array (
            'GET' => 0,
            'HEAD' => 1,
          ),
          3 => NULL,
          4 => false,
          5 => true,
          6 => NULL,
        ),
      ),
      263 => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'generated::VuURQLff21tJV6Bk',
          ),
          1 => 
          array (
            0 => 'bulkQuote',
          ),
          2 => 
          array (
            'POST' => 0,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      288 => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'generated::DTaiTlPqGfxOKjlX',
          ),
          1 => 
          array (
            0 => 'bulkQuote',
          ),
          2 => 
          array (
            'POST' => 0,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      319 => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'generated::x3R9lrUkk6iBK7gu',
          ),
          1 => 
          array (
            0 => 'bulkQuote',
          ),
          2 => 
          array (
            'POST' => 0,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      361 => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'generated::Swg5sa95Z3Ny49v2',
          ),
          1 => 
          array (
            0 => 'category',
          ),
          2 => 
          array (
            'GET' => 0,
            'HEAD' => 1,
          ),
          3 => NULL,
          4 => false,
          5 => true,
          6 => NULL,
        ),
      ),
      389 => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'generated::A9T2taTTamixz4KR',
          ),
          1 => 
          array (
            0 => 'customer',
          ),
          2 => 
          array (
            'GET' => 0,
            'HEAD' => 1,
          ),
          3 => NULL,
          4 => false,
          5 => true,
          6 => NULL,
        ),
        1 => 
        array (
          0 => 
          array (
            '_route' => 'generated::UM3RBzwEqKTNk7v5',
          ),
          1 => 
          array (
            0 => 'customer',
          ),
          2 => 
          array (
            'PATCH' => 0,
          ),
          3 => NULL,
          4 => false,
          5 => true,
          6 => NULL,
        ),
      ),
      419 => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'generated::jGRFZxaGnvsJtawz',
          ),
          1 => 
          array (
            0 => 'product',
          ),
          2 => 
          array (
            'GET' => 0,
            'HEAD' => 1,
          ),
          3 => NULL,
          4 => false,
          5 => true,
          6 => NULL,
        ),
        1 => 
        array (
          0 => 
          array (
            '_route' => 'generated::mW4YFZQEtrH1g5yu',
          ),
          1 => 
          array (
            0 => 'product',
          ),
          2 => 
          array (
            'PATCH' => 0,
          ),
          3 => NULL,
          4 => false,
          5 => true,
          6 => NULL,
        ),
      ),
      472 => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'generated::bCEB4smdpaTJtoOA',
          ),
          1 => 
          array (
            0 => 'proof',
          ),
          2 => 
          array (
            'POST' => 0,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      498 => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'generated::7OGEanJY1gzFn4LR',
          ),
          1 => 
          array (
            0 => 'proof',
          ),
          2 => 
          array (
            'GET' => 0,
            'HEAD' => 1,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      543 => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'admin.notifications.read',
          ),
          1 => 
          array (
            0 => 'notification',
          ),
          2 => 
          array (
            'POST' => 0,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      583 => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'admin.media-library.update',
          ),
          1 => 
          array (
            0 => 'media',
          ),
          2 => 
          array (
            'PATCH' => 0,
          ),
          3 => NULL,
          4 => false,
          5 => true,
          6 => NULL,
        ),
        1 => 
        array (
          0 => 
          array (
            '_route' => 'admin.media-library.destroy',
          ),
          1 => 
          array (
            0 => 'media',
          ),
          2 => 
          array (
            'DELETE' => 0,
          ),
          3 => NULL,
          4 => false,
          5 => true,
          6 => NULL,
        ),
      ),
      603 => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'admin.media-library.download',
          ),
          1 => 
          array (
            0 => 'media',
          ),
          2 => 
          array (
            'GET' => 0,
            'HEAD' => 1,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      618 => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'admin.media-library.preview',
          ),
          1 => 
          array (
            0 => 'media',
          ),
          2 => 
          array (
            'GET' => 0,
            'HEAD' => 1,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      648 => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'admin.menus.edit',
          ),
          1 => 
          array (
            0 => 'menu',
          ),
          2 => 
          array (
            'GET' => 0,
            'HEAD' => 1,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      656 => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'admin.menus.update',
          ),
          1 => 
          array (
            0 => 'menu',
          ),
          2 => 
          array (
            'PUT' => 0,
            'PATCH' => 1,
          ),
          3 => NULL,
          4 => false,
          5 => true,
          6 => NULL,
        ),
        1 => 
        array (
          0 => 
          array (
            '_route' => 'admin.menus.destroy',
          ),
          1 => 
          array (
            0 => 'menu',
          ),
          2 => 
          array (
            'DELETE' => 0,
          ),
          3 => NULL,
          4 => false,
          5 => true,
          6 => NULL,
        ),
      ),
      726 => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'admin.modules.show',
          ),
          1 => 
          array (
            0 => 'module',
          ),
          2 => 
          array (
            'GET' => 0,
            'HEAD' => 1,
          ),
          3 => NULL,
          4 => false,
          5 => true,
          6 => NULL,
        ),
      ),
      785 => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'admin.email-customization.templates.edit',
          ),
          1 => 
          array (
            0 => 'template',
          ),
          2 => 
          array (
            'GET' => 0,
            'HEAD' => 1,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      802 => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'admin.email-customization.templates.duplicate',
          ),
          1 => 
          array (
            0 => 'template',
          ),
          2 => 
          array (
            'POST' => 0,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      823 => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'admin.email-customization.templates.visibility',
          ),
          1 => 
          array (
            0 => 'template',
          ),
          2 => 
          array (
            'GET' => 0,
            'HEAD' => 1,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
        1 => 
        array (
          0 => 
          array (
            '_route' => 'admin.email-customization.templates.visibility.update',
          ),
          1 => 
          array (
            0 => 'template',
          ),
          2 => 
          array (
            'PUT' => 0,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      839 => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'admin.email-customization.templates.preview',
          ),
          1 => 
          array (
            0 => 'template',
          ),
          2 => 
          array (
            'GET' => 0,
            'HEAD' => 1,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      857 => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'admin.email-customization.templates.send-test',
          ),
          1 => 
          array (
            0 => 'template',
          ),
          2 => 
          array (
            'POST' => 0,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      866 => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'admin.email-customization.templates.update',
          ),
          1 => 
          array (
            0 => 'template',
          ),
          2 => 
          array (
            'PUT' => 0,
          ),
          3 => NULL,
          4 => false,
          5 => true,
          6 => NULL,
        ),
        1 => 
        array (
          0 => 
          array (
            '_route' => 'admin.email-customization.templates.destroy',
          ),
          1 => 
          array (
            0 => 'template',
          ),
          2 => 
          array (
            'DELETE' => 0,
          ),
          3 => NULL,
          4 => false,
          5 => true,
          6 => NULL,
        ),
      ),
      910 => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'admin.homepage.sections.edit',
          ),
          1 => 
          array (
            0 => 'key',
          ),
          2 => 
          array (
            'GET' => 0,
            'HEAD' => 1,
          ),
          3 => NULL,
          4 => false,
          5 => true,
          6 => NULL,
        ),
        1 => 
        array (
          0 => 
          array (
            '_route' => 'admin.homepage.sections.update',
          ),
          1 => 
          array (
            0 => 'key',
          ),
          2 => 
          array (
            'PATCH' => 0,
          ),
          3 => NULL,
          4 => false,
          5 => true,
          6 => NULL,
        ),
      ),
      949 => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'admin.homepage-slides.toggle',
          ),
          1 => 
          array (
            0 => 'homepageSlide',
          ),
          2 => 
          array (
            'PATCH' => 0,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      961 => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'admin.homepage-slides.edit',
          ),
          1 => 
          array (
            0 => 'homepage_slide',
          ),
          2 => 
          array (
            'GET' => 0,
            'HEAD' => 1,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      970 => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'admin.homepage-slides.update',
          ),
          1 => 
          array (
            0 => 'homepage_slide',
          ),
          2 => 
          array (
            'PUT' => 0,
            'PATCH' => 1,
          ),
          3 => NULL,
          4 => false,
          5 => true,
          6 => NULL,
        ),
        1 => 
        array (
          0 => 
          array (
            '_route' => 'admin.homepage-slides.destroy',
          ),
          1 => 
          array (
            0 => 'homepage_slide',
          ),
          2 => 
          array (
            'DELETE' => 0,
          ),
          3 => NULL,
          4 => false,
          5 => true,
          6 => NULL,
        ),
      ),
      1026 => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'admin.holiday-calendars.toggle-status',
          ),
          1 => 
          array (
            0 => 'holidayCalendar',
          ),
          2 => 
          array (
            'PATCH' => 0,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      1039 => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'admin.holiday-calendars.edit',
          ),
          1 => 
          array (
            0 => 'holidayCalendar',
          ),
          2 => 
          array (
            'GET' => 0,
            'HEAD' => 1,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      1049 => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'admin.holiday-calendars.show',
          ),
          1 => 
          array (
            0 => 'holidayCalendar',
          ),
          2 => 
          array (
            'GET' => 0,
            'HEAD' => 1,
          ),
          3 => NULL,
          4 => false,
          5 => true,
          6 => NULL,
        ),
        1 => 
        array (
          0 => 
          array (
            '_route' => 'admin.holiday-calendars.update',
          ),
          1 => 
          array (
            0 => 'holidayCalendar',
          ),
          2 => 
          array (
            'PUT' => 0,
            'PATCH' => 1,
          ),
          3 => NULL,
          4 => false,
          5 => true,
          6 => NULL,
        ),
        2 => 
        array (
          0 => 
          array (
            '_route' => 'admin.holiday-calendars.destroy',
          ),
          1 => 
          array (
            0 => 'holidayCalendar',
          ),
          2 => 
          array (
            'DELETE' => 0,
          ),
          3 => NULL,
          4 => false,
          5 => true,
          6 => NULL,
        ),
      ),
      1102 => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'admin.products.duplicate',
          ),
          1 => 
          array (
            0 => 'product',
          ),
          2 => 
          array (
            'POST' => 0,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      1115 => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'admin.products.edit',
          ),
          1 => 
          array (
            0 => 'product',
          ),
          2 => 
          array (
            'GET' => 0,
            'HEAD' => 1,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      1125 => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'admin.products.show',
          ),
          1 => 
          array (
            0 => 'product',
          ),
          2 => 
          array (
            'GET' => 0,
            'HEAD' => 1,
          ),
          3 => NULL,
          4 => false,
          5 => true,
          6 => NULL,
        ),
        1 => 
        array (
          0 => 
          array (
            '_route' => 'admin.products.update',
          ),
          1 => 
          array (
            0 => 'product',
          ),
          2 => 
          array (
            'PUT' => 0,
            'PATCH' => 1,
          ),
          3 => NULL,
          4 => false,
          5 => true,
          6 => NULL,
        ),
        2 => 
        array (
          0 => 
          array (
            '_route' => 'admin.products.destroy',
          ),
          1 => 
          array (
            0 => 'product',
          ),
          2 => 
          array (
            'DELETE' => 0,
          ),
          3 => NULL,
          4 => false,
          5 => true,
          6 => NULL,
        ),
      ),
      1164 => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'admin.production-methods.edit',
          ),
          1 => 
          array (
            0 => 'productionMethod',
          ),
          2 => 
          array (
            'GET' => 0,
            'HEAD' => 1,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      1173 => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'admin.production-methods.update',
          ),
          1 => 
          array (
            0 => 'productionMethod',
          ),
          2 => 
          array (
            'PUT' => 0,
            'PATCH' => 1,
          ),
          3 => NULL,
          4 => false,
          5 => true,
          6 => NULL,
        ),
        1 => 
        array (
          0 => 
          array (
            '_route' => 'admin.production-methods.destroy',
          ),
          1 => 
          array (
            0 => 'productionMethod',
          ),
          2 => 
          array (
            'DELETE' => 0,
          ),
          3 => NULL,
          4 => false,
          5 => true,
          6 => NULL,
        ),
      ),
      1217 => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'admin.promotions.sales.edit',
          ),
          1 => 
          array (
            0 => 'saleCampaign',
          ),
          2 => 
          array (
            'GET' => 0,
            'HEAD' => 1,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      1226 => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'admin.promotions.sales.update',
          ),
          1 => 
          array (
            0 => 'saleCampaign',
          ),
          2 => 
          array (
            'PUT' => 0,
          ),
          3 => NULL,
          4 => false,
          5 => true,
          6 => NULL,
        ),
      ),
      1258 => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'admin.promotions.banners.update',
          ),
          1 => 
          array (
            0 => 'saleBanner',
          ),
          2 => 
          array (
            'PUT' => 0,
          ),
          3 => NULL,
          4 => false,
          5 => true,
          6 => NULL,
        ),
        1 => 
        array (
          0 => 
          array (
            '_route' => 'admin.promotions.banners.destroy',
          ),
          1 => 
          array (
            0 => 'saleBanner',
          ),
          2 => 
          array (
            'DELETE' => 0,
          ),
          3 => NULL,
          4 => false,
          5 => true,
          6 => NULL,
        ),
      ),
      1275 => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'admin.promotions.banners.reorder',
          ),
          1 => 
          array (
          ),
          2 => 
          array (
            'POST' => 0,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      1319 => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'admin.payment-methods.edit',
          ),
          1 => 
          array (
            0 => 'paymentMethod',
          ),
          2 => 
          array (
            'GET' => 0,
            'HEAD' => 1,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      1328 => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'admin.payment-methods.update',
          ),
          1 => 
          array (
            0 => 'paymentMethod',
          ),
          2 => 
          array (
            'PUT' => 0,
            'PATCH' => 1,
          ),
          3 => NULL,
          4 => false,
          5 => true,
          6 => NULL,
        ),
        1 => 
        array (
          0 => 
          array (
            '_route' => 'admin.payment-methods.destroy',
          ),
          1 => 
          array (
            0 => 'paymentMethod',
          ),
          2 => 
          array (
            'DELETE' => 0,
          ),
          3 => NULL,
          4 => false,
          5 => true,
          6 => NULL,
        ),
      ),
      1377 => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'admin.categories.duplicate',
          ),
          1 => 
          array (
            0 => 'category',
          ),
          2 => 
          array (
            'POST' => 0,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      1397 => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'admin.categories.products.index',
          ),
          1 => 
          array (
            0 => 'category',
          ),
          2 => 
          array (
            'GET' => 0,
            'HEAD' => 1,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
        1 => 
        array (
          0 => 
          array (
            '_route' => 'admin.categories.products.update',
          ),
          1 => 
          array (
            0 => 'category',
          ),
          2 => 
          array (
            'PUT' => 0,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      1415 => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'admin.categories.products.destroy',
          ),
          1 => 
          array (
            0 => 'category',
            1 => 'product',
          ),
          2 => 
          array (
            'DELETE' => 0,
          ),
          3 => NULL,
          4 => false,
          5 => true,
          6 => NULL,
        ),
      ),
      1429 => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'admin.categories.edit',
          ),
          1 => 
          array (
            0 => 'category',
          ),
          2 => 
          array (
            'GET' => 0,
            'HEAD' => 1,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      1439 => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'admin.categories.update',
          ),
          1 => 
          array (
            0 => 'category',
          ),
          2 => 
          array (
            'PUT' => 0,
            'PATCH' => 1,
          ),
          3 => NULL,
          4 => false,
          5 => true,
          6 => NULL,
        ),
        1 => 
        array (
          0 => 
          array (
            '_route' => 'admin.categories.destroy',
          ),
          1 => 
          array (
            0 => 'category',
          ),
          2 => 
          array (
            'DELETE' => 0,
          ),
          3 => NULL,
          4 => false,
          5 => true,
          6 => NULL,
        ),
      ),
      1475 => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'admin.coupons.edit',
          ),
          1 => 
          array (
            0 => 'coupon',
          ),
          2 => 
          array (
            'GET' => 0,
            'HEAD' => 1,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      1484 => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'admin.coupons.update',
          ),
          1 => 
          array (
            0 => 'coupon',
          ),
          2 => 
          array (
            'PUT' => 0,
            'PATCH' => 1,
          ),
          3 => NULL,
          4 => false,
          5 => true,
          6 => NULL,
        ),
        1 => 
        array (
          0 => 
          array (
            '_route' => 'admin.coupons.destroy',
          ),
          1 => 
          array (
            0 => 'coupon',
          ),
          2 => 
          array (
            'DELETE' => 0,
          ),
          3 => NULL,
          4 => false,
          5 => true,
          6 => NULL,
        ),
      ),
      1531 => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'admin.country-calling-codes.edit',
          ),
          1 => 
          array (
            0 => 'countryCallingCode',
          ),
          2 => 
          array (
            'GET' => 0,
            'HEAD' => 1,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      1540 => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'admin.country-calling-codes.update',
          ),
          1 => 
          array (
            0 => 'countryCallingCode',
          ),
          2 => 
          array (
            'PUT' => 0,
            'PATCH' => 1,
          ),
          3 => NULL,
          4 => false,
          5 => true,
          6 => NULL,
        ),
        1 => 
        array (
          0 => 
          array (
            '_route' => 'admin.country-calling-codes.destroy',
          ),
          1 => 
          array (
            0 => 'countryCallingCode',
          ),
          2 => 
          array (
            'DELETE' => 0,
          ),
          3 => NULL,
          4 => false,
          5 => true,
          6 => NULL,
        ),
      ),
      1571 => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'admin.customers.show',
          ),
          1 => 
          array (
            0 => 'customer',
          ),
          2 => 
          array (
            'GET' => 0,
            'HEAD' => 1,
          ),
          3 => NULL,
          4 => false,
          5 => true,
          6 => NULL,
        ),
      ),
      1591 => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'admin.customers.suspend',
          ),
          1 => 
          array (
            0 => 'customer',
          ),
          2 => 
          array (
            'PATCH' => 0,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      1613 => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'admin.customers.reactivate',
          ),
          1 => 
          array (
            0 => 'customer',
          ),
          2 => 
          array (
            'PATCH' => 0,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      1630 => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'admin.customers.rewards.update',
          ),
          1 => 
          array (
            0 => 'customer',
          ),
          2 => 
          array (
            'PATCH' => 0,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
        1 => 
        array (
          0 => 
          array (
            '_route' => 'admin.customers.rewards.store',
          ),
          1 => 
          array (
            0 => 'customer',
          ),
          2 => 
          array (
            'POST' => 0,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      1674 => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'admin.attributes.edit',
          ),
          1 => 
          array (
            0 => 'attribute',
          ),
          2 => 
          array (
            'GET' => 0,
            'HEAD' => 1,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      1683 => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'admin.attributes.update',
          ),
          1 => 
          array (
            0 => 'attribute',
          ),
          2 => 
          array (
            'PUT' => 0,
            'PATCH' => 1,
          ),
          3 => NULL,
          4 => false,
          5 => true,
          6 => NULL,
        ),
        1 => 
        array (
          0 => 
          array (
            '_route' => 'admin.attributes.destroy',
          ),
          1 => 
          array (
            0 => 'attribute',
          ),
          2 => 
          array (
            'DELETE' => 0,
          ),
          3 => NULL,
          4 => false,
          5 => true,
          6 => NULL,
        ),
      ),
      1724 => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'admin.artwork-preferences.index',
          ),
          1 => 
          array (
            0 => 'type',
          ),
          2 => 
          array (
            'GET' => 0,
            'HEAD' => 1,
          ),
          3 => NULL,
          4 => false,
          5 => true,
          6 => NULL,
        ),
      ),
      1743 => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'admin.artwork-preferences.create',
          ),
          1 => 
          array (
            0 => 'type',
          ),
          2 => 
          array (
            'GET' => 0,
            'HEAD' => 1,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      1768 => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'admin.artwork-preferences.edit',
          ),
          1 => 
          array (
            0 => 'type',
            1 => 'preference',
          ),
          2 => 
          array (
            'GET' => 0,
            'HEAD' => 1,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      1777 => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'admin.artwork-preferences.update',
          ),
          1 => 
          array (
            0 => 'type',
            1 => 'preference',
          ),
          2 => 
          array (
            'PUT' => 0,
          ),
          3 => NULL,
          4 => false,
          5 => true,
          6 => NULL,
        ),
        1 => 
        array (
          0 => 
          array (
            '_route' => 'admin.artwork-preferences.destroy',
          ),
          1 => 
          array (
            0 => 'type',
            1 => 'preference',
          ),
          2 => 
          array (
            'DELETE' => 0,
          ),
          3 => NULL,
          4 => false,
          5 => true,
          6 => NULL,
        ),
      ),
      1788 => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'admin.artwork-preferences.store',
          ),
          1 => 
          array (
            0 => 'type',
          ),
          2 => 
          array (
            'POST' => 0,
          ),
          3 => NULL,
          4 => false,
          5 => true,
          6 => NULL,
        ),
      ),
      1849 => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'admin.jersey-customization-options.type',
          ),
          1 => 
          array (
            0 => 'type',
          ),
          2 => 
          array (
            'GET' => 0,
            'HEAD' => 1,
          ),
          3 => NULL,
          4 => false,
          5 => true,
          6 => NULL,
        ),
      ),
      1874 => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'admin.jersey-customization-options.import-fabrics',
          ),
          1 => 
          array (
            0 => 'type',
          ),
          2 => 
          array (
            'POST' => 0,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      1900 => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'admin.jersey-customization-options.edit',
          ),
          1 => 
          array (
            0 => 'jerseyCustomizationOption',
          ),
          2 => 
          array (
            'GET' => 0,
            'HEAD' => 1,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      1909 => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'admin.jersey-customization-options.update',
          ),
          1 => 
          array (
            0 => 'jerseyCustomizationOption',
          ),
          2 => 
          array (
            'PUT' => 0,
            'PATCH' => 1,
          ),
          3 => NULL,
          4 => false,
          5 => true,
          6 => NULL,
        ),
        1 => 
        array (
          0 => 
          array (
            '_route' => 'admin.jersey-customization-options.destroy',
          ),
          1 => 
          array (
            0 => 'jerseyCustomizationOption',
          ),
          2 => 
          array (
            'DELETE' => 0,
          ),
          3 => NULL,
          4 => false,
          5 => true,
          6 => NULL,
        ),
      ),
      1971 => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'admin.world-cup-customization-options.type',
          ),
          1 => 
          array (
            0 => 'type',
          ),
          2 => 
          array (
            'GET' => 0,
            'HEAD' => 1,
          ),
          3 => NULL,
          4 => false,
          5 => true,
          6 => NULL,
        ),
      ),
      1996 => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'admin.world-cup-customization-options.edit',
          ),
          1 => 
          array (
            0 => 'worldCupCustomizationOption',
          ),
          2 => 
          array (
            'GET' => 0,
            'HEAD' => 1,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      2005 => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'admin.world-cup-customization-options.update',
          ),
          1 => 
          array (
            0 => 'worldCupCustomizationOption',
          ),
          2 => 
          array (
            'PUT' => 0,
            'PATCH' => 1,
          ),
          3 => NULL,
          4 => false,
          5 => true,
          6 => NULL,
        ),
        1 => 
        array (
          0 => 
          array (
            '_route' => 'admin.world-cup-customization-options.destroy',
          ),
          1 => 
          array (
            0 => 'worldCupCustomizationOption',
          ),
          2 => 
          array (
            'DELETE' => 0,
          ),
          3 => NULL,
          4 => false,
          5 => true,
          6 => NULL,
        ),
      ),
      2074 => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'admin.training-vest-customization-options.type',
          ),
          1 => 
          array (
            0 => 'type',
          ),
          2 => 
          array (
            'GET' => 0,
            'HEAD' => 1,
          ),
          3 => NULL,
          4 => false,
          5 => true,
          6 => NULL,
        ),
      ),
      2112 => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'admin.training-vest-size-option-groups.edit',
          ),
          1 => 
          array (
            0 => 'trainingVestSizeOptionGroup',
          ),
          2 => 
          array (
            'GET' => 0,
            'HEAD' => 1,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      2121 => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'admin.training-vest-size-option-groups.update',
          ),
          1 => 
          array (
            0 => 'trainingVestSizeOptionGroup',
          ),
          2 => 
          array (
            'PUT' => 0,
          ),
          3 => NULL,
          4 => false,
          5 => true,
          6 => NULL,
        ),
        1 => 
        array (
          0 => 
          array (
            '_route' => 'admin.training-vest-size-option-groups.destroy',
          ),
          1 => 
          array (
            0 => 'trainingVestSizeOptionGroup',
          ),
          2 => 
          array (
            'DELETE' => 0,
          ),
          3 => NULL,
          4 => false,
          5 => true,
          6 => NULL,
        ),
      ),
      2147 => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'admin.training-vest-customization-options.edit',
          ),
          1 => 
          array (
            0 => 'trainingVestCustomizationOption',
          ),
          2 => 
          array (
            'GET' => 0,
            'HEAD' => 1,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      2156 => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'admin.training-vest-customization-options.update',
          ),
          1 => 
          array (
            0 => 'trainingVestCustomizationOption',
          ),
          2 => 
          array (
            'PUT' => 0,
            'PATCH' => 1,
          ),
          3 => NULL,
          4 => false,
          5 => true,
          6 => NULL,
        ),
        1 => 
        array (
          0 => 
          array (
            '_route' => 'admin.training-vest-customization-options.destroy',
          ),
          1 => 
          array (
            0 => 'trainingVestCustomizationOption',
          ),
          2 => 
          array (
            'DELETE' => 0,
          ),
          3 => NULL,
          4 => false,
          5 => true,
          6 => NULL,
        ),
      ),
      2194 => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'admin.time-zones.edit',
          ),
          1 => 
          array (
            0 => 'timeZone',
          ),
          2 => 
          array (
            'GET' => 0,
            'HEAD' => 1,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      2203 => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'admin.time-zones.update',
          ),
          1 => 
          array (
            0 => 'timeZone',
          ),
          2 => 
          array (
            'PUT' => 0,
            'PATCH' => 1,
          ),
          3 => NULL,
          4 => false,
          5 => true,
          6 => NULL,
        ),
        1 => 
        array (
          0 => 
          array (
            '_route' => 'admin.time-zones.destroy',
          ),
          1 => 
          array (
            0 => 'timeZone',
          ),
          2 => 
          array (
            'DELETE' => 0,
          ),
          3 => NULL,
          4 => false,
          5 => true,
          6 => NULL,
        ),
      ),
      2254 => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'admin.size-option-groups.edit',
          ),
          1 => 
          array (
            0 => 'sizeOptionGroup',
          ),
          2 => 
          array (
            'GET' => 0,
            'HEAD' => 1,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      2263 => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'admin.size-option-groups.update',
          ),
          1 => 
          array (
            0 => 'sizeOptionGroup',
          ),
          2 => 
          array (
            'PUT' => 0,
            'PATCH' => 1,
          ),
          3 => NULL,
          4 => false,
          5 => true,
          6 => NULL,
        ),
        1 => 
        array (
          0 => 
          array (
            '_route' => 'admin.size-option-groups.destroy',
          ),
          1 => 
          array (
            0 => 'sizeOptionGroup',
          ),
          2 => 
          array (
            'DELETE' => 0,
          ),
          3 => NULL,
          4 => false,
          5 => true,
          6 => NULL,
        ),
      ),
      2306 => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'admin.shipping-methods.edit',
          ),
          1 => 
          array (
            0 => 'shippingMethod',
          ),
          2 => 
          array (
            'GET' => 0,
            'HEAD' => 1,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      2315 => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'admin.shipping-methods.update',
          ),
          1 => 
          array (
            0 => 'shippingMethod',
          ),
          2 => 
          array (
            'PUT' => 0,
            'PATCH' => 1,
          ),
          3 => NULL,
          4 => false,
          5 => true,
          6 => NULL,
        ),
        1 => 
        array (
          0 => 
          array (
            '_route' => 'admin.shipping-methods.destroy',
          ),
          1 => 
          array (
            0 => 'shippingMethod',
          ),
          2 => 
          array (
            'DELETE' => 0,
          ),
          3 => NULL,
          4 => false,
          5 => true,
          6 => NULL,
        ),
      ),
      2369 => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'admin.rural-area-surcharges.edit',
          ),
          1 => 
          array (
            0 => 'ruralAreaSurcharge',
          ),
          2 => 
          array (
            'GET' => 0,
            'HEAD' => 1,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      2378 => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'admin.rural-area-surcharges.update',
          ),
          1 => 
          array (
            0 => 'ruralAreaSurcharge',
          ),
          2 => 
          array (
            'PUT' => 0,
            'PATCH' => 1,
          ),
          3 => NULL,
          4 => false,
          5 => true,
          6 => NULL,
        ),
        1 => 
        array (
          0 => 
          array (
            '_route' => 'admin.rural-area-surcharges.destroy',
          ),
          1 => 
          array (
            0 => 'ruralAreaSurcharge',
          ),
          2 => 
          array (
            'DELETE' => 0,
          ),
          3 => NULL,
          4 => false,
          5 => true,
          6 => NULL,
        ),
      ),
      2406 => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'admin.returns.show',
          ),
          1 => 
          array (
            0 => 'returnRequest',
          ),
          2 => 
          array (
            'GET' => 0,
            'HEAD' => 1,
          ),
          3 => NULL,
          4 => false,
          5 => true,
          6 => NULL,
        ),
      ),
      2436 => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'admin.returns.attachments.download',
          ),
          1 => 
          array (
            0 => 'returnRequest',
            1 => 'attachment',
          ),
          2 => 
          array (
            'GET' => 0,
            'HEAD' => 1,
          ),
          3 => NULL,
          4 => false,
          5 => true,
          6 => NULL,
        ),
      ),
      2445 => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'admin.returns.update',
          ),
          1 => 
          array (
            0 => 'returnRequest',
          ),
          2 => 
          array (
            'PATCH' => 0,
          ),
          3 => NULL,
          4 => false,
          5 => true,
          6 => NULL,
        ),
      ),
      2477 => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'admin.faqs.edit',
          ),
          1 => 
          array (
            0 => 'faq',
          ),
          2 => 
          array (
            'GET' => 0,
            'HEAD' => 1,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      2486 => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'admin.faqs.update',
          ),
          1 => 
          array (
            0 => 'faq',
          ),
          2 => 
          array (
            'PUT' => 0,
            'PATCH' => 1,
          ),
          3 => NULL,
          4 => false,
          5 => true,
          6 => NULL,
        ),
        1 => 
        array (
          0 => 
          array (
            '_route' => 'admin.faqs.destroy',
          ),
          1 => 
          array (
            0 => 'faq',
          ),
          2 => 
          array (
            'DELETE' => 0,
          ),
          3 => NULL,
          4 => false,
          5 => true,
          6 => NULL,
        ),
      ),
      2520 => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'admin.genders.edit',
          ),
          1 => 
          array (
            0 => 'gender',
          ),
          2 => 
          array (
            'GET' => 0,
            'HEAD' => 1,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      2529 => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'admin.genders.update',
          ),
          1 => 
          array (
            0 => 'gender',
          ),
          2 => 
          array (
            'PUT' => 0,
            'PATCH' => 1,
          ),
          3 => NULL,
          4 => false,
          5 => true,
          6 => NULL,
        ),
        1 => 
        array (
          0 => 
          array (
            '_route' => 'admin.genders.destroy',
          ),
          1 => 
          array (
            0 => 'gender',
          ),
          2 => 
          array (
            'DELETE' => 0,
          ),
          3 => NULL,
          4 => false,
          5 => true,
          6 => NULL,
        ),
      ),
      2586 => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'admin.bulk-quote-budget-ranges.edit',
          ),
          1 => 
          array (
            0 => 'bulkQuoteBudgetRange',
          ),
          2 => 
          array (
            'GET' => 0,
            'HEAD' => 1,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      2595 => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'admin.bulk-quote-budget-ranges.update',
          ),
          1 => 
          array (
            0 => 'bulkQuoteBudgetRange',
          ),
          2 => 
          array (
            'PUT' => 0,
            'PATCH' => 1,
          ),
          3 => NULL,
          4 => false,
          5 => true,
          6 => NULL,
        ),
        1 => 
        array (
          0 => 
          array (
            '_route' => 'admin.bulk-quote-budget-ranges.destroy',
          ),
          1 => 
          array (
            0 => 'bulkQuoteBudgetRange',
          ),
          2 => 
          array (
            'DELETE' => 0,
          ),
          3 => NULL,
          4 => false,
          5 => true,
          6 => NULL,
        ),
      ),
      2618 => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'admin.bulk-quotes.show',
          ),
          1 => 
          array (
            0 => 'bulkQuote',
          ),
          2 => 
          array (
            'GET' => 0,
            'HEAD' => 1,
          ),
          3 => NULL,
          4 => false,
          5 => true,
          6 => NULL,
        ),
      ),
      2641 => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'admin.bulk-quotes.attachment',
          ),
          1 => 
          array (
            0 => 'bulkQuote',
          ),
          2 => 
          array (
            'GET' => 0,
            'HEAD' => 1,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      2661 => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'admin.bulk-quotes.retry-sync',
          ),
          1 => 
          array (
            0 => 'bulkQuote',
          ),
          2 => 
          array (
            'POST' => 0,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      2677 => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'admin.bulk-quotes.publish',
          ),
          1 => 
          array (
            0 => 'bulkQuote',
          ),
          2 => 
          array (
            'POST' => 0,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      2693 => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'admin.bulk-quotes.message',
          ),
          1 => 
          array (
            0 => 'bulkQuote',
          ),
          2 => 
          array (
            'POST' => 0,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      2715 => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'admin.bulk-quotes.file',
          ),
          1 => 
          array (
            0 => 'bulkQuote',
            1 => 'file',
          ),
          2 => 
          array (
            'GET' => 0,
            'HEAD' => 1,
          ),
          3 => NULL,
          4 => false,
          5 => true,
          6 => NULL,
        ),
      ),
      2725 => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'admin.bulk-quotes.update',
          ),
          1 => 
          array (
            0 => 'bulkQuote',
          ),
          2 => 
          array (
            'PATCH' => 0,
          ),
          3 => NULL,
          4 => false,
          5 => true,
          6 => NULL,
        ),
      ),
      2750 => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'admin.users.update',
          ),
          1 => 
          array (
            0 => 'user',
          ),
          2 => 
          array (
            'PATCH' => 0,
          ),
          3 => NULL,
          4 => false,
          5 => true,
          6 => NULL,
        ),
      ),
      2777 => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'admin.orders.show',
          ),
          1 => 
          array (
            0 => 'order',
          ),
          2 => 
          array (
            'GET' => 0,
            'HEAD' => 1,
          ),
          3 => NULL,
          4 => false,
          5 => true,
          6 => NULL,
        ),
      ),
      2811 => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'admin.orders.artwork-proofs.store',
          ),
          1 => 
          array (
            0 => 'order',
          ),
          2 => 
          array (
            'POST' => 0,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      2837 => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'admin.orders.artwork-proofs.file',
          ),
          1 => 
          array (
            0 => 'order',
            1 => 'proof',
          ),
          2 => 
          array (
            'GET' => 0,
            'HEAD' => 1,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      2851 => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'admin.orders.artwork-proofs.reply',
          ),
          1 => 
          array (
            0 => 'order',
            1 => 'proof',
          ),
          2 => 
          array (
            'POST' => 0,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      2868 => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'admin.orders.approve',
          ),
          1 => 
          array (
            0 => 'order',
          ),
          2 => 
          array (
            'PATCH' => 0,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      2909 => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'admin.orders.artwork.show',
          ),
          1 => 
          array (
            0 => 'order',
            1 => 'orderItem',
            2 => 'artworkIndex',
          ),
          2 => 
          array (
            'GET' => 0,
            'HEAD' => 1,
          ),
          3 => NULL,
          4 => false,
          5 => true,
          6 => NULL,
        ),
      ),
      2932 => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'admin.orders.retry-sync',
          ),
          1 => 
          array (
            0 => 'order',
          ),
          2 => 
          array (
            'POST' => 0,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      2956 => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'admin.orders.requests.update',
          ),
          1 => 
          array (
            0 => 'order',
            1 => 'changeRequest',
          ),
          2 => 
          array (
            'PATCH' => 0,
          ),
          3 => NULL,
          4 => false,
          5 => true,
          6 => NULL,
        ),
      ),
      2978 => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'admin.orders.shipments.store',
          ),
          1 => 
          array (
            0 => 'order',
          ),
          2 => 
          array (
            'POST' => 0,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      2996 => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'admin.orders.shipments.update',
          ),
          1 => 
          array (
            0 => 'order',
            1 => 'shipment',
          ),
          2 => 
          array (
            'PATCH' => 0,
          ),
          3 => NULL,
          4 => false,
          5 => true,
          6 => NULL,
        ),
      ),
      3018 => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'admin.orders.downloads.store',
          ),
          1 => 
          array (
            0 => 'order',
          ),
          2 => 
          array (
            'POST' => 0,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      3036 => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'admin.orders.downloads.destroy',
          ),
          1 => 
          array (
            0 => 'order',
            1 => 'download',
          ),
          2 => 
          array (
            'DELETE' => 0,
          ),
          3 => NULL,
          4 => false,
          5 => true,
          6 => NULL,
        ),
      ),
      3047 => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'admin.orders.update',
          ),
          1 => 
          array (
            0 => 'order',
          ),
          2 => 
          array (
            'PATCH' => 0,
          ),
          3 => NULL,
          4 => false,
          5 => true,
          6 => NULL,
        ),
      ),
      3100 => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'account.addresses.default',
          ),
          1 => 
          array (
            0 => 'address',
          ),
          2 => 
          array (
            'PATCH' => 0,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      3109 => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'account.addresses.destroy',
          ),
          1 => 
          array (
            0 => 'address',
          ),
          2 => 
          array (
            'DELETE' => 0,
          ),
          3 => NULL,
          4 => false,
          5 => true,
          6 => NULL,
        ),
      ),
      3148 => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'account.artwork.show',
          ),
          1 => 
          array (
            0 => 'proof',
          ),
          2 => 
          array (
            'GET' => 0,
            'HEAD' => 1,
          ),
          3 => NULL,
          4 => false,
          5 => true,
          6 => NULL,
        ),
      ),
      3183 => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'account.artwork.changes',
          ),
          1 => 
          array (
            0 => 'proof',
          ),
          2 => 
          array (
            'GET' => 0,
            'HEAD' => 1,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
        1 => 
        array (
          0 => 
          array (
            '_route' => 'account.artwork.changes.store',
          ),
          1 => 
          array (
            0 => 'proof',
          ),
          2 => 
          array (
            'POST' => 0,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      3197 => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'account.artwork.reject',
          ),
          1 => 
          array (
            0 => 'proof',
          ),
          2 => 
          array (
            'POST' => 0,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      3217 => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'account.artwork.approve',
          ),
          1 => 
          array (
            0 => 'proof',
          ),
          2 => 
          array (
            'POST' => 0,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      3227 => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'account.artwork.approved',
          ),
          1 => 
          array (
            0 => 'proof',
          ),
          2 => 
          array (
            'GET' => 0,
            'HEAD' => 1,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      3244 => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'account.artwork.message',
          ),
          1 => 
          array (
            0 => 'proof',
          ),
          2 => 
          array (
            'POST' => 0,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      3257 => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'account.artwork.file',
          ),
          1 => 
          array (
            0 => 'proof',
          ),
          2 => 
          array (
            'GET' => 0,
            'HEAD' => 1,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      3305 => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'account.payment-methods.default',
          ),
          1 => 
          array (
            0 => 'paymentMethod',
          ),
          2 => 
          array (
            'PATCH' => 0,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      3314 => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'account.payment-methods.destroy',
          ),
          1 => 
          array (
            0 => 'paymentMethod',
          ),
          2 => 
          array (
            'DELETE' => 0,
          ),
          3 => NULL,
          4 => false,
          5 => true,
          6 => NULL,
        ),
      ),
      3348 => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'account.bulk-quotes.show',
          ),
          1 => 
          array (
            0 => 'reference',
          ),
          2 => 
          array (
            'GET' => 0,
            'HEAD' => 1,
          ),
          3 => NULL,
          4 => false,
          5 => true,
          6 => NULL,
        ),
      ),
      3371 => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'account.bulk-quotes.changes',
          ),
          1 => 
          array (
            0 => 'reference',
          ),
          2 => 
          array (
            'GET' => 0,
            'HEAD' => 1,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
        1 => 
        array (
          0 => 
          array (
            '_route' => 'account.bulk-quotes.changes.send',
          ),
          1 => 
          array (
            0 => 'reference',
          ),
          2 => 
          array (
            'POST' => 0,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      3388 => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'account.bulk-quotes.message',
          ),
          1 => 
          array (
            0 => 'reference',
          ),
          2 => 
          array (
            'POST' => 0,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      3405 => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'account.bulk-quotes.decision',
          ),
          1 => 
          array (
            0 => 'reference',
          ),
          2 => 
          array (
            'POST' => 0,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      3427 => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'account.bulk-quotes.file',
          ),
          1 => 
          array (
            0 => 'reference',
            1 => 'file',
          ),
          2 => 
          array (
            'GET' => 0,
            'HEAD' => 1,
          ),
          3 => NULL,
          4 => false,
          5 => true,
          6 => NULL,
        ),
      ),
      3459 => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'account.orders.show',
          ),
          1 => 
          array (
            0 => 'order',
          ),
          2 => 
          array (
            'GET' => 0,
            'HEAD' => 1,
          ),
          3 => NULL,
          4 => false,
          5 => true,
          6 => NULL,
        ),
      ),
      3478 => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'account.orders.pay',
          ),
          1 => 
          array (
            0 => 'order',
          ),
          2 => 
          array (
            'GET' => 0,
            'HEAD' => 1,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
        1 => 
        array (
          0 => 
          array (
            '_route' => 'account.orders.pay.store',
          ),
          1 => 
          array (
            0 => 'order',
          ),
          2 => 
          array (
            'POST' => 0,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      3508 => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'account.orders.payment.retry',
          ),
          1 => 
          array (
            0 => 'order',
          ),
          2 => 
          array (
            'GET' => 0,
            'HEAD' => 1,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      3532 => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'account.orders.returns.create',
          ),
          1 => 
          array (
            0 => 'order',
          ),
          2 => 
          array (
            'GET' => 0,
            'HEAD' => 1,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
        1 => 
        array (
          0 => 
          array (
            '_route' => 'account.orders.returns.store',
          ),
          1 => 
          array (
            0 => 'order',
          ),
          2 => 
          array (
            'POST' => 0,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      3551 => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'account.orders.reorder',
          ),
          1 => 
          array (
            0 => 'order',
          ),
          2 => 
          array (
            'GET' => 0,
            'HEAD' => 1,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
        1 => 
        array (
          0 => 
          array (
            '_route' => 'account.orders.reorder.store',
          ),
          1 => 
          array (
            0 => 'order',
          ),
          2 => 
          array (
            'POST' => 0,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      3583 => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'account.orders.cancel',
          ),
          1 => 
          array (
            0 => 'order',
          ),
          2 => 
          array (
            'GET' => 0,
            'HEAD' => 1,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
        1 => 
        array (
          0 => 
          array (
            '_route' => 'account.orders.cancel.store',
          ),
          1 => 
          array (
            0 => 'order',
          ),
          2 => 
          array (
            'POST' => 0,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      3610 => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'account.orders.change',
          ),
          1 => 
          array (
            0 => 'order',
          ),
          2 => 
          array (
            'GET' => 0,
            'HEAD' => 1,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
        1 => 
        array (
          0 => 
          array (
            '_route' => 'account.orders.change.store',
          ),
          1 => 
          array (
            0 => 'order',
          ),
          2 => 
          array (
            'POST' => 0,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      3633 => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'account.orders.shipments',
          ),
          1 => 
          array (
            0 => 'order',
          ),
          2 => 
          array (
            'GET' => 0,
            'HEAD' => 1,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      3651 => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'account.orders.shipments.show',
          ),
          1 => 
          array (
            0 => 'order',
            1 => 'shipment',
          ),
          2 => 
          array (
            'GET' => 0,
            'HEAD' => 1,
          ),
          3 => NULL,
          4 => false,
          5 => true,
          6 => NULL,
        ),
      ),
      3671 => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'account.orders.invoice',
          ),
          1 => 
          array (
            0 => 'order',
          ),
          2 => 
          array (
            'GET' => 0,
            'HEAD' => 1,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      3689 => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'account.orders.invoice.download',
          ),
          1 => 
          array (
            0 => 'order',
          ),
          2 => 
          array (
            'GET' => 0,
            'HEAD' => 1,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      3719 => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'account.orders.exchanges.create',
          ),
          1 => 
          array (
            0 => 'order',
          ),
          2 => 
          array (
            'GET' => 0,
            'HEAD' => 1,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
        1 => 
        array (
          0 => 
          array (
            '_route' => 'account.orders.exchanges.store',
          ),
          1 => 
          array (
            0 => 'order',
          ),
          2 => 
          array (
            'POST' => 0,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      3751 => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'account.downloads.download',
          ),
          1 => 
          array (
            0 => 'download',
          ),
          2 => 
          array (
            'GET' => 0,
            'HEAD' => 1,
          ),
          3 => NULL,
          4 => false,
          5 => true,
          6 => NULL,
        ),
      ),
      3783 => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'account.returns.show',
          ),
          1 => 
          array (
            0 => 'returnRequest',
          ),
          2 => 
          array (
            'GET' => 0,
            'HEAD' => 1,
          ),
          3 => NULL,
          4 => false,
          5 => true,
          6 => NULL,
        ),
      ),
      3814 => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'account.return-attachments.download',
          ),
          1 => 
          array (
            0 => 'attachment',
          ),
          2 => 
          array (
            'GET' => 0,
            'HEAD' => 1,
          ),
          3 => NULL,
          4 => false,
          5 => true,
          6 => NULL,
        ),
      ),
      3838 => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'account.refunds.show',
          ),
          1 => 
          array (
            0 => 'refund',
          ),
          2 => 
          array (
            'GET' => 0,
            'HEAD' => 1,
          ),
          3 => NULL,
          4 => false,
          5 => true,
          6 => NULL,
        ),
      ),
      3873 => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'account.credit-notes.show',
          ),
          1 => 
          array (
            0 => 'creditNote',
          ),
          2 => 
          array (
            'GET' => 0,
            'HEAD' => 1,
          ),
          3 => NULL,
          4 => false,
          5 => true,
          6 => NULL,
        ),
      ),
      3891 => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'account.credit-notes.download',
          ),
          1 => 
          array (
            0 => 'creditNote',
          ),
          2 => 
          array (
            'GET' => 0,
            'HEAD' => 1,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      3935 => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'payments.return',
          ),
          1 => 
          array (
            0 => 'provider',
          ),
          2 => 
          array (
            'GET' => 0,
            'HEAD' => 1,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      3962 => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'products.show',
          ),
          1 => 
          array (
            0 => 'slug',
          ),
          2 => 
          array (
            'GET' => 0,
            'HEAD' => 1,
          ),
          3 => NULL,
          4 => false,
          5 => true,
          6 => NULL,
        ),
      ),
      3981 => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'products.show.legacy',
          ),
          1 => 
          array (
            0 => 'slug',
          ),
          2 => 
          array (
            'GET' => 0,
            'HEAD' => 1,
          ),
          3 => NULL,
          4 => false,
          5 => true,
          6 => NULL,
        ),
      ),
      4021 => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'referral.offer',
          ),
          1 => 
          array (
            0 => 'token',
          ),
          2 => 
          array (
            'GET' => 0,
            'HEAD' => 1,
          ),
          3 => NULL,
          4 => false,
          5 => true,
          6 => NULL,
        ),
      ),
      4052 => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'password.reset',
          ),
          1 => 
          array (
            0 => 'token',
          ),
          2 => 
          array (
            'GET' => 0,
            'HEAD' => 1,
          ),
          3 => NULL,
          4 => false,
          5 => true,
          6 => NULL,
        ),
      ),
      4073 => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'media.public',
          ),
          1 => 
          array (
            0 => 'path',
          ),
          2 => 
          array (
            'GET' => 0,
            'HEAD' => 1,
          ),
          3 => NULL,
          4 => false,
          5 => true,
          6 => NULL,
        ),
      ),
      4125 => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'quote.guest.success',
          ),
          1 => 
          array (
            0 => 'reference',
          ),
          2 => 
          array (
            'GET' => 0,
            'HEAD' => 1,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      4140 => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'quote.guest.review',
          ),
          1 => 
          array (
            0 => 'reference',
          ),
          2 => 
          array (
            'GET' => 0,
            'HEAD' => 1,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      4159 => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'quote.guest.changes',
          ),
          1 => 
          array (
            0 => 'reference',
          ),
          2 => 
          array (
            'GET' => 0,
            'HEAD' => 1,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
        1 => 
        array (
          0 => 
          array (
            '_route' => 'quote.guest.changes.send',
          ),
          1 => 
          array (
            0 => 'reference',
          ),
          2 => 
          array (
            'POST' => 0,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      4176 => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'quote.guest.message',
          ),
          1 => 
          array (
            0 => 'reference',
          ),
          2 => 
          array (
            'POST' => 0,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      4193 => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'quote.guest.decision',
          ),
          1 => 
          array (
            0 => 'reference',
          ),
          2 => 
          array (
            'POST' => 0,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      4215 => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'quote.guest.file',
          ),
          1 => 
          array (
            0 => 'reference',
            1 => 'file',
          ),
          2 => 
          array (
            'GET' => 0,
            'HEAD' => 1,
          ),
          3 => NULL,
          4 => false,
          5 => true,
          6 => NULL,
        ),
      ),
      4225 => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'quote.guest.show',
          ),
          1 => 
          array (
            0 => 'reference',
          ),
          2 => 
          array (
            'GET' => 0,
            'HEAD' => 1,
          ),
          3 => NULL,
          4 => false,
          5 => true,
          6 => NULL,
        ),
      ),
      4266 => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'verification.verify',
          ),
          1 => 
          array (
            0 => 'id',
            1 => 'hash',
          ),
          2 => 
          array (
            'GET' => 0,
            'HEAD' => 1,
          ),
          3 => NULL,
          4 => false,
          5 => true,
          6 => NULL,
        ),
      ),
      4300 => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'categories.show',
          ),
          1 => 
          array (
            0 => 'slug',
          ),
          2 => 
          array (
            'GET' => 0,
            'HEAD' => 1,
          ),
          3 => NULL,
          4 => false,
          5 => true,
          6 => NULL,
        ),
      ),
      4349 => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'cart.items.artwork.show',
          ),
          1 => 
          array (
            0 => 'cartItem',
            1 => 'artworkIndex',
          ),
          2 => 
          array (
            'GET' => 0,
            'HEAD' => 1,
          ),
          3 => NULL,
          4 => false,
          5 => true,
          6 => NULL,
        ),
      ),
      4365 => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'cart.items.options.update',
          ),
          1 => 
          array (
            0 => 'cartItem',
          ),
          2 => 
          array (
            'PATCH' => 0,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      4375 => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'cart.items.update',
          ),
          1 => 
          array (
            0 => 'cartItem',
          ),
          2 => 
          array (
            'PATCH' => 0,
          ),
          3 => NULL,
          4 => false,
          5 => true,
          6 => NULL,
        ),
        1 => 
        array (
          0 => 
          array (
            '_route' => 'cart.items.destroy',
          ),
          1 => 
          array (
            0 => 'cartItem',
          ),
          2 => 
          array (
            'DELETE' => 0,
          ),
          3 => NULL,
          4 => false,
          5 => true,
          6 => NULL,
        ),
      ),
      4413 => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'wishlist.products.update',
          ),
          1 => 
          array (
            0 => 'product',
          ),
          2 => 
          array (
            'PUT' => 0,
          ),
          3 => NULL,
          4 => false,
          5 => true,
          6 => NULL,
        ),
      ),
      4446 => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'orders.details',
          ),
          1 => 
          array (
            0 => 'orderNumber',
          ),
          2 => 
          array (
            'GET' => 0,
            'HEAD' => 1,
          ),
          3 => NULL,
          4 => false,
          5 => true,
          6 => NULL,
        ),
      ),
      4480 => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'orders.invoice',
          ),
          1 => 
          array (
            0 => 'orderNumber',
          ),
          2 => 
          array (
            'GET' => 0,
            'HEAD' => 1,
          ),
          3 => NULL,
          4 => false,
          5 => true,
          6 => NULL,
        ),
      ),
      4505 => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'storage.local',
          ),
          1 => 
          array (
            0 => 'path',
          ),
          2 => 
          array (
            'GET' => 0,
            'HEAD' => 1,
          ),
          3 => NULL,
          4 => false,
          5 => true,
          6 => NULL,
        ),
        1 => 
        array (
          0 => 
          array (
            '_route' => 'storage.local.upload',
          ),
          1 => 
          array (
            0 => 'path',
          ),
          2 => 
          array (
            'PUT' => 0,
          ),
          3 => NULL,
          4 => false,
          5 => true,
          6 => NULL,
        ),
        2 => 
        array (
          0 => NULL,
          1 => NULL,
          2 => NULL,
          3 => NULL,
          4 => false,
          5 => false,
          6 => 0,
        ),
      ),
    ),
    4 => NULL,
  ),
  'attributes' => 
  array (
    'api.flowtrack.orders.progress' => 
    array (
      'methods' => 
      array (
        0 => 'POST',
      ),
      'uri' => 'api/integrations/flowtrack/orders/{orderNumber}/progress',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'api',
          1 => 'App\\Http\\Middleware\\VerifyFlowTrackIntegration',
          2 => 'throttle:300,1',
        ),
        'uses' => 'App\\Http\\Controllers\\Api\\FlowTrackOrderProgressController@__invoke',
        'controller' => 'App\\Http\\Controllers\\Api\\FlowTrackOrderProgressController',
        'namespace' => NULL,
        'prefix' => 'api',
        'where' => 
        array (
        ),
        'as' => 'api.flowtrack.orders.progress',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
        'orderNumber' => '[A-Za-z0-9_-]+',
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'api.flowtrack.order-items.artwork' => 
    array (
      'methods' => 
      array (
        0 => 'GET',
        1 => 'HEAD',
      ),
      'uri' => 'api/integrations/flowtrack/order-items/{orderItem}/artworks/{index}',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'api',
          1 => 'App\\Http\\Middleware\\VerifyFlowTrackIntegration',
          2 => 'throttle:60,1',
        ),
        'uses' => 'App\\Http\\Controllers\\Api\\FlowTrackArtworkController@show',
        'controller' => 'App\\Http\\Controllers\\Api\\FlowTrackArtworkController@show',
        'namespace' => NULL,
        'prefix' => 'api/integrations/flowtrack',
        'where' => 
        array (
        ),
        'as' => 'api.flowtrack.order-items.artwork',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
        'orderItem' => '[0-9]+',
        'index' => '[0-9]+',
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'generated::gEtRTxrt7DdU7kQJ' => 
    array (
      'methods' => 
      array (
        0 => 'GET',
        1 => 'HEAD',
      ),
      'uri' => 'api/integrations/flowtrack/bulk-quotes/{bulkQuote}/files/{file}',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'api',
          1 => 'App\\Http\\Middleware\\VerifyFlowTrackIntegration',
          2 => 'throttle:60,1',
        ),
        'uses' => 'App\\Http\\Controllers\\Api\\FlowTrackBulkQuoteAttachmentController@clientFile',
        'controller' => 'App\\Http\\Controllers\\Api\\FlowTrackBulkQuoteAttachmentController@clientFile',
        'namespace' => NULL,
        'prefix' => 'api/integrations/flowtrack',
        'where' => 
        array (
        ),
        'as' => 'generated::gEtRTxrt7DdU7kQJ',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
        'bulkQuote' => '[0-9]+',
        'file' => '[0-9]+',
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'api.flowtrack.bulk-quotes.attachment' => 
    array (
      'methods' => 
      array (
        0 => 'GET',
        1 => 'HEAD',
      ),
      'uri' => 'api/integrations/flowtrack/bulk-quotes/{bulkQuote}/attachment',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'api',
          1 => 'App\\Http\\Middleware\\VerifyFlowTrackIntegration',
          2 => 'throttle:60,1',
        ),
        'uses' => 'App\\Http\\Controllers\\Api\\FlowTrackBulkQuoteAttachmentController@show',
        'controller' => 'App\\Http\\Controllers\\Api\\FlowTrackBulkQuoteAttachmentController@show',
        'namespace' => NULL,
        'prefix' => 'api/integrations/flowtrack',
        'where' => 
        array (
        ),
        'as' => 'api.flowtrack.bulk-quotes.attachment',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
        'bulkQuote' => '[0-9]+',
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'generated::wZqXgnVqJD4H8Sny' => 
    array (
      'methods' => 
      array (
        0 => 'GET',
        1 => 'HEAD',
      ),
      'uri' => 'api/integrations/flowtrack/catalog/categories',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'api',
          1 => 'App\\Http\\Middleware\\VerifyFlowTrackIntegration',
          2 => 'throttle:120,1',
        ),
        'uses' => 'App\\Http\\Controllers\\Api\\FlowTrackCatalogController@categories',
        'controller' => 'App\\Http\\Controllers\\Api\\FlowTrackCatalogController@categories',
        'namespace' => NULL,
        'prefix' => 'api/integrations/flowtrack',
        'where' => 
        array (
        ),
        'as' => 'generated::wZqXgnVqJD4H8Sny',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'generated::Swg5sa95Z3Ny49v2' => 
    array (
      'methods' => 
      array (
        0 => 'GET',
        1 => 'HEAD',
      ),
      'uri' => 'api/integrations/flowtrack/catalog/categories/{category}',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'api',
          1 => 'App\\Http\\Middleware\\VerifyFlowTrackIntegration',
          2 => 'throttle:120,1',
        ),
        'uses' => 'App\\Http\\Controllers\\Api\\FlowTrackCatalogController@category',
        'controller' => 'App\\Http\\Controllers\\Api\\FlowTrackCatalogController@category',
        'namespace' => NULL,
        'prefix' => 'api/integrations/flowtrack',
        'where' => 
        array (
        ),
        'as' => 'generated::Swg5sa95Z3Ny49v2',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
        'category' => '[0-9]+',
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'generated::pt8mTKT6hr6yyMfu' => 
    array (
      'methods' => 
      array (
        0 => 'GET',
        1 => 'HEAD',
      ),
      'uri' => 'api/integrations/flowtrack/catalog/products',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'api',
          1 => 'App\\Http\\Middleware\\VerifyFlowTrackIntegration',
          2 => 'throttle:120,1',
        ),
        'uses' => 'App\\Http\\Controllers\\Api\\FlowTrackCatalogController@products',
        'controller' => 'App\\Http\\Controllers\\Api\\FlowTrackCatalogController@products',
        'namespace' => NULL,
        'prefix' => 'api/integrations/flowtrack',
        'where' => 
        array (
        ),
        'as' => 'generated::pt8mTKT6hr6yyMfu',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'generated::jGRFZxaGnvsJtawz' => 
    array (
      'methods' => 
      array (
        0 => 'GET',
        1 => 'HEAD',
      ),
      'uri' => 'api/integrations/flowtrack/catalog/products/{product}',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'api',
          1 => 'App\\Http\\Middleware\\VerifyFlowTrackIntegration',
          2 => 'throttle:120,1',
        ),
        'uses' => 'App\\Http\\Controllers\\Api\\FlowTrackCatalogController@product',
        'controller' => 'App\\Http\\Controllers\\Api\\FlowTrackCatalogController@product',
        'namespace' => NULL,
        'prefix' => 'api/integrations/flowtrack',
        'where' => 
        array (
        ),
        'as' => 'generated::jGRFZxaGnvsJtawz',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
        'product' => '[0-9]+',
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'generated::mW4YFZQEtrH1g5yu' => 
    array (
      'methods' => 
      array (
        0 => 'PATCH',
      ),
      'uri' => 'api/integrations/flowtrack/catalog/products/{product}',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'api',
          1 => 'App\\Http\\Middleware\\VerifyFlowTrackIntegration',
          2 => 'throttle:120,1',
        ),
        'uses' => 'App\\Http\\Controllers\\Api\\FlowTrackCatalogController@update',
        'controller' => 'App\\Http\\Controllers\\Api\\FlowTrackCatalogController@update',
        'namespace' => NULL,
        'prefix' => 'api/integrations/flowtrack',
        'where' => 
        array (
        ),
        'as' => 'generated::mW4YFZQEtrH1g5yu',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
        'product' => '[0-9]+',
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'generated::EO0sQ4mYUWlz0jNj' => 
    array (
      'methods' => 
      array (
        0 => 'GET',
        1 => 'HEAD',
      ),
      'uri' => 'api/integrations/flowtrack/catalog/customers',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'api',
          1 => 'App\\Http\\Middleware\\VerifyFlowTrackIntegration',
          2 => 'throttle:120,1',
        ),
        'uses' => 'App\\Http\\Controllers\\Api\\FlowTrackCatalogController@customers',
        'controller' => 'App\\Http\\Controllers\\Api\\FlowTrackCatalogController@customers',
        'namespace' => NULL,
        'prefix' => 'api/integrations/flowtrack',
        'where' => 
        array (
        ),
        'as' => 'generated::EO0sQ4mYUWlz0jNj',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'generated::A9T2taTTamixz4KR' => 
    array (
      'methods' => 
      array (
        0 => 'GET',
        1 => 'HEAD',
      ),
      'uri' => 'api/integrations/flowtrack/catalog/customers/{customer}',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'api',
          1 => 'App\\Http\\Middleware\\VerifyFlowTrackIntegration',
          2 => 'throttle:120,1',
        ),
        'uses' => 'App\\Http\\Controllers\\Api\\FlowTrackCatalogController@customer',
        'controller' => 'App\\Http\\Controllers\\Api\\FlowTrackCatalogController@customer',
        'namespace' => NULL,
        'prefix' => 'api/integrations/flowtrack',
        'where' => 
        array (
        ),
        'as' => 'generated::A9T2taTTamixz4KR',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
        'customer' => '[0-9]+',
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'generated::UM3RBzwEqKTNk7v5' => 
    array (
      'methods' => 
      array (
        0 => 'PATCH',
      ),
      'uri' => 'api/integrations/flowtrack/catalog/customers/{customer}',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'api',
          1 => 'App\\Http\\Middleware\\VerifyFlowTrackIntegration',
          2 => 'throttle:120,1',
        ),
        'uses' => 'App\\Http\\Controllers\\Api\\FlowTrackCatalogController@updateCustomer',
        'controller' => 'App\\Http\\Controllers\\Api\\FlowTrackCatalogController@updateCustomer',
        'namespace' => NULL,
        'prefix' => 'api/integrations/flowtrack',
        'where' => 
        array (
        ),
        'as' => 'generated::UM3RBzwEqKTNk7v5',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
        'customer' => '[0-9]+',
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'generated::LpQ2d8y9QrkrRqkI' => 
    array (
      'methods' => 
      array (
        0 => 'GET',
        1 => 'HEAD',
      ),
      'uri' => 'api/integrations/flowtrack/bulk-quotes/{bulkQuote}/published-files/{file}',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'api',
          1 => 'App\\Http\\Middleware\\VerifyFlowTrackIntegration',
          2 => 'throttle:120,1',
        ),
        'uses' => 'App\\Http\\Controllers\\Api\\FlowTrackPublishedQuotationFileController@__invoke',
        'controller' => 'App\\Http\\Controllers\\Api\\FlowTrackPublishedQuotationFileController',
        'namespace' => NULL,
        'prefix' => 'api/integrations/flowtrack',
        'where' => 
        array (
        ),
        'as' => 'generated::LpQ2d8y9QrkrRqkI',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
        'bulkQuote' => '[0-9]+',
        'file' => '[0-9]+',
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'generated::VuURQLff21tJV6Bk' => 
    array (
      'methods' => 
      array (
        0 => 'POST',
      ),
      'uri' => 'api/integrations/flowtrack/bulk-quotes/{bulkQuote}/offer-files',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'api',
          1 => 'App\\Http\\Middleware\\VerifyFlowTrackIntegration',
          2 => 'throttle:120,1',
        ),
        'uses' => 'App\\Http\\Controllers\\Api\\FlowTrackBulkQuoteOfferController@__invoke',
        'controller' => 'App\\Http\\Controllers\\Api\\FlowTrackBulkQuoteOfferController',
        'namespace' => NULL,
        'prefix' => 'api/integrations/flowtrack',
        'where' => 
        array (
        ),
        'as' => 'generated::VuURQLff21tJV6Bk',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
        'bulkQuote' => '[0-9]+',
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'generated::DTaiTlPqGfxOKjlX' => 
    array (
      'methods' => 
      array (
        0 => 'POST',
      ),
      'uri' => 'api/integrations/flowtrack/bulk-quotes/{bulkQuote}/messages',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'api',
          1 => 'App\\Http\\Middleware\\VerifyFlowTrackIntegration',
          2 => 'throttle:120,1',
        ),
        'uses' => 'App\\Http\\Controllers\\Api\\FlowTrackBulkQuoteMessageController@__invoke',
        'controller' => 'App\\Http\\Controllers\\Api\\FlowTrackBulkQuoteMessageController',
        'namespace' => NULL,
        'prefix' => 'api/integrations/flowtrack',
        'where' => 
        array (
        ),
        'as' => 'generated::DTaiTlPqGfxOKjlX',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
        'bulkQuote' => '[0-9]+',
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'generated::x3R9lrUkk6iBK7gu' => 
    array (
      'methods' => 
      array (
        0 => 'POST',
      ),
      'uri' => 'api/integrations/flowtrack/bulk-quotes/{bulkQuote}/task-progress',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'api',
          1 => 'App\\Http\\Middleware\\VerifyFlowTrackIntegration',
          2 => 'throttle:120,1',
        ),
        'uses' => 'App\\Http\\Controllers\\Api\\FlowTrackBulkQuoteTaskProgressController@__invoke',
        'controller' => 'App\\Http\\Controllers\\Api\\FlowTrackBulkQuoteTaskProgressController',
        'namespace' => NULL,
        'prefix' => 'api/integrations/flowtrack',
        'where' => 
        array (
        ),
        'as' => 'generated::x3R9lrUkk6iBK7gu',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
        'bulkQuote' => '[0-9]+',
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'generated::SsOnjmf9jUwdDi5k' => 
    array (
      'methods' => 
      array (
        0 => 'POST',
      ),
      'uri' => 'api/integrations/flowtrack/bulk-orders',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'api',
          1 => 'App\\Http\\Middleware\\VerifyFlowTrackIntegration',
          2 => 'throttle:120,1',
        ),
        'uses' => 'App\\Http\\Controllers\\Api\\FlowTrackBulkOrderController@store',
        'controller' => 'App\\Http\\Controllers\\Api\\FlowTrackBulkOrderController@store',
        'namespace' => NULL,
        'prefix' => 'api/integrations/flowtrack',
        'where' => 
        array (
        ),
        'as' => 'generated::SsOnjmf9jUwdDi5k',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'generated::iOJ7SenCuv4EjTTV' => 
    array (
      'methods' => 
      array (
        0 => 'POST',
      ),
      'uri' => 'api/integrations/flowtrack/orders/from-flowtrack',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'api',
          1 => 'App\\Http\\Middleware\\VerifyFlowTrackIntegration',
          2 => 'throttle:120,1',
        ),
        'uses' => 'App\\Http\\Controllers\\Api\\FlowTrackCreatedOrderController@store',
        'controller' => 'App\\Http\\Controllers\\Api\\FlowTrackCreatedOrderController@store',
        'namespace' => NULL,
        'prefix' => 'api/integrations/flowtrack',
        'where' => 
        array (
        ),
        'as' => 'generated::iOJ7SenCuv4EjTTV',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'generated::FJmCmozy8s8Y7SNk' => 
    array (
      'methods' => 
      array (
        0 => 'GET',
        1 => 'HEAD',
      ),
      'uri' => 'api/integrations/flowtrack/branding',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'api',
          1 => 'App\\Http\\Middleware\\VerifyFlowTrackIntegration',
          2 => 'throttle:60,1',
        ),
        'uses' => 'App\\Http\\Controllers\\Api\\FlowTrackBrandingController@__invoke',
        'controller' => 'App\\Http\\Controllers\\Api\\FlowTrackBrandingController',
        'namespace' => NULL,
        'prefix' => 'api',
        'where' => 
        array (
        ),
        'as' => 'generated::FJmCmozy8s8Y7SNk',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'generated::HimCZQFKUPnhD2wW' => 
    array (
      'methods' => 
      array (
        0 => 'POST',
      ),
      'uri' => 'api/integrations/flowtrack/artwork-proofs',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'api',
          1 => 'App\\Http\\Middleware\\VerifyFlowTrackIntegration',
          2 => 'throttle:120,1',
        ),
        'uses' => 'App\\Http\\Controllers\\Api\\FlowTrackArtworkReviewController@publish',
        'controller' => 'App\\Http\\Controllers\\Api\\FlowTrackArtworkReviewController@publish',
        'namespace' => NULL,
        'prefix' => 'api/integrations/flowtrack',
        'where' => 
        array (
        ),
        'as' => 'generated::HimCZQFKUPnhD2wW',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'generated::bCEB4smdpaTJtoOA' => 
    array (
      'methods' => 
      array (
        0 => 'POST',
      ),
      'uri' => 'api/integrations/flowtrack/artwork-proofs/{proof}/staff-messages',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'api',
          1 => 'App\\Http\\Middleware\\VerifyFlowTrackIntegration',
          2 => 'throttle:120,1',
        ),
        'uses' => 'App\\Http\\Controllers\\Api\\FlowTrackArtworkReviewController@staffMessage',
        'controller' => 'App\\Http\\Controllers\\Api\\FlowTrackArtworkReviewController@staffMessage',
        'namespace' => NULL,
        'prefix' => 'api/integrations/flowtrack',
        'where' => 
        array (
        ),
        'as' => 'generated::bCEB4smdpaTJtoOA',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
        'proof' => '[0-9]+',
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'generated::7OGEanJY1gzFn4LR' => 
    array (
      'methods' => 
      array (
        0 => 'GET',
        1 => 'HEAD',
      ),
      'uri' => 'api/integrations/flowtrack/artwork-proofs/{proof}/reference',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'api',
          1 => 'App\\Http\\Middleware\\VerifyFlowTrackIntegration',
          2 => 'throttle:120,1',
        ),
        'uses' => 'App\\Http\\Controllers\\Api\\FlowTrackArtworkReviewController@reference',
        'controller' => 'App\\Http\\Controllers\\Api\\FlowTrackArtworkReviewController@reference',
        'namespace' => NULL,
        'prefix' => 'api/integrations/flowtrack',
        'where' => 
        array (
        ),
        'as' => 'generated::7OGEanJY1gzFn4LR',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
        'proof' => '[0-9]+',
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'generated::d6gKHo5XrW8Q61sP' => 
    array (
      'methods' => 
      array (
        0 => 'GET',
        1 => 'HEAD',
      ),
      'uri' => 'up',
      'action' => 
      array (
        'uses' => 'O:55:"Laravel\\SerializableClosure\\UnsignedSerializableClosure":1:{s:12:"serializable";O:46:"Laravel\\SerializableClosure\\Serializers\\Native":5:{s:3:"use";a:0:{}s:8:"function";s:1160:"function (\\Illuminate\\Http\\Request $request) {
                    $exception = null;

                    try {
                        \\Illuminate\\Support\\Facades\\Event::dispatch(new \\Illuminate\\Foundation\\Events\\DiagnosingHealth);
                    } catch (\\Throwable $e) {
                        if (app()->hasDebugModeEnabled()) {
                            throw $e;
                        }

                        report($e);

                        $exception = $e->getMessage();
                    }

                    $status = $exception ? 500 : 200;

                    if ($request->expectsJson()) {
                        return response()->json([
                            \'status\' => $exception ? \'down\' : \'up\',
                        ], $status);
                    }

                    return response(\\Illuminate\\Support\\Facades\\View::file(\'/Applications/XAMPP/xamppfiles/htdocs/laravel/NextPlaySportswear/vendor/laravel/framework/src/Illuminate/Foundation/Configuration\'.\'/../resources/health-up.blade.php\', [
                        \'exception\' => $exception,
                    ]), status: $status);
                }";s:5:"scope";s:54:"Illuminate\\Foundation\\Configuration\\ApplicationBuilder";s:4:"this";N;s:4:"self";s:32:"0000000000000dda0000000000000000";}}',
        'as' => 'generated::d6gKHo5XrW8Q61sP',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'webhooks.stripe' => 
    array (
      'methods' => 
      array (
        0 => 'POST',
      ),
      'uri' => 'webhooks/stripe',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
        ),
        'uses' => 'App\\Http\\Controllers\\Webhooks\\StripeWebhookController@__invoke',
        'controller' => 'App\\Http\\Controllers\\Webhooks\\StripeWebhookController',
        'namespace' => NULL,
        'prefix' => '',
        'where' => 
        array (
        ),
        'as' => 'webhooks.stripe',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'payments.return' => 
    array (
      'methods' => 
      array (
        0 => 'GET',
        1 => 'HEAD',
      ),
      'uri' => 'payments/{provider}/return',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
        ),
        'uses' => 'App\\Http\\Controllers\\Payments\\PaymentReturnController@__invoke',
        'controller' => 'App\\Http\\Controllers\\Payments\\PaymentReturnController',
        'namespace' => NULL,
        'prefix' => '',
        'where' => 
        array (
        ),
        'as' => 'payments.return',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
        'provider' => '[a-z0-9-]+',
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'home' => 
    array (
      'methods' => 
      array (
        0 => 'GET',
        1 => 'HEAD',
      ),
      'uri' => '/',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
        ),
        'uses' => 'App\\Http\\Controllers\\Storefront\\HomeController@__invoke',
        'controller' => 'App\\Http\\Controllers\\Storefront\\HomeController',
        'namespace' => NULL,
        'prefix' => '',
        'where' => 
        array (
        ),
        'as' => 'home',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'referral.offer' => 
    array (
      'methods' => 
      array (
        0 => 'GET',
        1 => 'HEAD',
      ),
      'uri' => 'referral/{token}',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'throttle:60,1',
        ),
        'uses' => 'App\\Http\\Controllers\\Storefront\\ReferralOfferController@show',
        'controller' => 'App\\Http\\Controllers\\Storefront\\ReferralOfferController@show',
        'namespace' => NULL,
        'prefix' => '',
        'where' => 
        array (
        ),
        'as' => 'referral.offer',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
        'token' => '[A-Za-z0-9_-]+',
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'home.latest-products' => 
    array (
      'methods' => 
      array (
        0 => 'GET',
        1 => 'HEAD',
      ),
      'uri' => 'homepage/latest-products',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'throttle:120,1',
        ),
        'uses' => 'App\\Http\\Controllers\\Storefront\\HomeController@latestProducts',
        'controller' => 'App\\Http\\Controllers\\Storefront\\HomeController@latestProducts',
        'namespace' => NULL,
        'prefix' => '',
        'where' => 
        array (
        ),
        'as' => 'home.latest-products',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'sitemap' => 
    array (
      'methods' => 
      array (
        0 => 'GET',
        1 => 'HEAD',
      ),
      'uri' => 'sitemap.xml',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
        ),
        'uses' => 'App\\Http\\Controllers\\Storefront\\SitemapController@__invoke',
        'controller' => 'App\\Http\\Controllers\\Storefront\\SitemapController',
        'namespace' => NULL,
        'prefix' => '',
        'where' => 
        array (
        ),
        'as' => 'sitemap',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'products.visitor-activity' => 
    array (
      'methods' => 
      array (
        0 => 'POST',
      ),
      'uri' => 'products/visitor-activity',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'throttle:120,1',
        ),
        'uses' => 'App\\Http\\Controllers\\Storefront\\ProductActivityController@track',
        'controller' => 'App\\Http\\Controllers\\Storefront\\ProductActivityController@track',
        'namespace' => NULL,
        'prefix' => '',
        'where' => 
        array (
        ),
        'as' => 'products.visitor-activity',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'media.public' => 
    array (
      'methods' => 
      array (
        0 => 'GET',
        1 => 'HEAD',
      ),
      'uri' => 'media/{path}',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
        ),
        'uses' => 'App\\Http\\Controllers\\PublicMediaController@show',
        'controller' => 'App\\Http\\Controllers\\PublicMediaController@show',
        'namespace' => NULL,
        'prefix' => '',
        'where' => 
        array (
        ),
        'as' => 'media.public',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
        'path' => '.*',
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'about' => 
    array (
      'methods' => 
      array (
        0 => 'GET',
        1 => 'HEAD',
      ),
      'uri' => 'about-us',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
        ),
        'uses' => 'App\\Http\\Controllers\\Storefront\\ContentPageController@about',
        'controller' => 'App\\Http\\Controllers\\Storefront\\ContentPageController@about',
        'namespace' => NULL,
        'prefix' => '',
        'where' => 
        array (
        ),
        'as' => 'about',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'contact' => 
    array (
      'methods' => 
      array (
        0 => 'GET',
        1 => 'HEAD',
      ),
      'uri' => 'contact-us',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
        ),
        'uses' => 'App\\Http\\Controllers\\Storefront\\ContactController@index',
        'controller' => 'App\\Http\\Controllers\\Storefront\\ContactController@index',
        'namespace' => NULL,
        'prefix' => '',
        'where' => 
        array (
        ),
        'as' => 'contact',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'contact.store' => 
    array (
      'methods' => 
      array (
        0 => 'POST',
      ),
      'uri' => 'contact-us',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'throttle:contact',
        ),
        'uses' => 'App\\Http\\Controllers\\Storefront\\ContactController@store',
        'controller' => 'App\\Http\\Controllers\\Storefront\\ContactController@store',
        'namespace' => NULL,
        'prefix' => '',
        'where' => 
        array (
        ),
        'as' => 'contact.store',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'newsletter.store' => 
    array (
      'methods' => 
      array (
        0 => 'POST',
      ),
      'uri' => 'newsletter',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'throttle:6,1',
        ),
        'uses' => 'App\\Http\\Controllers\\Storefront\\NewsletterController@store',
        'controller' => 'App\\Http\\Controllers\\Storefront\\NewsletterController@store',
        'namespace' => NULL,
        'prefix' => '',
        'where' => 
        array (
        ),
        'as' => 'newsletter.store',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'faq' => 
    array (
      'methods' => 
      array (
        0 => 'GET',
        1 => 'HEAD',
      ),
      'uri' => 'help-center',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
        ),
        'uses' => 'App\\Http\\Controllers\\Storefront\\ContentPageController@faq',
        'controller' => 'App\\Http\\Controllers\\Storefront\\ContentPageController@faq',
        'namespace' => NULL,
        'prefix' => '',
        'where' => 
        array (
        ),
        'as' => 'faq',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'testimonials.index' => 
    array (
      'methods' => 
      array (
        0 => 'GET',
        1 => 'HEAD',
      ),
      'uri' => 'testimonials',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
        ),
        'uses' => 'App\\Http\\Controllers\\Storefront\\ContentPageController@testimonials',
        'controller' => 'App\\Http\\Controllers\\Storefront\\ContentPageController@testimonials',
        'namespace' => NULL,
        'prefix' => '',
        'where' => 
        array (
        ),
        'as' => 'testimonials.index',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'how-to-order' => 
    array (
      'methods' => 
      array (
        0 => 'GET',
        1 => 'HEAD',
      ),
      'uri' => 'how-to-order',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
        ),
        'uses' => 'App\\Http\\Controllers\\Storefront\\ContentPageController@howToOrder',
        'controller' => 'App\\Http\\Controllers\\Storefront\\ContentPageController@howToOrder',
        'namespace' => NULL,
        'prefix' => '',
        'where' => 
        array (
        ),
        'as' => 'how-to-order',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'size-guide' => 
    array (
      'methods' => 
      array (
        0 => 'GET',
        1 => 'HEAD',
      ),
      'uri' => 'size-guide',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
        ),
        'uses' => 'App\\Http\\Controllers\\Storefront\\ContentPageController@sizeGuide',
        'controller' => 'App\\Http\\Controllers\\Storefront\\ContentPageController@sizeGuide',
        'namespace' => NULL,
        'prefix' => '',
        'where' => 
        array (
        ),
        'as' => 'size-guide',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'artwork-guidelines' => 
    array (
      'methods' => 
      array (
        0 => 'GET',
        1 => 'HEAD',
      ),
      'uri' => 'artwork-guidelines',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
        ),
        'uses' => 'App\\Http\\Controllers\\Storefront\\ContentPageController@artworkGuidelines',
        'controller' => 'App\\Http\\Controllers\\Storefront\\ContentPageController@artworkGuidelines',
        'namespace' => NULL,
        'prefix' => '',
        'where' => 
        array (
        ),
        'as' => 'artwork-guidelines',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'customization-guide' => 
    array (
      'methods' => 
      array (
        0 => 'GET',
        1 => 'HEAD',
      ),
      'uri' => 'customization-guide',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
        ),
        'uses' => 'App\\Http\\Controllers\\Storefront\\ContentPageController@customizationGuide',
        'controller' => 'App\\Http\\Controllers\\Storefront\\ContentPageController@customizationGuide',
        'namespace' => NULL,
        'prefix' => '',
        'where' => 
        array (
        ),
        'as' => 'customization-guide',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'bulk-ordering' => 
    array (
      'methods' => 
      array (
        0 => 'GET',
        1 => 'HEAD',
      ),
      'uri' => 'bulk-team-ordering',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
        ),
        'uses' => 'App\\Http\\Controllers\\Storefront\\ContentPageController@bulkOrdering',
        'controller' => 'App\\Http\\Controllers\\Storefront\\ContentPageController@bulkOrdering',
        'namespace' => NULL,
        'prefix' => '',
        'where' => 
        array (
        ),
        'as' => 'bulk-ordering',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'quote.request' => 
    array (
      'methods' => 
      array (
        0 => 'GET',
        1 => 'HEAD',
      ),
      'uri' => 'bulk-quote',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
        ),
        'uses' => 'App\\Http\\Controllers\\Storefront\\BulkQuoteController@create',
        'controller' => 'App\\Http\\Controllers\\Storefront\\BulkQuoteController@create',
        'namespace' => NULL,
        'prefix' => '',
        'where' => 
        array (
        ),
        'as' => 'quote.request',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'quote.request.store' => 
    array (
      'methods' => 
      array (
        0 => 'POST',
      ),
      'uri' => 'bulk-quote',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'throttle:bulk-quote',
        ),
        'uses' => 'App\\Http\\Controllers\\Storefront\\BulkQuoteController@store',
        'controller' => 'App\\Http\\Controllers\\Storefront\\BulkQuoteController@store',
        'namespace' => NULL,
        'prefix' => '',
        'where' => 
        array (
        ),
        'as' => 'quote.request.store',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'quote.guest.track' => 
    array (
      'methods' => 
      array (
        0 => 'GET',
        1 => 'HEAD',
      ),
      'uri' => 'bulk-quote/track',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'App\\Http\\Middleware\\PrivateGuestQuoteResponse',
        ),
        'uses' => 'App\\Http\\Controllers\\Storefront\\GuestBulkQuoteController@track',
        'controller' => 'App\\Http\\Controllers\\Storefront\\GuestBulkQuoteController@track',
        'namespace' => NULL,
        'prefix' => '',
        'where' => 
        array (
        ),
        'as' => 'quote.guest.track',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'quote.guest.lookup' => 
    array (
      'methods' => 
      array (
        0 => 'POST',
      ),
      'uri' => 'bulk-quote/track',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'App\\Http\\Middleware\\PrivateGuestQuoteResponse',
          2 => 'throttle:10,1',
        ),
        'uses' => 'App\\Http\\Controllers\\Storefront\\GuestBulkQuoteController@lookup',
        'controller' => 'App\\Http\\Controllers\\Storefront\\GuestBulkQuoteController@lookup',
        'namespace' => NULL,
        'prefix' => '',
        'where' => 
        array (
        ),
        'as' => 'quote.guest.lookup',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'quote.guest.success' => 
    array (
      'methods' => 
      array (
        0 => 'GET',
        1 => 'HEAD',
      ),
      'uri' => 'bulk-quote/track/{reference}/submitted',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'App\\Http\\Middleware\\PrivateGuestQuoteResponse',
          2 => 'throttle:60,1',
        ),
        'uses' => 'App\\Http\\Controllers\\Storefront\\GuestBulkQuoteController@success',
        'controller' => 'App\\Http\\Controllers\\Storefront\\GuestBulkQuoteController@success',
        'namespace' => NULL,
        'prefix' => '',
        'where' => 
        array (
        ),
        'as' => 'quote.guest.success',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'quote.guest.show' => 
    array (
      'methods' => 
      array (
        0 => 'GET',
        1 => 'HEAD',
      ),
      'uri' => 'bulk-quote/track/{reference}',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'App\\Http\\Middleware\\PrivateGuestQuoteResponse',
          2 => 'throttle:60,1',
        ),
        'uses' => 'App\\Http\\Controllers\\Storefront\\GuestBulkQuoteController@show',
        'controller' => 'App\\Http\\Controllers\\Storefront\\GuestBulkQuoteController@show',
        'namespace' => NULL,
        'prefix' => '',
        'where' => 
        array (
        ),
        'as' => 'quote.guest.show',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'quote.guest.review' => 
    array (
      'methods' => 
      array (
        0 => 'GET',
        1 => 'HEAD',
      ),
      'uri' => 'bulk-quote/track/{reference}/review',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'App\\Http\\Middleware\\PrivateGuestQuoteResponse',
          2 => 'throttle:60,1',
        ),
        'uses' => 'App\\Http\\Controllers\\Storefront\\GuestBulkQuoteController@review',
        'controller' => 'App\\Http\\Controllers\\Storefront\\GuestBulkQuoteController@review',
        'namespace' => NULL,
        'prefix' => '',
        'where' => 
        array (
        ),
        'as' => 'quote.guest.review',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'quote.guest.changes' => 
    array (
      'methods' => 
      array (
        0 => 'GET',
        1 => 'HEAD',
      ),
      'uri' => 'bulk-quote/track/{reference}/changes',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'App\\Http\\Middleware\\PrivateGuestQuoteResponse',
          2 => 'throttle:60,1',
        ),
        'uses' => 'App\\Http\\Controllers\\Storefront\\GuestBulkQuoteController@changes',
        'controller' => 'App\\Http\\Controllers\\Storefront\\GuestBulkQuoteController@changes',
        'namespace' => NULL,
        'prefix' => '',
        'where' => 
        array (
        ),
        'as' => 'quote.guest.changes',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'quote.guest.changes.send' => 
    array (
      'methods' => 
      array (
        0 => 'POST',
      ),
      'uri' => 'bulk-quote/track/{reference}/changes',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'App\\Http\\Middleware\\PrivateGuestQuoteResponse',
          2 => 'throttle:6,1',
        ),
        'uses' => 'App\\Http\\Controllers\\Storefront\\GuestBulkQuoteController@sendChanges',
        'controller' => 'App\\Http\\Controllers\\Storefront\\GuestBulkQuoteController@sendChanges',
        'namespace' => NULL,
        'prefix' => '',
        'where' => 
        array (
        ),
        'as' => 'quote.guest.changes.send',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'quote.guest.message' => 
    array (
      'methods' => 
      array (
        0 => 'POST',
      ),
      'uri' => 'bulk-quote/track/{reference}/message',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'App\\Http\\Middleware\\PrivateGuestQuoteResponse',
          2 => 'throttle:quote-message',
        ),
        'uses' => 'App\\Http\\Controllers\\Storefront\\GuestBulkQuoteController@sendMessage',
        'controller' => 'App\\Http\\Controllers\\Storefront\\GuestBulkQuoteController@sendMessage',
        'namespace' => NULL,
        'prefix' => '',
        'where' => 
        array (
        ),
        'as' => 'quote.guest.message',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'quote.guest.decision' => 
    array (
      'methods' => 
      array (
        0 => 'POST',
      ),
      'uri' => 'bulk-quote/track/{reference}/decision',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'App\\Http\\Middleware\\PrivateGuestQuoteResponse',
          2 => 'throttle:guest-quote-decision',
        ),
        'uses' => 'App\\Http\\Controllers\\Storefront\\GuestBulkQuoteController@decision',
        'controller' => 'App\\Http\\Controllers\\Storefront\\GuestBulkQuoteController@decision',
        'namespace' => NULL,
        'prefix' => '',
        'where' => 
        array (
        ),
        'as' => 'quote.guest.decision',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'quote.guest.file' => 
    array (
      'methods' => 
      array (
        0 => 'GET',
        1 => 'HEAD',
      ),
      'uri' => 'bulk-quote/track/{reference}/file/{file}',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'App\\Http\\Middleware\\PrivateGuestQuoteResponse',
          2 => 'throttle:30,1',
        ),
        'uses' => 'App\\Http\\Controllers\\Storefront\\GuestBulkQuoteController@file',
        'controller' => 'App\\Http\\Controllers\\Storefront\\GuestBulkQuoteController@file',
        'namespace' => NULL,
        'prefix' => '',
        'where' => 
        array (
        ),
        'as' => 'quote.guest.file',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'shipping' => 
    array (
      'methods' => 
      array (
        0 => 'GET',
        1 => 'HEAD',
      ),
      'uri' => 'shipping-delivery',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
        ),
        'uses' => 'App\\Http\\Controllers\\Storefront\\ContentPageController@shipping',
        'controller' => 'App\\Http\\Controllers\\Storefront\\ContentPageController@shipping',
        'namespace' => NULL,
        'prefix' => '',
        'where' => 
        array (
        ),
        'as' => 'shipping',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'sustainability' => 
    array (
      'methods' => 
      array (
        0 => 'GET',
        1 => 'HEAD',
      ),
      'uri' => 'sustainability',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
        ),
        'uses' => 'App\\Http\\Controllers\\Storefront\\ContentPageController@sustainability',
        'controller' => 'App\\Http\\Controllers\\Storefront\\ContentPageController@sustainability',
        'namespace' => NULL,
        'prefix' => '',
        'where' => 
        array (
        ),
        'as' => 'sustainability',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'returns' => 
    array (
      'methods' => 
      array (
        0 => 'GET',
        1 => 'HEAD',
      ),
      'uri' => 'returns-refunds-exchanges',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
        ),
        'uses' => 'App\\Http\\Controllers\\Storefront\\ContentPageController@returns',
        'controller' => 'App\\Http\\Controllers\\Storefront\\ContentPageController@returns',
        'namespace' => NULL,
        'prefix' => '',
        'where' => 
        array (
        ),
        'as' => 'returns',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'payment-information' => 
    array (
      'methods' => 
      array (
        0 => 'GET',
        1 => 'HEAD',
      ),
      'uri' => 'payment-information',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
        ),
        'uses' => 'App\\Http\\Controllers\\Storefront\\ContentPageController@payment',
        'controller' => 'App\\Http\\Controllers\\Storefront\\ContentPageController@payment',
        'namespace' => NULL,
        'prefix' => '',
        'where' => 
        array (
        ),
        'as' => 'payment-information',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'privacy' => 
    array (
      'methods' => 
      array (
        0 => 'GET',
        1 => 'HEAD',
      ),
      'uri' => 'privacy-policy',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
        ),
        'uses' => 'App\\Http\\Controllers\\Storefront\\ContentPageController@privacy',
        'controller' => 'App\\Http\\Controllers\\Storefront\\ContentPageController@privacy',
        'namespace' => NULL,
        'prefix' => '',
        'where' => 
        array (
        ),
        'as' => 'privacy',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'terms' => 
    array (
      'methods' => 
      array (
        0 => 'GET',
        1 => 'HEAD',
      ),
      'uri' => 'terms-conditions',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
        ),
        'uses' => 'App\\Http\\Controllers\\Storefront\\ContentPageController@terms',
        'controller' => 'App\\Http\\Controllers\\Storefront\\ContentPageController@terms',
        'namespace' => NULL,
        'prefix' => '',
        'where' => 
        array (
        ),
        'as' => 'terms',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'cookies' => 
    array (
      'methods' => 
      array (
        0 => 'GET',
        1 => 'HEAD',
      ),
      'uri' => 'cookie-policy',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
        ),
        'uses' => 'App\\Http\\Controllers\\Storefront\\ContentPageController@cookies',
        'controller' => 'App\\Http\\Controllers\\Storefront\\ContentPageController@cookies',
        'namespace' => NULL,
        'prefix' => '',
        'where' => 
        array (
        ),
        'as' => 'cookies',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'accessibility' => 
    array (
      'methods' => 
      array (
        0 => 'GET',
        1 => 'HEAD',
      ),
      'uri' => 'accessibility',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
        ),
        'uses' => 'App\\Http\\Controllers\\Storefront\\ContentPageController@accessibility',
        'controller' => 'App\\Http\\Controllers\\Storefront\\ContentPageController@accessibility',
        'namespace' => NULL,
        'prefix' => '',
        'where' => 
        array (
        ),
        'as' => 'accessibility',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'generated::TmikGhq4CfJLNLRb' => 
    array (
      'methods' => 
      array (
        0 => 'GET',
        1 => 'HEAD',
        2 => 'POST',
        3 => 'PUT',
        4 => 'PATCH',
        5 => 'DELETE',
        6 => 'OPTIONS',
      ),
      'uri' => 'about',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
        ),
        'uses' => '\\Illuminate\\Routing\\RedirectController@__invoke',
        'controller' => '\\Illuminate\\Routing\\RedirectController',
        'namespace' => NULL,
        'prefix' => '',
        'where' => 
        array (
        ),
        'as' => 'generated::TmikGhq4CfJLNLRb',
      ),
      'fallback' => false,
      'defaults' => 
      array (
        'destination' => '/about-us',
        'status' => 301,
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'generated::mLRRPFz02HhGoWWx' => 
    array (
      'methods' => 
      array (
        0 => 'GET',
        1 => 'HEAD',
        2 => 'POST',
        3 => 'PUT',
        4 => 'PATCH',
        5 => 'DELETE',
        6 => 'OPTIONS',
      ),
      'uri' => 'contact',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
        ),
        'uses' => '\\Illuminate\\Routing\\RedirectController@__invoke',
        'controller' => '\\Illuminate\\Routing\\RedirectController',
        'namespace' => NULL,
        'prefix' => '',
        'where' => 
        array (
        ),
        'as' => 'generated::mLRRPFz02HhGoWWx',
      ),
      'fallback' => false,
      'defaults' => 
      array (
        'destination' => '/contact-us',
        'status' => 301,
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'generated::srLUzAxZM00g5Ov8' => 
    array (
      'methods' => 
      array (
        0 => 'GET',
        1 => 'HEAD',
        2 => 'POST',
        3 => 'PUT',
        4 => 'PATCH',
        5 => 'DELETE',
        6 => 'OPTIONS',
      ),
      'uri' => 'faq',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
        ),
        'uses' => '\\Illuminate\\Routing\\RedirectController@__invoke',
        'controller' => '\\Illuminate\\Routing\\RedirectController',
        'namespace' => NULL,
        'prefix' => '',
        'where' => 
        array (
        ),
        'as' => 'generated::srLUzAxZM00g5Ov8',
      ),
      'fallback' => false,
      'defaults' => 
      array (
        'destination' => '/help-center',
        'status' => 301,
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'generated::fnWuKrBT0k5OXhFf' => 
    array (
      'methods' => 
      array (
        0 => 'GET',
        1 => 'HEAD',
        2 => 'POST',
        3 => 'PUT',
        4 => 'PATCH',
        5 => 'DELETE',
        6 => 'OPTIONS',
      ),
      'uri' => 'help',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
        ),
        'uses' => '\\Illuminate\\Routing\\RedirectController@__invoke',
        'controller' => '\\Illuminate\\Routing\\RedirectController',
        'namespace' => NULL,
        'prefix' => '',
        'where' => 
        array (
        ),
        'as' => 'generated::fnWuKrBT0k5OXhFf',
      ),
      'fallback' => false,
      'defaults' => 
      array (
        'destination' => '/help-center',
        'status' => 301,
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'generated::OLCEuHaGyr27tnkS' => 
    array (
      'methods' => 
      array (
        0 => 'GET',
        1 => 'HEAD',
        2 => 'POST',
        3 => 'PUT',
        4 => 'PATCH',
        5 => 'DELETE',
        6 => 'OPTIONS',
      ),
      'uri' => 'shipping',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
        ),
        'uses' => '\\Illuminate\\Routing\\RedirectController@__invoke',
        'controller' => '\\Illuminate\\Routing\\RedirectController',
        'namespace' => NULL,
        'prefix' => '',
        'where' => 
        array (
        ),
        'as' => 'generated::OLCEuHaGyr27tnkS',
      ),
      'fallback' => false,
      'defaults' => 
      array (
        'destination' => '/shipping-delivery',
        'status' => 301,
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'generated::IrBCmyABD70rq2MK' => 
    array (
      'methods' => 
      array (
        0 => 'GET',
        1 => 'HEAD',
        2 => 'POST',
        3 => 'PUT',
        4 => 'PATCH',
        5 => 'DELETE',
        6 => 'OPTIONS',
      ),
      'uri' => 'returns',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
        ),
        'uses' => '\\Illuminate\\Routing\\RedirectController@__invoke',
        'controller' => '\\Illuminate\\Routing\\RedirectController',
        'namespace' => NULL,
        'prefix' => '',
        'where' => 
        array (
        ),
        'as' => 'generated::IrBCmyABD70rq2MK',
      ),
      'fallback' => false,
      'defaults' => 
      array (
        'destination' => '/returns-refunds-exchanges',
        'status' => 301,
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'generated::oCHOdAuCpIXEnM2f' => 
    array (
      'methods' => 
      array (
        0 => 'GET',
        1 => 'HEAD',
        2 => 'POST',
        3 => 'PUT',
        4 => 'PATCH',
        5 => 'DELETE',
        6 => 'OPTIONS',
      ),
      'uri' => 'privacy',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
        ),
        'uses' => '\\Illuminate\\Routing\\RedirectController@__invoke',
        'controller' => '\\Illuminate\\Routing\\RedirectController',
        'namespace' => NULL,
        'prefix' => '',
        'where' => 
        array (
        ),
        'as' => 'generated::oCHOdAuCpIXEnM2f',
      ),
      'fallback' => false,
      'defaults' => 
      array (
        'destination' => '/privacy-policy',
        'status' => 301,
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'generated::OB9tfvae8bb1KgDb' => 
    array (
      'methods' => 
      array (
        0 => 'GET',
        1 => 'HEAD',
        2 => 'POST',
        3 => 'PUT',
        4 => 'PATCH',
        5 => 'DELETE',
        6 => 'OPTIONS',
      ),
      'uri' => 'terms',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
        ),
        'uses' => '\\Illuminate\\Routing\\RedirectController@__invoke',
        'controller' => '\\Illuminate\\Routing\\RedirectController',
        'namespace' => NULL,
        'prefix' => '',
        'where' => 
        array (
        ),
        'as' => 'generated::OB9tfvae8bb1KgDb',
      ),
      'fallback' => false,
      'defaults' => 
      array (
        'destination' => '/terms-conditions',
        'status' => 301,
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'generated::yfT3dURg3fL15Awu' => 
    array (
      'methods' => 
      array (
        0 => 'GET',
        1 => 'HEAD',
        2 => 'POST',
        3 => 'PUT',
        4 => 'PATCH',
        5 => 'DELETE',
        6 => 'OPTIONS',
      ),
      'uri' => 'cookies',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
        ),
        'uses' => '\\Illuminate\\Routing\\RedirectController@__invoke',
        'controller' => '\\Illuminate\\Routing\\RedirectController',
        'namespace' => NULL,
        'prefix' => '',
        'where' => 
        array (
        ),
        'as' => 'generated::yfT3dURg3fL15Awu',
      ),
      'fallback' => false,
      'defaults' => 
      array (
        'destination' => '/cookie-policy',
        'status' => 301,
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'generated::YX5QHxsmehzvodQe' => 
    array (
      'methods' => 
      array (
        0 => 'GET',
        1 => 'HEAD',
        2 => 'POST',
        3 => 'PUT',
        4 => 'PATCH',
        5 => 'DELETE',
        6 => 'OPTIONS',
      ),
      'uri' => 'accessibility-statement',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
        ),
        'uses' => '\\Illuminate\\Routing\\RedirectController@__invoke',
        'controller' => '\\Illuminate\\Routing\\RedirectController',
        'namespace' => NULL,
        'prefix' => '',
        'where' => 
        array (
        ),
        'as' => 'generated::YX5QHxsmehzvodQe',
      ),
      'fallback' => false,
      'defaults' => 
      array (
        'destination' => '/accessibility',
        'status' => 301,
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'admin.login' => 
    array (
      'methods' => 
      array (
        0 => 'GET',
        1 => 'HEAD',
      ),
      'uri' => 'admin/login',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'admin.hidden',
        ),
        'uses' => 'App\\Http\\Controllers\\Admin\\Auth\\AdminSessionController@create',
        'controller' => 'App\\Http\\Controllers\\Admin\\Auth\\AdminSessionController@create',
        'as' => 'admin.login',
        'namespace' => NULL,
        'prefix' => '/admin',
        'where' => 
        array (
        ),
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'admin.login.store' => 
    array (
      'methods' => 
      array (
        0 => 'POST',
      ),
      'uri' => 'admin/login',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'admin.hidden',
          2 => 'throttle:admin-login',
        ),
        'uses' => 'App\\Http\\Controllers\\Admin\\Auth\\AdminSessionController@store',
        'controller' => 'App\\Http\\Controllers\\Admin\\Auth\\AdminSessionController@store',
        'as' => 'admin.login.store',
        'namespace' => NULL,
        'prefix' => '/admin',
        'where' => 
        array (
        ),
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'admin.dashboard' => 
    array (
      'methods' => 
      array (
        0 => 'GET',
        1 => 'HEAD',
      ),
      'uri' => 'admin',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'admin.hidden',
          2 => 'auth:admin',
          3 => 'admin',
          4 => 'admin.permission',
          5 => 'admin.activity',
        ),
        'uses' => 'App\\Http\\Controllers\\Admin\\DashboardController@__invoke',
        'controller' => 'App\\Http\\Controllers\\Admin\\DashboardController',
        'as' => 'admin.dashboard',
        'namespace' => NULL,
        'prefix' => '/admin',
        'where' => 
        array (
        ),
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'admin.logout' => 
    array (
      'methods' => 
      array (
        0 => 'POST',
      ),
      'uri' => 'admin/logout',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'admin.hidden',
          2 => 'auth:admin',
          3 => 'admin',
          4 => 'admin.permission',
          5 => 'admin.activity',
        ),
        'uses' => 'App\\Http\\Controllers\\Admin\\Auth\\AdminSessionController@destroy',
        'controller' => 'App\\Http\\Controllers\\Admin\\Auth\\AdminSessionController@destroy',
        'as' => 'admin.logout',
        'namespace' => NULL,
        'prefix' => '/admin',
        'where' => 
        array (
        ),
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'admin.notifications.index' => 
    array (
      'methods' => 
      array (
        0 => 'GET',
        1 => 'HEAD',
      ),
      'uri' => 'admin/notifications',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'admin.hidden',
          2 => 'auth:admin',
          3 => 'admin',
          4 => 'admin.permission',
          5 => 'admin.activity',
        ),
        'uses' => 'App\\Http\\Controllers\\Admin\\NotificationController@index',
        'controller' => 'App\\Http\\Controllers\\Admin\\NotificationController@index',
        'as' => 'admin.notifications.index',
        'namespace' => NULL,
        'prefix' => '/admin',
        'where' => 
        array (
        ),
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'admin.notifications.feed' => 
    array (
      'methods' => 
      array (
        0 => 'GET',
        1 => 'HEAD',
      ),
      'uri' => 'admin/notifications/feed',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'admin.hidden',
          2 => 'auth:admin',
          3 => 'admin',
          4 => 'admin.permission',
          5 => 'admin.activity',
        ),
        'uses' => 'App\\Http\\Controllers\\Admin\\NotificationController@feed',
        'controller' => 'App\\Http\\Controllers\\Admin\\NotificationController@feed',
        'as' => 'admin.notifications.feed',
        'namespace' => NULL,
        'prefix' => '/admin',
        'where' => 
        array (
        ),
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'admin.notifications.read-all' => 
    array (
      'methods' => 
      array (
        0 => 'POST',
      ),
      'uri' => 'admin/notifications/read-all',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'admin.hidden',
          2 => 'auth:admin',
          3 => 'admin',
          4 => 'admin.permission',
          5 => 'admin.activity',
        ),
        'uses' => 'App\\Http\\Controllers\\Admin\\NotificationController@markAllRead',
        'controller' => 'App\\Http\\Controllers\\Admin\\NotificationController@markAllRead',
        'as' => 'admin.notifications.read-all',
        'namespace' => NULL,
        'prefix' => '/admin',
        'where' => 
        array (
        ),
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'admin.notifications.read' => 
    array (
      'methods' => 
      array (
        0 => 'POST',
      ),
      'uri' => 'admin/notifications/{notification}/read',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'admin.hidden',
          2 => 'auth:admin',
          3 => 'admin',
          4 => 'admin.permission',
          5 => 'admin.activity',
        ),
        'uses' => 'App\\Http\\Controllers\\Admin\\NotificationController@markRead',
        'controller' => 'App\\Http\\Controllers\\Admin\\NotificationController@markRead',
        'as' => 'admin.notifications.read',
        'namespace' => NULL,
        'prefix' => '/admin',
        'where' => 
        array (
        ),
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'admin.notifications.pusher-auth' => 
    array (
      'methods' => 
      array (
        0 => 'POST',
      ),
      'uri' => 'admin/notifications/pusher/auth',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'admin.hidden',
          2 => 'auth:admin',
          3 => 'admin',
          4 => 'admin.permission',
          5 => 'admin.activity',
        ),
        'uses' => 'App\\Http\\Controllers\\Admin\\NotificationController@pusherAuth',
        'controller' => 'App\\Http\\Controllers\\Admin\\NotificationController@pusherAuth',
        'as' => 'admin.notifications.pusher-auth',
        'namespace' => NULL,
        'prefix' => '/admin',
        'where' => 
        array (
        ),
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'admin.newsletter-subscribers.index' => 
    array (
      'methods' => 
      array (
        0 => 'GET',
        1 => 'HEAD',
      ),
      'uri' => 'admin/newsletter-subscribers',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'admin.hidden',
          2 => 'auth:admin',
          3 => 'admin',
          4 => 'admin.permission',
          5 => 'admin.activity',
        ),
        'uses' => 'App\\Http\\Controllers\\Admin\\NewsletterSubscriberController@index',
        'controller' => 'App\\Http\\Controllers\\Admin\\NewsletterSubscriberController@index',
        'as' => 'admin.newsletter-subscribers.index',
        'namespace' => NULL,
        'prefix' => '/admin',
        'where' => 
        array (
        ),
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'admin.newsletter-subscribers.export' => 
    array (
      'methods' => 
      array (
        0 => 'GET',
        1 => 'HEAD',
      ),
      'uri' => 'admin/newsletter-subscribers/export',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'admin.hidden',
          2 => 'auth:admin',
          3 => 'admin',
          4 => 'admin.permission',
          5 => 'admin.activity',
        ),
        'uses' => 'App\\Http\\Controllers\\Admin\\NewsletterSubscriberController@export',
        'controller' => 'App\\Http\\Controllers\\Admin\\NewsletterSubscriberController@export',
        'as' => 'admin.newsletter-subscribers.export',
        'namespace' => NULL,
        'prefix' => '/admin',
        'where' => 
        array (
        ),
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'admin.media-library.index' => 
    array (
      'methods' => 
      array (
        0 => 'GET',
        1 => 'HEAD',
      ),
      'uri' => 'admin/media-library',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'admin.hidden',
          2 => 'auth:admin',
          3 => 'admin',
          4 => 'admin.permission',
          5 => 'admin.activity',
        ),
        'uses' => 'App\\Http\\Controllers\\Admin\\MediaLibraryController@index',
        'controller' => 'App\\Http\\Controllers\\Admin\\MediaLibraryController@index',
        'as' => 'admin.media-library.index',
        'namespace' => NULL,
        'prefix' => '/admin',
        'where' => 
        array (
        ),
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'admin.media-library.upload' => 
    array (
      'methods' => 
      array (
        0 => 'GET',
        1 => 'HEAD',
      ),
      'uri' => 'admin/media-library/upload',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'admin.hidden',
          2 => 'auth:admin',
          3 => 'admin',
          4 => 'admin.permission',
          5 => 'admin.activity',
        ),
        'uses' => 'App\\Http\\Controllers\\Admin\\MediaLibraryController@upload',
        'controller' => 'App\\Http\\Controllers\\Admin\\MediaLibraryController@upload',
        'as' => 'admin.media-library.upload',
        'namespace' => NULL,
        'prefix' => '/admin',
        'where' => 
        array (
        ),
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'admin.media-library.update' => 
    array (
      'methods' => 
      array (
        0 => 'PATCH',
      ),
      'uri' => 'admin/media-library/{media}',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'admin.hidden',
          2 => 'auth:admin',
          3 => 'admin',
          4 => 'admin.permission',
          5 => 'admin.activity',
        ),
        'uses' => 'App\\Http\\Controllers\\Admin\\MediaLibraryController@update',
        'controller' => 'App\\Http\\Controllers\\Admin\\MediaLibraryController@update',
        'as' => 'admin.media-library.update',
        'namespace' => NULL,
        'prefix' => '/admin',
        'where' => 
        array (
        ),
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'admin.media-library.destroy' => 
    array (
      'methods' => 
      array (
        0 => 'DELETE',
      ),
      'uri' => 'admin/media-library/{media}',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'admin.hidden',
          2 => 'auth:admin',
          3 => 'admin',
          4 => 'admin.permission',
          5 => 'admin.activity',
        ),
        'uses' => 'App\\Http\\Controllers\\Admin\\MediaLibraryController@destroy',
        'controller' => 'App\\Http\\Controllers\\Admin\\MediaLibraryController@destroy',
        'as' => 'admin.media-library.destroy',
        'namespace' => NULL,
        'prefix' => '/admin',
        'where' => 
        array (
        ),
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'admin.media-library.download' => 
    array (
      'methods' => 
      array (
        0 => 'GET',
        1 => 'HEAD',
      ),
      'uri' => 'admin/media-library/{media}/download',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'admin.hidden',
          2 => 'auth:admin',
          3 => 'admin',
          4 => 'admin.permission',
          5 => 'admin.activity',
        ),
        'uses' => 'App\\Http\\Controllers\\Admin\\MediaLibraryController@download',
        'controller' => 'App\\Http\\Controllers\\Admin\\MediaLibraryController@download',
        'as' => 'admin.media-library.download',
        'namespace' => NULL,
        'prefix' => '/admin',
        'where' => 
        array (
        ),
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'admin.media-library.preview' => 
    array (
      'methods' => 
      array (
        0 => 'GET',
        1 => 'HEAD',
      ),
      'uri' => 'admin/media-library/{media}/preview',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'admin.hidden',
          2 => 'auth:admin',
          3 => 'admin',
          4 => 'admin.permission',
          5 => 'admin.activity',
        ),
        'uses' => 'App\\Http\\Controllers\\Admin\\MediaLibraryController@preview',
        'controller' => 'App\\Http\\Controllers\\Admin\\MediaLibraryController@preview',
        'as' => 'admin.media-library.preview',
        'namespace' => NULL,
        'prefix' => '/admin',
        'where' => 
        array (
        ),
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'admin.media-library.store' => 
    array (
      'methods' => 
      array (
        0 => 'POST',
      ),
      'uri' => 'admin/media-library',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'admin.hidden',
          2 => 'auth:admin',
          3 => 'admin',
          4 => 'admin.permission',
          5 => 'admin.activity',
          6 => 'throttle:30,1',
        ),
        'uses' => 'App\\Http\\Controllers\\Admin\\MediaLibraryController@store',
        'controller' => 'App\\Http\\Controllers\\Admin\\MediaLibraryController@store',
        'as' => 'admin.media-library.store',
        'namespace' => NULL,
        'prefix' => '/admin',
        'where' => 
        array (
        ),
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'admin.storefront-branding.edit' => 
    array (
      'methods' => 
      array (
        0 => 'GET',
        1 => 'HEAD',
      ),
      'uri' => 'admin/storefront-branding',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'admin.hidden',
          2 => 'auth:admin',
          3 => 'admin',
          4 => 'admin.permission',
          5 => 'admin.activity',
        ),
        'uses' => 'App\\Http\\Controllers\\Admin\\StorefrontBrandingController@edit',
        'controller' => 'App\\Http\\Controllers\\Admin\\StorefrontBrandingController@edit',
        'as' => 'admin.storefront-branding.edit',
        'namespace' => NULL,
        'prefix' => '/admin',
        'where' => 
        array (
        ),
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'admin.storefront-branding.update' => 
    array (
      'methods' => 
      array (
        0 => 'PUT',
      ),
      'uri' => 'admin/storefront-branding',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'admin.hidden',
          2 => 'auth:admin',
          3 => 'admin',
          4 => 'admin.permission',
          5 => 'admin.activity',
        ),
        'uses' => 'App\\Http\\Controllers\\Admin\\StorefrontBrandingController@update',
        'controller' => 'App\\Http\\Controllers\\Admin\\StorefrontBrandingController@update',
        'as' => 'admin.storefront-branding.update',
        'namespace' => NULL,
        'prefix' => '/admin',
        'where' => 
        array (
        ),
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'admin.product-detail-controls.edit' => 
    array (
      'methods' => 
      array (
        0 => 'GET',
        1 => 'HEAD',
      ),
      'uri' => 'admin/product-detail-controls',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'admin.hidden',
          2 => 'auth:admin',
          3 => 'admin',
          4 => 'admin.permission',
          5 => 'admin.activity',
        ),
        'uses' => 'App\\Http\\Controllers\\Admin\\ProductDetailUiSettingsController@edit',
        'controller' => 'App\\Http\\Controllers\\Admin\\ProductDetailUiSettingsController@edit',
        'as' => 'admin.product-detail-controls.edit',
        'namespace' => NULL,
        'prefix' => '/admin',
        'where' => 
        array (
        ),
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'admin.product-detail-controls.update' => 
    array (
      'methods' => 
      array (
        0 => 'PUT',
      ),
      'uri' => 'admin/product-detail-controls',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'admin.hidden',
          2 => 'auth:admin',
          3 => 'admin',
          4 => 'admin.permission',
          5 => 'admin.activity',
        ),
        'uses' => 'App\\Http\\Controllers\\Admin\\ProductDetailUiSettingsController@update',
        'controller' => 'App\\Http\\Controllers\\Admin\\ProductDetailUiSettingsController@update',
        'as' => 'admin.product-detail-controls.update',
        'namespace' => NULL,
        'prefix' => '/admin',
        'where' => 
        array (
        ),
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'admin.about-page.edit' => 
    array (
      'methods' => 
      array (
        0 => 'GET',
        1 => 'HEAD',
      ),
      'uri' => 'admin/about-page',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'admin.hidden',
          2 => 'auth:admin',
          3 => 'admin',
          4 => 'admin.permission',
          5 => 'admin.activity',
        ),
        'uses' => 'App\\Http\\Controllers\\Admin\\AboutPageController@edit',
        'controller' => 'App\\Http\\Controllers\\Admin\\AboutPageController@edit',
        'as' => 'admin.about-page.edit',
        'namespace' => NULL,
        'prefix' => '/admin',
        'where' => 
        array (
        ),
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'admin.about-page.update' => 
    array (
      'methods' => 
      array (
        0 => 'PUT',
      ),
      'uri' => 'admin/about-page',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'admin.hidden',
          2 => 'auth:admin',
          3 => 'admin',
          4 => 'admin.permission',
          5 => 'admin.activity',
        ),
        'uses' => 'App\\Http\\Controllers\\Admin\\AboutPageController@update',
        'controller' => 'App\\Http\\Controllers\\Admin\\AboutPageController@update',
        'as' => 'admin.about-page.update',
        'namespace' => NULL,
        'prefix' => '/admin',
        'where' => 
        array (
        ),
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'admin.shipping-delivery-page.edit' => 
    array (
      'methods' => 
      array (
        0 => 'GET',
        1 => 'HEAD',
      ),
      'uri' => 'admin/shipping-delivery-page',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'admin.hidden',
          2 => 'auth:admin',
          3 => 'admin',
          4 => 'admin.permission',
          5 => 'admin.activity',
        ),
        'uses' => 'App\\Http\\Controllers\\Admin\\ShippingDeliveryPageController@edit',
        'controller' => 'App\\Http\\Controllers\\Admin\\ShippingDeliveryPageController@edit',
        'as' => 'admin.shipping-delivery-page.edit',
        'namespace' => NULL,
        'prefix' => '/admin',
        'where' => 
        array (
        ),
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'admin.shipping-delivery-page.update' => 
    array (
      'methods' => 
      array (
        0 => 'PUT',
      ),
      'uri' => 'admin/shipping-delivery-page',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'admin.hidden',
          2 => 'auth:admin',
          3 => 'admin',
          4 => 'admin.permission',
          5 => 'admin.activity',
        ),
        'uses' => 'App\\Http\\Controllers\\Admin\\ShippingDeliveryPageController@update',
        'controller' => 'App\\Http\\Controllers\\Admin\\ShippingDeliveryPageController@update',
        'as' => 'admin.shipping-delivery-page.update',
        'namespace' => NULL,
        'prefix' => '/admin',
        'where' => 
        array (
        ),
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'admin.sustainability-page.edit' => 
    array (
      'methods' => 
      array (
        0 => 'GET',
        1 => 'HEAD',
      ),
      'uri' => 'admin/sustainability-page',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'admin.hidden',
          2 => 'auth:admin',
          3 => 'admin',
          4 => 'admin.permission',
          5 => 'admin.activity',
        ),
        'uses' => 'App\\Http\\Controllers\\Admin\\SustainabilityPageController@edit',
        'controller' => 'App\\Http\\Controllers\\Admin\\SustainabilityPageController@edit',
        'as' => 'admin.sustainability-page.edit',
        'namespace' => NULL,
        'prefix' => '/admin',
        'where' => 
        array (
        ),
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'admin.sustainability-page.update' => 
    array (
      'methods' => 
      array (
        0 => 'PUT',
      ),
      'uri' => 'admin/sustainability-page',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'admin.hidden',
          2 => 'auth:admin',
          3 => 'admin',
          4 => 'admin.permission',
          5 => 'admin.activity',
        ),
        'uses' => 'App\\Http\\Controllers\\Admin\\SustainabilityPageController@update',
        'controller' => 'App\\Http\\Controllers\\Admin\\SustainabilityPageController@update',
        'as' => 'admin.sustainability-page.update',
        'namespace' => NULL,
        'prefix' => '/admin',
        'where' => 
        array (
        ),
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'admin.email-customization.index' => 
    array (
      'methods' => 
      array (
        0 => 'GET',
        1 => 'HEAD',
      ),
      'uri' => 'admin/email-customization',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'admin.hidden',
          2 => 'auth:admin',
          3 => 'admin',
          4 => 'admin.permission',
          5 => 'admin.activity',
        ),
        'uses' => 'App\\Http\\Controllers\\Admin\\EmailCustomizationController@templates',
        'controller' => 'App\\Http\\Controllers\\Admin\\EmailCustomizationController@templates',
        'as' => 'admin.email-customization.index',
        'namespace' => NULL,
        'prefix' => 'admin/email-customization',
        'where' => 
        array (
        ),
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'admin.email-customization.templates.index' => 
    array (
      'methods' => 
      array (
        0 => 'GET',
        1 => 'HEAD',
      ),
      'uri' => 'admin/email-customization/templates',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'admin.hidden',
          2 => 'auth:admin',
          3 => 'admin',
          4 => 'admin.permission',
          5 => 'admin.activity',
        ),
        'uses' => 'App\\Http\\Controllers\\Admin\\EmailCustomizationController@templates',
        'controller' => 'App\\Http\\Controllers\\Admin\\EmailCustomizationController@templates',
        'as' => 'admin.email-customization.templates.index',
        'namespace' => NULL,
        'prefix' => 'admin/email-customization',
        'where' => 
        array (
        ),
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'admin.email-customization.templates.create' => 
    array (
      'methods' => 
      array (
        0 => 'GET',
        1 => 'HEAD',
      ),
      'uri' => 'admin/email-customization/templates/create',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'admin.hidden',
          2 => 'auth:admin',
          3 => 'admin',
          4 => 'admin.permission',
          5 => 'admin.activity',
        ),
        'uses' => 'App\\Http\\Controllers\\Admin\\EmailCustomizationController@createTemplate',
        'controller' => 'App\\Http\\Controllers\\Admin\\EmailCustomizationController@createTemplate',
        'as' => 'admin.email-customization.templates.create',
        'namespace' => NULL,
        'prefix' => 'admin/email-customization',
        'where' => 
        array (
        ),
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'admin.email-customization.templates.store' => 
    array (
      'methods' => 
      array (
        0 => 'POST',
      ),
      'uri' => 'admin/email-customization/templates',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'admin.hidden',
          2 => 'auth:admin',
          3 => 'admin',
          4 => 'admin.permission',
          5 => 'admin.activity',
        ),
        'uses' => 'App\\Http\\Controllers\\Admin\\EmailCustomizationController@storeTemplate',
        'controller' => 'App\\Http\\Controllers\\Admin\\EmailCustomizationController@storeTemplate',
        'as' => 'admin.email-customization.templates.store',
        'namespace' => NULL,
        'prefix' => 'admin/email-customization',
        'where' => 
        array (
        ),
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'admin.email-customization.templates.edit' => 
    array (
      'methods' => 
      array (
        0 => 'GET',
        1 => 'HEAD',
      ),
      'uri' => 'admin/email-customization/templates/{template}/edit',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'admin.hidden',
          2 => 'auth:admin',
          3 => 'admin',
          4 => 'admin.permission',
          5 => 'admin.activity',
        ),
        'uses' => 'App\\Http\\Controllers\\Admin\\EmailCustomizationController@editTemplate',
        'controller' => 'App\\Http\\Controllers\\Admin\\EmailCustomizationController@editTemplate',
        'as' => 'admin.email-customization.templates.edit',
        'namespace' => NULL,
        'prefix' => 'admin/email-customization',
        'where' => 
        array (
        ),
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'admin.email-customization.templates.update' => 
    array (
      'methods' => 
      array (
        0 => 'PUT',
      ),
      'uri' => 'admin/email-customization/templates/{template}',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'admin.hidden',
          2 => 'auth:admin',
          3 => 'admin',
          4 => 'admin.permission',
          5 => 'admin.activity',
        ),
        'uses' => 'App\\Http\\Controllers\\Admin\\EmailCustomizationController@updateTemplate',
        'controller' => 'App\\Http\\Controllers\\Admin\\EmailCustomizationController@updateTemplate',
        'as' => 'admin.email-customization.templates.update',
        'namespace' => NULL,
        'prefix' => 'admin/email-customization',
        'where' => 
        array (
        ),
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'admin.email-customization.templates.duplicate' => 
    array (
      'methods' => 
      array (
        0 => 'POST',
      ),
      'uri' => 'admin/email-customization/templates/{template}/duplicate',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'admin.hidden',
          2 => 'auth:admin',
          3 => 'admin',
          4 => 'admin.permission',
          5 => 'admin.activity',
        ),
        'uses' => 'App\\Http\\Controllers\\Admin\\EmailCustomizationController@duplicateTemplate',
        'controller' => 'App\\Http\\Controllers\\Admin\\EmailCustomizationController@duplicateTemplate',
        'as' => 'admin.email-customization.templates.duplicate',
        'namespace' => NULL,
        'prefix' => 'admin/email-customization',
        'where' => 
        array (
        ),
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'admin.email-customization.templates.destroy' => 
    array (
      'methods' => 
      array (
        0 => 'DELETE',
      ),
      'uri' => 'admin/email-customization/templates/{template}',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'admin.hidden',
          2 => 'auth:admin',
          3 => 'admin',
          4 => 'admin.permission',
          5 => 'admin.activity',
        ),
        'uses' => 'App\\Http\\Controllers\\Admin\\EmailCustomizationController@destroyTemplate',
        'controller' => 'App\\Http\\Controllers\\Admin\\EmailCustomizationController@destroyTemplate',
        'as' => 'admin.email-customization.templates.destroy',
        'namespace' => NULL,
        'prefix' => 'admin/email-customization',
        'where' => 
        array (
        ),
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'admin.email-customization.templates.visibility' => 
    array (
      'methods' => 
      array (
        0 => 'GET',
        1 => 'HEAD',
      ),
      'uri' => 'admin/email-customization/templates/{template}/visibility',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'admin.hidden',
          2 => 'auth:admin',
          3 => 'admin',
          4 => 'admin.permission',
          5 => 'admin.activity',
        ),
        'uses' => 'App\\Http\\Controllers\\Admin\\EmailCustomizationController@visibility',
        'controller' => 'App\\Http\\Controllers\\Admin\\EmailCustomizationController@visibility',
        'as' => 'admin.email-customization.templates.visibility',
        'namespace' => NULL,
        'prefix' => 'admin/email-customization',
        'where' => 
        array (
        ),
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'admin.email-customization.templates.visibility.update' => 
    array (
      'methods' => 
      array (
        0 => 'PUT',
      ),
      'uri' => 'admin/email-customization/templates/{template}/visibility',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'admin.hidden',
          2 => 'auth:admin',
          3 => 'admin',
          4 => 'admin.permission',
          5 => 'admin.activity',
        ),
        'uses' => 'App\\Http\\Controllers\\Admin\\EmailCustomizationController@updateVisibility',
        'controller' => 'App\\Http\\Controllers\\Admin\\EmailCustomizationController@updateVisibility',
        'as' => 'admin.email-customization.templates.visibility.update',
        'namespace' => NULL,
        'prefix' => 'admin/email-customization',
        'where' => 
        array (
        ),
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'admin.email-customization.templates.preview' => 
    array (
      'methods' => 
      array (
        0 => 'GET',
        1 => 'HEAD',
      ),
      'uri' => 'admin/email-customization/templates/{template}/preview',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'admin.hidden',
          2 => 'auth:admin',
          3 => 'admin',
          4 => 'admin.permission',
          5 => 'admin.activity',
        ),
        'uses' => 'App\\Http\\Controllers\\Admin\\EmailCustomizationController@preview',
        'controller' => 'App\\Http\\Controllers\\Admin\\EmailCustomizationController@preview',
        'as' => 'admin.email-customization.templates.preview',
        'namespace' => NULL,
        'prefix' => 'admin/email-customization',
        'where' => 
        array (
        ),
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'admin.email-customization.templates.send-test' => 
    array (
      'methods' => 
      array (
        0 => 'POST',
      ),
      'uri' => 'admin/email-customization/templates/{template}/send-test',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'admin.hidden',
          2 => 'auth:admin',
          3 => 'admin',
          4 => 'admin.permission',
          5 => 'admin.activity',
        ),
        'uses' => 'App\\Http\\Controllers\\Admin\\EmailCustomizationController@sendTest',
        'controller' => 'App\\Http\\Controllers\\Admin\\EmailCustomizationController@sendTest',
        'as' => 'admin.email-customization.templates.send-test',
        'namespace' => NULL,
        'prefix' => 'admin/email-customization',
        'where' => 
        array (
        ),
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'admin.email-customization.branding.edit' => 
    array (
      'methods' => 
      array (
        0 => 'GET',
        1 => 'HEAD',
      ),
      'uri' => 'admin/email-customization/branding',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'admin.hidden',
          2 => 'auth:admin',
          3 => 'admin',
          4 => 'admin.permission',
          5 => 'admin.activity',
        ),
        'uses' => 'App\\Http\\Controllers\\Admin\\EmailCustomizationController@branding',
        'controller' => 'App\\Http\\Controllers\\Admin\\EmailCustomizationController@branding',
        'as' => 'admin.email-customization.branding.edit',
        'namespace' => NULL,
        'prefix' => 'admin/email-customization',
        'where' => 
        array (
        ),
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'admin.email-customization.branding.update' => 
    array (
      'methods' => 
      array (
        0 => 'PUT',
      ),
      'uri' => 'admin/email-customization/branding',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'admin.hidden',
          2 => 'auth:admin',
          3 => 'admin',
          4 => 'admin.permission',
          5 => 'admin.activity',
        ),
        'uses' => 'App\\Http\\Controllers\\Admin\\EmailCustomizationController@updateBranding',
        'controller' => 'App\\Http\\Controllers\\Admin\\EmailCustomizationController@updateBranding',
        'as' => 'admin.email-customization.branding.update',
        'namespace' => NULL,
        'prefix' => 'admin/email-customization',
        'where' => 
        array (
        ),
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'admin.homepage.sections.index' => 
    array (
      'methods' => 
      array (
        0 => 'GET',
        1 => 'HEAD',
      ),
      'uri' => 'admin/homepage',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'admin.hidden',
          2 => 'auth:admin',
          3 => 'admin',
          4 => 'admin.permission',
          5 => 'admin.activity',
        ),
        'uses' => 'App\\Http\\Controllers\\Admin\\HomepageSectionController@index',
        'controller' => 'App\\Http\\Controllers\\Admin\\HomepageSectionController@index',
        'as' => 'admin.homepage.sections.index',
        'namespace' => NULL,
        'prefix' => '/admin',
        'where' => 
        array (
        ),
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'admin.homepage.sections.edit' => 
    array (
      'methods' => 
      array (
        0 => 'GET',
        1 => 'HEAD',
      ),
      'uri' => 'admin/homepage/sections/{key}',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'admin.hidden',
          2 => 'auth:admin',
          3 => 'admin',
          4 => 'admin.permission',
          5 => 'admin.activity',
        ),
        'uses' => 'App\\Http\\Controllers\\Admin\\HomepageSectionController@edit',
        'controller' => 'App\\Http\\Controllers\\Admin\\HomepageSectionController@edit',
        'as' => 'admin.homepage.sections.edit',
        'namespace' => NULL,
        'prefix' => '/admin',
        'where' => 
        array (
        ),
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'admin.homepage.sections.update' => 
    array (
      'methods' => 
      array (
        0 => 'PATCH',
      ),
      'uri' => 'admin/homepage/sections/{key}',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'admin.hidden',
          2 => 'auth:admin',
          3 => 'admin',
          4 => 'admin.permission',
          5 => 'admin.activity',
        ),
        'uses' => 'App\\Http\\Controllers\\Admin\\HomepageSectionController@update',
        'controller' => 'App\\Http\\Controllers\\Admin\\HomepageSectionController@update',
        'as' => 'admin.homepage.sections.update',
        'namespace' => NULL,
        'prefix' => '/admin',
        'where' => 
        array (
        ),
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'admin.homepage-slides.toggle' => 
    array (
      'methods' => 
      array (
        0 => 'PATCH',
      ),
      'uri' => 'admin/homepage-slides/{homepageSlide}/toggle',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'admin.hidden',
          2 => 'auth:admin',
          3 => 'admin',
          4 => 'admin.permission',
          5 => 'admin.activity',
        ),
        'uses' => 'App\\Http\\Controllers\\Admin\\HomepageSlideController@toggle',
        'controller' => 'App\\Http\\Controllers\\Admin\\HomepageSlideController@toggle',
        'as' => 'admin.homepage-slides.toggle',
        'namespace' => NULL,
        'prefix' => '/admin',
        'where' => 
        array (
        ),
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'admin.homepage-slides.index' => 
    array (
      'methods' => 
      array (
        0 => 'GET',
        1 => 'HEAD',
      ),
      'uri' => 'admin/homepage-slides',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'admin.hidden',
          2 => 'auth:admin',
          3 => 'admin',
          4 => 'admin.permission',
          5 => 'admin.activity',
        ),
        'as' => 'admin.homepage-slides.index',
        'uses' => 'App\\Http\\Controllers\\Admin\\HomepageSlideController@index',
        'controller' => 'App\\Http\\Controllers\\Admin\\HomepageSlideController@index',
        'namespace' => NULL,
        'prefix' => '/admin',
        'where' => 
        array (
        ),
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'admin.homepage-slides.create' => 
    array (
      'methods' => 
      array (
        0 => 'GET',
        1 => 'HEAD',
      ),
      'uri' => 'admin/homepage-slides/create',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'admin.hidden',
          2 => 'auth:admin',
          3 => 'admin',
          4 => 'admin.permission',
          5 => 'admin.activity',
        ),
        'as' => 'admin.homepage-slides.create',
        'uses' => 'App\\Http\\Controllers\\Admin\\HomepageSlideController@create',
        'controller' => 'App\\Http\\Controllers\\Admin\\HomepageSlideController@create',
        'namespace' => NULL,
        'prefix' => '/admin',
        'where' => 
        array (
        ),
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'admin.homepage-slides.store' => 
    array (
      'methods' => 
      array (
        0 => 'POST',
      ),
      'uri' => 'admin/homepage-slides',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'admin.hidden',
          2 => 'auth:admin',
          3 => 'admin',
          4 => 'admin.permission',
          5 => 'admin.activity',
        ),
        'as' => 'admin.homepage-slides.store',
        'uses' => 'App\\Http\\Controllers\\Admin\\HomepageSlideController@store',
        'controller' => 'App\\Http\\Controllers\\Admin\\HomepageSlideController@store',
        'namespace' => NULL,
        'prefix' => '/admin',
        'where' => 
        array (
        ),
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'admin.homepage-slides.edit' => 
    array (
      'methods' => 
      array (
        0 => 'GET',
        1 => 'HEAD',
      ),
      'uri' => 'admin/homepage-slides/{homepage_slide}/edit',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'admin.hidden',
          2 => 'auth:admin',
          3 => 'admin',
          4 => 'admin.permission',
          5 => 'admin.activity',
        ),
        'as' => 'admin.homepage-slides.edit',
        'uses' => 'App\\Http\\Controllers\\Admin\\HomepageSlideController@edit',
        'controller' => 'App\\Http\\Controllers\\Admin\\HomepageSlideController@edit',
        'namespace' => NULL,
        'prefix' => '/admin',
        'where' => 
        array (
        ),
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'admin.homepage-slides.update' => 
    array (
      'methods' => 
      array (
        0 => 'PUT',
        1 => 'PATCH',
      ),
      'uri' => 'admin/homepage-slides/{homepage_slide}',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'admin.hidden',
          2 => 'auth:admin',
          3 => 'admin',
          4 => 'admin.permission',
          5 => 'admin.activity',
        ),
        'as' => 'admin.homepage-slides.update',
        'uses' => 'App\\Http\\Controllers\\Admin\\HomepageSlideController@update',
        'controller' => 'App\\Http\\Controllers\\Admin\\HomepageSlideController@update',
        'namespace' => NULL,
        'prefix' => '/admin',
        'where' => 
        array (
        ),
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'admin.homepage-slides.destroy' => 
    array (
      'methods' => 
      array (
        0 => 'DELETE',
      ),
      'uri' => 'admin/homepage-slides/{homepage_slide}',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'admin.hidden',
          2 => 'auth:admin',
          3 => 'admin',
          4 => 'admin.permission',
          5 => 'admin.activity',
        ),
        'as' => 'admin.homepage-slides.destroy',
        'uses' => 'App\\Http\\Controllers\\Admin\\HomepageSlideController@destroy',
        'controller' => 'App\\Http\\Controllers\\Admin\\HomepageSlideController@destroy',
        'namespace' => NULL,
        'prefix' => '/admin',
        'where' => 
        array (
        ),
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'admin.products.stats' => 
    array (
      'methods' => 
      array (
        0 => 'GET',
        1 => 'HEAD',
      ),
      'uri' => 'admin/products/stats',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'admin.hidden',
          2 => 'auth:admin',
          3 => 'admin',
          4 => 'admin.permission',
          5 => 'admin.activity',
        ),
        'uses' => 'App\\Http\\Controllers\\Admin\\ProductController@stats',
        'controller' => 'App\\Http\\Controllers\\Admin\\ProductController@stats',
        'as' => 'admin.products.stats',
        'namespace' => NULL,
        'prefix' => '/admin',
        'where' => 
        array (
        ),
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'admin.products.suggestions' => 
    array (
      'methods' => 
      array (
        0 => 'GET',
        1 => 'HEAD',
      ),
      'uri' => 'admin/products/search-suggestions',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'admin.hidden',
          2 => 'auth:admin',
          3 => 'admin',
          4 => 'admin.permission',
          5 => 'admin.activity',
        ),
        'uses' => 'App\\Http\\Controllers\\Admin\\ProductController@suggestions',
        'controller' => 'App\\Http\\Controllers\\Admin\\ProductController@suggestions',
        'as' => 'admin.products.suggestions',
        'namespace' => NULL,
        'prefix' => '/admin',
        'where' => 
        array (
        ),
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'admin.products.duplicate' => 
    array (
      'methods' => 
      array (
        0 => 'POST',
      ),
      'uri' => 'admin/products/{product}/duplicate',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'admin.hidden',
          2 => 'auth:admin',
          3 => 'admin',
          4 => 'admin.permission',
          5 => 'admin.activity',
        ),
        'uses' => 'App\\Http\\Controllers\\Admin\\ProductController@duplicate',
        'controller' => 'App\\Http\\Controllers\\Admin\\ProductController@duplicate',
        'as' => 'admin.products.duplicate',
        'namespace' => NULL,
        'prefix' => '/admin',
        'where' => 
        array (
        ),
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'admin.products.bulk' => 
    array (
      'methods' => 
      array (
        0 => 'POST',
      ),
      'uri' => 'admin/products/bulk',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'admin.hidden',
          2 => 'auth:admin',
          3 => 'admin',
          4 => 'admin.permission',
          5 => 'admin.activity',
        ),
        'uses' => 'App\\Http\\Controllers\\Admin\\ProductController@bulk',
        'controller' => 'App\\Http\\Controllers\\Admin\\ProductController@bulk',
        'as' => 'admin.products.bulk',
        'namespace' => NULL,
        'prefix' => '/admin',
        'where' => 
        array (
        ),
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'admin.products.index' => 
    array (
      'methods' => 
      array (
        0 => 'GET',
        1 => 'HEAD',
      ),
      'uri' => 'admin/products',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'admin.hidden',
          2 => 'auth:admin',
          3 => 'admin',
          4 => 'admin.permission',
          5 => 'admin.activity',
        ),
        'as' => 'admin.products.index',
        'uses' => 'App\\Http\\Controllers\\Admin\\ProductController@index',
        'controller' => 'App\\Http\\Controllers\\Admin\\ProductController@index',
        'namespace' => NULL,
        'prefix' => '/admin',
        'where' => 
        array (
        ),
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'admin.products.create' => 
    array (
      'methods' => 
      array (
        0 => 'GET',
        1 => 'HEAD',
      ),
      'uri' => 'admin/products/create',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'admin.hidden',
          2 => 'auth:admin',
          3 => 'admin',
          4 => 'admin.permission',
          5 => 'admin.activity',
        ),
        'as' => 'admin.products.create',
        'uses' => 'App\\Http\\Controllers\\Admin\\ProductController@create',
        'controller' => 'App\\Http\\Controllers\\Admin\\ProductController@create',
        'namespace' => NULL,
        'prefix' => '/admin',
        'where' => 
        array (
        ),
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'admin.products.store' => 
    array (
      'methods' => 
      array (
        0 => 'POST',
      ),
      'uri' => 'admin/products',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'admin.hidden',
          2 => 'auth:admin',
          3 => 'admin',
          4 => 'admin.permission',
          5 => 'admin.activity',
        ),
        'as' => 'admin.products.store',
        'uses' => 'App\\Http\\Controllers\\Admin\\ProductController@store',
        'controller' => 'App\\Http\\Controllers\\Admin\\ProductController@store',
        'namespace' => NULL,
        'prefix' => '/admin',
        'where' => 
        array (
        ),
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'admin.products.show' => 
    array (
      'methods' => 
      array (
        0 => 'GET',
        1 => 'HEAD',
      ),
      'uri' => 'admin/products/{product}',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'admin.hidden',
          2 => 'auth:admin',
          3 => 'admin',
          4 => 'admin.permission',
          5 => 'admin.activity',
        ),
        'as' => 'admin.products.show',
        'uses' => 'App\\Http\\Controllers\\Admin\\ProductController@show',
        'controller' => 'App\\Http\\Controllers\\Admin\\ProductController@show',
        'namespace' => NULL,
        'prefix' => '/admin',
        'where' => 
        array (
        ),
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'admin.products.edit' => 
    array (
      'methods' => 
      array (
        0 => 'GET',
        1 => 'HEAD',
      ),
      'uri' => 'admin/products/{product}/edit',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'admin.hidden',
          2 => 'auth:admin',
          3 => 'admin',
          4 => 'admin.permission',
          5 => 'admin.activity',
        ),
        'as' => 'admin.products.edit',
        'uses' => 'App\\Http\\Controllers\\Admin\\ProductController@edit',
        'controller' => 'App\\Http\\Controllers\\Admin\\ProductController@edit',
        'namespace' => NULL,
        'prefix' => '/admin',
        'where' => 
        array (
        ),
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'admin.products.update' => 
    array (
      'methods' => 
      array (
        0 => 'PUT',
        1 => 'PATCH',
      ),
      'uri' => 'admin/products/{product}',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'admin.hidden',
          2 => 'auth:admin',
          3 => 'admin',
          4 => 'admin.permission',
          5 => 'admin.activity',
        ),
        'as' => 'admin.products.update',
        'uses' => 'App\\Http\\Controllers\\Admin\\ProductController@update',
        'controller' => 'App\\Http\\Controllers\\Admin\\ProductController@update',
        'namespace' => NULL,
        'prefix' => '/admin',
        'where' => 
        array (
        ),
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'admin.products.destroy' => 
    array (
      'methods' => 
      array (
        0 => 'DELETE',
      ),
      'uri' => 'admin/products/{product}',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'admin.hidden',
          2 => 'auth:admin',
          3 => 'admin',
          4 => 'admin.permission',
          5 => 'admin.activity',
        ),
        'as' => 'admin.products.destroy',
        'uses' => 'App\\Http\\Controllers\\Admin\\ProductController@destroy',
        'controller' => 'App\\Http\\Controllers\\Admin\\ProductController@destroy',
        'namespace' => NULL,
        'prefix' => '/admin',
        'where' => 
        array (
        ),
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'admin.categories.catalog-banner.update' => 
    array (
      'methods' => 
      array (
        0 => 'PUT',
      ),
      'uri' => 'admin/categories/catalog-banner',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'admin.hidden',
          2 => 'auth:admin',
          3 => 'admin',
          4 => 'admin.permission',
          5 => 'admin.activity',
        ),
        'uses' => 'App\\Http\\Controllers\\Admin\\CategoryController@updateCatalogBanner',
        'controller' => 'App\\Http\\Controllers\\Admin\\CategoryController@updateCatalogBanner',
        'as' => 'admin.categories.catalog-banner.update',
        'namespace' => NULL,
        'prefix' => '/admin',
        'where' => 
        array (
        ),
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'admin.categories.bulk' => 
    array (
      'methods' => 
      array (
        0 => 'POST',
      ),
      'uri' => 'admin/categories/bulk',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'admin.hidden',
          2 => 'auth:admin',
          3 => 'admin',
          4 => 'admin.permission',
          5 => 'admin.activity',
        ),
        'uses' => 'App\\Http\\Controllers\\Admin\\CategoryOperationsController@bulk',
        'controller' => 'App\\Http\\Controllers\\Admin\\CategoryOperationsController@bulk',
        'as' => 'admin.categories.bulk',
        'namespace' => NULL,
        'prefix' => '/admin',
        'where' => 
        array (
        ),
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'admin.categories.duplicate' => 
    array (
      'methods' => 
      array (
        0 => 'POST',
      ),
      'uri' => 'admin/categories/{category}/duplicate',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'admin.hidden',
          2 => 'auth:admin',
          3 => 'admin',
          4 => 'admin.permission',
          5 => 'admin.activity',
        ),
        'uses' => 'App\\Http\\Controllers\\Admin\\CategoryController@duplicate',
        'controller' => 'App\\Http\\Controllers\\Admin\\CategoryController@duplicate',
        'as' => 'admin.categories.duplicate',
        'namespace' => NULL,
        'prefix' => '/admin',
        'where' => 
        array (
        ),
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'admin.categories.export' => 
    array (
      'methods' => 
      array (
        0 => 'GET',
        1 => 'HEAD',
      ),
      'uri' => 'admin/categories/export',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'admin.hidden',
          2 => 'auth:admin',
          3 => 'admin',
          4 => 'admin.permission',
          5 => 'admin.activity',
        ),
        'uses' => 'App\\Http\\Controllers\\Admin\\CategoryOperationsController@export',
        'controller' => 'App\\Http\\Controllers\\Admin\\CategoryOperationsController@export',
        'as' => 'admin.categories.export',
        'namespace' => NULL,
        'prefix' => '/admin',
        'where' => 
        array (
        ),
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'admin.categories.import' => 
    array (
      'methods' => 
      array (
        0 => 'POST',
      ),
      'uri' => 'admin/categories/import',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'admin.hidden',
          2 => 'auth:admin',
          3 => 'admin',
          4 => 'admin.permission',
          5 => 'admin.activity',
          6 => 'throttle:3,1',
        ),
        'uses' => 'App\\Http\\Controllers\\Admin\\CategoryOperationsController@import',
        'controller' => 'App\\Http\\Controllers\\Admin\\CategoryOperationsController@import',
        'as' => 'admin.categories.import',
        'namespace' => NULL,
        'prefix' => '/admin',
        'where' => 
        array (
        ),
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'admin.categories.ordering' => 
    array (
      'methods' => 
      array (
        0 => 'GET',
        1 => 'HEAD',
      ),
      'uri' => 'admin/categories-ordering',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'admin.hidden',
          2 => 'auth:admin',
          3 => 'admin',
          4 => 'admin.permission',
          5 => 'admin.activity',
        ),
        'uses' => 'App\\Http\\Controllers\\Admin\\CategoryOperationsController@ordering',
        'controller' => 'App\\Http\\Controllers\\Admin\\CategoryOperationsController@ordering',
        'as' => 'admin.categories.ordering',
        'namespace' => NULL,
        'prefix' => '/admin',
        'where' => 
        array (
        ),
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'admin.categories.ordering.update' => 
    array (
      'methods' => 
      array (
        0 => 'PUT',
      ),
      'uri' => 'admin/categories-ordering',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'admin.hidden',
          2 => 'auth:admin',
          3 => 'admin',
          4 => 'admin.permission',
          5 => 'admin.activity',
        ),
        'uses' => 'App\\Http\\Controllers\\Admin\\CategoryOperationsController@updateOrdering',
        'controller' => 'App\\Http\\Controllers\\Admin\\CategoryOperationsController@updateOrdering',
        'as' => 'admin.categories.ordering.update',
        'namespace' => NULL,
        'prefix' => '/admin',
        'where' => 
        array (
        ),
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'admin.categories.products.sync-legacy' => 
    array (
      'methods' => 
      array (
        0 => 'POST',
      ),
      'uri' => 'admin/categories/products/sync-legacy',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'admin.hidden',
          2 => 'auth:admin',
          3 => 'admin',
          4 => 'admin.permission',
          5 => 'admin.activity',
        ),
        'uses' => 'App\\Http\\Controllers\\Admin\\CategoryProductController@syncLegacyAssignments',
        'controller' => 'App\\Http\\Controllers\\Admin\\CategoryProductController@syncLegacyAssignments',
        'as' => 'admin.categories.products.sync-legacy',
        'namespace' => NULL,
        'prefix' => '/admin',
        'where' => 
        array (
        ),
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'admin.categories.products.index' => 
    array (
      'methods' => 
      array (
        0 => 'GET',
        1 => 'HEAD',
      ),
      'uri' => 'admin/categories/{category}/products',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'admin.hidden',
          2 => 'auth:admin',
          3 => 'admin',
          4 => 'admin.permission',
          5 => 'admin.activity',
        ),
        'uses' => 'App\\Http\\Controllers\\Admin\\CategoryProductController@index',
        'controller' => 'App\\Http\\Controllers\\Admin\\CategoryProductController@index',
        'as' => 'admin.categories.products.index',
        'namespace' => NULL,
        'prefix' => '/admin',
        'where' => 
        array (
        ),
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'admin.categories.products.update' => 
    array (
      'methods' => 
      array (
        0 => 'PUT',
      ),
      'uri' => 'admin/categories/{category}/products',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'admin.hidden',
          2 => 'auth:admin',
          3 => 'admin',
          4 => 'admin.permission',
          5 => 'admin.activity',
        ),
        'uses' => 'App\\Http\\Controllers\\Admin\\CategoryProductController@update',
        'controller' => 'App\\Http\\Controllers\\Admin\\CategoryProductController@update',
        'as' => 'admin.categories.products.update',
        'namespace' => NULL,
        'prefix' => '/admin',
        'where' => 
        array (
        ),
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'admin.categories.products.destroy' => 
    array (
      'methods' => 
      array (
        0 => 'DELETE',
      ),
      'uri' => 'admin/categories/{category}/products/{product}',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'admin.hidden',
          2 => 'auth:admin',
          3 => 'admin',
          4 => 'admin.permission',
          5 => 'admin.activity',
        ),
        'uses' => 'App\\Http\\Controllers\\Admin\\CategoryProductController@destroy',
        'controller' => 'App\\Http\\Controllers\\Admin\\CategoryProductController@destroy',
        'as' => 'admin.categories.products.destroy',
        'namespace' => NULL,
        'prefix' => '/admin',
        'where' => 
        array (
        ),
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'admin.categories.index' => 
    array (
      'methods' => 
      array (
        0 => 'GET',
        1 => 'HEAD',
      ),
      'uri' => 'admin/categories',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'admin.hidden',
          2 => 'auth:admin',
          3 => 'admin',
          4 => 'admin.permission',
          5 => 'admin.activity',
        ),
        'as' => 'admin.categories.index',
        'uses' => 'App\\Http\\Controllers\\Admin\\CategoryController@index',
        'controller' => 'App\\Http\\Controllers\\Admin\\CategoryController@index',
        'namespace' => NULL,
        'prefix' => '/admin',
        'where' => 
        array (
        ),
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'admin.categories.create' => 
    array (
      'methods' => 
      array (
        0 => 'GET',
        1 => 'HEAD',
      ),
      'uri' => 'admin/categories/create',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'admin.hidden',
          2 => 'auth:admin',
          3 => 'admin',
          4 => 'admin.permission',
          5 => 'admin.activity',
        ),
        'as' => 'admin.categories.create',
        'uses' => 'App\\Http\\Controllers\\Admin\\CategoryController@create',
        'controller' => 'App\\Http\\Controllers\\Admin\\CategoryController@create',
        'namespace' => NULL,
        'prefix' => '/admin',
        'where' => 
        array (
        ),
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'admin.categories.store' => 
    array (
      'methods' => 
      array (
        0 => 'POST',
      ),
      'uri' => 'admin/categories',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'admin.hidden',
          2 => 'auth:admin',
          3 => 'admin',
          4 => 'admin.permission',
          5 => 'admin.activity',
        ),
        'as' => 'admin.categories.store',
        'uses' => 'App\\Http\\Controllers\\Admin\\CategoryController@store',
        'controller' => 'App\\Http\\Controllers\\Admin\\CategoryController@store',
        'namespace' => NULL,
        'prefix' => '/admin',
        'where' => 
        array (
        ),
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'admin.categories.edit' => 
    array (
      'methods' => 
      array (
        0 => 'GET',
        1 => 'HEAD',
      ),
      'uri' => 'admin/categories/{category}/edit',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'admin.hidden',
          2 => 'auth:admin',
          3 => 'admin',
          4 => 'admin.permission',
          5 => 'admin.activity',
        ),
        'as' => 'admin.categories.edit',
        'uses' => 'App\\Http\\Controllers\\Admin\\CategoryController@edit',
        'controller' => 'App\\Http\\Controllers\\Admin\\CategoryController@edit',
        'namespace' => NULL,
        'prefix' => '/admin',
        'where' => 
        array (
        ),
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'admin.categories.update' => 
    array (
      'methods' => 
      array (
        0 => 'PUT',
        1 => 'PATCH',
      ),
      'uri' => 'admin/categories/{category}',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'admin.hidden',
          2 => 'auth:admin',
          3 => 'admin',
          4 => 'admin.permission',
          5 => 'admin.activity',
        ),
        'as' => 'admin.categories.update',
        'uses' => 'App\\Http\\Controllers\\Admin\\CategoryController@update',
        'controller' => 'App\\Http\\Controllers\\Admin\\CategoryController@update',
        'namespace' => NULL,
        'prefix' => '/admin',
        'where' => 
        array (
        ),
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'admin.categories.destroy' => 
    array (
      'methods' => 
      array (
        0 => 'DELETE',
      ),
      'uri' => 'admin/categories/{category}',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'admin.hidden',
          2 => 'auth:admin',
          3 => 'admin',
          4 => 'admin.permission',
          5 => 'admin.activity',
        ),
        'as' => 'admin.categories.destroy',
        'uses' => 'App\\Http\\Controllers\\Admin\\CategoryController@destroy',
        'controller' => 'App\\Http\\Controllers\\Admin\\CategoryController@destroy',
        'namespace' => NULL,
        'prefix' => '/admin',
        'where' => 
        array (
        ),
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'admin.attributes.index' => 
    array (
      'methods' => 
      array (
        0 => 'GET',
        1 => 'HEAD',
      ),
      'uri' => 'admin/attributes',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'admin.hidden',
          2 => 'auth:admin',
          3 => 'admin',
          4 => 'admin.permission',
          5 => 'admin.activity',
        ),
        'as' => 'admin.attributes.index',
        'uses' => 'App\\Http\\Controllers\\Admin\\AttributeController@index',
        'controller' => 'App\\Http\\Controllers\\Admin\\AttributeController@index',
        'namespace' => NULL,
        'prefix' => '/admin',
        'where' => 
        array (
        ),
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'admin.attributes.create' => 
    array (
      'methods' => 
      array (
        0 => 'GET',
        1 => 'HEAD',
      ),
      'uri' => 'admin/attributes/create',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'admin.hidden',
          2 => 'auth:admin',
          3 => 'admin',
          4 => 'admin.permission',
          5 => 'admin.activity',
        ),
        'as' => 'admin.attributes.create',
        'uses' => 'App\\Http\\Controllers\\Admin\\AttributeController@create',
        'controller' => 'App\\Http\\Controllers\\Admin\\AttributeController@create',
        'namespace' => NULL,
        'prefix' => '/admin',
        'where' => 
        array (
        ),
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'admin.attributes.store' => 
    array (
      'methods' => 
      array (
        0 => 'POST',
      ),
      'uri' => 'admin/attributes',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'admin.hidden',
          2 => 'auth:admin',
          3 => 'admin',
          4 => 'admin.permission',
          5 => 'admin.activity',
        ),
        'as' => 'admin.attributes.store',
        'uses' => 'App\\Http\\Controllers\\Admin\\AttributeController@store',
        'controller' => 'App\\Http\\Controllers\\Admin\\AttributeController@store',
        'namespace' => NULL,
        'prefix' => '/admin',
        'where' => 
        array (
        ),
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'admin.attributes.edit' => 
    array (
      'methods' => 
      array (
        0 => 'GET',
        1 => 'HEAD',
      ),
      'uri' => 'admin/attributes/{attribute}/edit',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'admin.hidden',
          2 => 'auth:admin',
          3 => 'admin',
          4 => 'admin.permission',
          5 => 'admin.activity',
        ),
        'as' => 'admin.attributes.edit',
        'uses' => 'App\\Http\\Controllers\\Admin\\AttributeController@edit',
        'controller' => 'App\\Http\\Controllers\\Admin\\AttributeController@edit',
        'namespace' => NULL,
        'prefix' => '/admin',
        'where' => 
        array (
        ),
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'admin.attributes.update' => 
    array (
      'methods' => 
      array (
        0 => 'PUT',
        1 => 'PATCH',
      ),
      'uri' => 'admin/attributes/{attribute}',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'admin.hidden',
          2 => 'auth:admin',
          3 => 'admin',
          4 => 'admin.permission',
          5 => 'admin.activity',
        ),
        'as' => 'admin.attributes.update',
        'uses' => 'App\\Http\\Controllers\\Admin\\AttributeController@update',
        'controller' => 'App\\Http\\Controllers\\Admin\\AttributeController@update',
        'namespace' => NULL,
        'prefix' => '/admin',
        'where' => 
        array (
        ),
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'admin.attributes.destroy' => 
    array (
      'methods' => 
      array (
        0 => 'DELETE',
      ),
      'uri' => 'admin/attributes/{attribute}',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'admin.hidden',
          2 => 'auth:admin',
          3 => 'admin',
          4 => 'admin.permission',
          5 => 'admin.activity',
        ),
        'as' => 'admin.attributes.destroy',
        'uses' => 'App\\Http\\Controllers\\Admin\\AttributeController@destroy',
        'controller' => 'App\\Http\\Controllers\\Admin\\AttributeController@destroy',
        'namespace' => NULL,
        'prefix' => '/admin',
        'where' => 
        array (
        ),
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'admin.artwork-preferences.index' => 
    array (
      'methods' => 
      array (
        0 => 'GET',
        1 => 'HEAD',
      ),
      'uri' => 'admin/artwork-preferences/{type}',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'admin.hidden',
          2 => 'auth:admin',
          3 => 'admin',
          4 => 'admin.permission',
          5 => 'admin.activity',
        ),
        'uses' => 'App\\Http\\Controllers\\Admin\\ArtworkPreferenceController@index',
        'controller' => 'App\\Http\\Controllers\\Admin\\ArtworkPreferenceController@index',
        'as' => 'admin.artwork-preferences.index',
        'namespace' => NULL,
        'prefix' => '/admin',
        'where' => 
        array (
        ),
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'admin.artwork-preferences.create' => 
    array (
      'methods' => 
      array (
        0 => 'GET',
        1 => 'HEAD',
      ),
      'uri' => 'admin/artwork-preferences/{type}/create',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'admin.hidden',
          2 => 'auth:admin',
          3 => 'admin',
          4 => 'admin.permission',
          5 => 'admin.activity',
        ),
        'uses' => 'App\\Http\\Controllers\\Admin\\ArtworkPreferenceController@create',
        'controller' => 'App\\Http\\Controllers\\Admin\\ArtworkPreferenceController@create',
        'as' => 'admin.artwork-preferences.create',
        'namespace' => NULL,
        'prefix' => '/admin',
        'where' => 
        array (
        ),
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'admin.artwork-preferences.store' => 
    array (
      'methods' => 
      array (
        0 => 'POST',
      ),
      'uri' => 'admin/artwork-preferences/{type}',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'admin.hidden',
          2 => 'auth:admin',
          3 => 'admin',
          4 => 'admin.permission',
          5 => 'admin.activity',
        ),
        'uses' => 'App\\Http\\Controllers\\Admin\\ArtworkPreferenceController@store',
        'controller' => 'App\\Http\\Controllers\\Admin\\ArtworkPreferenceController@store',
        'as' => 'admin.artwork-preferences.store',
        'namespace' => NULL,
        'prefix' => '/admin',
        'where' => 
        array (
        ),
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'admin.artwork-preferences.edit' => 
    array (
      'methods' => 
      array (
        0 => 'GET',
        1 => 'HEAD',
      ),
      'uri' => 'admin/artwork-preferences/{type}/{preference}/edit',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'admin.hidden',
          2 => 'auth:admin',
          3 => 'admin',
          4 => 'admin.permission',
          5 => 'admin.activity',
        ),
        'uses' => 'App\\Http\\Controllers\\Admin\\ArtworkPreferenceController@edit',
        'controller' => 'App\\Http\\Controllers\\Admin\\ArtworkPreferenceController@edit',
        'as' => 'admin.artwork-preferences.edit',
        'namespace' => NULL,
        'prefix' => '/admin',
        'where' => 
        array (
        ),
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'admin.artwork-preferences.update' => 
    array (
      'methods' => 
      array (
        0 => 'PUT',
      ),
      'uri' => 'admin/artwork-preferences/{type}/{preference}',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'admin.hidden',
          2 => 'auth:admin',
          3 => 'admin',
          4 => 'admin.permission',
          5 => 'admin.activity',
        ),
        'uses' => 'App\\Http\\Controllers\\Admin\\ArtworkPreferenceController@update',
        'controller' => 'App\\Http\\Controllers\\Admin\\ArtworkPreferenceController@update',
        'as' => 'admin.artwork-preferences.update',
        'namespace' => NULL,
        'prefix' => '/admin',
        'where' => 
        array (
        ),
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'admin.artwork-preferences.destroy' => 
    array (
      'methods' => 
      array (
        0 => 'DELETE',
      ),
      'uri' => 'admin/artwork-preferences/{type}/{preference}',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'admin.hidden',
          2 => 'auth:admin',
          3 => 'admin',
          4 => 'admin.permission',
          5 => 'admin.activity',
        ),
        'uses' => 'App\\Http\\Controllers\\Admin\\ArtworkPreferenceController@destroy',
        'controller' => 'App\\Http\\Controllers\\Admin\\ArtworkPreferenceController@destroy',
        'as' => 'admin.artwork-preferences.destroy',
        'namespace' => NULL,
        'prefix' => '/admin',
        'where' => 
        array (
        ),
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'admin.jersey-customization-options.type' => 
    array (
      'methods' => 
      array (
        0 => 'GET',
        1 => 'HEAD',
      ),
      'uri' => 'admin/jersey-customization-options/type/{type}',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'admin.hidden',
          2 => 'auth:admin',
          3 => 'admin',
          4 => 'admin.permission',
          5 => 'admin.activity',
        ),
        'uses' => 'App\\Http\\Controllers\\Admin\\JerseyCustomizationOptionController@typeIndex',
        'controller' => 'App\\Http\\Controllers\\Admin\\JerseyCustomizationOptionController@typeIndex',
        'as' => 'admin.jersey-customization-options.type',
        'namespace' => NULL,
        'prefix' => '/admin',
        'where' => 
        array (
        ),
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'admin.jersey-customization-options.import-fabrics' => 
    array (
      'methods' => 
      array (
        0 => 'POST',
      ),
      'uri' => 'admin/jersey-customization-options/type/{type}/import-fabrics',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'admin.hidden',
          2 => 'auth:admin',
          3 => 'admin',
          4 => 'admin.permission',
          5 => 'admin.activity',
        ),
        'uses' => 'App\\Http\\Controllers\\Admin\\JerseyCustomizationOptionController@importFabrics',
        'controller' => 'App\\Http\\Controllers\\Admin\\JerseyCustomizationOptionController@importFabrics',
        'as' => 'admin.jersey-customization-options.import-fabrics',
        'namespace' => NULL,
        'prefix' => '/admin',
        'where' => 
        array (
        ),
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'admin.jersey-customization-options.index' => 
    array (
      'methods' => 
      array (
        0 => 'GET',
        1 => 'HEAD',
      ),
      'uri' => 'admin/jersey-customization-options',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'admin.hidden',
          2 => 'auth:admin',
          3 => 'admin',
          4 => 'admin.permission',
          5 => 'admin.activity',
        ),
        'as' => 'admin.jersey-customization-options.index',
        'uses' => 'App\\Http\\Controllers\\Admin\\JerseyCustomizationOptionController@index',
        'controller' => 'App\\Http\\Controllers\\Admin\\JerseyCustomizationOptionController@index',
        'namespace' => NULL,
        'prefix' => '/admin',
        'where' => 
        array (
        ),
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'admin.jersey-customization-options.create' => 
    array (
      'methods' => 
      array (
        0 => 'GET',
        1 => 'HEAD',
      ),
      'uri' => 'admin/jersey-customization-options/create',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'admin.hidden',
          2 => 'auth:admin',
          3 => 'admin',
          4 => 'admin.permission',
          5 => 'admin.activity',
        ),
        'as' => 'admin.jersey-customization-options.create',
        'uses' => 'App\\Http\\Controllers\\Admin\\JerseyCustomizationOptionController@create',
        'controller' => 'App\\Http\\Controllers\\Admin\\JerseyCustomizationOptionController@create',
        'namespace' => NULL,
        'prefix' => '/admin',
        'where' => 
        array (
        ),
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'admin.jersey-customization-options.store' => 
    array (
      'methods' => 
      array (
        0 => 'POST',
      ),
      'uri' => 'admin/jersey-customization-options',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'admin.hidden',
          2 => 'auth:admin',
          3 => 'admin',
          4 => 'admin.permission',
          5 => 'admin.activity',
        ),
        'as' => 'admin.jersey-customization-options.store',
        'uses' => 'App\\Http\\Controllers\\Admin\\JerseyCustomizationOptionController@store',
        'controller' => 'App\\Http\\Controllers\\Admin\\JerseyCustomizationOptionController@store',
        'namespace' => NULL,
        'prefix' => '/admin',
        'where' => 
        array (
        ),
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'admin.jersey-customization-options.edit' => 
    array (
      'methods' => 
      array (
        0 => 'GET',
        1 => 'HEAD',
      ),
      'uri' => 'admin/jersey-customization-options/{jerseyCustomizationOption}/edit',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'admin.hidden',
          2 => 'auth:admin',
          3 => 'admin',
          4 => 'admin.permission',
          5 => 'admin.activity',
        ),
        'as' => 'admin.jersey-customization-options.edit',
        'uses' => 'App\\Http\\Controllers\\Admin\\JerseyCustomizationOptionController@edit',
        'controller' => 'App\\Http\\Controllers\\Admin\\JerseyCustomizationOptionController@edit',
        'namespace' => NULL,
        'prefix' => '/admin',
        'where' => 
        array (
        ),
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'admin.jersey-customization-options.update' => 
    array (
      'methods' => 
      array (
        0 => 'PUT',
        1 => 'PATCH',
      ),
      'uri' => 'admin/jersey-customization-options/{jerseyCustomizationOption}',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'admin.hidden',
          2 => 'auth:admin',
          3 => 'admin',
          4 => 'admin.permission',
          5 => 'admin.activity',
        ),
        'as' => 'admin.jersey-customization-options.update',
        'uses' => 'App\\Http\\Controllers\\Admin\\JerseyCustomizationOptionController@update',
        'controller' => 'App\\Http\\Controllers\\Admin\\JerseyCustomizationOptionController@update',
        'namespace' => NULL,
        'prefix' => '/admin',
        'where' => 
        array (
        ),
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'admin.jersey-customization-options.destroy' => 
    array (
      'methods' => 
      array (
        0 => 'DELETE',
      ),
      'uri' => 'admin/jersey-customization-options/{jerseyCustomizationOption}',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'admin.hidden',
          2 => 'auth:admin',
          3 => 'admin',
          4 => 'admin.permission',
          5 => 'admin.activity',
        ),
        'as' => 'admin.jersey-customization-options.destroy',
        'uses' => 'App\\Http\\Controllers\\Admin\\JerseyCustomizationOptionController@destroy',
        'controller' => 'App\\Http\\Controllers\\Admin\\JerseyCustomizationOptionController@destroy',
        'namespace' => NULL,
        'prefix' => '/admin',
        'where' => 
        array (
        ),
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'admin.world-cup-customization-options.type' => 
    array (
      'methods' => 
      array (
        0 => 'GET',
        1 => 'HEAD',
      ),
      'uri' => 'admin/world-cup-customization-options/type/{type}',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'admin.hidden',
          2 => 'auth:admin',
          3 => 'admin',
          4 => 'admin.permission',
          5 => 'admin.activity',
        ),
        'uses' => 'App\\Http\\Controllers\\Admin\\WorldCupCustomizationOptionController@typeIndex',
        'controller' => 'App\\Http\\Controllers\\Admin\\WorldCupCustomizationOptionController@typeIndex',
        'as' => 'admin.world-cup-customization-options.type',
        'namespace' => NULL,
        'prefix' => '/admin',
        'where' => 
        array (
        ),
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'admin.world-cup-customization-options.index' => 
    array (
      'methods' => 
      array (
        0 => 'GET',
        1 => 'HEAD',
      ),
      'uri' => 'admin/world-cup-customization-options',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'admin.hidden',
          2 => 'auth:admin',
          3 => 'admin',
          4 => 'admin.permission',
          5 => 'admin.activity',
        ),
        'as' => 'admin.world-cup-customization-options.index',
        'uses' => 'App\\Http\\Controllers\\Admin\\WorldCupCustomizationOptionController@index',
        'controller' => 'App\\Http\\Controllers\\Admin\\WorldCupCustomizationOptionController@index',
        'namespace' => NULL,
        'prefix' => '/admin',
        'where' => 
        array (
        ),
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'admin.world-cup-customization-options.create' => 
    array (
      'methods' => 
      array (
        0 => 'GET',
        1 => 'HEAD',
      ),
      'uri' => 'admin/world-cup-customization-options/create',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'admin.hidden',
          2 => 'auth:admin',
          3 => 'admin',
          4 => 'admin.permission',
          5 => 'admin.activity',
        ),
        'as' => 'admin.world-cup-customization-options.create',
        'uses' => 'App\\Http\\Controllers\\Admin\\WorldCupCustomizationOptionController@create',
        'controller' => 'App\\Http\\Controllers\\Admin\\WorldCupCustomizationOptionController@create',
        'namespace' => NULL,
        'prefix' => '/admin',
        'where' => 
        array (
        ),
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'admin.world-cup-customization-options.store' => 
    array (
      'methods' => 
      array (
        0 => 'POST',
      ),
      'uri' => 'admin/world-cup-customization-options',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'admin.hidden',
          2 => 'auth:admin',
          3 => 'admin',
          4 => 'admin.permission',
          5 => 'admin.activity',
        ),
        'as' => 'admin.world-cup-customization-options.store',
        'uses' => 'App\\Http\\Controllers\\Admin\\WorldCupCustomizationOptionController@store',
        'controller' => 'App\\Http\\Controllers\\Admin\\WorldCupCustomizationOptionController@store',
        'namespace' => NULL,
        'prefix' => '/admin',
        'where' => 
        array (
        ),
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'admin.world-cup-customization-options.edit' => 
    array (
      'methods' => 
      array (
        0 => 'GET',
        1 => 'HEAD',
      ),
      'uri' => 'admin/world-cup-customization-options/{worldCupCustomizationOption}/edit',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'admin.hidden',
          2 => 'auth:admin',
          3 => 'admin',
          4 => 'admin.permission',
          5 => 'admin.activity',
        ),
        'as' => 'admin.world-cup-customization-options.edit',
        'uses' => 'App\\Http\\Controllers\\Admin\\WorldCupCustomizationOptionController@edit',
        'controller' => 'App\\Http\\Controllers\\Admin\\WorldCupCustomizationOptionController@edit',
        'namespace' => NULL,
        'prefix' => '/admin',
        'where' => 
        array (
        ),
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'admin.world-cup-customization-options.update' => 
    array (
      'methods' => 
      array (
        0 => 'PUT',
        1 => 'PATCH',
      ),
      'uri' => 'admin/world-cup-customization-options/{worldCupCustomizationOption}',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'admin.hidden',
          2 => 'auth:admin',
          3 => 'admin',
          4 => 'admin.permission',
          5 => 'admin.activity',
        ),
        'as' => 'admin.world-cup-customization-options.update',
        'uses' => 'App\\Http\\Controllers\\Admin\\WorldCupCustomizationOptionController@update',
        'controller' => 'App\\Http\\Controllers\\Admin\\WorldCupCustomizationOptionController@update',
        'namespace' => NULL,
        'prefix' => '/admin',
        'where' => 
        array (
        ),
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'admin.world-cup-customization-options.destroy' => 
    array (
      'methods' => 
      array (
        0 => 'DELETE',
      ),
      'uri' => 'admin/world-cup-customization-options/{worldCupCustomizationOption}',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'admin.hidden',
          2 => 'auth:admin',
          3 => 'admin',
          4 => 'admin.permission',
          5 => 'admin.activity',
        ),
        'as' => 'admin.world-cup-customization-options.destroy',
        'uses' => 'App\\Http\\Controllers\\Admin\\WorldCupCustomizationOptionController@destroy',
        'controller' => 'App\\Http\\Controllers\\Admin\\WorldCupCustomizationOptionController@destroy',
        'namespace' => NULL,
        'prefix' => '/admin',
        'where' => 
        array (
        ),
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'admin.training-vest-customization-options.type' => 
    array (
      'methods' => 
      array (
        0 => 'GET',
        1 => 'HEAD',
      ),
      'uri' => 'admin/training-vest-customization-options/type/{type}',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'admin.hidden',
          2 => 'auth:admin',
          3 => 'admin',
          4 => 'admin.permission',
          5 => 'admin.activity',
        ),
        'uses' => 'App\\Http\\Controllers\\Admin\\TrainingVestCustomizationOptionController@typeIndex',
        'controller' => 'App\\Http\\Controllers\\Admin\\TrainingVestCustomizationOptionController@typeIndex',
        'as' => 'admin.training-vest-customization-options.type',
        'namespace' => NULL,
        'prefix' => '/admin',
        'where' => 
        array (
        ),
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'admin.training-vest-size-option-groups.create' => 
    array (
      'methods' => 
      array (
        0 => 'GET',
        1 => 'HEAD',
      ),
      'uri' => 'admin/training-vest-customization-options/size-groups/create',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'admin.hidden',
          2 => 'auth:admin',
          3 => 'admin',
          4 => 'admin.permission',
          5 => 'admin.activity',
        ),
        'uses' => 'App\\Http\\Controllers\\Admin\\TrainingVestCustomizationOptionController@createSizeGroup',
        'controller' => 'App\\Http\\Controllers\\Admin\\TrainingVestCustomizationOptionController@createSizeGroup',
        'as' => 'admin.training-vest-size-option-groups.create',
        'namespace' => NULL,
        'prefix' => '/admin',
        'where' => 
        array (
        ),
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'admin.training-vest-size-option-groups.store' => 
    array (
      'methods' => 
      array (
        0 => 'POST',
      ),
      'uri' => 'admin/training-vest-customization-options/size-groups',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'admin.hidden',
          2 => 'auth:admin',
          3 => 'admin',
          4 => 'admin.permission',
          5 => 'admin.activity',
        ),
        'uses' => 'App\\Http\\Controllers\\Admin\\TrainingVestCustomizationOptionController@storeSizeGroup',
        'controller' => 'App\\Http\\Controllers\\Admin\\TrainingVestCustomizationOptionController@storeSizeGroup',
        'as' => 'admin.training-vest-size-option-groups.store',
        'namespace' => NULL,
        'prefix' => '/admin',
        'where' => 
        array (
        ),
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'admin.training-vest-size-option-groups.edit' => 
    array (
      'methods' => 
      array (
        0 => 'GET',
        1 => 'HEAD',
      ),
      'uri' => 'admin/training-vest-customization-options/size-groups/{trainingVestSizeOptionGroup}/edit',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'admin.hidden',
          2 => 'auth:admin',
          3 => 'admin',
          4 => 'admin.permission',
          5 => 'admin.activity',
        ),
        'uses' => 'App\\Http\\Controllers\\Admin\\TrainingVestCustomizationOptionController@editSizeGroup',
        'controller' => 'App\\Http\\Controllers\\Admin\\TrainingVestCustomizationOptionController@editSizeGroup',
        'as' => 'admin.training-vest-size-option-groups.edit',
        'namespace' => NULL,
        'prefix' => '/admin',
        'where' => 
        array (
        ),
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'admin.training-vest-size-option-groups.update' => 
    array (
      'methods' => 
      array (
        0 => 'PUT',
      ),
      'uri' => 'admin/training-vest-customization-options/size-groups/{trainingVestSizeOptionGroup}',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'admin.hidden',
          2 => 'auth:admin',
          3 => 'admin',
          4 => 'admin.permission',
          5 => 'admin.activity',
        ),
        'uses' => 'App\\Http\\Controllers\\Admin\\TrainingVestCustomizationOptionController@updateSizeGroup',
        'controller' => 'App\\Http\\Controllers\\Admin\\TrainingVestCustomizationOptionController@updateSizeGroup',
        'as' => 'admin.training-vest-size-option-groups.update',
        'namespace' => NULL,
        'prefix' => '/admin',
        'where' => 
        array (
        ),
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'admin.training-vest-size-option-groups.destroy' => 
    array (
      'methods' => 
      array (
        0 => 'DELETE',
      ),
      'uri' => 'admin/training-vest-customization-options/size-groups/{trainingVestSizeOptionGroup}',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'admin.hidden',
          2 => 'auth:admin',
          3 => 'admin',
          4 => 'admin.permission',
          5 => 'admin.activity',
        ),
        'uses' => 'App\\Http\\Controllers\\Admin\\TrainingVestCustomizationOptionController@destroySizeGroup',
        'controller' => 'App\\Http\\Controllers\\Admin\\TrainingVestCustomizationOptionController@destroySizeGroup',
        'as' => 'admin.training-vest-size-option-groups.destroy',
        'namespace' => NULL,
        'prefix' => '/admin',
        'where' => 
        array (
        ),
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'admin.training-vest-customization-options.index' => 
    array (
      'methods' => 
      array (
        0 => 'GET',
        1 => 'HEAD',
      ),
      'uri' => 'admin/training-vest-customization-options',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'admin.hidden',
          2 => 'auth:admin',
          3 => 'admin',
          4 => 'admin.permission',
          5 => 'admin.activity',
        ),
        'as' => 'admin.training-vest-customization-options.index',
        'uses' => 'App\\Http\\Controllers\\Admin\\TrainingVestCustomizationOptionController@index',
        'controller' => 'App\\Http\\Controllers\\Admin\\TrainingVestCustomizationOptionController@index',
        'namespace' => NULL,
        'prefix' => '/admin',
        'where' => 
        array (
        ),
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'admin.training-vest-customization-options.create' => 
    array (
      'methods' => 
      array (
        0 => 'GET',
        1 => 'HEAD',
      ),
      'uri' => 'admin/training-vest-customization-options/create',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'admin.hidden',
          2 => 'auth:admin',
          3 => 'admin',
          4 => 'admin.permission',
          5 => 'admin.activity',
        ),
        'as' => 'admin.training-vest-customization-options.create',
        'uses' => 'App\\Http\\Controllers\\Admin\\TrainingVestCustomizationOptionController@create',
        'controller' => 'App\\Http\\Controllers\\Admin\\TrainingVestCustomizationOptionController@create',
        'namespace' => NULL,
        'prefix' => '/admin',
        'where' => 
        array (
        ),
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'admin.training-vest-customization-options.store' => 
    array (
      'methods' => 
      array (
        0 => 'POST',
      ),
      'uri' => 'admin/training-vest-customization-options',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'admin.hidden',
          2 => 'auth:admin',
          3 => 'admin',
          4 => 'admin.permission',
          5 => 'admin.activity',
        ),
        'as' => 'admin.training-vest-customization-options.store',
        'uses' => 'App\\Http\\Controllers\\Admin\\TrainingVestCustomizationOptionController@store',
        'controller' => 'App\\Http\\Controllers\\Admin\\TrainingVestCustomizationOptionController@store',
        'namespace' => NULL,
        'prefix' => '/admin',
        'where' => 
        array (
        ),
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'admin.training-vest-customization-options.edit' => 
    array (
      'methods' => 
      array (
        0 => 'GET',
        1 => 'HEAD',
      ),
      'uri' => 'admin/training-vest-customization-options/{trainingVestCustomizationOption}/edit',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'admin.hidden',
          2 => 'auth:admin',
          3 => 'admin',
          4 => 'admin.permission',
          5 => 'admin.activity',
        ),
        'as' => 'admin.training-vest-customization-options.edit',
        'uses' => 'App\\Http\\Controllers\\Admin\\TrainingVestCustomizationOptionController@edit',
        'controller' => 'App\\Http\\Controllers\\Admin\\TrainingVestCustomizationOptionController@edit',
        'namespace' => NULL,
        'prefix' => '/admin',
        'where' => 
        array (
        ),
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'admin.training-vest-customization-options.update' => 
    array (
      'methods' => 
      array (
        0 => 'PUT',
        1 => 'PATCH',
      ),
      'uri' => 'admin/training-vest-customization-options/{trainingVestCustomizationOption}',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'admin.hidden',
          2 => 'auth:admin',
          3 => 'admin',
          4 => 'admin.permission',
          5 => 'admin.activity',
        ),
        'as' => 'admin.training-vest-customization-options.update',
        'uses' => 'App\\Http\\Controllers\\Admin\\TrainingVestCustomizationOptionController@update',
        'controller' => 'App\\Http\\Controllers\\Admin\\TrainingVestCustomizationOptionController@update',
        'namespace' => NULL,
        'prefix' => '/admin',
        'where' => 
        array (
        ),
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'admin.training-vest-customization-options.destroy' => 
    array (
      'methods' => 
      array (
        0 => 'DELETE',
      ),
      'uri' => 'admin/training-vest-customization-options/{trainingVestCustomizationOption}',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'admin.hidden',
          2 => 'auth:admin',
          3 => 'admin',
          4 => 'admin.permission',
          5 => 'admin.activity',
        ),
        'as' => 'admin.training-vest-customization-options.destroy',
        'uses' => 'App\\Http\\Controllers\\Admin\\TrainingVestCustomizationOptionController@destroy',
        'controller' => 'App\\Http\\Controllers\\Admin\\TrainingVestCustomizationOptionController@destroy',
        'namespace' => NULL,
        'prefix' => '/admin',
        'where' => 
        array (
        ),
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'admin.size-option-groups.index' => 
    array (
      'methods' => 
      array (
        0 => 'GET',
        1 => 'HEAD',
      ),
      'uri' => 'admin/size-option-groups',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'admin.hidden',
          2 => 'auth:admin',
          3 => 'admin',
          4 => 'admin.permission',
          5 => 'admin.activity',
        ),
        'as' => 'admin.size-option-groups.index',
        'uses' => 'App\\Http\\Controllers\\Admin\\SizeOptionGroupController@index',
        'controller' => 'App\\Http\\Controllers\\Admin\\SizeOptionGroupController@index',
        'namespace' => NULL,
        'prefix' => '/admin',
        'where' => 
        array (
        ),
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'admin.size-option-groups.create' => 
    array (
      'methods' => 
      array (
        0 => 'GET',
        1 => 'HEAD',
      ),
      'uri' => 'admin/size-option-groups/create',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'admin.hidden',
          2 => 'auth:admin',
          3 => 'admin',
          4 => 'admin.permission',
          5 => 'admin.activity',
        ),
        'as' => 'admin.size-option-groups.create',
        'uses' => 'App\\Http\\Controllers\\Admin\\SizeOptionGroupController@create',
        'controller' => 'App\\Http\\Controllers\\Admin\\SizeOptionGroupController@create',
        'namespace' => NULL,
        'prefix' => '/admin',
        'where' => 
        array (
        ),
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'admin.size-option-groups.store' => 
    array (
      'methods' => 
      array (
        0 => 'POST',
      ),
      'uri' => 'admin/size-option-groups',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'admin.hidden',
          2 => 'auth:admin',
          3 => 'admin',
          4 => 'admin.permission',
          5 => 'admin.activity',
        ),
        'as' => 'admin.size-option-groups.store',
        'uses' => 'App\\Http\\Controllers\\Admin\\SizeOptionGroupController@store',
        'controller' => 'App\\Http\\Controllers\\Admin\\SizeOptionGroupController@store',
        'namespace' => NULL,
        'prefix' => '/admin',
        'where' => 
        array (
        ),
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'admin.size-option-groups.edit' => 
    array (
      'methods' => 
      array (
        0 => 'GET',
        1 => 'HEAD',
      ),
      'uri' => 'admin/size-option-groups/{sizeOptionGroup}/edit',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'admin.hidden',
          2 => 'auth:admin',
          3 => 'admin',
          4 => 'admin.permission',
          5 => 'admin.activity',
        ),
        'as' => 'admin.size-option-groups.edit',
        'uses' => 'App\\Http\\Controllers\\Admin\\SizeOptionGroupController@edit',
        'controller' => 'App\\Http\\Controllers\\Admin\\SizeOptionGroupController@edit',
        'namespace' => NULL,
        'prefix' => '/admin',
        'where' => 
        array (
        ),
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'admin.size-option-groups.update' => 
    array (
      'methods' => 
      array (
        0 => 'PUT',
        1 => 'PATCH',
      ),
      'uri' => 'admin/size-option-groups/{sizeOptionGroup}',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'admin.hidden',
          2 => 'auth:admin',
          3 => 'admin',
          4 => 'admin.permission',
          5 => 'admin.activity',
        ),
        'as' => 'admin.size-option-groups.update',
        'uses' => 'App\\Http\\Controllers\\Admin\\SizeOptionGroupController@update',
        'controller' => 'App\\Http\\Controllers\\Admin\\SizeOptionGroupController@update',
        'namespace' => NULL,
        'prefix' => '/admin',
        'where' => 
        array (
        ),
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'admin.size-option-groups.destroy' => 
    array (
      'methods' => 
      array (
        0 => 'DELETE',
      ),
      'uri' => 'admin/size-option-groups/{sizeOptionGroup}',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'admin.hidden',
          2 => 'auth:admin',
          3 => 'admin',
          4 => 'admin.permission',
          5 => 'admin.activity',
        ),
        'as' => 'admin.size-option-groups.destroy',
        'uses' => 'App\\Http\\Controllers\\Admin\\SizeOptionGroupController@destroy',
        'controller' => 'App\\Http\\Controllers\\Admin\\SizeOptionGroupController@destroy',
        'namespace' => NULL,
        'prefix' => '/admin',
        'where' => 
        array (
        ),
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'admin.menus.index' => 
    array (
      'methods' => 
      array (
        0 => 'GET',
        1 => 'HEAD',
      ),
      'uri' => 'admin/menus',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'admin.hidden',
          2 => 'auth:admin',
          3 => 'admin',
          4 => 'admin.permission',
          5 => 'admin.activity',
        ),
        'as' => 'admin.menus.index',
        'uses' => 'App\\Http\\Controllers\\Admin\\MenuController@index',
        'controller' => 'App\\Http\\Controllers\\Admin\\MenuController@index',
        'namespace' => NULL,
        'prefix' => '/admin',
        'where' => 
        array (
        ),
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'admin.menus.create' => 
    array (
      'methods' => 
      array (
        0 => 'GET',
        1 => 'HEAD',
      ),
      'uri' => 'admin/menus/create',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'admin.hidden',
          2 => 'auth:admin',
          3 => 'admin',
          4 => 'admin.permission',
          5 => 'admin.activity',
        ),
        'as' => 'admin.menus.create',
        'uses' => 'App\\Http\\Controllers\\Admin\\MenuController@create',
        'controller' => 'App\\Http\\Controllers\\Admin\\MenuController@create',
        'namespace' => NULL,
        'prefix' => '/admin',
        'where' => 
        array (
        ),
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'admin.menus.store' => 
    array (
      'methods' => 
      array (
        0 => 'POST',
      ),
      'uri' => 'admin/menus',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'admin.hidden',
          2 => 'auth:admin',
          3 => 'admin',
          4 => 'admin.permission',
          5 => 'admin.activity',
        ),
        'as' => 'admin.menus.store',
        'uses' => 'App\\Http\\Controllers\\Admin\\MenuController@store',
        'controller' => 'App\\Http\\Controllers\\Admin\\MenuController@store',
        'namespace' => NULL,
        'prefix' => '/admin',
        'where' => 
        array (
        ),
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'admin.menus.edit' => 
    array (
      'methods' => 
      array (
        0 => 'GET',
        1 => 'HEAD',
      ),
      'uri' => 'admin/menus/{menu}/edit',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'admin.hidden',
          2 => 'auth:admin',
          3 => 'admin',
          4 => 'admin.permission',
          5 => 'admin.activity',
        ),
        'as' => 'admin.menus.edit',
        'uses' => 'App\\Http\\Controllers\\Admin\\MenuController@edit',
        'controller' => 'App\\Http\\Controllers\\Admin\\MenuController@edit',
        'namespace' => NULL,
        'prefix' => '/admin',
        'where' => 
        array (
        ),
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'admin.menus.update' => 
    array (
      'methods' => 
      array (
        0 => 'PUT',
        1 => 'PATCH',
      ),
      'uri' => 'admin/menus/{menu}',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'admin.hidden',
          2 => 'auth:admin',
          3 => 'admin',
          4 => 'admin.permission',
          5 => 'admin.activity',
        ),
        'as' => 'admin.menus.update',
        'uses' => 'App\\Http\\Controllers\\Admin\\MenuController@update',
        'controller' => 'App\\Http\\Controllers\\Admin\\MenuController@update',
        'namespace' => NULL,
        'prefix' => '/admin',
        'where' => 
        array (
        ),
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'admin.menus.destroy' => 
    array (
      'methods' => 
      array (
        0 => 'DELETE',
      ),
      'uri' => 'admin/menus/{menu}',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'admin.hidden',
          2 => 'auth:admin',
          3 => 'admin',
          4 => 'admin.permission',
          5 => 'admin.activity',
        ),
        'as' => 'admin.menus.destroy',
        'uses' => 'App\\Http\\Controllers\\Admin\\MenuController@destroy',
        'controller' => 'App\\Http\\Controllers\\Admin\\MenuController@destroy',
        'namespace' => NULL,
        'prefix' => '/admin',
        'where' => 
        array (
        ),
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'admin.promotions.sales.index' => 
    array (
      'methods' => 
      array (
        0 => 'GET',
        1 => 'HEAD',
      ),
      'uri' => 'admin/promotions/sales',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'admin.hidden',
          2 => 'auth:admin',
          3 => 'admin',
          4 => 'admin.permission',
          5 => 'admin.activity',
        ),
        'uses' => 'App\\Http\\Controllers\\Admin\\SaleCampaignController@index',
        'controller' => 'App\\Http\\Controllers\\Admin\\SaleCampaignController@index',
        'as' => 'admin.promotions.sales.index',
        'namespace' => NULL,
        'prefix' => '/admin',
        'where' => 
        array (
        ),
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'admin.promotions.sales.options' => 
    array (
      'methods' => 
      array (
        0 => 'GET',
        1 => 'HEAD',
      ),
      'uri' => 'admin/promotions/sales/options',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'admin.hidden',
          2 => 'auth:admin',
          3 => 'admin',
          4 => 'admin.permission',
          5 => 'admin.activity',
        ),
        'uses' => 'App\\Http\\Controllers\\Admin\\SaleCampaignController@options',
        'controller' => 'App\\Http\\Controllers\\Admin\\SaleCampaignController@options',
        'as' => 'admin.promotions.sales.options',
        'namespace' => NULL,
        'prefix' => '/admin',
        'where' => 
        array (
        ),
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'admin.promotions.sales.create' => 
    array (
      'methods' => 
      array (
        0 => 'GET',
        1 => 'HEAD',
      ),
      'uri' => 'admin/promotions/sales/create',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'admin.hidden',
          2 => 'auth:admin',
          3 => 'admin',
          4 => 'admin.permission',
          5 => 'admin.activity',
        ),
        'uses' => 'App\\Http\\Controllers\\Admin\\SaleCampaignController@create',
        'controller' => 'App\\Http\\Controllers\\Admin\\SaleCampaignController@create',
        'as' => 'admin.promotions.sales.create',
        'namespace' => NULL,
        'prefix' => '/admin',
        'where' => 
        array (
        ),
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'admin.promotions.sales.store' => 
    array (
      'methods' => 
      array (
        0 => 'POST',
      ),
      'uri' => 'admin/promotions/sales',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'admin.hidden',
          2 => 'auth:admin',
          3 => 'admin',
          4 => 'admin.permission',
          5 => 'admin.activity',
        ),
        'uses' => 'App\\Http\\Controllers\\Admin\\SaleCampaignController@store',
        'controller' => 'App\\Http\\Controllers\\Admin\\SaleCampaignController@store',
        'as' => 'admin.promotions.sales.store',
        'namespace' => NULL,
        'prefix' => '/admin',
        'where' => 
        array (
        ),
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'admin.promotions.sales.edit' => 
    array (
      'methods' => 
      array (
        0 => 'GET',
        1 => 'HEAD',
      ),
      'uri' => 'admin/promotions/sales/{saleCampaign}/edit',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'admin.hidden',
          2 => 'auth:admin',
          3 => 'admin',
          4 => 'admin.permission',
          5 => 'admin.activity',
        ),
        'uses' => 'App\\Http\\Controllers\\Admin\\SaleCampaignController@edit',
        'controller' => 'App\\Http\\Controllers\\Admin\\SaleCampaignController@edit',
        'as' => 'admin.promotions.sales.edit',
        'namespace' => NULL,
        'prefix' => '/admin',
        'where' => 
        array (
        ),
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'admin.promotions.sales.update' => 
    array (
      'methods' => 
      array (
        0 => 'PUT',
      ),
      'uri' => 'admin/promotions/sales/{saleCampaign}',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'admin.hidden',
          2 => 'auth:admin',
          3 => 'admin',
          4 => 'admin.permission',
          5 => 'admin.activity',
        ),
        'uses' => 'App\\Http\\Controllers\\Admin\\SaleCampaignController@update',
        'controller' => 'App\\Http\\Controllers\\Admin\\SaleCampaignController@update',
        'as' => 'admin.promotions.sales.update',
        'namespace' => NULL,
        'prefix' => '/admin',
        'where' => 
        array (
        ),
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'admin.promotions.banners.index' => 
    array (
      'methods' => 
      array (
        0 => 'GET',
        1 => 'HEAD',
      ),
      'uri' => 'admin/promotions/banners',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'admin.hidden',
          2 => 'auth:admin',
          3 => 'admin',
          4 => 'admin.permission',
          5 => 'admin.activity',
        ),
        'uses' => 'App\\Http\\Controllers\\Admin\\SaleBannerController@index',
        'controller' => 'App\\Http\\Controllers\\Admin\\SaleBannerController@index',
        'as' => 'admin.promotions.banners.index',
        'namespace' => NULL,
        'prefix' => '/admin',
        'where' => 
        array (
        ),
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'admin.promotions.banners.store' => 
    array (
      'methods' => 
      array (
        0 => 'POST',
      ),
      'uri' => 'admin/promotions/banners',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'admin.hidden',
          2 => 'auth:admin',
          3 => 'admin',
          4 => 'admin.permission',
          5 => 'admin.activity',
        ),
        'uses' => 'App\\Http\\Controllers\\Admin\\SaleBannerController@store',
        'controller' => 'App\\Http\\Controllers\\Admin\\SaleBannerController@store',
        'as' => 'admin.promotions.banners.store',
        'namespace' => NULL,
        'prefix' => '/admin',
        'where' => 
        array (
        ),
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'admin.promotions.banners.update' => 
    array (
      'methods' => 
      array (
        0 => 'PUT',
      ),
      'uri' => 'admin/promotions/banners/{saleBanner}',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'admin.hidden',
          2 => 'auth:admin',
          3 => 'admin',
          4 => 'admin.permission',
          5 => 'admin.activity',
        ),
        'uses' => 'App\\Http\\Controllers\\Admin\\SaleBannerController@update',
        'controller' => 'App\\Http\\Controllers\\Admin\\SaleBannerController@update',
        'as' => 'admin.promotions.banners.update',
        'namespace' => NULL,
        'prefix' => '/admin',
        'where' => 
        array (
        ),
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'admin.promotions.banners.destroy' => 
    array (
      'methods' => 
      array (
        0 => 'DELETE',
      ),
      'uri' => 'admin/promotions/banners/{saleBanner}',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'admin.hidden',
          2 => 'auth:admin',
          3 => 'admin',
          4 => 'admin.permission',
          5 => 'admin.activity',
        ),
        'uses' => 'App\\Http\\Controllers\\Admin\\SaleBannerController@destroy',
        'controller' => 'App\\Http\\Controllers\\Admin\\SaleBannerController@destroy',
        'as' => 'admin.promotions.banners.destroy',
        'namespace' => NULL,
        'prefix' => '/admin',
        'where' => 
        array (
        ),
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'admin.promotions.banners.reorder' => 
    array (
      'methods' => 
      array (
        0 => 'POST',
      ),
      'uri' => 'admin/promotions/banners/reorder',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'admin.hidden',
          2 => 'auth:admin',
          3 => 'admin',
          4 => 'admin.permission',
          5 => 'admin.activity',
        ),
        'uses' => 'App\\Http\\Controllers\\Admin\\SaleBannerController@reorder',
        'controller' => 'App\\Http\\Controllers\\Admin\\SaleBannerController@reorder',
        'as' => 'admin.promotions.banners.reorder',
        'namespace' => NULL,
        'prefix' => '/admin',
        'where' => 
        array (
        ),
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'admin.time-zones.index' => 
    array (
      'methods' => 
      array (
        0 => 'GET',
        1 => 'HEAD',
      ),
      'uri' => 'admin/time-zones',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'admin.hidden',
          2 => 'auth:admin',
          3 => 'admin',
          4 => 'admin.permission',
          5 => 'admin.activity',
        ),
        'as' => 'admin.time-zones.index',
        'uses' => 'App\\Http\\Controllers\\Admin\\TimeZoneController@index',
        'controller' => 'App\\Http\\Controllers\\Admin\\TimeZoneController@index',
        'namespace' => NULL,
        'prefix' => '/admin',
        'where' => 
        array (
        ),
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'admin.time-zones.create' => 
    array (
      'methods' => 
      array (
        0 => 'GET',
        1 => 'HEAD',
      ),
      'uri' => 'admin/time-zones/create',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'admin.hidden',
          2 => 'auth:admin',
          3 => 'admin',
          4 => 'admin.permission',
          5 => 'admin.activity',
        ),
        'as' => 'admin.time-zones.create',
        'uses' => 'App\\Http\\Controllers\\Admin\\TimeZoneController@create',
        'controller' => 'App\\Http\\Controllers\\Admin\\TimeZoneController@create',
        'namespace' => NULL,
        'prefix' => '/admin',
        'where' => 
        array (
        ),
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'admin.time-zones.store' => 
    array (
      'methods' => 
      array (
        0 => 'POST',
      ),
      'uri' => 'admin/time-zones',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'admin.hidden',
          2 => 'auth:admin',
          3 => 'admin',
          4 => 'admin.permission',
          5 => 'admin.activity',
        ),
        'as' => 'admin.time-zones.store',
        'uses' => 'App\\Http\\Controllers\\Admin\\TimeZoneController@store',
        'controller' => 'App\\Http\\Controllers\\Admin\\TimeZoneController@store',
        'namespace' => NULL,
        'prefix' => '/admin',
        'where' => 
        array (
        ),
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'admin.time-zones.edit' => 
    array (
      'methods' => 
      array (
        0 => 'GET',
        1 => 'HEAD',
      ),
      'uri' => 'admin/time-zones/{timeZone}/edit',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'admin.hidden',
          2 => 'auth:admin',
          3 => 'admin',
          4 => 'admin.permission',
          5 => 'admin.activity',
        ),
        'as' => 'admin.time-zones.edit',
        'uses' => 'App\\Http\\Controllers\\Admin\\TimeZoneController@edit',
        'controller' => 'App\\Http\\Controllers\\Admin\\TimeZoneController@edit',
        'namespace' => NULL,
        'prefix' => '/admin',
        'where' => 
        array (
        ),
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'admin.time-zones.update' => 
    array (
      'methods' => 
      array (
        0 => 'PUT',
        1 => 'PATCH',
      ),
      'uri' => 'admin/time-zones/{timeZone}',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'admin.hidden',
          2 => 'auth:admin',
          3 => 'admin',
          4 => 'admin.permission',
          5 => 'admin.activity',
        ),
        'as' => 'admin.time-zones.update',
        'uses' => 'App\\Http\\Controllers\\Admin\\TimeZoneController@update',
        'controller' => 'App\\Http\\Controllers\\Admin\\TimeZoneController@update',
        'namespace' => NULL,
        'prefix' => '/admin',
        'where' => 
        array (
        ),
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'admin.time-zones.destroy' => 
    array (
      'methods' => 
      array (
        0 => 'DELETE',
      ),
      'uri' => 'admin/time-zones/{timeZone}',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'admin.hidden',
          2 => 'auth:admin',
          3 => 'admin',
          4 => 'admin.permission',
          5 => 'admin.activity',
        ),
        'as' => 'admin.time-zones.destroy',
        'uses' => 'App\\Http\\Controllers\\Admin\\TimeZoneController@destroy',
        'controller' => 'App\\Http\\Controllers\\Admin\\TimeZoneController@destroy',
        'namespace' => NULL,
        'prefix' => '/admin',
        'where' => 
        array (
        ),
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'admin.coupons.index' => 
    array (
      'methods' => 
      array (
        0 => 'GET',
        1 => 'HEAD',
      ),
      'uri' => 'admin/coupons',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'admin.hidden',
          2 => 'auth:admin',
          3 => 'admin',
          4 => 'admin.permission',
          5 => 'admin.activity',
        ),
        'as' => 'admin.coupons.index',
        'uses' => 'App\\Http\\Controllers\\Admin\\CouponController@index',
        'controller' => 'App\\Http\\Controllers\\Admin\\CouponController@index',
        'namespace' => NULL,
        'prefix' => '/admin',
        'where' => 
        array (
        ),
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'admin.coupons.create' => 
    array (
      'methods' => 
      array (
        0 => 'GET',
        1 => 'HEAD',
      ),
      'uri' => 'admin/coupons/create',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'admin.hidden',
          2 => 'auth:admin',
          3 => 'admin',
          4 => 'admin.permission',
          5 => 'admin.activity',
        ),
        'as' => 'admin.coupons.create',
        'uses' => 'App\\Http\\Controllers\\Admin\\CouponController@create',
        'controller' => 'App\\Http\\Controllers\\Admin\\CouponController@create',
        'namespace' => NULL,
        'prefix' => '/admin',
        'where' => 
        array (
        ),
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'admin.coupons.store' => 
    array (
      'methods' => 
      array (
        0 => 'POST',
      ),
      'uri' => 'admin/coupons',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'admin.hidden',
          2 => 'auth:admin',
          3 => 'admin',
          4 => 'admin.permission',
          5 => 'admin.activity',
        ),
        'as' => 'admin.coupons.store',
        'uses' => 'App\\Http\\Controllers\\Admin\\CouponController@store',
        'controller' => 'App\\Http\\Controllers\\Admin\\CouponController@store',
        'namespace' => NULL,
        'prefix' => '/admin',
        'where' => 
        array (
        ),
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'admin.coupons.edit' => 
    array (
      'methods' => 
      array (
        0 => 'GET',
        1 => 'HEAD',
      ),
      'uri' => 'admin/coupons/{coupon}/edit',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'admin.hidden',
          2 => 'auth:admin',
          3 => 'admin',
          4 => 'admin.permission',
          5 => 'admin.activity',
        ),
        'as' => 'admin.coupons.edit',
        'uses' => 'App\\Http\\Controllers\\Admin\\CouponController@edit',
        'controller' => 'App\\Http\\Controllers\\Admin\\CouponController@edit',
        'namespace' => NULL,
        'prefix' => '/admin',
        'where' => 
        array (
        ),
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'admin.coupons.update' => 
    array (
      'methods' => 
      array (
        0 => 'PUT',
        1 => 'PATCH',
      ),
      'uri' => 'admin/coupons/{coupon}',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'admin.hidden',
          2 => 'auth:admin',
          3 => 'admin',
          4 => 'admin.permission',
          5 => 'admin.activity',
        ),
        'as' => 'admin.coupons.update',
        'uses' => 'App\\Http\\Controllers\\Admin\\CouponController@update',
        'controller' => 'App\\Http\\Controllers\\Admin\\CouponController@update',
        'namespace' => NULL,
        'prefix' => '/admin',
        'where' => 
        array (
        ),
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'admin.coupons.destroy' => 
    array (
      'methods' => 
      array (
        0 => 'DELETE',
      ),
      'uri' => 'admin/coupons/{coupon}',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'admin.hidden',
          2 => 'auth:admin',
          3 => 'admin',
          4 => 'admin.permission',
          5 => 'admin.activity',
        ),
        'as' => 'admin.coupons.destroy',
        'uses' => 'App\\Http\\Controllers\\Admin\\CouponController@destroy',
        'controller' => 'App\\Http\\Controllers\\Admin\\CouponController@destroy',
        'namespace' => NULL,
        'prefix' => '/admin',
        'where' => 
        array (
        ),
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'admin.rural-area-surcharges.import.start' => 
    array (
      'methods' => 
      array (
        0 => 'POST',
      ),
      'uri' => 'admin/rural-area-surcharges/import/start',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'admin.hidden',
          2 => 'auth:admin',
          3 => 'admin',
          4 => 'admin.permission',
          5 => 'admin.activity',
          6 => 'throttle:10,1',
        ),
        'uses' => 'App\\Http\\Controllers\\Admin\\RuralAreaSurchargeController@importStart',
        'controller' => 'App\\Http\\Controllers\\Admin\\RuralAreaSurchargeController@importStart',
        'as' => 'admin.rural-area-surcharges.import.start',
        'namespace' => NULL,
        'prefix' => '/admin',
        'where' => 
        array (
        ),
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'admin.rural-area-surcharges.import.chunk' => 
    array (
      'methods' => 
      array (
        0 => 'POST',
      ),
      'uri' => 'admin/rural-area-surcharges/import/chunk',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'admin.hidden',
          2 => 'auth:admin',
          3 => 'admin',
          4 => 'admin.permission',
          5 => 'admin.activity',
          6 => 'throttle:120,1',
        ),
        'uses' => 'App\\Http\\Controllers\\Admin\\RuralAreaSurchargeController@importChunk',
        'controller' => 'App\\Http\\Controllers\\Admin\\RuralAreaSurchargeController@importChunk',
        'as' => 'admin.rural-area-surcharges.import.chunk',
        'namespace' => NULL,
        'prefix' => '/admin',
        'where' => 
        array (
        ),
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'admin.rural-area-surcharges.import.finish' => 
    array (
      'methods' => 
      array (
        0 => 'POST',
      ),
      'uri' => 'admin/rural-area-surcharges/import/finish',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'admin.hidden',
          2 => 'auth:admin',
          3 => 'admin',
          4 => 'admin.permission',
          5 => 'admin.activity',
          6 => 'throttle:10,1',
        ),
        'uses' => 'App\\Http\\Controllers\\Admin\\RuralAreaSurchargeController@importFinish',
        'controller' => 'App\\Http\\Controllers\\Admin\\RuralAreaSurchargeController@importFinish',
        'as' => 'admin.rural-area-surcharges.import.finish',
        'namespace' => NULL,
        'prefix' => '/admin',
        'where' => 
        array (
        ),
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'admin.rural-area-surcharges.index' => 
    array (
      'methods' => 
      array (
        0 => 'GET',
        1 => 'HEAD',
      ),
      'uri' => 'admin/rural-area-surcharges',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'admin.hidden',
          2 => 'auth:admin',
          3 => 'admin',
          4 => 'admin.permission',
          5 => 'admin.activity',
        ),
        'as' => 'admin.rural-area-surcharges.index',
        'uses' => 'App\\Http\\Controllers\\Admin\\RuralAreaSurchargeController@index',
        'controller' => 'App\\Http\\Controllers\\Admin\\RuralAreaSurchargeController@index',
        'namespace' => NULL,
        'prefix' => '/admin',
        'where' => 
        array (
        ),
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'admin.rural-area-surcharges.create' => 
    array (
      'methods' => 
      array (
        0 => 'GET',
        1 => 'HEAD',
      ),
      'uri' => 'admin/rural-area-surcharges/create',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'admin.hidden',
          2 => 'auth:admin',
          3 => 'admin',
          4 => 'admin.permission',
          5 => 'admin.activity',
        ),
        'as' => 'admin.rural-area-surcharges.create',
        'uses' => 'App\\Http\\Controllers\\Admin\\RuralAreaSurchargeController@create',
        'controller' => 'App\\Http\\Controllers\\Admin\\RuralAreaSurchargeController@create',
        'namespace' => NULL,
        'prefix' => '/admin',
        'where' => 
        array (
        ),
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'admin.rural-area-surcharges.store' => 
    array (
      'methods' => 
      array (
        0 => 'POST',
      ),
      'uri' => 'admin/rural-area-surcharges',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'admin.hidden',
          2 => 'auth:admin',
          3 => 'admin',
          4 => 'admin.permission',
          5 => 'admin.activity',
        ),
        'as' => 'admin.rural-area-surcharges.store',
        'uses' => 'App\\Http\\Controllers\\Admin\\RuralAreaSurchargeController@store',
        'controller' => 'App\\Http\\Controllers\\Admin\\RuralAreaSurchargeController@store',
        'namespace' => NULL,
        'prefix' => '/admin',
        'where' => 
        array (
        ),
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'admin.rural-area-surcharges.edit' => 
    array (
      'methods' => 
      array (
        0 => 'GET',
        1 => 'HEAD',
      ),
      'uri' => 'admin/rural-area-surcharges/{ruralAreaSurcharge}/edit',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'admin.hidden',
          2 => 'auth:admin',
          3 => 'admin',
          4 => 'admin.permission',
          5 => 'admin.activity',
        ),
        'as' => 'admin.rural-area-surcharges.edit',
        'uses' => 'App\\Http\\Controllers\\Admin\\RuralAreaSurchargeController@edit',
        'controller' => 'App\\Http\\Controllers\\Admin\\RuralAreaSurchargeController@edit',
        'namespace' => NULL,
        'prefix' => '/admin',
        'where' => 
        array (
        ),
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'admin.rural-area-surcharges.update' => 
    array (
      'methods' => 
      array (
        0 => 'PUT',
        1 => 'PATCH',
      ),
      'uri' => 'admin/rural-area-surcharges/{ruralAreaSurcharge}',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'admin.hidden',
          2 => 'auth:admin',
          3 => 'admin',
          4 => 'admin.permission',
          5 => 'admin.activity',
        ),
        'as' => 'admin.rural-area-surcharges.update',
        'uses' => 'App\\Http\\Controllers\\Admin\\RuralAreaSurchargeController@update',
        'controller' => 'App\\Http\\Controllers\\Admin\\RuralAreaSurchargeController@update',
        'namespace' => NULL,
        'prefix' => '/admin',
        'where' => 
        array (
        ),
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'admin.rural-area-surcharges.destroy' => 
    array (
      'methods' => 
      array (
        0 => 'DELETE',
      ),
      'uri' => 'admin/rural-area-surcharges/{ruralAreaSurcharge}',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'admin.hidden',
          2 => 'auth:admin',
          3 => 'admin',
          4 => 'admin.permission',
          5 => 'admin.activity',
        ),
        'as' => 'admin.rural-area-surcharges.destroy',
        'uses' => 'App\\Http\\Controllers\\Admin\\RuralAreaSurchargeController@destroy',
        'controller' => 'App\\Http\\Controllers\\Admin\\RuralAreaSurchargeController@destroy',
        'namespace' => NULL,
        'prefix' => '/admin',
        'where' => 
        array (
        ),
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'admin.production-methods.index' => 
    array (
      'methods' => 
      array (
        0 => 'GET',
        1 => 'HEAD',
      ),
      'uri' => 'admin/production-methods',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'admin.hidden',
          2 => 'auth:admin',
          3 => 'admin',
          4 => 'admin.permission',
          5 => 'admin.activity',
        ),
        'as' => 'admin.production-methods.index',
        'uses' => 'App\\Http\\Controllers\\Admin\\ProductionMethodController@index',
        'controller' => 'App\\Http\\Controllers\\Admin\\ProductionMethodController@index',
        'namespace' => NULL,
        'prefix' => '/admin',
        'where' => 
        array (
        ),
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'admin.production-methods.create' => 
    array (
      'methods' => 
      array (
        0 => 'GET',
        1 => 'HEAD',
      ),
      'uri' => 'admin/production-methods/create',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'admin.hidden',
          2 => 'auth:admin',
          3 => 'admin',
          4 => 'admin.permission',
          5 => 'admin.activity',
        ),
        'as' => 'admin.production-methods.create',
        'uses' => 'App\\Http\\Controllers\\Admin\\ProductionMethodController@create',
        'controller' => 'App\\Http\\Controllers\\Admin\\ProductionMethodController@create',
        'namespace' => NULL,
        'prefix' => '/admin',
        'where' => 
        array (
        ),
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'admin.production-methods.store' => 
    array (
      'methods' => 
      array (
        0 => 'POST',
      ),
      'uri' => 'admin/production-methods',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'admin.hidden',
          2 => 'auth:admin',
          3 => 'admin',
          4 => 'admin.permission',
          5 => 'admin.activity',
        ),
        'as' => 'admin.production-methods.store',
        'uses' => 'App\\Http\\Controllers\\Admin\\ProductionMethodController@store',
        'controller' => 'App\\Http\\Controllers\\Admin\\ProductionMethodController@store',
        'namespace' => NULL,
        'prefix' => '/admin',
        'where' => 
        array (
        ),
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'admin.production-methods.edit' => 
    array (
      'methods' => 
      array (
        0 => 'GET',
        1 => 'HEAD',
      ),
      'uri' => 'admin/production-methods/{productionMethod}/edit',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'admin.hidden',
          2 => 'auth:admin',
          3 => 'admin',
          4 => 'admin.permission',
          5 => 'admin.activity',
        ),
        'as' => 'admin.production-methods.edit',
        'uses' => 'App\\Http\\Controllers\\Admin\\ProductionMethodController@edit',
        'controller' => 'App\\Http\\Controllers\\Admin\\ProductionMethodController@edit',
        'namespace' => NULL,
        'prefix' => '/admin',
        'where' => 
        array (
        ),
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'admin.production-methods.update' => 
    array (
      'methods' => 
      array (
        0 => 'PUT',
        1 => 'PATCH',
      ),
      'uri' => 'admin/production-methods/{productionMethod}',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'admin.hidden',
          2 => 'auth:admin',
          3 => 'admin',
          4 => 'admin.permission',
          5 => 'admin.activity',
        ),
        'as' => 'admin.production-methods.update',
        'uses' => 'App\\Http\\Controllers\\Admin\\ProductionMethodController@update',
        'controller' => 'App\\Http\\Controllers\\Admin\\ProductionMethodController@update',
        'namespace' => NULL,
        'prefix' => '/admin',
        'where' => 
        array (
        ),
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'admin.production-methods.destroy' => 
    array (
      'methods' => 
      array (
        0 => 'DELETE',
      ),
      'uri' => 'admin/production-methods/{productionMethod}',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'admin.hidden',
          2 => 'auth:admin',
          3 => 'admin',
          4 => 'admin.permission',
          5 => 'admin.activity',
        ),
        'as' => 'admin.production-methods.destroy',
        'uses' => 'App\\Http\\Controllers\\Admin\\ProductionMethodController@destroy',
        'controller' => 'App\\Http\\Controllers\\Admin\\ProductionMethodController@destroy',
        'namespace' => NULL,
        'prefix' => '/admin',
        'where' => 
        array (
        ),
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'admin.shipping-methods.index' => 
    array (
      'methods' => 
      array (
        0 => 'GET',
        1 => 'HEAD',
      ),
      'uri' => 'admin/shipping-methods',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'admin.hidden',
          2 => 'auth:admin',
          3 => 'admin',
          4 => 'admin.permission',
          5 => 'admin.activity',
        ),
        'as' => 'admin.shipping-methods.index',
        'uses' => 'App\\Http\\Controllers\\Admin\\ShippingMethodController@index',
        'controller' => 'App\\Http\\Controllers\\Admin\\ShippingMethodController@index',
        'namespace' => NULL,
        'prefix' => '/admin',
        'where' => 
        array (
        ),
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'admin.shipping-methods.create' => 
    array (
      'methods' => 
      array (
        0 => 'GET',
        1 => 'HEAD',
      ),
      'uri' => 'admin/shipping-methods/create',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'admin.hidden',
          2 => 'auth:admin',
          3 => 'admin',
          4 => 'admin.permission',
          5 => 'admin.activity',
        ),
        'as' => 'admin.shipping-methods.create',
        'uses' => 'App\\Http\\Controllers\\Admin\\ShippingMethodController@create',
        'controller' => 'App\\Http\\Controllers\\Admin\\ShippingMethodController@create',
        'namespace' => NULL,
        'prefix' => '/admin',
        'where' => 
        array (
        ),
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'admin.shipping-methods.store' => 
    array (
      'methods' => 
      array (
        0 => 'POST',
      ),
      'uri' => 'admin/shipping-methods',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'admin.hidden',
          2 => 'auth:admin',
          3 => 'admin',
          4 => 'admin.permission',
          5 => 'admin.activity',
        ),
        'as' => 'admin.shipping-methods.store',
        'uses' => 'App\\Http\\Controllers\\Admin\\ShippingMethodController@store',
        'controller' => 'App\\Http\\Controllers\\Admin\\ShippingMethodController@store',
        'namespace' => NULL,
        'prefix' => '/admin',
        'where' => 
        array (
        ),
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'admin.shipping-methods.edit' => 
    array (
      'methods' => 
      array (
        0 => 'GET',
        1 => 'HEAD',
      ),
      'uri' => 'admin/shipping-methods/{shippingMethod}/edit',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'admin.hidden',
          2 => 'auth:admin',
          3 => 'admin',
          4 => 'admin.permission',
          5 => 'admin.activity',
        ),
        'as' => 'admin.shipping-methods.edit',
        'uses' => 'App\\Http\\Controllers\\Admin\\ShippingMethodController@edit',
        'controller' => 'App\\Http\\Controllers\\Admin\\ShippingMethodController@edit',
        'namespace' => NULL,
        'prefix' => '/admin',
        'where' => 
        array (
        ),
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'admin.shipping-methods.update' => 
    array (
      'methods' => 
      array (
        0 => 'PUT',
        1 => 'PATCH',
      ),
      'uri' => 'admin/shipping-methods/{shippingMethod}',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'admin.hidden',
          2 => 'auth:admin',
          3 => 'admin',
          4 => 'admin.permission',
          5 => 'admin.activity',
        ),
        'as' => 'admin.shipping-methods.update',
        'uses' => 'App\\Http\\Controllers\\Admin\\ShippingMethodController@update',
        'controller' => 'App\\Http\\Controllers\\Admin\\ShippingMethodController@update',
        'namespace' => NULL,
        'prefix' => '/admin',
        'where' => 
        array (
        ),
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'admin.shipping-methods.destroy' => 
    array (
      'methods' => 
      array (
        0 => 'DELETE',
      ),
      'uri' => 'admin/shipping-methods/{shippingMethod}',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'admin.hidden',
          2 => 'auth:admin',
          3 => 'admin',
          4 => 'admin.permission',
          5 => 'admin.activity',
        ),
        'as' => 'admin.shipping-methods.destroy',
        'uses' => 'App\\Http\\Controllers\\Admin\\ShippingMethodController@destroy',
        'controller' => 'App\\Http\\Controllers\\Admin\\ShippingMethodController@destroy',
        'namespace' => NULL,
        'prefix' => '/admin',
        'where' => 
        array (
        ),
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'admin.holiday-calendars.toggle-status' => 
    array (
      'methods' => 
      array (
        0 => 'PATCH',
      ),
      'uri' => 'admin/holiday-calendars/{holidayCalendar}/toggle-status',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'admin.hidden',
          2 => 'auth:admin',
          3 => 'admin',
          4 => 'admin.permission',
          5 => 'admin.activity',
        ),
        'uses' => 'App\\Http\\Controllers\\Admin\\HolidayCalendarController@toggleStatus',
        'controller' => 'App\\Http\\Controllers\\Admin\\HolidayCalendarController@toggleStatus',
        'as' => 'admin.holiday-calendars.toggle-status',
        'namespace' => NULL,
        'prefix' => '/admin',
        'where' => 
        array (
        ),
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'admin.holiday-calendars.index' => 
    array (
      'methods' => 
      array (
        0 => 'GET',
        1 => 'HEAD',
      ),
      'uri' => 'admin/holiday-calendars',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'admin.hidden',
          2 => 'auth:admin',
          3 => 'admin',
          4 => 'admin.permission',
          5 => 'admin.activity',
        ),
        'as' => 'admin.holiday-calendars.index',
        'uses' => 'App\\Http\\Controllers\\Admin\\HolidayCalendarController@index',
        'controller' => 'App\\Http\\Controllers\\Admin\\HolidayCalendarController@index',
        'namespace' => NULL,
        'prefix' => '/admin',
        'where' => 
        array (
        ),
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'admin.holiday-calendars.create' => 
    array (
      'methods' => 
      array (
        0 => 'GET',
        1 => 'HEAD',
      ),
      'uri' => 'admin/holiday-calendars/create',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'admin.hidden',
          2 => 'auth:admin',
          3 => 'admin',
          4 => 'admin.permission',
          5 => 'admin.activity',
        ),
        'as' => 'admin.holiday-calendars.create',
        'uses' => 'App\\Http\\Controllers\\Admin\\HolidayCalendarController@create',
        'controller' => 'App\\Http\\Controllers\\Admin\\HolidayCalendarController@create',
        'namespace' => NULL,
        'prefix' => '/admin',
        'where' => 
        array (
        ),
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'admin.holiday-calendars.store' => 
    array (
      'methods' => 
      array (
        0 => 'POST',
      ),
      'uri' => 'admin/holiday-calendars',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'admin.hidden',
          2 => 'auth:admin',
          3 => 'admin',
          4 => 'admin.permission',
          5 => 'admin.activity',
        ),
        'as' => 'admin.holiday-calendars.store',
        'uses' => 'App\\Http\\Controllers\\Admin\\HolidayCalendarController@store',
        'controller' => 'App\\Http\\Controllers\\Admin\\HolidayCalendarController@store',
        'namespace' => NULL,
        'prefix' => '/admin',
        'where' => 
        array (
        ),
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'admin.holiday-calendars.show' => 
    array (
      'methods' => 
      array (
        0 => 'GET',
        1 => 'HEAD',
      ),
      'uri' => 'admin/holiday-calendars/{holidayCalendar}',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'admin.hidden',
          2 => 'auth:admin',
          3 => 'admin',
          4 => 'admin.permission',
          5 => 'admin.activity',
        ),
        'as' => 'admin.holiday-calendars.show',
        'uses' => 'App\\Http\\Controllers\\Admin\\HolidayCalendarController@show',
        'controller' => 'App\\Http\\Controllers\\Admin\\HolidayCalendarController@show',
        'namespace' => NULL,
        'prefix' => '/admin',
        'where' => 
        array (
        ),
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'admin.holiday-calendars.edit' => 
    array (
      'methods' => 
      array (
        0 => 'GET',
        1 => 'HEAD',
      ),
      'uri' => 'admin/holiday-calendars/{holidayCalendar}/edit',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'admin.hidden',
          2 => 'auth:admin',
          3 => 'admin',
          4 => 'admin.permission',
          5 => 'admin.activity',
        ),
        'as' => 'admin.holiday-calendars.edit',
        'uses' => 'App\\Http\\Controllers\\Admin\\HolidayCalendarController@edit',
        'controller' => 'App\\Http\\Controllers\\Admin\\HolidayCalendarController@edit',
        'namespace' => NULL,
        'prefix' => '/admin',
        'where' => 
        array (
        ),
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'admin.holiday-calendars.update' => 
    array (
      'methods' => 
      array (
        0 => 'PUT',
        1 => 'PATCH',
      ),
      'uri' => 'admin/holiday-calendars/{holidayCalendar}',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'admin.hidden',
          2 => 'auth:admin',
          3 => 'admin',
          4 => 'admin.permission',
          5 => 'admin.activity',
        ),
        'as' => 'admin.holiday-calendars.update',
        'uses' => 'App\\Http\\Controllers\\Admin\\HolidayCalendarController@update',
        'controller' => 'App\\Http\\Controllers\\Admin\\HolidayCalendarController@update',
        'namespace' => NULL,
        'prefix' => '/admin',
        'where' => 
        array (
        ),
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'admin.holiday-calendars.destroy' => 
    array (
      'methods' => 
      array (
        0 => 'DELETE',
      ),
      'uri' => 'admin/holiday-calendars/{holidayCalendar}',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'admin.hidden',
          2 => 'auth:admin',
          3 => 'admin',
          4 => 'admin.permission',
          5 => 'admin.activity',
        ),
        'as' => 'admin.holiday-calendars.destroy',
        'uses' => 'App\\Http\\Controllers\\Admin\\HolidayCalendarController@destroy',
        'controller' => 'App\\Http\\Controllers\\Admin\\HolidayCalendarController@destroy',
        'namespace' => NULL,
        'prefix' => '/admin',
        'where' => 
        array (
        ),
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'admin.faqs.index' => 
    array (
      'methods' => 
      array (
        0 => 'GET',
        1 => 'HEAD',
      ),
      'uri' => 'admin/faqs',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'admin.hidden',
          2 => 'auth:admin',
          3 => 'admin',
          4 => 'admin.permission',
          5 => 'admin.activity',
        ),
        'as' => 'admin.faqs.index',
        'uses' => 'App\\Http\\Controllers\\Admin\\FaqController@index',
        'controller' => 'App\\Http\\Controllers\\Admin\\FaqController@index',
        'namespace' => NULL,
        'prefix' => '/admin',
        'where' => 
        array (
        ),
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'admin.faqs.create' => 
    array (
      'methods' => 
      array (
        0 => 'GET',
        1 => 'HEAD',
      ),
      'uri' => 'admin/faqs/create',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'admin.hidden',
          2 => 'auth:admin',
          3 => 'admin',
          4 => 'admin.permission',
          5 => 'admin.activity',
        ),
        'as' => 'admin.faqs.create',
        'uses' => 'App\\Http\\Controllers\\Admin\\FaqController@create',
        'controller' => 'App\\Http\\Controllers\\Admin\\FaqController@create',
        'namespace' => NULL,
        'prefix' => '/admin',
        'where' => 
        array (
        ),
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'admin.faqs.store' => 
    array (
      'methods' => 
      array (
        0 => 'POST',
      ),
      'uri' => 'admin/faqs',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'admin.hidden',
          2 => 'auth:admin',
          3 => 'admin',
          4 => 'admin.permission',
          5 => 'admin.activity',
        ),
        'as' => 'admin.faqs.store',
        'uses' => 'App\\Http\\Controllers\\Admin\\FaqController@store',
        'controller' => 'App\\Http\\Controllers\\Admin\\FaqController@store',
        'namespace' => NULL,
        'prefix' => '/admin',
        'where' => 
        array (
        ),
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'admin.faqs.edit' => 
    array (
      'methods' => 
      array (
        0 => 'GET',
        1 => 'HEAD',
      ),
      'uri' => 'admin/faqs/{faq}/edit',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'admin.hidden',
          2 => 'auth:admin',
          3 => 'admin',
          4 => 'admin.permission',
          5 => 'admin.activity',
        ),
        'as' => 'admin.faqs.edit',
        'uses' => 'App\\Http\\Controllers\\Admin\\FaqController@edit',
        'controller' => 'App\\Http\\Controllers\\Admin\\FaqController@edit',
        'namespace' => NULL,
        'prefix' => '/admin',
        'where' => 
        array (
        ),
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'admin.faqs.update' => 
    array (
      'methods' => 
      array (
        0 => 'PUT',
        1 => 'PATCH',
      ),
      'uri' => 'admin/faqs/{faq}',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'admin.hidden',
          2 => 'auth:admin',
          3 => 'admin',
          4 => 'admin.permission',
          5 => 'admin.activity',
        ),
        'as' => 'admin.faqs.update',
        'uses' => 'App\\Http\\Controllers\\Admin\\FaqController@update',
        'controller' => 'App\\Http\\Controllers\\Admin\\FaqController@update',
        'namespace' => NULL,
        'prefix' => '/admin',
        'where' => 
        array (
        ),
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'admin.faqs.destroy' => 
    array (
      'methods' => 
      array (
        0 => 'DELETE',
      ),
      'uri' => 'admin/faqs/{faq}',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'admin.hidden',
          2 => 'auth:admin',
          3 => 'admin',
          4 => 'admin.permission',
          5 => 'admin.activity',
        ),
        'as' => 'admin.faqs.destroy',
        'uses' => 'App\\Http\\Controllers\\Admin\\FaqController@destroy',
        'controller' => 'App\\Http\\Controllers\\Admin\\FaqController@destroy',
        'namespace' => NULL,
        'prefix' => '/admin',
        'where' => 
        array (
        ),
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'admin.genders.index' => 
    array (
      'methods' => 
      array (
        0 => 'GET',
        1 => 'HEAD',
      ),
      'uri' => 'admin/genders',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'admin.hidden',
          2 => 'auth:admin',
          3 => 'admin',
          4 => 'admin.permission',
          5 => 'admin.activity',
        ),
        'as' => 'admin.genders.index',
        'uses' => 'App\\Http\\Controllers\\Admin\\GenderController@index',
        'controller' => 'App\\Http\\Controllers\\Admin\\GenderController@index',
        'namespace' => NULL,
        'prefix' => '/admin',
        'where' => 
        array (
        ),
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'admin.genders.create' => 
    array (
      'methods' => 
      array (
        0 => 'GET',
        1 => 'HEAD',
      ),
      'uri' => 'admin/genders/create',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'admin.hidden',
          2 => 'auth:admin',
          3 => 'admin',
          4 => 'admin.permission',
          5 => 'admin.activity',
        ),
        'as' => 'admin.genders.create',
        'uses' => 'App\\Http\\Controllers\\Admin\\GenderController@create',
        'controller' => 'App\\Http\\Controllers\\Admin\\GenderController@create',
        'namespace' => NULL,
        'prefix' => '/admin',
        'where' => 
        array (
        ),
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'admin.genders.store' => 
    array (
      'methods' => 
      array (
        0 => 'POST',
      ),
      'uri' => 'admin/genders',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'admin.hidden',
          2 => 'auth:admin',
          3 => 'admin',
          4 => 'admin.permission',
          5 => 'admin.activity',
        ),
        'as' => 'admin.genders.store',
        'uses' => 'App\\Http\\Controllers\\Admin\\GenderController@store',
        'controller' => 'App\\Http\\Controllers\\Admin\\GenderController@store',
        'namespace' => NULL,
        'prefix' => '/admin',
        'where' => 
        array (
        ),
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'admin.genders.edit' => 
    array (
      'methods' => 
      array (
        0 => 'GET',
        1 => 'HEAD',
      ),
      'uri' => 'admin/genders/{gender}/edit',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'admin.hidden',
          2 => 'auth:admin',
          3 => 'admin',
          4 => 'admin.permission',
          5 => 'admin.activity',
        ),
        'as' => 'admin.genders.edit',
        'uses' => 'App\\Http\\Controllers\\Admin\\GenderController@edit',
        'controller' => 'App\\Http\\Controllers\\Admin\\GenderController@edit',
        'namespace' => NULL,
        'prefix' => '/admin',
        'where' => 
        array (
        ),
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'admin.genders.update' => 
    array (
      'methods' => 
      array (
        0 => 'PUT',
        1 => 'PATCH',
      ),
      'uri' => 'admin/genders/{gender}',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'admin.hidden',
          2 => 'auth:admin',
          3 => 'admin',
          4 => 'admin.permission',
          5 => 'admin.activity',
        ),
        'as' => 'admin.genders.update',
        'uses' => 'App\\Http\\Controllers\\Admin\\GenderController@update',
        'controller' => 'App\\Http\\Controllers\\Admin\\GenderController@update',
        'namespace' => NULL,
        'prefix' => '/admin',
        'where' => 
        array (
        ),
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'admin.genders.destroy' => 
    array (
      'methods' => 
      array (
        0 => 'DELETE',
      ),
      'uri' => 'admin/genders/{gender}',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'admin.hidden',
          2 => 'auth:admin',
          3 => 'admin',
          4 => 'admin.permission',
          5 => 'admin.activity',
        ),
        'as' => 'admin.genders.destroy',
        'uses' => 'App\\Http\\Controllers\\Admin\\GenderController@destroy',
        'controller' => 'App\\Http\\Controllers\\Admin\\GenderController@destroy',
        'namespace' => NULL,
        'prefix' => '/admin',
        'where' => 
        array (
        ),
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'admin.country-calling-codes.quick-store' => 
    array (
      'methods' => 
      array (
        0 => 'POST',
      ),
      'uri' => 'admin/country-calling-codes/quick-store',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'admin.hidden',
          2 => 'auth:admin',
          3 => 'admin',
          4 => 'admin.permission',
          5 => 'admin.activity',
        ),
        'uses' => 'App\\Http\\Controllers\\Admin\\CountryCallingCodeController@quickStore',
        'controller' => 'App\\Http\\Controllers\\Admin\\CountryCallingCodeController@quickStore',
        'as' => 'admin.country-calling-codes.quick-store',
        'namespace' => NULL,
        'prefix' => '/admin',
        'where' => 
        array (
        ),
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'admin.country-calling-codes.index' => 
    array (
      'methods' => 
      array (
        0 => 'GET',
        1 => 'HEAD',
      ),
      'uri' => 'admin/country-calling-codes',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'admin.hidden',
          2 => 'auth:admin',
          3 => 'admin',
          4 => 'admin.permission',
          5 => 'admin.activity',
        ),
        'as' => 'admin.country-calling-codes.index',
        'uses' => 'App\\Http\\Controllers\\Admin\\CountryCallingCodeController@index',
        'controller' => 'App\\Http\\Controllers\\Admin\\CountryCallingCodeController@index',
        'namespace' => NULL,
        'prefix' => '/admin',
        'where' => 
        array (
        ),
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'admin.country-calling-codes.create' => 
    array (
      'methods' => 
      array (
        0 => 'GET',
        1 => 'HEAD',
      ),
      'uri' => 'admin/country-calling-codes/create',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'admin.hidden',
          2 => 'auth:admin',
          3 => 'admin',
          4 => 'admin.permission',
          5 => 'admin.activity',
        ),
        'as' => 'admin.country-calling-codes.create',
        'uses' => 'App\\Http\\Controllers\\Admin\\CountryCallingCodeController@create',
        'controller' => 'App\\Http\\Controllers\\Admin\\CountryCallingCodeController@create',
        'namespace' => NULL,
        'prefix' => '/admin',
        'where' => 
        array (
        ),
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'admin.country-calling-codes.store' => 
    array (
      'methods' => 
      array (
        0 => 'POST',
      ),
      'uri' => 'admin/country-calling-codes',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'admin.hidden',
          2 => 'auth:admin',
          3 => 'admin',
          4 => 'admin.permission',
          5 => 'admin.activity',
        ),
        'as' => 'admin.country-calling-codes.store',
        'uses' => 'App\\Http\\Controllers\\Admin\\CountryCallingCodeController@store',
        'controller' => 'App\\Http\\Controllers\\Admin\\CountryCallingCodeController@store',
        'namespace' => NULL,
        'prefix' => '/admin',
        'where' => 
        array (
        ),
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'admin.country-calling-codes.edit' => 
    array (
      'methods' => 
      array (
        0 => 'GET',
        1 => 'HEAD',
      ),
      'uri' => 'admin/country-calling-codes/{countryCallingCode}/edit',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'admin.hidden',
          2 => 'auth:admin',
          3 => 'admin',
          4 => 'admin.permission',
          5 => 'admin.activity',
        ),
        'as' => 'admin.country-calling-codes.edit',
        'uses' => 'App\\Http\\Controllers\\Admin\\CountryCallingCodeController@edit',
        'controller' => 'App\\Http\\Controllers\\Admin\\CountryCallingCodeController@edit',
        'namespace' => NULL,
        'prefix' => '/admin',
        'where' => 
        array (
        ),
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'admin.country-calling-codes.update' => 
    array (
      'methods' => 
      array (
        0 => 'PUT',
        1 => 'PATCH',
      ),
      'uri' => 'admin/country-calling-codes/{countryCallingCode}',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'admin.hidden',
          2 => 'auth:admin',
          3 => 'admin',
          4 => 'admin.permission',
          5 => 'admin.activity',
        ),
        'as' => 'admin.country-calling-codes.update',
        'uses' => 'App\\Http\\Controllers\\Admin\\CountryCallingCodeController@update',
        'controller' => 'App\\Http\\Controllers\\Admin\\CountryCallingCodeController@update',
        'namespace' => NULL,
        'prefix' => '/admin',
        'where' => 
        array (
        ),
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'admin.country-calling-codes.destroy' => 
    array (
      'methods' => 
      array (
        0 => 'DELETE',
      ),
      'uri' => 'admin/country-calling-codes/{countryCallingCode}',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'admin.hidden',
          2 => 'auth:admin',
          3 => 'admin',
          4 => 'admin.permission',
          5 => 'admin.activity',
        ),
        'as' => 'admin.country-calling-codes.destroy',
        'uses' => 'App\\Http\\Controllers\\Admin\\CountryCallingCodeController@destroy',
        'controller' => 'App\\Http\\Controllers\\Admin\\CountryCallingCodeController@destroy',
        'namespace' => NULL,
        'prefix' => '/admin',
        'where' => 
        array (
        ),
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'admin.bulk-quote-budget-ranges.index' => 
    array (
      'methods' => 
      array (
        0 => 'GET',
        1 => 'HEAD',
      ),
      'uri' => 'admin/bulk-quote-budget-ranges',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'admin.hidden',
          2 => 'auth:admin',
          3 => 'admin',
          4 => 'admin.permission',
          5 => 'admin.activity',
        ),
        'as' => 'admin.bulk-quote-budget-ranges.index',
        'uses' => 'App\\Http\\Controllers\\Admin\\BulkQuoteBudgetRangeController@index',
        'controller' => 'App\\Http\\Controllers\\Admin\\BulkQuoteBudgetRangeController@index',
        'namespace' => NULL,
        'prefix' => '/admin',
        'where' => 
        array (
        ),
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'admin.bulk-quote-budget-ranges.create' => 
    array (
      'methods' => 
      array (
        0 => 'GET',
        1 => 'HEAD',
      ),
      'uri' => 'admin/bulk-quote-budget-ranges/create',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'admin.hidden',
          2 => 'auth:admin',
          3 => 'admin',
          4 => 'admin.permission',
          5 => 'admin.activity',
        ),
        'as' => 'admin.bulk-quote-budget-ranges.create',
        'uses' => 'App\\Http\\Controllers\\Admin\\BulkQuoteBudgetRangeController@create',
        'controller' => 'App\\Http\\Controllers\\Admin\\BulkQuoteBudgetRangeController@create',
        'namespace' => NULL,
        'prefix' => '/admin',
        'where' => 
        array (
        ),
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'admin.bulk-quote-budget-ranges.store' => 
    array (
      'methods' => 
      array (
        0 => 'POST',
      ),
      'uri' => 'admin/bulk-quote-budget-ranges',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'admin.hidden',
          2 => 'auth:admin',
          3 => 'admin',
          4 => 'admin.permission',
          5 => 'admin.activity',
        ),
        'as' => 'admin.bulk-quote-budget-ranges.store',
        'uses' => 'App\\Http\\Controllers\\Admin\\BulkQuoteBudgetRangeController@store',
        'controller' => 'App\\Http\\Controllers\\Admin\\BulkQuoteBudgetRangeController@store',
        'namespace' => NULL,
        'prefix' => '/admin',
        'where' => 
        array (
        ),
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'admin.bulk-quote-budget-ranges.edit' => 
    array (
      'methods' => 
      array (
        0 => 'GET',
        1 => 'HEAD',
      ),
      'uri' => 'admin/bulk-quote-budget-ranges/{bulkQuoteBudgetRange}/edit',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'admin.hidden',
          2 => 'auth:admin',
          3 => 'admin',
          4 => 'admin.permission',
          5 => 'admin.activity',
        ),
        'as' => 'admin.bulk-quote-budget-ranges.edit',
        'uses' => 'App\\Http\\Controllers\\Admin\\BulkQuoteBudgetRangeController@edit',
        'controller' => 'App\\Http\\Controllers\\Admin\\BulkQuoteBudgetRangeController@edit',
        'namespace' => NULL,
        'prefix' => '/admin',
        'where' => 
        array (
        ),
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'admin.bulk-quote-budget-ranges.update' => 
    array (
      'methods' => 
      array (
        0 => 'PUT',
        1 => 'PATCH',
      ),
      'uri' => 'admin/bulk-quote-budget-ranges/{bulkQuoteBudgetRange}',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'admin.hidden',
          2 => 'auth:admin',
          3 => 'admin',
          4 => 'admin.permission',
          5 => 'admin.activity',
        ),
        'as' => 'admin.bulk-quote-budget-ranges.update',
        'uses' => 'App\\Http\\Controllers\\Admin\\BulkQuoteBudgetRangeController@update',
        'controller' => 'App\\Http\\Controllers\\Admin\\BulkQuoteBudgetRangeController@update',
        'namespace' => NULL,
        'prefix' => '/admin',
        'where' => 
        array (
        ),
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'admin.bulk-quote-budget-ranges.destroy' => 
    array (
      'methods' => 
      array (
        0 => 'DELETE',
      ),
      'uri' => 'admin/bulk-quote-budget-ranges/{bulkQuoteBudgetRange}',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'admin.hidden',
          2 => 'auth:admin',
          3 => 'admin',
          4 => 'admin.permission',
          5 => 'admin.activity',
        ),
        'as' => 'admin.bulk-quote-budget-ranges.destroy',
        'uses' => 'App\\Http\\Controllers\\Admin\\BulkQuoteBudgetRangeController@destroy',
        'controller' => 'App\\Http\\Controllers\\Admin\\BulkQuoteBudgetRangeController@destroy',
        'namespace' => NULL,
        'prefix' => '/admin',
        'where' => 
        array (
        ),
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'admin.payment-methods.index' => 
    array (
      'methods' => 
      array (
        0 => 'GET',
        1 => 'HEAD',
      ),
      'uri' => 'admin/payment-methods',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'admin.hidden',
          2 => 'auth:admin',
          3 => 'admin',
          4 => 'admin.permission',
          5 => 'admin.activity',
        ),
        'as' => 'admin.payment-methods.index',
        'uses' => 'App\\Http\\Controllers\\Admin\\PaymentMethodController@index',
        'controller' => 'App\\Http\\Controllers\\Admin\\PaymentMethodController@index',
        'namespace' => NULL,
        'prefix' => '/admin',
        'where' => 
        array (
        ),
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'admin.payment-methods.create' => 
    array (
      'methods' => 
      array (
        0 => 'GET',
        1 => 'HEAD',
      ),
      'uri' => 'admin/payment-methods/create',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'admin.hidden',
          2 => 'auth:admin',
          3 => 'admin',
          4 => 'admin.permission',
          5 => 'admin.activity',
        ),
        'as' => 'admin.payment-methods.create',
        'uses' => 'App\\Http\\Controllers\\Admin\\PaymentMethodController@create',
        'controller' => 'App\\Http\\Controllers\\Admin\\PaymentMethodController@create',
        'namespace' => NULL,
        'prefix' => '/admin',
        'where' => 
        array (
        ),
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'admin.payment-methods.store' => 
    array (
      'methods' => 
      array (
        0 => 'POST',
      ),
      'uri' => 'admin/payment-methods',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'admin.hidden',
          2 => 'auth:admin',
          3 => 'admin',
          4 => 'admin.permission',
          5 => 'admin.activity',
        ),
        'as' => 'admin.payment-methods.store',
        'uses' => 'App\\Http\\Controllers\\Admin\\PaymentMethodController@store',
        'controller' => 'App\\Http\\Controllers\\Admin\\PaymentMethodController@store',
        'namespace' => NULL,
        'prefix' => '/admin',
        'where' => 
        array (
        ),
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'admin.payment-methods.edit' => 
    array (
      'methods' => 
      array (
        0 => 'GET',
        1 => 'HEAD',
      ),
      'uri' => 'admin/payment-methods/{paymentMethod}/edit',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'admin.hidden',
          2 => 'auth:admin',
          3 => 'admin',
          4 => 'admin.permission',
          5 => 'admin.activity',
        ),
        'as' => 'admin.payment-methods.edit',
        'uses' => 'App\\Http\\Controllers\\Admin\\PaymentMethodController@edit',
        'controller' => 'App\\Http\\Controllers\\Admin\\PaymentMethodController@edit',
        'namespace' => NULL,
        'prefix' => '/admin',
        'where' => 
        array (
        ),
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'admin.payment-methods.update' => 
    array (
      'methods' => 
      array (
        0 => 'PUT',
        1 => 'PATCH',
      ),
      'uri' => 'admin/payment-methods/{paymentMethod}',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'admin.hidden',
          2 => 'auth:admin',
          3 => 'admin',
          4 => 'admin.permission',
          5 => 'admin.activity',
        ),
        'as' => 'admin.payment-methods.update',
        'uses' => 'App\\Http\\Controllers\\Admin\\PaymentMethodController@update',
        'controller' => 'App\\Http\\Controllers\\Admin\\PaymentMethodController@update',
        'namespace' => NULL,
        'prefix' => '/admin',
        'where' => 
        array (
        ),
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'admin.payment-methods.destroy' => 
    array (
      'methods' => 
      array (
        0 => 'DELETE',
      ),
      'uri' => 'admin/payment-methods/{paymentMethod}',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'admin.hidden',
          2 => 'auth:admin',
          3 => 'admin',
          4 => 'admin.permission',
          5 => 'admin.activity',
        ),
        'as' => 'admin.payment-methods.destroy',
        'uses' => 'App\\Http\\Controllers\\Admin\\PaymentMethodController@destroy',
        'controller' => 'App\\Http\\Controllers\\Admin\\PaymentMethodController@destroy',
        'namespace' => NULL,
        'prefix' => '/admin',
        'where' => 
        array (
        ),
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'admin.reward-program.edit' => 
    array (
      'methods' => 
      array (
        0 => 'GET',
        1 => 'HEAD',
      ),
      'uri' => 'admin/reward-program',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'admin.hidden',
          2 => 'auth:admin',
          3 => 'admin',
          4 => 'admin.permission',
          5 => 'admin.activity',
        ),
        'uses' => 'App\\Http\\Controllers\\Admin\\RewardProgramController@edit',
        'controller' => 'App\\Http\\Controllers\\Admin\\RewardProgramController@edit',
        'as' => 'admin.reward-program.edit',
        'namespace' => NULL,
        'prefix' => '/admin',
        'where' => 
        array (
        ),
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'admin.reward-program.update' => 
    array (
      'methods' => 
      array (
        0 => 'PUT',
      ),
      'uri' => 'admin/reward-program',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'admin.hidden',
          2 => 'auth:admin',
          3 => 'admin',
          4 => 'admin.permission',
          5 => 'admin.activity',
        ),
        'uses' => 'App\\Http\\Controllers\\Admin\\RewardProgramController@update',
        'controller' => 'App\\Http\\Controllers\\Admin\\RewardProgramController@update',
        'as' => 'admin.reward-program.update',
        'namespace' => NULL,
        'prefix' => '/admin',
        'where' => 
        array (
        ),
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'admin.customers.index' => 
    array (
      'methods' => 
      array (
        0 => 'GET',
        1 => 'HEAD',
      ),
      'uri' => 'admin/customers',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'admin.hidden',
          2 => 'auth:admin',
          3 => 'admin',
          4 => 'admin.permission',
          5 => 'admin.activity',
        ),
        'uses' => 'App\\Http\\Controllers\\Admin\\CustomerController@index',
        'controller' => 'App\\Http\\Controllers\\Admin\\CustomerController@index',
        'as' => 'admin.customers.index',
        'namespace' => NULL,
        'prefix' => '/admin',
        'where' => 
        array (
        ),
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'admin.customers.show' => 
    array (
      'methods' => 
      array (
        0 => 'GET',
        1 => 'HEAD',
      ),
      'uri' => 'admin/customers/{customer}',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'admin.hidden',
          2 => 'auth:admin',
          3 => 'admin',
          4 => 'admin.permission',
          5 => 'admin.activity',
        ),
        'uses' => 'App\\Http\\Controllers\\Admin\\CustomerController@show',
        'controller' => 'App\\Http\\Controllers\\Admin\\CustomerController@show',
        'as' => 'admin.customers.show',
        'namespace' => NULL,
        'prefix' => '/admin',
        'where' => 
        array (
        ),
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'admin.customers.suspend' => 
    array (
      'methods' => 
      array (
        0 => 'PATCH',
      ),
      'uri' => 'admin/customers/{customer}/suspend',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'admin.hidden',
          2 => 'auth:admin',
          3 => 'admin',
          4 => 'admin.permission',
          5 => 'admin.activity',
          6 => 'throttle:10,1',
        ),
        'uses' => 'App\\Http\\Controllers\\Admin\\CustomerController@suspend',
        'controller' => 'App\\Http\\Controllers\\Admin\\CustomerController@suspend',
        'as' => 'admin.customers.suspend',
        'namespace' => NULL,
        'prefix' => '/admin',
        'where' => 
        array (
        ),
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'admin.customers.reactivate' => 
    array (
      'methods' => 
      array (
        0 => 'PATCH',
      ),
      'uri' => 'admin/customers/{customer}/reactivate',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'admin.hidden',
          2 => 'auth:admin',
          3 => 'admin',
          4 => 'admin.permission',
          5 => 'admin.activity',
          6 => 'throttle:10,1',
        ),
        'uses' => 'App\\Http\\Controllers\\Admin\\CustomerController@reactivate',
        'controller' => 'App\\Http\\Controllers\\Admin\\CustomerController@reactivate',
        'as' => 'admin.customers.reactivate',
        'namespace' => NULL,
        'prefix' => '/admin',
        'where' => 
        array (
        ),
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'admin.customers.rewards.update' => 
    array (
      'methods' => 
      array (
        0 => 'PATCH',
      ),
      'uri' => 'admin/customers/{customer}/rewards',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'admin.hidden',
          2 => 'auth:admin',
          3 => 'admin',
          4 => 'admin.permission',
          5 => 'admin.activity',
          6 => 'throttle:20,1',
        ),
        'uses' => 'App\\Http\\Controllers\\Admin\\CustomerRewardController@update',
        'controller' => 'App\\Http\\Controllers\\Admin\\CustomerRewardController@update',
        'as' => 'admin.customers.rewards.update',
        'namespace' => NULL,
        'prefix' => '/admin',
        'where' => 
        array (
        ),
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'admin.customers.rewards.store' => 
    array (
      'methods' => 
      array (
        0 => 'POST',
      ),
      'uri' => 'admin/customers/{customer}/rewards',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'admin.hidden',
          2 => 'auth:admin',
          3 => 'admin',
          4 => 'admin.permission',
          5 => 'admin.activity',
          6 => 'throttle:20,1',
        ),
        'uses' => 'App\\Http\\Controllers\\Admin\\CustomerRewardController@store',
        'controller' => 'App\\Http\\Controllers\\Admin\\CustomerRewardController@store',
        'as' => 'admin.customers.rewards.store',
        'namespace' => NULL,
        'prefix' => '/admin',
        'where' => 
        array (
        ),
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'admin.users.index' => 
    array (
      'methods' => 
      array (
        0 => 'GET',
        1 => 'HEAD',
      ),
      'uri' => 'admin/users',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'admin.hidden',
          2 => 'auth:admin',
          3 => 'admin',
          4 => 'admin.permission',
          5 => 'admin.activity',
        ),
        'uses' => 'App\\Http\\Controllers\\Admin\\AdminUserController@index',
        'controller' => 'App\\Http\\Controllers\\Admin\\AdminUserController@index',
        'as' => 'admin.users.index',
        'namespace' => NULL,
        'prefix' => '/admin',
        'where' => 
        array (
        ),
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'admin.users.store' => 
    array (
      'methods' => 
      array (
        0 => 'POST',
      ),
      'uri' => 'admin/users',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'admin.hidden',
          2 => 'auth:admin',
          3 => 'admin',
          4 => 'admin.permission',
          5 => 'admin.activity',
          6 => 'throttle:10,1',
        ),
        'uses' => 'App\\Http\\Controllers\\Admin\\AdminUserController@store',
        'controller' => 'App\\Http\\Controllers\\Admin\\AdminUserController@store',
        'as' => 'admin.users.store',
        'namespace' => NULL,
        'prefix' => '/admin',
        'where' => 
        array (
        ),
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'admin.users.update' => 
    array (
      'methods' => 
      array (
        0 => 'PATCH',
      ),
      'uri' => 'admin/users/{user}',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'admin.hidden',
          2 => 'auth:admin',
          3 => 'admin',
          4 => 'admin.permission',
          5 => 'admin.activity',
          6 => 'throttle:20,1',
        ),
        'uses' => 'App\\Http\\Controllers\\Admin\\AdminUserController@update',
        'controller' => 'App\\Http\\Controllers\\Admin\\AdminUserController@update',
        'as' => 'admin.users.update',
        'namespace' => NULL,
        'prefix' => '/admin',
        'where' => 
        array (
        ),
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'admin.role-matrix.index' => 
    array (
      'methods' => 
      array (
        0 => 'GET',
        1 => 'HEAD',
      ),
      'uri' => 'admin/role-matrix',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'admin.hidden',
          2 => 'auth:admin',
          3 => 'admin',
          4 => 'admin.permission',
          5 => 'admin.activity',
        ),
        'uses' => 'App\\Http\\Controllers\\Admin\\RoleMatrixController@index',
        'controller' => 'App\\Http\\Controllers\\Admin\\RoleMatrixController@index',
        'as' => 'admin.role-matrix.index',
        'namespace' => NULL,
        'prefix' => '/admin',
        'where' => 
        array (
        ),
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'admin.role-matrix.roles.store' => 
    array (
      'methods' => 
      array (
        0 => 'POST',
      ),
      'uri' => 'admin/role-matrix/roles',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'admin.hidden',
          2 => 'auth:admin',
          3 => 'admin',
          4 => 'admin.permission',
          5 => 'admin.activity',
          6 => 'throttle:10,1',
        ),
        'uses' => 'App\\Http\\Controllers\\Admin\\RoleMatrixController@storeRole',
        'controller' => 'App\\Http\\Controllers\\Admin\\RoleMatrixController@storeRole',
        'as' => 'admin.role-matrix.roles.store',
        'namespace' => NULL,
        'prefix' => '/admin',
        'where' => 
        array (
        ),
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'admin.role-matrix.update' => 
    array (
      'methods' => 
      array (
        0 => 'POST',
      ),
      'uri' => 'admin/role-matrix',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'admin.hidden',
          2 => 'auth:admin',
          3 => 'admin',
          4 => 'admin.permission',
          5 => 'admin.activity',
          6 => 'throttle:20,1',
        ),
        'uses' => 'App\\Http\\Controllers\\Admin\\RoleMatrixController@update',
        'controller' => 'App\\Http\\Controllers\\Admin\\RoleMatrixController@update',
        'as' => 'admin.role-matrix.update',
        'namespace' => NULL,
        'prefix' => '/admin',
        'where' => 
        array (
        ),
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'admin.bulk-quotes.index' => 
    array (
      'methods' => 
      array (
        0 => 'GET',
        1 => 'HEAD',
      ),
      'uri' => 'admin/bulk-quotes',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'admin.hidden',
          2 => 'auth:admin',
          3 => 'admin',
          4 => 'admin.permission',
          5 => 'admin.activity',
        ),
        'uses' => 'App\\Http\\Controllers\\Admin\\BulkQuoteRequestController@index',
        'controller' => 'App\\Http\\Controllers\\Admin\\BulkQuoteRequestController@index',
        'as' => 'admin.bulk-quotes.index',
        'namespace' => NULL,
        'prefix' => '/admin',
        'where' => 
        array (
        ),
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'admin.bulk-quotes.show' => 
    array (
      'methods' => 
      array (
        0 => 'GET',
        1 => 'HEAD',
      ),
      'uri' => 'admin/bulk-quotes/{bulkQuote}',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'admin.hidden',
          2 => 'auth:admin',
          3 => 'admin',
          4 => 'admin.permission',
          5 => 'admin.activity',
        ),
        'uses' => 'App\\Http\\Controllers\\Admin\\BulkQuoteRequestController@show',
        'controller' => 'App\\Http\\Controllers\\Admin\\BulkQuoteRequestController@show',
        'as' => 'admin.bulk-quotes.show',
        'namespace' => NULL,
        'prefix' => '/admin',
        'where' => 
        array (
        ),
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'admin.bulk-quotes.attachment' => 
    array (
      'methods' => 
      array (
        0 => 'GET',
        1 => 'HEAD',
      ),
      'uri' => 'admin/bulk-quotes/{bulkQuote}/attachment',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'admin.hidden',
          2 => 'auth:admin',
          3 => 'admin',
          4 => 'admin.permission',
          5 => 'admin.activity',
        ),
        'uses' => 'App\\Http\\Controllers\\Admin\\BulkQuoteRequestController@attachment',
        'controller' => 'App\\Http\\Controllers\\Admin\\BulkQuoteRequestController@attachment',
        'as' => 'admin.bulk-quotes.attachment',
        'namespace' => NULL,
        'prefix' => '/admin',
        'where' => 
        array (
        ),
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'admin.bulk-quotes.update' => 
    array (
      'methods' => 
      array (
        0 => 'PATCH',
      ),
      'uri' => 'admin/bulk-quotes/{bulkQuote}',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'admin.hidden',
          2 => 'auth:admin',
          3 => 'admin',
          4 => 'admin.permission',
          5 => 'admin.activity',
          6 => 'throttle:20,1',
        ),
        'uses' => 'App\\Http\\Controllers\\Admin\\BulkQuoteRequestController@update',
        'controller' => 'App\\Http\\Controllers\\Admin\\BulkQuoteRequestController@update',
        'as' => 'admin.bulk-quotes.update',
        'namespace' => NULL,
        'prefix' => '/admin',
        'where' => 
        array (
        ),
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'admin.bulk-quotes.retry-sync' => 
    array (
      'methods' => 
      array (
        0 => 'POST',
      ),
      'uri' => 'admin/bulk-quotes/{bulkQuote}/retry-sync',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'admin.hidden',
          2 => 'auth:admin',
          3 => 'admin',
          4 => 'admin.permission',
          5 => 'admin.activity',
          6 => 'throttle:6,1',
        ),
        'uses' => 'App\\Http\\Controllers\\Admin\\BulkQuoteRequestController@retrySync',
        'controller' => 'App\\Http\\Controllers\\Admin\\BulkQuoteRequestController@retrySync',
        'as' => 'admin.bulk-quotes.retry-sync',
        'namespace' => NULL,
        'prefix' => '/admin',
        'where' => 
        array (
        ),
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'admin.bulk-quotes.publish' => 
    array (
      'methods' => 
      array (
        0 => 'POST',
      ),
      'uri' => 'admin/bulk-quotes/{bulkQuote}/publish',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'admin.hidden',
          2 => 'auth:admin',
          3 => 'admin',
          4 => 'admin.permission',
          5 => 'admin.activity',
          6 => 'throttle:10,1',
        ),
        'uses' => 'App\\Http\\Controllers\\Admin\\BulkQuoteGuestAdminController@publish',
        'controller' => 'App\\Http\\Controllers\\Admin\\BulkQuoteGuestAdminController@publish',
        'as' => 'admin.bulk-quotes.publish',
        'namespace' => NULL,
        'prefix' => '/admin',
        'where' => 
        array (
        ),
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'admin.bulk-quotes.message' => 
    array (
      'methods' => 
      array (
        0 => 'POST',
      ),
      'uri' => 'admin/bulk-quotes/{bulkQuote}/message',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'admin.hidden',
          2 => 'auth:admin',
          3 => 'admin',
          4 => 'admin.permission',
          5 => 'admin.activity',
          6 => 'throttle:15,1',
        ),
        'uses' => 'App\\Http\\Controllers\\Admin\\BulkQuoteGuestAdminController@message',
        'controller' => 'App\\Http\\Controllers\\Admin\\BulkQuoteGuestAdminController@message',
        'as' => 'admin.bulk-quotes.message',
        'namespace' => NULL,
        'prefix' => '/admin',
        'where' => 
        array (
        ),
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'admin.bulk-quotes.file' => 
    array (
      'methods' => 
      array (
        0 => 'GET',
        1 => 'HEAD',
      ),
      'uri' => 'admin/bulk-quotes/{bulkQuote}/file/{file}',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'admin.hidden',
          2 => 'auth:admin',
          3 => 'admin',
          4 => 'admin.permission',
          5 => 'admin.activity',
        ),
        'uses' => 'App\\Http\\Controllers\\Admin\\BulkQuoteGuestAdminController@file',
        'controller' => 'App\\Http\\Controllers\\Admin\\BulkQuoteGuestAdminController@file',
        'as' => 'admin.bulk-quotes.file',
        'namespace' => NULL,
        'prefix' => '/admin',
        'where' => 
        array (
        ),
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'admin.artwork-approvals.index' => 
    array (
      'methods' => 
      array (
        0 => 'GET',
        1 => 'HEAD',
      ),
      'uri' => 'admin/artwork-approvals',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'admin.hidden',
          2 => 'auth:admin',
          3 => 'admin',
          4 => 'admin.permission',
          5 => 'admin.activity',
        ),
        'uses' => 'App\\Http\\Controllers\\Admin\\ArtworkProofController@index',
        'controller' => 'App\\Http\\Controllers\\Admin\\ArtworkProofController@index',
        'as' => 'admin.artwork-approvals.index',
        'namespace' => NULL,
        'prefix' => '/admin',
        'where' => 
        array (
        ),
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'admin.orders.index' => 
    array (
      'methods' => 
      array (
        0 => 'GET',
        1 => 'HEAD',
      ),
      'uri' => 'admin/orders',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'admin.hidden',
          2 => 'auth:admin',
          3 => 'admin',
          4 => 'admin.permission',
          5 => 'admin.activity',
        ),
        'uses' => 'App\\Http\\Controllers\\Admin\\OrderController@index',
        'controller' => 'App\\Http\\Controllers\\Admin\\OrderController@index',
        'as' => 'admin.orders.index',
        'namespace' => NULL,
        'prefix' => '/admin',
        'where' => 
        array (
        ),
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'admin.orders.show' => 
    array (
      'methods' => 
      array (
        0 => 'GET',
        1 => 'HEAD',
      ),
      'uri' => 'admin/orders/{order}',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'admin.hidden',
          2 => 'auth:admin',
          3 => 'admin',
          4 => 'admin.permission',
          5 => 'admin.activity',
        ),
        'uses' => 'App\\Http\\Controllers\\Admin\\OrderController@show',
        'controller' => 'App\\Http\\Controllers\\Admin\\OrderController@show',
        'as' => 'admin.orders.show',
        'namespace' => NULL,
        'prefix' => '/admin',
        'where' => 
        array (
        ),
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'admin.orders.artwork-proofs.store' => 
    array (
      'methods' => 
      array (
        0 => 'POST',
      ),
      'uri' => 'admin/orders/{order}/artwork-proofs',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'admin.hidden',
          2 => 'auth:admin',
          3 => 'admin',
          4 => 'admin.permission',
          5 => 'admin.activity',
          6 => 'throttle:10,1',
        ),
        'uses' => 'App\\Http\\Controllers\\Admin\\ArtworkProofController@store',
        'controller' => 'App\\Http\\Controllers\\Admin\\ArtworkProofController@store',
        'as' => 'admin.orders.artwork-proofs.store',
        'namespace' => NULL,
        'prefix' => '/admin',
        'where' => 
        array (
        ),
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'admin.orders.artwork-proofs.file' => 
    array (
      'methods' => 
      array (
        0 => 'GET',
        1 => 'HEAD',
      ),
      'uri' => 'admin/orders/{order}/artwork-proofs/{proof}/file',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'admin.hidden',
          2 => 'auth:admin',
          3 => 'admin',
          4 => 'admin.permission',
          5 => 'admin.activity',
        ),
        'uses' => 'App\\Http\\Controllers\\Admin\\ArtworkProofController@file',
        'controller' => 'App\\Http\\Controllers\\Admin\\ArtworkProofController@file',
        'as' => 'admin.orders.artwork-proofs.file',
        'namespace' => NULL,
        'prefix' => '/admin',
        'where' => 
        array (
        ),
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'admin.orders.artwork-proofs.reply' => 
    array (
      'methods' => 
      array (
        0 => 'POST',
      ),
      'uri' => 'admin/orders/{order}/artwork-proofs/{proof}/reply',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'admin.hidden',
          2 => 'auth:admin',
          3 => 'admin',
          4 => 'admin.permission',
          5 => 'admin.activity',
          6 => 'throttle:10,1',
        ),
        'uses' => 'App\\Http\\Controllers\\Admin\\ArtworkProofController@reply',
        'controller' => 'App\\Http\\Controllers\\Admin\\ArtworkProofController@reply',
        'as' => 'admin.orders.artwork-proofs.reply',
        'namespace' => NULL,
        'prefix' => '/admin',
        'where' => 
        array (
        ),
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'admin.orders.artwork.show' => 
    array (
      'methods' => 
      array (
        0 => 'GET',
        1 => 'HEAD',
      ),
      'uri' => 'admin/orders/{order}/items/{orderItem}/artwork/{artworkIndex}',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'admin.hidden',
          2 => 'auth:admin',
          3 => 'admin',
          4 => 'admin.permission',
          5 => 'admin.activity',
        ),
        'uses' => 'App\\Http\\Controllers\\Admin\\OrderController@artwork',
        'controller' => 'App\\Http\\Controllers\\Admin\\OrderController@artwork',
        'as' => 'admin.orders.artwork.show',
        'namespace' => NULL,
        'prefix' => '/admin',
        'where' => 
        array (
        ),
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
        'artworkIndex' => '[0-9]+',
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'admin.orders.approve' => 
    array (
      'methods' => 
      array (
        0 => 'PATCH',
      ),
      'uri' => 'admin/orders/{order}/approve',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'admin.hidden',
          2 => 'auth:admin',
          3 => 'admin',
          4 => 'admin.permission',
          5 => 'admin.activity',
          6 => 'throttle:10,1',
        ),
        'uses' => 'App\\Http\\Controllers\\Admin\\OrderController@approve',
        'controller' => 'App\\Http\\Controllers\\Admin\\OrderController@approve',
        'as' => 'admin.orders.approve',
        'namespace' => NULL,
        'prefix' => '/admin',
        'where' => 
        array (
        ),
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'admin.orders.retry-sync' => 
    array (
      'methods' => 
      array (
        0 => 'POST',
      ),
      'uri' => 'admin/orders/{order}/retry-sync',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'admin.hidden',
          2 => 'auth:admin',
          3 => 'admin',
          4 => 'admin.permission',
          5 => 'admin.activity',
          6 => 'throttle:6,1',
        ),
        'uses' => 'App\\Http\\Controllers\\Admin\\OrderController@retryFlowTrackSync',
        'controller' => 'App\\Http\\Controllers\\Admin\\OrderController@retryFlowTrackSync',
        'as' => 'admin.orders.retry-sync',
        'namespace' => NULL,
        'prefix' => '/admin',
        'where' => 
        array (
        ),
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'admin.orders.update' => 
    array (
      'methods' => 
      array (
        0 => 'PATCH',
      ),
      'uri' => 'admin/orders/{order}',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'admin.hidden',
          2 => 'auth:admin',
          3 => 'admin',
          4 => 'admin.permission',
          5 => 'admin.activity',
          6 => 'throttle:20,1',
        ),
        'uses' => 'App\\Http\\Controllers\\Admin\\OrderController@update',
        'controller' => 'App\\Http\\Controllers\\Admin\\OrderController@update',
        'as' => 'admin.orders.update',
        'namespace' => NULL,
        'prefix' => '/admin',
        'where' => 
        array (
        ),
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'admin.orders.shipments.store' => 
    array (
      'methods' => 
      array (
        0 => 'POST',
      ),
      'uri' => 'admin/orders/{order}/shipments',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'admin.hidden',
          2 => 'auth:admin',
          3 => 'admin',
          4 => 'admin.permission',
          5 => 'admin.activity',
          6 => 'throttle:20,1',
        ),
        'uses' => 'App\\Http\\Controllers\\Admin\\OrderShipmentController@store',
        'controller' => 'App\\Http\\Controllers\\Admin\\OrderShipmentController@store',
        'as' => 'admin.orders.shipments.store',
        'namespace' => NULL,
        'prefix' => '/admin',
        'where' => 
        array (
        ),
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'admin.orders.shipments.update' => 
    array (
      'methods' => 
      array (
        0 => 'PATCH',
      ),
      'uri' => 'admin/orders/{order}/shipments/{shipment}',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'admin.hidden',
          2 => 'auth:admin',
          3 => 'admin',
          4 => 'admin.permission',
          5 => 'admin.activity',
          6 => 'throttle:20,1',
        ),
        'uses' => 'App\\Http\\Controllers\\Admin\\OrderShipmentController@update',
        'controller' => 'App\\Http\\Controllers\\Admin\\OrderShipmentController@update',
        'as' => 'admin.orders.shipments.update',
        'namespace' => NULL,
        'prefix' => '/admin',
        'where' => 
        array (
        ),
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'admin.orders.requests.update' => 
    array (
      'methods' => 
      array (
        0 => 'PATCH',
      ),
      'uri' => 'admin/orders/{order}/requests/{changeRequest}',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'admin.hidden',
          2 => 'auth:admin',
          3 => 'admin',
          4 => 'admin.permission',
          5 => 'admin.activity',
          6 => 'throttle:20,1',
        ),
        'uses' => 'App\\Http\\Controllers\\Admin\\OrderChangeRequestController@update',
        'controller' => 'App\\Http\\Controllers\\Admin\\OrderChangeRequestController@update',
        'as' => 'admin.orders.requests.update',
        'namespace' => NULL,
        'prefix' => '/admin',
        'where' => 
        array (
        ),
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'admin.orders.downloads.store' => 
    array (
      'methods' => 
      array (
        0 => 'POST',
      ),
      'uri' => 'admin/orders/{order}/downloads',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'admin.hidden',
          2 => 'auth:admin',
          3 => 'admin',
          4 => 'admin.permission',
          5 => 'admin.activity',
          6 => 'throttle:10,1',
        ),
        'uses' => 'App\\Http\\Controllers\\Admin\\OrderDownloadController@store',
        'controller' => 'App\\Http\\Controllers\\Admin\\OrderDownloadController@store',
        'as' => 'admin.orders.downloads.store',
        'namespace' => NULL,
        'prefix' => '/admin',
        'where' => 
        array (
        ),
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'admin.orders.downloads.destroy' => 
    array (
      'methods' => 
      array (
        0 => 'DELETE',
      ),
      'uri' => 'admin/orders/{order}/downloads/{download}',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'admin.hidden',
          2 => 'auth:admin',
          3 => 'admin',
          4 => 'admin.permission',
          5 => 'admin.activity',
        ),
        'uses' => 'App\\Http\\Controllers\\Admin\\OrderDownloadController@destroy',
        'controller' => 'App\\Http\\Controllers\\Admin\\OrderDownloadController@destroy',
        'as' => 'admin.orders.downloads.destroy',
        'namespace' => NULL,
        'prefix' => '/admin',
        'where' => 
        array (
        ),
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'admin.returns.index' => 
    array (
      'methods' => 
      array (
        0 => 'GET',
        1 => 'HEAD',
      ),
      'uri' => 'admin/returns',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'admin.hidden',
          2 => 'auth:admin',
          3 => 'admin',
          4 => 'admin.permission',
          5 => 'admin.activity',
        ),
        'uses' => 'App\\Http\\Controllers\\Admin\\OrderReturnController@index',
        'controller' => 'App\\Http\\Controllers\\Admin\\OrderReturnController@index',
        'as' => 'admin.returns.index',
        'namespace' => NULL,
        'prefix' => '/admin',
        'where' => 
        array (
        ),
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'admin.returns.show' => 
    array (
      'methods' => 
      array (
        0 => 'GET',
        1 => 'HEAD',
      ),
      'uri' => 'admin/returns/{returnRequest}',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'admin.hidden',
          2 => 'auth:admin',
          3 => 'admin',
          4 => 'admin.permission',
          5 => 'admin.activity',
        ),
        'uses' => 'App\\Http\\Controllers\\Admin\\OrderReturnController@show',
        'controller' => 'App\\Http\\Controllers\\Admin\\OrderReturnController@show',
        'as' => 'admin.returns.show',
        'namespace' => NULL,
        'prefix' => '/admin',
        'where' => 
        array (
        ),
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'admin.returns.attachments.download' => 
    array (
      'methods' => 
      array (
        0 => 'GET',
        1 => 'HEAD',
      ),
      'uri' => 'admin/returns/{returnRequest}/attachments/{attachment}',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'admin.hidden',
          2 => 'auth:admin',
          3 => 'admin',
          4 => 'admin.permission',
          5 => 'admin.activity',
        ),
        'uses' => 'App\\Http\\Controllers\\Admin\\OrderReturnController@downloadAttachment',
        'controller' => 'App\\Http\\Controllers\\Admin\\OrderReturnController@downloadAttachment',
        'as' => 'admin.returns.attachments.download',
        'namespace' => NULL,
        'prefix' => '/admin',
        'where' => 
        array (
        ),
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'admin.returns.update' => 
    array (
      'methods' => 
      array (
        0 => 'PATCH',
      ),
      'uri' => 'admin/returns/{returnRequest}',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'admin.hidden',
          2 => 'auth:admin',
          3 => 'admin',
          4 => 'admin.permission',
          5 => 'admin.activity',
          6 => 'throttle:20,1',
        ),
        'uses' => 'App\\Http\\Controllers\\Admin\\OrderReturnController@update',
        'controller' => 'App\\Http\\Controllers\\Admin\\OrderReturnController@update',
        'as' => 'admin.returns.update',
        'namespace' => NULL,
        'prefix' => '/admin',
        'where' => 
        array (
        ),
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'admin.modules.show' => 
    array (
      'methods' => 
      array (
        0 => 'GET',
        1 => 'HEAD',
      ),
      'uri' => 'admin/module/{module}',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'admin.hidden',
          2 => 'auth:admin',
          3 => 'admin',
          4 => 'admin.permission',
          5 => 'admin.activity',
        ),
        'uses' => 'App\\Http\\Controllers\\Admin\\ModuleController@show',
        'controller' => 'App\\Http\\Controllers\\Admin\\ModuleController@show',
        'as' => 'admin.modules.show',
        'namespace' => NULL,
        'prefix' => '/admin',
        'where' => 
        array (
        ),
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
        'module' => 'orders|inventory|discounts|content|shipping|payments',
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'login' => 
    array (
      'methods' => 
      array (
        0 => 'GET',
        1 => 'HEAD',
      ),
      'uri' => 'login',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'guest:web',
          2 => 'not.admin',
        ),
        'uses' => 'App\\Http\\Controllers\\Storefront\\Auth\\AuthenticatedSessionController@create',
        'controller' => 'App\\Http\\Controllers\\Storefront\\Auth\\AuthenticatedSessionController@create',
        'namespace' => NULL,
        'prefix' => '',
        'where' => 
        array (
        ),
        'as' => 'login',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'login.store' => 
    array (
      'methods' => 
      array (
        0 => 'POST',
      ),
      'uri' => 'login',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'guest:web',
          2 => 'not.admin',
          3 => 'throttle:storefront-login',
        ),
        'uses' => 'App\\Http\\Controllers\\Storefront\\Auth\\AuthenticatedSessionController@store',
        'controller' => 'App\\Http\\Controllers\\Storefront\\Auth\\AuthenticatedSessionController@store',
        'namespace' => NULL,
        'prefix' => '',
        'where' => 
        array (
        ),
        'as' => 'login.store',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'register' => 
    array (
      'methods' => 
      array (
        0 => 'GET',
        1 => 'HEAD',
      ),
      'uri' => 'register',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'guest:web',
          2 => 'not.admin',
        ),
        'uses' => 'App\\Http\\Controllers\\Storefront\\Auth\\RegisteredUserController@create',
        'controller' => 'App\\Http\\Controllers\\Storefront\\Auth\\RegisteredUserController@create',
        'namespace' => NULL,
        'prefix' => '',
        'where' => 
        array (
        ),
        'as' => 'register',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'register.store' => 
    array (
      'methods' => 
      array (
        0 => 'POST',
      ),
      'uri' => 'register',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'guest:web',
          2 => 'not.admin',
          3 => 'throttle:5,1',
        ),
        'uses' => 'App\\Http\\Controllers\\Storefront\\Auth\\RegisteredUserController@store',
        'controller' => 'App\\Http\\Controllers\\Storefront\\Auth\\RegisteredUserController@store',
        'namespace' => NULL,
        'prefix' => '',
        'where' => 
        array (
        ),
        'as' => 'register.store',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'password.request' => 
    array (
      'methods' => 
      array (
        0 => 'GET',
        1 => 'HEAD',
      ),
      'uri' => 'forgot-password',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'guest:web',
          2 => 'not.admin',
        ),
        'uses' => 'App\\Http\\Controllers\\Storefront\\Auth\\PasswordResetLinkController@create',
        'controller' => 'App\\Http\\Controllers\\Storefront\\Auth\\PasswordResetLinkController@create',
        'namespace' => NULL,
        'prefix' => '',
        'where' => 
        array (
        ),
        'as' => 'password.request',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'password.email' => 
    array (
      'methods' => 
      array (
        0 => 'POST',
      ),
      'uri' => 'forgot-password',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'guest:web',
          2 => 'not.admin',
          3 => 'throttle:password-reset-link',
        ),
        'uses' => 'App\\Http\\Controllers\\Storefront\\Auth\\PasswordResetLinkController@store',
        'controller' => 'App\\Http\\Controllers\\Storefront\\Auth\\PasswordResetLinkController@store',
        'namespace' => NULL,
        'prefix' => '',
        'where' => 
        array (
        ),
        'as' => 'password.email',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'password.reset' => 
    array (
      'methods' => 
      array (
        0 => 'GET',
        1 => 'HEAD',
      ),
      'uri' => 'reset-password/{token}',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'guest:web',
          2 => 'not.admin',
        ),
        'uses' => 'App\\Http\\Controllers\\Storefront\\Auth\\NewPasswordController@create',
        'controller' => 'App\\Http\\Controllers\\Storefront\\Auth\\NewPasswordController@create',
        'namespace' => NULL,
        'prefix' => '',
        'where' => 
        array (
        ),
        'as' => 'password.reset',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'password.store' => 
    array (
      'methods' => 
      array (
        0 => 'POST',
      ),
      'uri' => 'reset-password',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'guest:web',
          2 => 'not.admin',
          3 => 'throttle:password-reset',
        ),
        'uses' => 'App\\Http\\Controllers\\Storefront\\Auth\\NewPasswordController@store',
        'controller' => 'App\\Http\\Controllers\\Storefront\\Auth\\NewPasswordController@store',
        'namespace' => NULL,
        'prefix' => '',
        'where' => 
        array (
        ),
        'as' => 'password.store',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'verification.notice' => 
    array (
      'methods' => 
      array (
        0 => 'GET',
        1 => 'HEAD',
      ),
      'uri' => 'email/verify',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'not.admin',
          2 => 'auth:web',
          3 => 'customer',
        ),
        'uses' => 'App\\Http\\Controllers\\Storefront\\Auth\\EmailVerificationController@notice',
        'controller' => 'App\\Http\\Controllers\\Storefront\\Auth\\EmailVerificationController@notice',
        'namespace' => NULL,
        'prefix' => '',
        'where' => 
        array (
        ),
        'as' => 'verification.notice',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'verification.verify' => 
    array (
      'methods' => 
      array (
        0 => 'GET',
        1 => 'HEAD',
      ),
      'uri' => 'email/verify/{id}/{hash}',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'not.admin',
          2 => 'auth:web',
          3 => 'customer',
          4 => 'signed',
          5 => 'throttle:30,1',
        ),
        'uses' => 'App\\Http\\Controllers\\Storefront\\Auth\\EmailVerificationController@verify',
        'controller' => 'App\\Http\\Controllers\\Storefront\\Auth\\EmailVerificationController@verify',
        'namespace' => NULL,
        'prefix' => '',
        'where' => 
        array (
        ),
        'as' => 'verification.verify',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'verification.success' => 
    array (
      'methods' => 
      array (
        0 => 'GET',
        1 => 'HEAD',
      ),
      'uri' => 'email/verified',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'not.admin',
          2 => 'auth:web',
          3 => 'customer',
          4 => 'verified',
        ),
        'uses' => 'App\\Http\\Controllers\\Storefront\\Auth\\EmailVerificationController@success',
        'controller' => 'App\\Http\\Controllers\\Storefront\\Auth\\EmailVerificationController@success',
        'namespace' => NULL,
        'prefix' => '',
        'where' => 
        array (
        ),
        'as' => 'verification.success',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'verification.send' => 
    array (
      'methods' => 
      array (
        0 => 'POST',
      ),
      'uri' => 'email/verification-notification',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'not.admin',
          2 => 'auth:web',
          3 => 'customer',
          4 => 'throttle:email-verification-send',
        ),
        'uses' => 'App\\Http\\Controllers\\Storefront\\Auth\\EmailVerificationController@resend',
        'controller' => 'App\\Http\\Controllers\\Storefront\\Auth\\EmailVerificationController@resend',
        'namespace' => NULL,
        'prefix' => '',
        'where' => 
        array (
        ),
        'as' => 'verification.send',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'logout' => 
    array (
      'methods' => 
      array (
        0 => 'POST',
      ),
      'uri' => 'logout',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'auth:web',
          2 => 'customer',
        ),
        'uses' => 'App\\Http\\Controllers\\Storefront\\Auth\\AuthenticatedSessionController@destroy',
        'controller' => 'App\\Http\\Controllers\\Storefront\\Auth\\AuthenticatedSessionController@destroy',
        'namespace' => NULL,
        'prefix' => '',
        'where' => 
        array (
        ),
        'as' => 'logout',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'account.dashboard' => 
    array (
      'methods' => 
      array (
        0 => 'GET',
        1 => 'HEAD',
      ),
      'uri' => 'account',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'not.admin',
          2 => 'auth:web',
          3 => 'customer',
          4 => 'verified',
        ),
        'uses' => 'App\\Http\\Controllers\\Storefront\\Account\\AccountController@index',
        'controller' => 'App\\Http\\Controllers\\Storefront\\Account\\AccountController@index',
        'as' => 'account.dashboard',
        'namespace' => NULL,
        'prefix' => '/account',
        'where' => 
        array (
        ),
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'account.rewards' => 
    array (
      'methods' => 
      array (
        0 => 'GET',
        1 => 'HEAD',
      ),
      'uri' => 'account/rewards',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'not.admin',
          2 => 'auth:web',
          3 => 'customer',
          4 => 'verified',
        ),
        'uses' => 'App\\Http\\Controllers\\Storefront\\Account\\AccountController@rewards',
        'controller' => 'App\\Http\\Controllers\\Storefront\\Account\\AccountController@rewards',
        'as' => 'account.rewards',
        'namespace' => NULL,
        'prefix' => '/account',
        'where' => 
        array (
        ),
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'account.referrals' => 
    array (
      'methods' => 
      array (
        0 => 'GET',
        1 => 'HEAD',
      ),
      'uri' => 'account/refer-a-friend',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'not.admin',
          2 => 'auth:web',
          3 => 'customer',
          4 => 'verified',
        ),
        'uses' => 'App\\Http\\Controllers\\Storefront\\Account\\AccountController@referrals',
        'controller' => 'App\\Http\\Controllers\\Storefront\\Account\\AccountController@referrals',
        'as' => 'account.referrals',
        'namespace' => NULL,
        'prefix' => '/account',
        'where' => 
        array (
        ),
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'account.profile.edit' => 
    array (
      'methods' => 
      array (
        0 => 'GET',
        1 => 'HEAD',
      ),
      'uri' => 'account/profile',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'not.admin',
          2 => 'auth:web',
          3 => 'customer',
          4 => 'verified',
        ),
        'uses' => 'App\\Http\\Controllers\\Storefront\\Account\\ProfileController@edit',
        'controller' => 'App\\Http\\Controllers\\Storefront\\Account\\ProfileController@edit',
        'as' => 'account.profile.edit',
        'namespace' => NULL,
        'prefix' => '/account',
        'where' => 
        array (
        ),
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'account.profile.update' => 
    array (
      'methods' => 
      array (
        0 => 'PATCH',
      ),
      'uri' => 'account/profile',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'not.admin',
          2 => 'auth:web',
          3 => 'customer',
          4 => 'verified',
          5 => 'throttle:10,1',
        ),
        'uses' => 'App\\Http\\Controllers\\Storefront\\Account\\ProfileController@update',
        'controller' => 'App\\Http\\Controllers\\Storefront\\Account\\ProfileController@update',
        'as' => 'account.profile.update',
        'namespace' => NULL,
        'prefix' => '/account',
        'where' => 
        array (
        ),
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'account.password.update' => 
    array (
      'methods' => 
      array (
        0 => 'PATCH',
      ),
      'uri' => 'account/password',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'not.admin',
          2 => 'auth:web',
          3 => 'customer',
          4 => 'verified',
          5 => 'throttle:5,1',
        ),
        'uses' => 'App\\Http\\Controllers\\Storefront\\Account\\ProfileController@updatePassword',
        'controller' => 'App\\Http\\Controllers\\Storefront\\Account\\ProfileController@updatePassword',
        'as' => 'account.password.update',
        'namespace' => NULL,
        'prefix' => '/account',
        'where' => 
        array (
        ),
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'account.addresses.index' => 
    array (
      'methods' => 
      array (
        0 => 'GET',
        1 => 'HEAD',
      ),
      'uri' => 'account/addresses',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'not.admin',
          2 => 'auth:web',
          3 => 'customer',
          4 => 'verified',
        ),
        'uses' => 'App\\Http\\Controllers\\Storefront\\Account\\AddressController@index',
        'controller' => 'App\\Http\\Controllers\\Storefront\\Account\\AddressController@index',
        'as' => 'account.addresses.index',
        'namespace' => NULL,
        'prefix' => '/account',
        'where' => 
        array (
        ),
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'account.addresses.store' => 
    array (
      'methods' => 
      array (
        0 => 'POST',
      ),
      'uri' => 'account/addresses',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'not.admin',
          2 => 'auth:web',
          3 => 'customer',
          4 => 'verified',
          5 => 'throttle:10,1',
        ),
        'uses' => 'App\\Http\\Controllers\\Storefront\\Account\\AddressController@store',
        'controller' => 'App\\Http\\Controllers\\Storefront\\Account\\AddressController@store',
        'as' => 'account.addresses.store',
        'namespace' => NULL,
        'prefix' => '/account',
        'where' => 
        array (
        ),
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'account.addresses.default' => 
    array (
      'methods' => 
      array (
        0 => 'PATCH',
      ),
      'uri' => 'account/addresses/{address}/default',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'not.admin',
          2 => 'auth:web',
          3 => 'customer',
          4 => 'verified',
        ),
        'uses' => 'App\\Http\\Controllers\\Storefront\\Account\\AddressController@makeDefault',
        'controller' => 'App\\Http\\Controllers\\Storefront\\Account\\AddressController@makeDefault',
        'as' => 'account.addresses.default',
        'namespace' => NULL,
        'prefix' => '/account',
        'where' => 
        array (
        ),
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'account.addresses.destroy' => 
    array (
      'methods' => 
      array (
        0 => 'DELETE',
      ),
      'uri' => 'account/addresses/{address}',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'not.admin',
          2 => 'auth:web',
          3 => 'customer',
          4 => 'verified',
        ),
        'uses' => 'App\\Http\\Controllers\\Storefront\\Account\\AddressController@destroy',
        'controller' => 'App\\Http\\Controllers\\Storefront\\Account\\AddressController@destroy',
        'as' => 'account.addresses.destroy',
        'namespace' => NULL,
        'prefix' => '/account',
        'where' => 
        array (
        ),
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'account.payment-methods.index' => 
    array (
      'methods' => 
      array (
        0 => 'GET',
        1 => 'HEAD',
      ),
      'uri' => 'account/payment-methods',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'not.admin',
          2 => 'auth:web',
          3 => 'customer',
          4 => 'verified',
        ),
        'uses' => 'App\\Http\\Controllers\\Storefront\\Account\\PaymentMethodController@index',
        'controller' => 'App\\Http\\Controllers\\Storefront\\Account\\PaymentMethodController@index',
        'as' => 'account.payment-methods.index',
        'namespace' => NULL,
        'prefix' => '/account',
        'where' => 
        array (
        ),
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'account.payment-methods.default' => 
    array (
      'methods' => 
      array (
        0 => 'PATCH',
      ),
      'uri' => 'account/payment-methods/{paymentMethod}/default',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'not.admin',
          2 => 'auth:web',
          3 => 'customer',
          4 => 'verified',
        ),
        'uses' => 'App\\Http\\Controllers\\Storefront\\Account\\PaymentMethodController@makeDefault',
        'controller' => 'App\\Http\\Controllers\\Storefront\\Account\\PaymentMethodController@makeDefault',
        'as' => 'account.payment-methods.default',
        'namespace' => NULL,
        'prefix' => '/account',
        'where' => 
        array (
        ),
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'account.payment-methods.destroy' => 
    array (
      'methods' => 
      array (
        0 => 'DELETE',
      ),
      'uri' => 'account/payment-methods/{paymentMethod}',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'not.admin',
          2 => 'auth:web',
          3 => 'customer',
          4 => 'verified',
        ),
        'uses' => 'App\\Http\\Controllers\\Storefront\\Account\\PaymentMethodController@destroy',
        'controller' => 'App\\Http\\Controllers\\Storefront\\Account\\PaymentMethodController@destroy',
        'as' => 'account.payment-methods.destroy',
        'namespace' => NULL,
        'prefix' => '/account',
        'where' => 
        array (
        ),
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'account.bulk-quotes.index' => 
    array (
      'methods' => 
      array (
        0 => 'GET',
        1 => 'HEAD',
      ),
      'uri' => 'account/bulk-quotes',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'not.admin',
          2 => 'auth:web',
          3 => 'customer',
          4 => 'verified',
        ),
        'uses' => 'App\\Http\\Controllers\\Storefront\\Account\\BulkQuoteCenterController@index',
        'controller' => 'App\\Http\\Controllers\\Storefront\\Account\\BulkQuoteCenterController@index',
        'as' => 'account.bulk-quotes.index',
        'namespace' => NULL,
        'prefix' => '/account',
        'where' => 
        array (
        ),
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'account.bulk-quotes.show' => 
    array (
      'methods' => 
      array (
        0 => 'GET',
        1 => 'HEAD',
      ),
      'uri' => 'account/bulk-quotes/{reference}',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'not.admin',
          2 => 'auth:web',
          3 => 'customer',
          4 => 'verified',
        ),
        'uses' => 'App\\Http\\Controllers\\Storefront\\Account\\BulkQuoteCenterController@show',
        'controller' => 'App\\Http\\Controllers\\Storefront\\Account\\BulkQuoteCenterController@show',
        'as' => 'account.bulk-quotes.show',
        'namespace' => NULL,
        'prefix' => '/account',
        'where' => 
        array (
        ),
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'account.bulk-quotes.changes' => 
    array (
      'methods' => 
      array (
        0 => 'GET',
        1 => 'HEAD',
      ),
      'uri' => 'account/bulk-quotes/{reference}/changes',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'not.admin',
          2 => 'auth:web',
          3 => 'customer',
          4 => 'verified',
        ),
        'uses' => 'App\\Http\\Controllers\\Storefront\\Account\\BulkQuoteCenterController@changes',
        'controller' => 'App\\Http\\Controllers\\Storefront\\Account\\BulkQuoteCenterController@changes',
        'as' => 'account.bulk-quotes.changes',
        'namespace' => NULL,
        'prefix' => '/account',
        'where' => 
        array (
        ),
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'account.bulk-quotes.changes.send' => 
    array (
      'methods' => 
      array (
        0 => 'POST',
      ),
      'uri' => 'account/bulk-quotes/{reference}/changes',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'not.admin',
          2 => 'auth:web',
          3 => 'customer',
          4 => 'verified',
          5 => 'throttle:6,1',
        ),
        'uses' => 'App\\Http\\Controllers\\Storefront\\Account\\BulkQuoteCenterController@sendChanges',
        'controller' => 'App\\Http\\Controllers\\Storefront\\Account\\BulkQuoteCenterController@sendChanges',
        'as' => 'account.bulk-quotes.changes.send',
        'namespace' => NULL,
        'prefix' => '/account',
        'where' => 
        array (
        ),
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'account.bulk-quotes.message' => 
    array (
      'methods' => 
      array (
        0 => 'POST',
      ),
      'uri' => 'account/bulk-quotes/{reference}/message',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'not.admin',
          2 => 'auth:web',
          3 => 'customer',
          4 => 'verified',
          5 => 'throttle:quote-message',
        ),
        'uses' => 'App\\Http\\Controllers\\Storefront\\Account\\BulkQuoteCenterController@sendMessage',
        'controller' => 'App\\Http\\Controllers\\Storefront\\Account\\BulkQuoteCenterController@sendMessage',
        'as' => 'account.bulk-quotes.message',
        'namespace' => NULL,
        'prefix' => '/account',
        'where' => 
        array (
        ),
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'account.bulk-quotes.decision' => 
    array (
      'methods' => 
      array (
        0 => 'POST',
      ),
      'uri' => 'account/bulk-quotes/{reference}/decision',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'not.admin',
          2 => 'auth:web',
          3 => 'customer',
          4 => 'verified',
          5 => 'throttle:guest-quote-decision',
        ),
        'uses' => 'App\\Http\\Controllers\\Storefront\\Account\\BulkQuoteCenterController@decision',
        'controller' => 'App\\Http\\Controllers\\Storefront\\Account\\BulkQuoteCenterController@decision',
        'as' => 'account.bulk-quotes.decision',
        'namespace' => NULL,
        'prefix' => '/account',
        'where' => 
        array (
        ),
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'account.bulk-quotes.file' => 
    array (
      'methods' => 
      array (
        0 => 'GET',
        1 => 'HEAD',
      ),
      'uri' => 'account/bulk-quotes/{reference}/file/{file}',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'not.admin',
          2 => 'auth:web',
          3 => 'customer',
          4 => 'verified',
          5 => 'throttle:30,1',
        ),
        'uses' => 'App\\Http\\Controllers\\Storefront\\Account\\BulkQuoteCenterController@file',
        'controller' => 'App\\Http\\Controllers\\Storefront\\Account\\BulkQuoteCenterController@file',
        'as' => 'account.bulk-quotes.file',
        'namespace' => NULL,
        'prefix' => '/account',
        'where' => 
        array (
        ),
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'account.artwork.index' => 
    array (
      'methods' => 
      array (
        0 => 'GET',
        1 => 'HEAD',
      ),
      'uri' => 'account/artwork-approvals',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'not.admin',
          2 => 'auth:web',
          3 => 'customer',
          4 => 'verified',
        ),
        'uses' => 'App\\Http\\Controllers\\Storefront\\Account\\ArtworkApprovalController@index',
        'controller' => 'App\\Http\\Controllers\\Storefront\\Account\\ArtworkApprovalController@index',
        'as' => 'account.artwork.index',
        'namespace' => NULL,
        'prefix' => '/account',
        'where' => 
        array (
        ),
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'account.artwork.show' => 
    array (
      'methods' => 
      array (
        0 => 'GET',
        1 => 'HEAD',
      ),
      'uri' => 'account/artwork-approvals/{proof}',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'not.admin',
          2 => 'auth:web',
          3 => 'customer',
          4 => 'verified',
        ),
        'uses' => 'App\\Http\\Controllers\\Storefront\\Account\\ArtworkApprovalController@show',
        'controller' => 'App\\Http\\Controllers\\Storefront\\Account\\ArtworkApprovalController@show',
        'as' => 'account.artwork.show',
        'namespace' => NULL,
        'prefix' => '/account',
        'where' => 
        array (
        ),
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'account.artwork.changes' => 
    array (
      'methods' => 
      array (
        0 => 'GET',
        1 => 'HEAD',
      ),
      'uri' => 'account/artwork-approvals/{proof}/request-changes',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'not.admin',
          2 => 'auth:web',
          3 => 'customer',
          4 => 'verified',
        ),
        'uses' => 'App\\Http\\Controllers\\Storefront\\Account\\ArtworkApprovalController@changes',
        'controller' => 'App\\Http\\Controllers\\Storefront\\Account\\ArtworkApprovalController@changes',
        'as' => 'account.artwork.changes',
        'namespace' => NULL,
        'prefix' => '/account',
        'where' => 
        array (
        ),
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'account.artwork.changes.store' => 
    array (
      'methods' => 
      array (
        0 => 'POST',
      ),
      'uri' => 'account/artwork-approvals/{proof}/request-changes',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'not.admin',
          2 => 'auth:web',
          3 => 'customer',
          4 => 'verified',
          5 => 'throttle:5,1',
        ),
        'uses' => 'App\\Http\\Controllers\\Storefront\\Account\\ArtworkApprovalController@requestChanges',
        'controller' => 'App\\Http\\Controllers\\Storefront\\Account\\ArtworkApprovalController@requestChanges',
        'as' => 'account.artwork.changes.store',
        'namespace' => NULL,
        'prefix' => '/account',
        'where' => 
        array (
        ),
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'account.artwork.approve' => 
    array (
      'methods' => 
      array (
        0 => 'POST',
      ),
      'uri' => 'account/artwork-approvals/{proof}/approve',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'not.admin',
          2 => 'auth:web',
          3 => 'customer',
          4 => 'verified',
          5 => 'throttle:5,1',
        ),
        'uses' => 'App\\Http\\Controllers\\Storefront\\Account\\ArtworkApprovalController@approve',
        'controller' => 'App\\Http\\Controllers\\Storefront\\Account\\ArtworkApprovalController@approve',
        'as' => 'account.artwork.approve',
        'namespace' => NULL,
        'prefix' => '/account',
        'where' => 
        array (
        ),
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'account.artwork.reject' => 
    array (
      'methods' => 
      array (
        0 => 'POST',
      ),
      'uri' => 'account/artwork-approvals/{proof}/reject',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'not.admin',
          2 => 'auth:web',
          3 => 'customer',
          4 => 'verified',
          5 => 'throttle:5,1',
        ),
        'uses' => 'App\\Http\\Controllers\\Storefront\\Account\\ArtworkApprovalController@reject',
        'controller' => 'App\\Http\\Controllers\\Storefront\\Account\\ArtworkApprovalController@reject',
        'as' => 'account.artwork.reject',
        'namespace' => NULL,
        'prefix' => '/account',
        'where' => 
        array (
        ),
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'account.artwork.message' => 
    array (
      'methods' => 
      array (
        0 => 'POST',
      ),
      'uri' => 'account/artwork-approvals/{proof}/message',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'not.admin',
          2 => 'auth:web',
          3 => 'customer',
          4 => 'verified',
          5 => 'throttle:10,1',
        ),
        'uses' => 'App\\Http\\Controllers\\Storefront\\Account\\ArtworkApprovalController@message',
        'controller' => 'App\\Http\\Controllers\\Storefront\\Account\\ArtworkApprovalController@message',
        'as' => 'account.artwork.message',
        'namespace' => NULL,
        'prefix' => '/account',
        'where' => 
        array (
        ),
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'account.artwork.approved' => 
    array (
      'methods' => 
      array (
        0 => 'GET',
        1 => 'HEAD',
      ),
      'uri' => 'account/artwork-approvals/{proof}/approved',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'not.admin',
          2 => 'auth:web',
          3 => 'customer',
          4 => 'verified',
        ),
        'uses' => 'App\\Http\\Controllers\\Storefront\\Account\\ArtworkApprovalController@approved',
        'controller' => 'App\\Http\\Controllers\\Storefront\\Account\\ArtworkApprovalController@approved',
        'as' => 'account.artwork.approved',
        'namespace' => NULL,
        'prefix' => '/account',
        'where' => 
        array (
        ),
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'account.artwork.file' => 
    array (
      'methods' => 
      array (
        0 => 'GET',
        1 => 'HEAD',
      ),
      'uri' => 'account/artwork-approvals/{proof}/file',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'not.admin',
          2 => 'auth:web',
          3 => 'customer',
          4 => 'verified',
        ),
        'uses' => 'App\\Http\\Controllers\\Storefront\\Account\\ArtworkApprovalController@file',
        'controller' => 'App\\Http\\Controllers\\Storefront\\Account\\ArtworkApprovalController@file',
        'as' => 'account.artwork.file',
        'namespace' => NULL,
        'prefix' => '/account',
        'where' => 
        array (
        ),
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'account.orders.dashboard' => 
    array (
      'methods' => 
      array (
        0 => 'GET',
        1 => 'HEAD',
      ),
      'uri' => 'account/orders',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'not.admin',
          2 => 'auth:web',
          3 => 'customer',
          4 => 'verified',
        ),
        'uses' => 'App\\Http\\Controllers\\Storefront\\Account\\OrderCenterController@dashboard',
        'controller' => 'App\\Http\\Controllers\\Storefront\\Account\\OrderCenterController@dashboard',
        'as' => 'account.orders.dashboard',
        'namespace' => NULL,
        'prefix' => '/account',
        'where' => 
        array (
        ),
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'account.orders.index' => 
    array (
      'methods' => 
      array (
        0 => 'GET',
        1 => 'HEAD',
      ),
      'uri' => 'account/orders/history',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'not.admin',
          2 => 'auth:web',
          3 => 'customer',
          4 => 'verified',
        ),
        'uses' => 'App\\Http\\Controllers\\Storefront\\Account\\OrderCenterController@index',
        'controller' => 'App\\Http\\Controllers\\Storefront\\Account\\OrderCenterController@index',
        'as' => 'account.orders.index',
        'namespace' => NULL,
        'prefix' => '/account',
        'where' => 
        array (
        ),
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'account.orders.show' => 
    array (
      'methods' => 
      array (
        0 => 'GET',
        1 => 'HEAD',
      ),
      'uri' => 'account/orders/{order}',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'not.admin',
          2 => 'auth:web',
          3 => 'customer',
          4 => 'verified',
        ),
        'uses' => 'App\\Http\\Controllers\\Storefront\\Account\\OrderCenterController@show',
        'controller' => 'App\\Http\\Controllers\\Storefront\\Account\\OrderCenterController@show',
        'as' => 'account.orders.show',
        'namespace' => NULL,
        'prefix' => '/account',
        'where' => 
        array (
        ),
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'account.orders.pay' => 
    array (
      'methods' => 
      array (
        0 => 'GET',
        1 => 'HEAD',
      ),
      'uri' => 'account/orders/{order}/pay',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'not.admin',
          2 => 'auth:web',
          3 => 'customer',
          4 => 'verified',
        ),
        'uses' => 'App\\Http\\Controllers\\Storefront\\Account\\OrderCenterController@pay',
        'controller' => 'App\\Http\\Controllers\\Storefront\\Account\\OrderCenterController@pay',
        'as' => 'account.orders.pay',
        'namespace' => NULL,
        'prefix' => '/account',
        'where' => 
        array (
        ),
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'account.orders.pay.store' => 
    array (
      'methods' => 
      array (
        0 => 'POST',
      ),
      'uri' => 'account/orders/{order}/pay',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'not.admin',
          2 => 'auth:web',
          3 => 'customer',
          4 => 'verified',
          5 => 'throttle:5,1',
        ),
        'uses' => 'App\\Http\\Controllers\\Storefront\\Account\\OrderCenterController@storePayment',
        'controller' => 'App\\Http\\Controllers\\Storefront\\Account\\OrderCenterController@storePayment',
        'as' => 'account.orders.pay.store',
        'namespace' => NULL,
        'prefix' => '/account',
        'where' => 
        array (
        ),
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'account.orders.payment.retry' => 
    array (
      'methods' => 
      array (
        0 => 'GET',
        1 => 'HEAD',
      ),
      'uri' => 'account/orders/{order}/retry-payment',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'not.admin',
          2 => 'auth:web',
          3 => 'customer',
          4 => 'verified',
        ),
        'uses' => 'App\\Http\\Controllers\\Storefront\\Account\\OrderCenterController@retry',
        'controller' => 'App\\Http\\Controllers\\Storefront\\Account\\OrderCenterController@retry',
        'as' => 'account.orders.payment.retry',
        'namespace' => NULL,
        'prefix' => '/account',
        'where' => 
        array (
        ),
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'account.orders.reorder' => 
    array (
      'methods' => 
      array (
        0 => 'GET',
        1 => 'HEAD',
      ),
      'uri' => 'account/orders/{order}/reorder',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'not.admin',
          2 => 'auth:web',
          3 => 'customer',
          4 => 'verified',
        ),
        'uses' => 'App\\Http\\Controllers\\Storefront\\Account\\OrderCenterController@reorder',
        'controller' => 'App\\Http\\Controllers\\Storefront\\Account\\OrderCenterController@reorder',
        'as' => 'account.orders.reorder',
        'namespace' => NULL,
        'prefix' => '/account',
        'where' => 
        array (
        ),
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'account.orders.reorder.store' => 
    array (
      'methods' => 
      array (
        0 => 'POST',
      ),
      'uri' => 'account/orders/{order}/reorder',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'not.admin',
          2 => 'auth:web',
          3 => 'customer',
          4 => 'verified',
          5 => 'throttle:order-reorder',
        ),
        'uses' => 'App\\Http\\Controllers\\Storefront\\Account\\OrderCenterController@storeReorder',
        'controller' => 'App\\Http\\Controllers\\Storefront\\Account\\OrderCenterController@storeReorder',
        'as' => 'account.orders.reorder.store',
        'namespace' => NULL,
        'prefix' => '/account',
        'where' => 
        array (
        ),
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'account.orders.cancel' => 
    array (
      'methods' => 
      array (
        0 => 'GET',
        1 => 'HEAD',
      ),
      'uri' => 'account/orders/{order}/cancel-request',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'not.admin',
          2 => 'auth:web',
          3 => 'customer',
          4 => 'verified',
        ),
        'uses' => 'App\\Http\\Controllers\\Storefront\\Account\\OrderCenterController@cancel',
        'controller' => 'App\\Http\\Controllers\\Storefront\\Account\\OrderCenterController@cancel',
        'as' => 'account.orders.cancel',
        'namespace' => NULL,
        'prefix' => '/account',
        'where' => 
        array (
        ),
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'account.orders.cancel.store' => 
    array (
      'methods' => 
      array (
        0 => 'POST',
      ),
      'uri' => 'account/orders/{order}/cancel-request',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'not.admin',
          2 => 'auth:web',
          3 => 'customer',
          4 => 'verified',
          5 => 'throttle:5,1',
        ),
        'uses' => 'App\\Http\\Controllers\\Storefront\\Account\\OrderCenterController@storeCancel',
        'controller' => 'App\\Http\\Controllers\\Storefront\\Account\\OrderCenterController@storeCancel',
        'as' => 'account.orders.cancel.store',
        'namespace' => NULL,
        'prefix' => '/account',
        'where' => 
        array (
        ),
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'account.orders.change' => 
    array (
      'methods' => 
      array (
        0 => 'GET',
        1 => 'HEAD',
      ),
      'uri' => 'account/orders/{order}/change-request',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'not.admin',
          2 => 'auth:web',
          3 => 'customer',
          4 => 'verified',
        ),
        'uses' => 'App\\Http\\Controllers\\Storefront\\Account\\OrderCenterController@change',
        'controller' => 'App\\Http\\Controllers\\Storefront\\Account\\OrderCenterController@change',
        'as' => 'account.orders.change',
        'namespace' => NULL,
        'prefix' => '/account',
        'where' => 
        array (
        ),
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'account.orders.change.store' => 
    array (
      'methods' => 
      array (
        0 => 'POST',
      ),
      'uri' => 'account/orders/{order}/change-request',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'not.admin',
          2 => 'auth:web',
          3 => 'customer',
          4 => 'verified',
          5 => 'throttle:5,1',
        ),
        'uses' => 'App\\Http\\Controllers\\Storefront\\Account\\OrderCenterController@storeChange',
        'controller' => 'App\\Http\\Controllers\\Storefront\\Account\\OrderCenterController@storeChange',
        'as' => 'account.orders.change.store',
        'namespace' => NULL,
        'prefix' => '/account',
        'where' => 
        array (
        ),
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'account.orders.shipments' => 
    array (
      'methods' => 
      array (
        0 => 'GET',
        1 => 'HEAD',
      ),
      'uri' => 'account/orders/{order}/shipments',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'not.admin',
          2 => 'auth:web',
          3 => 'customer',
          4 => 'verified',
        ),
        'uses' => 'App\\Http\\Controllers\\Storefront\\Account\\OrderCenterController@shipments',
        'controller' => 'App\\Http\\Controllers\\Storefront\\Account\\OrderCenterController@shipments',
        'as' => 'account.orders.shipments',
        'namespace' => NULL,
        'prefix' => '/account',
        'where' => 
        array (
        ),
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'account.orders.shipments.show' => 
    array (
      'methods' => 
      array (
        0 => 'GET',
        1 => 'HEAD',
      ),
      'uri' => 'account/orders/{order}/shipments/{shipment}',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'not.admin',
          2 => 'auth:web',
          3 => 'customer',
          4 => 'verified',
        ),
        'uses' => 'App\\Http\\Controllers\\Storefront\\Account\\OrderCenterController@shipment',
        'controller' => 'App\\Http\\Controllers\\Storefront\\Account\\OrderCenterController@shipment',
        'as' => 'account.orders.shipments.show',
        'namespace' => NULL,
        'prefix' => '/account',
        'where' => 
        array (
        ),
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'account.orders.invoice' => 
    array (
      'methods' => 
      array (
        0 => 'GET',
        1 => 'HEAD',
      ),
      'uri' => 'account/orders/{order}/invoice',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'not.admin',
          2 => 'auth:web',
          3 => 'customer',
          4 => 'verified',
        ),
        'uses' => 'App\\Http\\Controllers\\Storefront\\Account\\OrderCenterController@invoice',
        'controller' => 'App\\Http\\Controllers\\Storefront\\Account\\OrderCenterController@invoice',
        'as' => 'account.orders.invoice',
        'namespace' => NULL,
        'prefix' => '/account',
        'where' => 
        array (
        ),
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'account.orders.invoice.download' => 
    array (
      'methods' => 
      array (
        0 => 'GET',
        1 => 'HEAD',
      ),
      'uri' => 'account/orders/{order}/invoice/download',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'not.admin',
          2 => 'auth:web',
          3 => 'customer',
          4 => 'verified',
          5 => 'signed',
        ),
        'uses' => 'App\\Http\\Controllers\\Storefront\\Account\\OrderCenterController@downloadInvoice',
        'controller' => 'App\\Http\\Controllers\\Storefront\\Account\\OrderCenterController@downloadInvoice',
        'as' => 'account.orders.invoice.download',
        'namespace' => NULL,
        'prefix' => '/account',
        'where' => 
        array (
        ),
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'account.orders.returns.create' => 
    array (
      'methods' => 
      array (
        0 => 'GET',
        1 => 'HEAD',
      ),
      'uri' => 'account/orders/{order}/return-request',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'not.admin',
          2 => 'auth:web',
          3 => 'customer',
          4 => 'verified',
        ),
        'uses' => 'App\\Http\\Controllers\\Storefront\\Account\\ReturnCenterController@create',
        'controller' => 'App\\Http\\Controllers\\Storefront\\Account\\ReturnCenterController@create',
        'as' => 'account.orders.returns.create',
        'namespace' => NULL,
        'prefix' => '/account',
        'where' => 
        array (
        ),
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'account.orders.returns.store' => 
    array (
      'methods' => 
      array (
        0 => 'POST',
      ),
      'uri' => 'account/orders/{order}/return-request',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'not.admin',
          2 => 'auth:web',
          3 => 'customer',
          4 => 'verified',
          5 => 'throttle:5,1',
        ),
        'uses' => 'App\\Http\\Controllers\\Storefront\\Account\\ReturnCenterController@store',
        'controller' => 'App\\Http\\Controllers\\Storefront\\Account\\ReturnCenterController@store',
        'as' => 'account.orders.returns.store',
        'namespace' => NULL,
        'prefix' => '/account',
        'where' => 
        array (
        ),
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'account.orders.exchanges.create' => 
    array (
      'methods' => 
      array (
        0 => 'GET',
        1 => 'HEAD',
      ),
      'uri' => 'account/orders/{order}/exchange-request',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'not.admin',
          2 => 'auth:web',
          3 => 'customer',
          4 => 'verified',
        ),
        'uses' => 'App\\Http\\Controllers\\Storefront\\Account\\ReturnCenterController@createExchange',
        'controller' => 'App\\Http\\Controllers\\Storefront\\Account\\ReturnCenterController@createExchange',
        'as' => 'account.orders.exchanges.create',
        'namespace' => NULL,
        'prefix' => '/account',
        'where' => 
        array (
        ),
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'account.orders.exchanges.store' => 
    array (
      'methods' => 
      array (
        0 => 'POST',
      ),
      'uri' => 'account/orders/{order}/exchange-request',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'not.admin',
          2 => 'auth:web',
          3 => 'customer',
          4 => 'verified',
          5 => 'throttle:5,1',
        ),
        'uses' => 'App\\Http\\Controllers\\Storefront\\Account\\ReturnCenterController@storeExchange',
        'controller' => 'App\\Http\\Controllers\\Storefront\\Account\\ReturnCenterController@storeExchange',
        'as' => 'account.orders.exchanges.store',
        'namespace' => NULL,
        'prefix' => '/account',
        'where' => 
        array (
        ),
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'account.returns.index' => 
    array (
      'methods' => 
      array (
        0 => 'GET',
        1 => 'HEAD',
      ),
      'uri' => 'account/returns',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'not.admin',
          2 => 'auth:web',
          3 => 'customer',
          4 => 'verified',
        ),
        'uses' => 'App\\Http\\Controllers\\Storefront\\Account\\ReturnCenterController@index',
        'controller' => 'App\\Http\\Controllers\\Storefront\\Account\\ReturnCenterController@index',
        'as' => 'account.returns.index',
        'namespace' => NULL,
        'prefix' => '/account',
        'where' => 
        array (
        ),
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'account.returns.show' => 
    array (
      'methods' => 
      array (
        0 => 'GET',
        1 => 'HEAD',
      ),
      'uri' => 'account/returns/{returnRequest}',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'not.admin',
          2 => 'auth:web',
          3 => 'customer',
          4 => 'verified',
        ),
        'uses' => 'App\\Http\\Controllers\\Storefront\\Account\\ReturnCenterController@show',
        'controller' => 'App\\Http\\Controllers\\Storefront\\Account\\ReturnCenterController@show',
        'as' => 'account.returns.show',
        'namespace' => NULL,
        'prefix' => '/account',
        'where' => 
        array (
        ),
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'account.return-attachments.download' => 
    array (
      'methods' => 
      array (
        0 => 'GET',
        1 => 'HEAD',
      ),
      'uri' => 'account/return-attachments/{attachment}',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'not.admin',
          2 => 'auth:web',
          3 => 'customer',
          4 => 'verified',
          5 => 'signed',
        ),
        'uses' => 'App\\Http\\Controllers\\Storefront\\Account\\ReturnCenterController@downloadAttachment',
        'controller' => 'App\\Http\\Controllers\\Storefront\\Account\\ReturnCenterController@downloadAttachment',
        'as' => 'account.return-attachments.download',
        'namespace' => NULL,
        'prefix' => '/account',
        'where' => 
        array (
        ),
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'account.refunds.show' => 
    array (
      'methods' => 
      array (
        0 => 'GET',
        1 => 'HEAD',
      ),
      'uri' => 'account/refunds/{refund}',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'not.admin',
          2 => 'auth:web',
          3 => 'customer',
          4 => 'verified',
        ),
        'uses' => 'App\\Http\\Controllers\\Storefront\\Account\\ReturnCenterController@refund',
        'controller' => 'App\\Http\\Controllers\\Storefront\\Account\\ReturnCenterController@refund',
        'as' => 'account.refunds.show',
        'namespace' => NULL,
        'prefix' => '/account',
        'where' => 
        array (
        ),
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'account.credit-notes.show' => 
    array (
      'methods' => 
      array (
        0 => 'GET',
        1 => 'HEAD',
      ),
      'uri' => 'account/credit-notes/{creditNote}',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'not.admin',
          2 => 'auth:web',
          3 => 'customer',
          4 => 'verified',
        ),
        'uses' => 'App\\Http\\Controllers\\Storefront\\Account\\ReturnCenterController@creditNote',
        'controller' => 'App\\Http\\Controllers\\Storefront\\Account\\ReturnCenterController@creditNote',
        'as' => 'account.credit-notes.show',
        'namespace' => NULL,
        'prefix' => '/account',
        'where' => 
        array (
        ),
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'account.credit-notes.download' => 
    array (
      'methods' => 
      array (
        0 => 'GET',
        1 => 'HEAD',
      ),
      'uri' => 'account/credit-notes/{creditNote}/download',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'not.admin',
          2 => 'auth:web',
          3 => 'customer',
          4 => 'verified',
          5 => 'signed',
        ),
        'uses' => 'App\\Http\\Controllers\\Storefront\\Account\\ReturnCenterController@downloadCreditNote',
        'controller' => 'App\\Http\\Controllers\\Storefront\\Account\\ReturnCenterController@downloadCreditNote',
        'as' => 'account.credit-notes.download',
        'namespace' => NULL,
        'prefix' => '/account',
        'where' => 
        array (
        ),
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'account.downloads.index' => 
    array (
      'methods' => 
      array (
        0 => 'GET',
        1 => 'HEAD',
      ),
      'uri' => 'account/order-downloads',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'not.admin',
          2 => 'auth:web',
          3 => 'customer',
          4 => 'verified',
        ),
        'uses' => 'App\\Http\\Controllers\\Storefront\\Account\\OrderCenterController@downloads',
        'controller' => 'App\\Http\\Controllers\\Storefront\\Account\\OrderCenterController@downloads',
        'as' => 'account.downloads.index',
        'namespace' => NULL,
        'prefix' => '/account',
        'where' => 
        array (
        ),
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'account.downloads.download' => 
    array (
      'methods' => 
      array (
        0 => 'GET',
        1 => 'HEAD',
      ),
      'uri' => 'account/order-downloads/{download}',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'not.admin',
          2 => 'auth:web',
          3 => 'customer',
          4 => 'verified',
          5 => 'signed',
        ),
        'uses' => 'App\\Http\\Controllers\\Storefront\\Account\\OrderCenterController@download',
        'controller' => 'App\\Http\\Controllers\\Storefront\\Account\\OrderCenterController@download',
        'as' => 'account.downloads.download',
        'namespace' => NULL,
        'prefix' => '/account',
        'where' => 
        array (
        ),
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'categories.index' => 
    array (
      'methods' => 
      array (
        0 => 'GET',
        1 => 'HEAD',
      ),
      'uri' => 'categories',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
        ),
        'uses' => 'App\\Http\\Controllers\\Storefront\\CategoryController@index',
        'controller' => 'App\\Http\\Controllers\\Storefront\\CategoryController@index',
        'namespace' => NULL,
        'prefix' => '',
        'where' => 
        array (
        ),
        'as' => 'categories.index',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'categories.show' => 
    array (
      'methods' => 
      array (
        0 => 'GET',
        1 => 'HEAD',
      ),
      'uri' => 'category/{slug}',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
        ),
        'uses' => 'App\\Http\\Controllers\\Storefront\\CategoryController@show',
        'controller' => 'App\\Http\\Controllers\\Storefront\\CategoryController@show',
        'namespace' => NULL,
        'prefix' => '',
        'where' => 
        array (
        ),
        'as' => 'categories.show',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
        'slug' => '[a-z0-9-]+',
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'sale.index' => 
    array (
      'methods' => 
      array (
        0 => 'GET',
        1 => 'HEAD',
      ),
      'uri' => 'sale',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
        ),
        'uses' => 'App\\Http\\Controllers\\Storefront\\ProductController@sale',
        'controller' => 'App\\Http\\Controllers\\Storefront\\ProductController@sale',
        'namespace' => NULL,
        'prefix' => '',
        'where' => 
        array (
        ),
        'as' => 'sale.index',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'products.index' => 
    array (
      'methods' => 
      array (
        0 => 'GET',
        1 => 'HEAD',
      ),
      'uri' => 'products',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
        ),
        'uses' => 'App\\Http\\Controllers\\Storefront\\ProductController@index',
        'controller' => 'App\\Http\\Controllers\\Storefront\\ProductController@index',
        'namespace' => NULL,
        'prefix' => '',
        'where' => 
        array (
        ),
        'as' => 'products.index',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'products.suggestions' => 
    array (
      'methods' => 
      array (
        0 => 'GET',
        1 => 'HEAD',
      ),
      'uri' => 'products/search-suggestions',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'throttle:60,1',
        ),
        'uses' => 'App\\Http\\Controllers\\Storefront\\ProductController@suggestions',
        'controller' => 'App\\Http\\Controllers\\Storefront\\ProductController@suggestions',
        'namespace' => NULL,
        'prefix' => '',
        'where' => 
        array (
        ),
        'as' => 'products.suggestions',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'products.show' => 
    array (
      'methods' => 
      array (
        0 => 'GET',
        1 => 'HEAD',
      ),
      'uri' => 'product/{slug}',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
        ),
        'uses' => 'App\\Http\\Controllers\\Storefront\\ProductController@show',
        'controller' => 'App\\Http\\Controllers\\Storefront\\ProductController@show',
        'namespace' => NULL,
        'prefix' => '',
        'where' => 
        array (
        ),
        'as' => 'products.show',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'products.show.legacy' => 
    array (
      'methods' => 
      array (
        0 => 'GET',
        1 => 'HEAD',
      ),
      'uri' => 'products/{slug}',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
        ),
        'uses' => 'App\\Http\\Controllers\\Storefront\\ProductController@show',
        'controller' => 'App\\Http\\Controllers\\Storefront\\ProductController@show',
        'namespace' => NULL,
        'prefix' => '',
        'where' => 
        array (
        ),
        'as' => 'products.show.legacy',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'wishlist.index' => 
    array (
      'methods' => 
      array (
        0 => 'GET',
        1 => 'HEAD',
      ),
      'uri' => 'wishlist',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'not.admin',
        ),
        'uses' => 'App\\Http\\Controllers\\Storefront\\ProductWishlistController@index',
        'controller' => 'App\\Http\\Controllers\\Storefront\\ProductWishlistController@index',
        'namespace' => NULL,
        'prefix' => '',
        'where' => 
        array (
        ),
        'as' => 'wishlist.index',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'wishlist.guest-products' => 
    array (
      'methods' => 
      array (
        0 => 'POST',
      ),
      'uri' => 'wishlist/guest-products',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'not.admin',
          2 => 'throttle:60,1',
        ),
        'uses' => 'App\\Http\\Controllers\\Storefront\\ProductWishlistController@guestProducts',
        'controller' => 'App\\Http\\Controllers\\Storefront\\ProductWishlistController@guestProducts',
        'namespace' => NULL,
        'prefix' => '',
        'where' => 
        array (
        ),
        'as' => 'wishlist.guest-products',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'wishlist.status' => 
    array (
      'methods' => 
      array (
        0 => 'GET',
        1 => 'HEAD',
      ),
      'uri' => 'wishlist/status',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'not.admin',
          2 => 'auth:web',
          3 => 'customer',
          4 => 'throttle:60,1',
        ),
        'uses' => 'App\\Http\\Controllers\\Storefront\\ProductWishlistController@status',
        'controller' => 'App\\Http\\Controllers\\Storefront\\ProductWishlistController@status',
        'namespace' => NULL,
        'prefix' => '',
        'where' => 
        array (
        ),
        'as' => 'wishlist.status',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'wishlist.preview' => 
    array (
      'methods' => 
      array (
        0 => 'GET',
        1 => 'HEAD',
      ),
      'uri' => 'wishlist/preview',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'not.admin',
          2 => 'auth:web',
          3 => 'customer',
          4 => 'throttle:120,1',
        ),
        'uses' => 'App\\Http\\Controllers\\Storefront\\ProductWishlistController@preview',
        'controller' => 'App\\Http\\Controllers\\Storefront\\ProductWishlistController@preview',
        'namespace' => NULL,
        'prefix' => '',
        'where' => 
        array (
        ),
        'as' => 'wishlist.preview',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'wishlist.products.update' => 
    array (
      'methods' => 
      array (
        0 => 'PUT',
      ),
      'uri' => 'wishlist/products/{product}',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'not.admin',
          2 => 'auth:web',
          3 => 'customer',
          4 => 'throttle:60,1',
        ),
        'uses' => 'App\\Http\\Controllers\\Storefront\\ProductWishlistController@update',
        'controller' => 'App\\Http\\Controllers\\Storefront\\ProductWishlistController@update',
        'namespace' => NULL,
        'prefix' => '',
        'where' => 
        array (
        ),
        'as' => 'wishlist.products.update',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'generated::mQEEzSBaNqo3s8MN' => 
    array (
      'methods' => 
      array (
        0 => 'GET',
        1 => 'HEAD',
        2 => 'POST',
        3 => 'PUT',
        4 => 'PATCH',
        5 => 'DELETE',
        6 => 'OPTIONS',
      ),
      'uri' => 'quote-request',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
        ),
        'uses' => '\\Illuminate\\Routing\\RedirectController@__invoke',
        'controller' => '\\Illuminate\\Routing\\RedirectController',
        'namespace' => NULL,
        'prefix' => '',
        'where' => 
        array (
        ),
        'as' => 'generated::mQEEzSBaNqo3s8MN',
      ),
      'fallback' => false,
      'defaults' => 
      array (
        'destination' => '/bulk-quote',
        'status' => 301,
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'cart.index' => 
    array (
      'methods' => 
      array (
        0 => 'GET',
        1 => 'HEAD',
      ),
      'uri' => 'cart',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
        ),
        'uses' => 'App\\Http\\Controllers\\Storefront\\CartController@index',
        'controller' => 'App\\Http\\Controllers\\Storefront\\CartController@index',
        'namespace' => NULL,
        'prefix' => '',
        'where' => 
        array (
        ),
        'as' => 'cart.index',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'cart.items.artwork.show' => 
    array (
      'methods' => 
      array (
        0 => 'GET',
        1 => 'HEAD',
      ),
      'uri' => 'cart/items/{cartItem}/artwork/{artworkIndex}',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
        ),
        'uses' => 'App\\Http\\Controllers\\Storefront\\CartController@showArtwork',
        'controller' => 'App\\Http\\Controllers\\Storefront\\CartController@showArtwork',
        'namespace' => NULL,
        'prefix' => '',
        'where' => 
        array (
        ),
        'as' => 'cart.items.artwork.show',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
        'artworkIndex' => '[0-9]+',
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'cart.items.store' => 
    array (
      'methods' => 
      array (
        0 => 'POST',
      ),
      'uri' => 'cart/items',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
        ),
        'uses' => 'App\\Http\\Controllers\\Storefront\\CartController@store',
        'controller' => 'App\\Http\\Controllers\\Storefront\\CartController@store',
        'namespace' => NULL,
        'prefix' => '',
        'where' => 
        array (
        ),
        'as' => 'cart.items.store',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'cart.items.options.update' => 
    array (
      'methods' => 
      array (
        0 => 'PATCH',
      ),
      'uri' => 'cart/items/{cartItem}/options',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
        ),
        'uses' => 'App\\Http\\Controllers\\Storefront\\CartController@updateOptions',
        'controller' => 'App\\Http\\Controllers\\Storefront\\CartController@updateOptions',
        'namespace' => NULL,
        'prefix' => '',
        'where' => 
        array (
        ),
        'as' => 'cart.items.options.update',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'cart.items.update' => 
    array (
      'methods' => 
      array (
        0 => 'PATCH',
      ),
      'uri' => 'cart/items/{cartItem}',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
        ),
        'uses' => 'App\\Http\\Controllers\\Storefront\\CartController@update',
        'controller' => 'App\\Http\\Controllers\\Storefront\\CartController@update',
        'namespace' => NULL,
        'prefix' => '',
        'where' => 
        array (
        ),
        'as' => 'cart.items.update',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'cart.items.destroy' => 
    array (
      'methods' => 
      array (
        0 => 'DELETE',
      ),
      'uri' => 'cart/items/{cartItem}',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
        ),
        'uses' => 'App\\Http\\Controllers\\Storefront\\CartController@destroy',
        'controller' => 'App\\Http\\Controllers\\Storefront\\CartController@destroy',
        'namespace' => NULL,
        'prefix' => '',
        'where' => 
        array (
        ),
        'as' => 'cart.items.destroy',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'cart.coupon.apply' => 
    array (
      'methods' => 
      array (
        0 => 'POST',
      ),
      'uri' => 'cart/coupon',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
        ),
        'uses' => 'App\\Http\\Controllers\\Storefront\\CartController@applyCoupon',
        'controller' => 'App\\Http\\Controllers\\Storefront\\CartController@applyCoupon',
        'namespace' => NULL,
        'prefix' => '',
        'where' => 
        array (
        ),
        'as' => 'cart.coupon.apply',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'cart.coupon.destroy' => 
    array (
      'methods' => 
      array (
        0 => 'DELETE',
      ),
      'uri' => 'cart/coupon',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
        ),
        'uses' => 'App\\Http\\Controllers\\Storefront\\CartController@removeCoupon',
        'controller' => 'App\\Http\\Controllers\\Storefront\\CartController@removeCoupon',
        'namespace' => NULL,
        'prefix' => '',
        'where' => 
        array (
        ),
        'as' => 'cart.coupon.destroy',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'cart.rewards.apply' => 
    array (
      'methods' => 
      array (
        0 => 'POST',
      ),
      'uri' => 'cart/rewards',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'not.admin',
          2 => 'auth:web',
          3 => 'customer',
          4 => 'verified',
        ),
        'uses' => 'App\\Http\\Controllers\\Storefront\\CartController@applyRewards',
        'controller' => 'App\\Http\\Controllers\\Storefront\\CartController@applyRewards',
        'namespace' => NULL,
        'prefix' => '',
        'where' => 
        array (
        ),
        'as' => 'cart.rewards.apply',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'cart.rewards.destroy' => 
    array (
      'methods' => 
      array (
        0 => 'DELETE',
      ),
      'uri' => 'cart/rewards',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'not.admin',
          2 => 'auth:web',
          3 => 'customer',
          4 => 'verified',
        ),
        'uses' => 'App\\Http\\Controllers\\Storefront\\CartController@removeRewards',
        'controller' => 'App\\Http\\Controllers\\Storefront\\CartController@removeRewards',
        'namespace' => NULL,
        'prefix' => '',
        'where' => 
        array (
        ),
        'as' => 'cart.rewards.destroy',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'order.confirmation' => 
    array (
      'methods' => 
      array (
        0 => 'GET',
        1 => 'HEAD',
      ),
      'uri' => 'order-confirmation',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
        ),
        'uses' => 'App\\Http\\Controllers\\Storefront\\OrderController@confirmation',
        'controller' => 'App\\Http\\Controllers\\Storefront\\OrderController@confirmation',
        'namespace' => NULL,
        'prefix' => '',
        'where' => 
        array (
        ),
        'as' => 'order.confirmation',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'payment.success' => 
    array (
      'methods' => 
      array (
        0 => 'GET',
        1 => 'HEAD',
      ),
      'uri' => 'payment/success',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
        ),
        'uses' => 'App\\Http\\Controllers\\Storefront\\OrderController@paymentSuccess',
        'controller' => 'App\\Http\\Controllers\\Storefront\\OrderController@paymentSuccess',
        'namespace' => NULL,
        'prefix' => '',
        'where' => 
        array (
        ),
        'as' => 'payment.success',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'payment.failed' => 
    array (
      'methods' => 
      array (
        0 => 'GET',
        1 => 'HEAD',
      ),
      'uri' => 'payment/failed',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
        ),
        'uses' => 'App\\Http\\Controllers\\Storefront\\OrderController@paymentFailed',
        'controller' => 'App\\Http\\Controllers\\Storefront\\OrderController@paymentFailed',
        'namespace' => NULL,
        'prefix' => '',
        'where' => 
        array (
        ),
        'as' => 'payment.failed',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'orders.details.legacy' => 
    array (
      'methods' => 
      array (
        0 => 'GET',
        1 => 'HEAD',
      ),
      'uri' => 'order-details',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
        ),
        'uses' => 'App\\Http\\Controllers\\Storefront\\OrderController@details',
        'controller' => 'App\\Http\\Controllers\\Storefront\\OrderController@details',
        'namespace' => NULL,
        'prefix' => '',
        'where' => 
        array (
        ),
        'as' => 'orders.details.legacy',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'orders.details' => 
    array (
      'methods' => 
      array (
        0 => 'GET',
        1 => 'HEAD',
      ),
      'uri' => 'orders/{orderNumber}',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
        ),
        'uses' => 'App\\Http\\Controllers\\Storefront\\OrderController@details',
        'controller' => 'App\\Http\\Controllers\\Storefront\\OrderController@details',
        'namespace' => NULL,
        'prefix' => '',
        'where' => 
        array (
        ),
        'as' => 'orders.details',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
        'orderNumber' => '[A-Za-z0-9\\-]+',
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'orders.track' => 
    array (
      'methods' => 
      array (
        0 => 'GET',
        1 => 'HEAD',
      ),
      'uri' => 'track-order',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
        ),
        'uses' => 'App\\Http\\Controllers\\Storefront\\OrderController@tracking',
        'controller' => 'App\\Http\\Controllers\\Storefront\\OrderController@tracking',
        'namespace' => NULL,
        'prefix' => '',
        'where' => 
        array (
        ),
        'as' => 'orders.track',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'orders.track.lookup' => 
    array (
      'methods' => 
      array (
        0 => 'POST',
      ),
      'uri' => 'track-order',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'throttle:8,1',
        ),
        'uses' => 'App\\Http\\Controllers\\Storefront\\OrderController@lookup',
        'controller' => 'App\\Http\\Controllers\\Storefront\\OrderController@lookup',
        'namespace' => NULL,
        'prefix' => '',
        'where' => 
        array (
        ),
        'as' => 'orders.track.lookup',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'orders.invoice.legacy' => 
    array (
      'methods' => 
      array (
        0 => 'GET',
        1 => 'HEAD',
      ),
      'uri' => 'invoice-download',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
        ),
        'uses' => 'App\\Http\\Controllers\\Storefront\\OrderController@invoice',
        'controller' => 'App\\Http\\Controllers\\Storefront\\OrderController@invoice',
        'namespace' => NULL,
        'prefix' => '',
        'where' => 
        array (
        ),
        'as' => 'orders.invoice.legacy',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'orders.invoice' => 
    array (
      'methods' => 
      array (
        0 => 'GET',
        1 => 'HEAD',
      ),
      'uri' => 'invoice/{orderNumber}',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
        ),
        'uses' => 'App\\Http\\Controllers\\Storefront\\OrderController@invoice',
        'controller' => 'App\\Http\\Controllers\\Storefront\\OrderController@invoice',
        'namespace' => NULL,
        'prefix' => '',
        'where' => 
        array (
        ),
        'as' => 'orders.invoice',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
        'orderNumber' => '[A-Za-z0-9\\-]+',
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'checkout.referral' => 
    array (
      'methods' => 
      array (
        0 => 'GET',
        1 => 'HEAD',
      ),
      'uri' => 'checkout/referral',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'not.admin',
          2 => 'auth:web',
          3 => 'customer',
          4 => 'verified',
        ),
        'uses' => 'App\\Http\\Controllers\\Storefront\\Checkout\\CheckoutController@referral',
        'controller' => 'App\\Http\\Controllers\\Storefront\\Checkout\\CheckoutController@referral',
        'as' => 'checkout.referral',
        'namespace' => NULL,
        'prefix' => '/checkout',
        'where' => 
        array (
        ),
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'checkout.referral.store' => 
    array (
      'methods' => 
      array (
        0 => 'POST',
      ),
      'uri' => 'checkout/referral',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'not.admin',
          2 => 'auth:web',
          3 => 'customer',
          4 => 'verified',
          5 => 'throttle:checkout-step',
        ),
        'uses' => 'App\\Http\\Controllers\\Storefront\\Checkout\\CheckoutController@storeReferral',
        'controller' => 'App\\Http\\Controllers\\Storefront\\Checkout\\CheckoutController@storeReferral',
        'as' => 'checkout.referral.store',
        'namespace' => NULL,
        'prefix' => '/checkout',
        'where' => 
        array (
        ),
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'checkout.index' => 
    array (
      'methods' => 
      array (
        0 => 'GET',
        1 => 'HEAD',
      ),
      'uri' => 'checkout',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'not.admin',
          2 => 'auth:web',
          3 => 'customer',
          4 => 'verified',
        ),
        'uses' => 'App\\Http\\Controllers\\Storefront\\Checkout\\CheckoutController@information',
        'controller' => 'App\\Http\\Controllers\\Storefront\\Checkout\\CheckoutController@information',
        'as' => 'checkout.index',
        'namespace' => NULL,
        'prefix' => '/checkout',
        'where' => 
        array (
        ),
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'checkout.information' => 
    array (
      'methods' => 
      array (
        0 => 'GET',
        1 => 'HEAD',
      ),
      'uri' => 'checkout/information',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'not.admin',
          2 => 'auth:web',
          3 => 'customer',
          4 => 'verified',
        ),
        'uses' => 'App\\Http\\Controllers\\Storefront\\Checkout\\CheckoutController@information',
        'controller' => 'App\\Http\\Controllers\\Storefront\\Checkout\\CheckoutController@information',
        'as' => 'checkout.information',
        'namespace' => NULL,
        'prefix' => '/checkout',
        'where' => 
        array (
        ),
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'checkout.information.store' => 
    array (
      'methods' => 
      array (
        0 => 'POST',
      ),
      'uri' => 'checkout/information',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'not.admin',
          2 => 'auth:web',
          3 => 'customer',
          4 => 'verified',
          5 => 'throttle:checkout-step',
        ),
        'uses' => 'App\\Http\\Controllers\\Storefront\\Checkout\\CheckoutController@storeInformation',
        'controller' => 'App\\Http\\Controllers\\Storefront\\Checkout\\CheckoutController@storeInformation',
        'as' => 'checkout.information.store',
        'namespace' => NULL,
        'prefix' => '/checkout',
        'where' => 
        array (
        ),
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'checkout.shipping-address' => 
    array (
      'methods' => 
      array (
        0 => 'GET',
        1 => 'HEAD',
      ),
      'uri' => 'checkout/shipping-address',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'not.admin',
          2 => 'auth:web',
          3 => 'customer',
          4 => 'verified',
        ),
        'uses' => 'App\\Http\\Controllers\\Storefront\\Checkout\\CheckoutController@shippingAddress',
        'controller' => 'App\\Http\\Controllers\\Storefront\\Checkout\\CheckoutController@shippingAddress',
        'as' => 'checkout.shipping-address',
        'namespace' => NULL,
        'prefix' => '/checkout',
        'where' => 
        array (
        ),
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'checkout.shipping-address.store' => 
    array (
      'methods' => 
      array (
        0 => 'POST',
      ),
      'uri' => 'checkout/shipping-address',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'not.admin',
          2 => 'auth:web',
          3 => 'customer',
          4 => 'verified',
          5 => 'throttle:checkout-step',
        ),
        'uses' => 'App\\Http\\Controllers\\Storefront\\Checkout\\CheckoutController@storeShippingAddress',
        'controller' => 'App\\Http\\Controllers\\Storefront\\Checkout\\CheckoutController@storeShippingAddress',
        'as' => 'checkout.shipping-address.store',
        'namespace' => NULL,
        'prefix' => '/checkout',
        'where' => 
        array (
        ),
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'checkout.billing-address' => 
    array (
      'methods' => 
      array (
        0 => 'GET',
        1 => 'HEAD',
      ),
      'uri' => 'checkout/billing-address',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'not.admin',
          2 => 'auth:web',
          3 => 'customer',
          4 => 'verified',
        ),
        'uses' => 'App\\Http\\Controllers\\Storefront\\Checkout\\CheckoutController@billingAddress',
        'controller' => 'App\\Http\\Controllers\\Storefront\\Checkout\\CheckoutController@billingAddress',
        'as' => 'checkout.billing-address',
        'namespace' => NULL,
        'prefix' => '/checkout',
        'where' => 
        array (
        ),
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'checkout.billing-address.store' => 
    array (
      'methods' => 
      array (
        0 => 'POST',
      ),
      'uri' => 'checkout/billing-address',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'not.admin',
          2 => 'auth:web',
          3 => 'customer',
          4 => 'verified',
          5 => 'throttle:checkout-step',
        ),
        'uses' => 'App\\Http\\Controllers\\Storefront\\Checkout\\CheckoutController@storeBillingAddress',
        'controller' => 'App\\Http\\Controllers\\Storefront\\Checkout\\CheckoutController@storeBillingAddress',
        'as' => 'checkout.billing-address.store',
        'namespace' => NULL,
        'prefix' => '/checkout',
        'where' => 
        array (
        ),
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'checkout.shipping-method' => 
    array (
      'methods' => 
      array (
        0 => 'GET',
        1 => 'HEAD',
      ),
      'uri' => 'checkout/shipping-method',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'not.admin',
          2 => 'auth:web',
          3 => 'customer',
          4 => 'verified',
        ),
        'uses' => 'App\\Http\\Controllers\\Storefront\\Checkout\\CheckoutController@shippingMethod',
        'controller' => 'App\\Http\\Controllers\\Storefront\\Checkout\\CheckoutController@shippingMethod',
        'as' => 'checkout.shipping-method',
        'namespace' => NULL,
        'prefix' => '/checkout',
        'where' => 
        array (
        ),
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'checkout.shipping-method.store' => 
    array (
      'methods' => 
      array (
        0 => 'POST',
      ),
      'uri' => 'checkout/shipping-method',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'not.admin',
          2 => 'auth:web',
          3 => 'customer',
          4 => 'verified',
          5 => 'throttle:checkout-step',
        ),
        'uses' => 'App\\Http\\Controllers\\Storefront\\Checkout\\CheckoutController@storeShippingMethod',
        'controller' => 'App\\Http\\Controllers\\Storefront\\Checkout\\CheckoutController@storeShippingMethod',
        'as' => 'checkout.shipping-method.store',
        'namespace' => NULL,
        'prefix' => '/checkout',
        'where' => 
        array (
        ),
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'checkout.payment-method' => 
    array (
      'methods' => 
      array (
        0 => 'GET',
        1 => 'HEAD',
      ),
      'uri' => 'checkout/payment-method',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'not.admin',
          2 => 'auth:web',
          3 => 'customer',
          4 => 'verified',
        ),
        'uses' => 'App\\Http\\Controllers\\Storefront\\Checkout\\CheckoutController@paymentMethod',
        'controller' => 'App\\Http\\Controllers\\Storefront\\Checkout\\CheckoutController@paymentMethod',
        'as' => 'checkout.payment-method',
        'namespace' => NULL,
        'prefix' => '/checkout',
        'where' => 
        array (
        ),
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'checkout.payment-method.store' => 
    array (
      'methods' => 
      array (
        0 => 'POST',
      ),
      'uri' => 'checkout/payment-method',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'not.admin',
          2 => 'auth:web',
          3 => 'customer',
          4 => 'verified',
          5 => 'throttle:checkout-step',
        ),
        'uses' => 'App\\Http\\Controllers\\Storefront\\Checkout\\CheckoutController@storePaymentMethod',
        'controller' => 'App\\Http\\Controllers\\Storefront\\Checkout\\CheckoutController@storePaymentMethod',
        'as' => 'checkout.payment-method.store',
        'namespace' => NULL,
        'prefix' => '/checkout',
        'where' => 
        array (
        ),
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'checkout.review' => 
    array (
      'methods' => 
      array (
        0 => 'GET',
        1 => 'HEAD',
      ),
      'uri' => 'checkout/review',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'not.admin',
          2 => 'auth:web',
          3 => 'customer',
          4 => 'verified',
        ),
        'uses' => 'App\\Http\\Controllers\\Storefront\\Checkout\\CheckoutController@review',
        'controller' => 'App\\Http\\Controllers\\Storefront\\Checkout\\CheckoutController@review',
        'as' => 'checkout.review',
        'namespace' => NULL,
        'prefix' => '/checkout',
        'where' => 
        array (
        ),
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'checkout.review.store' => 
    array (
      'methods' => 
      array (
        0 => 'POST',
      ),
      'uri' => 'checkout/review',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'not.admin',
          2 => 'auth:web',
          3 => 'customer',
          4 => 'verified',
          5 => 'throttle:checkout-step',
        ),
        'uses' => 'App\\Http\\Controllers\\Storefront\\Checkout\\CheckoutController@storeReview',
        'controller' => 'App\\Http\\Controllers\\Storefront\\Checkout\\CheckoutController@storeReview',
        'as' => 'checkout.review.store',
        'namespace' => NULL,
        'prefix' => '/checkout',
        'where' => 
        array (
        ),
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'checkout.place-order' => 
    array (
      'methods' => 
      array (
        0 => 'GET',
        1 => 'HEAD',
      ),
      'uri' => 'checkout/place-order',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'not.admin',
          2 => 'auth:web',
          3 => 'customer',
          4 => 'verified',
        ),
        'uses' => 'App\\Http\\Controllers\\Storefront\\Checkout\\CheckoutController@placeOrder',
        'controller' => 'App\\Http\\Controllers\\Storefront\\Checkout\\CheckoutController@placeOrder',
        'as' => 'checkout.place-order',
        'namespace' => NULL,
        'prefix' => '/checkout',
        'where' => 
        array (
        ),
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'checkout.place-order.submit' => 
    array (
      'methods' => 
      array (
        0 => 'POST',
      ),
      'uri' => 'checkout/place-order',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'not.admin',
          2 => 'auth:web',
          3 => 'customer',
          4 => 'verified',
          5 => 'throttle:checkout-place-order',
        ),
        'uses' => 'App\\Http\\Controllers\\Storefront\\Checkout\\CheckoutController@submitOrder',
        'controller' => 'App\\Http\\Controllers\\Storefront\\Checkout\\CheckoutController@submitOrder',
        'as' => 'checkout.place-order.submit',
        'namespace' => NULL,
        'prefix' => '/checkout',
        'where' => 
        array (
        ),
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'checkout.success' => 
    array (
      'methods' => 
      array (
        0 => 'GET',
        1 => 'HEAD',
      ),
      'uri' => 'checkout/success',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'not.admin',
          2 => 'auth:web',
          3 => 'customer',
          4 => 'verified',
        ),
        'uses' => 'App\\Http\\Controllers\\Storefront\\Checkout\\CheckoutController@success',
        'controller' => 'App\\Http\\Controllers\\Storefront\\Checkout\\CheckoutController@success',
        'as' => 'checkout.success',
        'namespace' => NULL,
        'prefix' => '/checkout',
        'where' => 
        array (
        ),
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'storage.local' => 
    array (
      'methods' => 
      array (
        0 => 'GET',
        1 => 'HEAD',
      ),
      'uri' => 'storage/{path}',
      'action' => 
      array (
        'uses' => 'O:55:"Laravel\\SerializableClosure\\UnsignedSerializableClosure":1:{s:12:"serializable";O:46:"Laravel\\SerializableClosure\\Serializers\\Native":5:{s:3:"use";a:3:{s:4:"disk";s:5:"local";s:6:"config";a:5:{s:6:"driver";s:5:"local";s:4:"root";s:84:"/Applications/XAMPP/xamppfiles/htdocs/laravel/NextPlaySportswear/storage/app/private";s:5:"serve";b:1;s:5:"throw";b:0;s:6:"report";b:0;}s:12:"isProduction";b:0;}s:8:"function";s:323:"function (\\Illuminate\\Http\\Request $request, string $path) use ($disk, $config, $isProduction) {
                    return (new \\Illuminate\\Filesystem\\ServeFile(
                        $disk,
                        $config,
                        $isProduction
                    ))($request, $path);
                }";s:5:"scope";s:47:"Illuminate\\Filesystem\\FilesystemServiceProvider";s:4:"this";N;s:4:"self";s:32:"0000000000000dcd0000000000000000";}}',
        'as' => 'storage.local',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
        'path' => '.*',
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'storage.local.upload' => 
    array (
      'methods' => 
      array (
        0 => 'PUT',
      ),
      'uri' => 'storage/{path}',
      'action' => 
      array (
        'uses' => 'O:55:"Laravel\\SerializableClosure\\UnsignedSerializableClosure":1:{s:12:"serializable";O:46:"Laravel\\SerializableClosure\\Serializers\\Native":5:{s:3:"use";a:3:{s:4:"disk";s:5:"local";s:6:"config";a:5:{s:6:"driver";s:5:"local";s:4:"root";s:84:"/Applications/XAMPP/xamppfiles/htdocs/laravel/NextPlaySportswear/storage/app/private";s:5:"serve";b:1;s:5:"throw";b:0;s:6:"report";b:0;}s:12:"isProduction";b:0;}s:8:"function";s:325:"function (\\Illuminate\\Http\\Request $request, string $path) use ($disk, $config, $isProduction) {
                    return (new \\Illuminate\\Filesystem\\ReceiveFile(
                        $disk,
                        $config,
                        $isProduction
                    ))($request, $path);
                }";s:5:"scope";s:47:"Illuminate\\Filesystem\\FilesystemServiceProvider";s:4:"this";N;s:4:"self";s:32:"0000000000000c260000000000000000";}}',
        'as' => 'storage.local.upload',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
        'path' => '.*',
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
  ),
)
);
