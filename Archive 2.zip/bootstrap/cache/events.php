<?php return array (
  'Illuminate\\Foundation\\Support\\Providers\\EventServiceProvider' => 
  array (
    'App\\Events\\DeliveryEstimateUpdated' => 
    array (
      0 => 'App\\Listeners\\Order\\SendDeliveryEstimateUpdatedNotification@handle',
    ),
    'Illuminate\\Auth\\Events\\Verified' => 
    array (
      0 => 'App\\Listeners\\Auth\\SendWelcomeEmailAfterVerification@handle',
    ),
  ),
);