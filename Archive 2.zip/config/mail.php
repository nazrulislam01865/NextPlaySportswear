<?php

$parseMailerList = static function (?string $value, array $fallback): array {
    $mailers = array_values(array_filter(array_map(
        static fn (string $mailer): string => trim($mailer),
        explode(',', (string) $value),
    ), static fn (string $mailer): bool => $mailer !== ''));

    return $mailers !== [] ? $mailers : $fallback;
};

return [

    /*
    |--------------------------------------------------------------------------
    | Default Mailer
    |--------------------------------------------------------------------------
    |
    | This option controls the default mailer that is used to send all email
    | messages unless another mailer is explicitly specified when sending
    | the message. All additional mailers can be configured within the
    | "mailers" array. Examples of each type of mailer are provided.
    |
    */

    'default' => env('MAIL_MAILER', 'log'),

    /*
    |--------------------------------------------------------------------------
    | Mailer Configurations
    |--------------------------------------------------------------------------
    |
    | Here you may configure all of the mailers used by your application plus
    | their respective settings. Several examples have been configured for
    | you and you are free to add your own as your application requires.
    |
    | Laravel supports a variety of mail "transport" drivers that can be used
    | when delivering an email. You may specify which one you're using for
    | your mailers below. You may also add additional mailers if needed.
    |
    | Supported: "smtp", "sendmail", "mailgun", "ses", "ses-v2",
    |            "postmark", "resend", "log", "array",
    |            "failover", "roundrobin"
    |
    */

    'mailers' => [

        // Select MAIL_MAILER=e2a to send through the e2a HTTPS API.
        'e2a' => [
            'transport' => 'e2a',
            'api_key' => env('E2A_API_KEY'),
            'sender' => env('E2A_FROM_EMAIL'),
            'api_url' => env('E2A_API_URL', 'https://api.e2a.dev/v1'),
            'timeout' => (int) env('E2A_TIMEOUT', 20),
        ],

        'smtp' => [
            'transport' => 'smtp',
            'scheme' => env('MAIL_SCHEME'),
            'url' => env('MAIL_URL'),
            'host' => env('MAIL_HOST', '127.0.0.1'),
            'port' => env('MAIL_PORT', 2525),
            'username' => env('MAIL_USERNAME'),
            'password' => env('MAIL_PASSWORD'),
            'timeout' => (int) env('MAIL_TIMEOUT', 10),
            'local_domain' => env('MAIL_EHLO_DOMAIN', parse_url((string) env('APP_URL', 'http://localhost'), PHP_URL_HOST)),
        ],

        'ses' => [
            'transport' => 'ses',
        ],

        'postmark' => [
            'transport' => 'postmark',
            // 'message_stream_id' => env('POSTMARK_MESSAGE_STREAM_ID'),
            // 'client' => [
            //     'timeout' => 5,
            // ],
        ],

        'resend' => [
            'transport' => 'resend',
        ],

        'sendmail' => [
            'transport' => 'sendmail',
            'path' => env('MAIL_SENDMAIL_PATH', '/usr/sbin/sendmail -bs -i'),
        ],

        'log' => [
            'transport' => 'log',
            'channel' => env('MAIL_LOG_CHANNEL'),
        ],

        'array' => [
            'transport' => 'array',
        ],

        'failover' => [
            'transport' => 'failover',

            // Keep delivery providers configurable. Do not silently fall back
            // to the log transport for transactional mail because that could
            // report a successful send without delivering anything.
            'mailers' => $parseMailerList(
                env('MAIL_FAILOVER_MAILERS'),
                ['smtp']
            ),
            'retry_after' => (int) env('MAIL_FAILOVER_RETRY_AFTER', 60),
        ],

        'roundrobin' => [
            'transport' => 'roundrobin',
            'mailers' => $parseMailerList(
                env('MAIL_ROUNDROBIN_MAILERS'),
                ['ses', 'postmark']
            ),
            'retry_after' => (int) env('MAIL_ROUNDROBIN_RETRY_AFTER', 60),
        ],

    ],

    /*
    |--------------------------------------------------------------------------
    | Global "From" Address
    |--------------------------------------------------------------------------
    |
    | You may wish for all emails sent by your application to be sent from
    | the same address. Here you may specify a name and address that is
    | used globally for all emails that are sent by your application.
    |
    */

    'from' => [
        'address' => env('MAIL_FROM_ADDRESS', 'hello@example.com'),
        'name' => env('MAIL_FROM_NAME', env('APP_NAME', 'Laravel')),
    ],

];
