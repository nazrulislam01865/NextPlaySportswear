<?php

return [
    'name' => env('STOREFRONT_NAME', 'NextPlay Sportswear'),

    'tagline' => 'Custom sportswear, team uniforms, jerseys, hoodies, caps, bags, and promotional products.',

    'email' => env('STOREFRONT_EMAIL', 'support@example.com'),

    'whatsapp' => env('STOREFRONT_WHATSAPP', '+1 000 000 0000'),

    'whatsapp_url' => env('STOREFRONT_WHATSAPP_URL'),

    'social' => [
        'instagram' => env('STOREFRONT_INSTAGRAM_URL', 'https://www.instagram.com/nextplaysportswear/'),
        'facebook' => env('STOREFRONT_FACEBOOK_URL', 'https://www.facebook.com/nextplaysportswear'),
        'tiktok' => env('STOREFRONT_TIKTOK_URL', 'https://www.tiktok.com/@nextplaysportswear'),
        'youtube' => env('STOREFRONT_YOUTUBE_URL', 'https://www.youtube.com/@nextplaysportswear'),
    ],

    'url' => env('STOREFRONT_URL', env('APP_URL', 'https://example.com')),

    'logo' => env('STOREFRONT_LOGO', '/images/logo.png'),

    'og_image' => env('STOREFRONT_OG_IMAGE', 'images/og-default.jpg'),

    'area_served' => env('STOREFRONT_AREA_SERVED', 'Worldwide'),

    'available_languages' => array_values(array_filter(array_map(
        'trim',
        explode(',', (string) env('STOREFRONT_AVAILABLE_LANGUAGES', 'English'))
    ))),

    'slider_cache_seconds' => (int) env('STOREFRONT_SLIDER_CACHE_SECONDS', 600),

    'artwork' => [
        // Set to 0 for unlimited included revisions.
        'max_revisions' => (int) env('STOREFRONT_ARTWORK_MAX_REVISIONS', 2),
    ],

    'product_cards' => [
        // Used only when a product has no product-level rating/review value yet.
        // Set STOREFRONT_PRODUCT_CARD_SHOW_DEFAULT_RATING=false to hide this fallback.
        'show_default_rating' => filter_var(env('STOREFRONT_PRODUCT_CARD_SHOW_DEFAULT_RATING', true), FILTER_VALIDATE_BOOLEAN),
        'default_rating' => (float) env('STOREFRONT_PRODUCT_CARD_DEFAULT_RATING', 4.8),
        'default_reviews_count' => (int) env('STOREFRONT_PRODUCT_CARD_DEFAULT_REVIEWS_COUNT', 23),
        'live_viewer_window_minutes' => (int) env('STOREFRONT_PRODUCT_CARD_LIVE_VIEWER_WINDOW_MINUTES', 5),
    ],
];
