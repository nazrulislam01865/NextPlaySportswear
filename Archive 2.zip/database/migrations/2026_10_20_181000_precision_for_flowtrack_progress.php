<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

return new class extends Migration {
    public function up(): void
    {
        // Consecutive task changes can occur within a single second.
        Schema::table('orders', function (Blueprint $table): void {
            $table->timestamp('flowtrack_operational_updated_at', 6)->nullable()->change();
        });
    }

    public function down(): void
    {
        Schema::table('orders', function (Blueprint $table): void {
            $table->timestamp('flowtrack_operational_updated_at')->nullable()->change();
        });
    }
};
