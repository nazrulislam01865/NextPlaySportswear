<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Attributes\Fillable;
use Illuminate\Database\Eloquent\Casts\Attribute;
use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;
use Illuminate\Database\Eloquent\Relations\BelongsTo;
use Illuminate\Database\Eloquent\Relations\HasMany;
use Illuminate\Database\Eloquent\SoftDeletes;

#[Fillable([
    'user_id', 'order_number', 'status', 'payment_status', 'fulfillment_status', 'currency',
    'coupon_id', 'coupon_code', 'coupon_snapshot', 'customer_name', 'customer_email', 'customer_phone', 'subtotal', 'customization_total',
    'discount_total', 'shipping_total', 'rural_surcharge_total', 'product_shipping_total', 'tax_total', 'grand_total', 'total_quantity',
    'information', 'shipping_address', 'billing_address', 'shipping_method', 'payment_method',
    'customer_note', 'admin_note', 'idempotency_key', 'placed_at', 'paid_at', 'cancelled_at',
    'completed_at', 'delivered_at',
    'estimated_delivery_start_at', 'estimated_delivery_end_at', 'holiday_adjustment_applied',
    'holiday_adjustment_reason', 'holiday_adjustment_meta',
    'flowtrack_sync_status', 'flowtrack_sync_attempts', 'flowtrack_order_id', 'flowtrack_order_number', 'flowtrack_job_id',
    'flowtrack_last_attempt_at', 'flowtrack_synced_at', 'flowtrack_sync_error', 'flowtrack_response',
    'flowtrack_operational_status', 'flowtrack_operational_stage', 'flowtrack_operational_progress', 'flowtrack_operational_updated_at',
])]
class Order extends Model
{
    use HasFactory, SoftDeletes;

    public function getRouteKeyName(): string
    {
        return 'order_number';
    }

    public function user(): BelongsTo
    {
        return $this->belongsTo(User::class);
    }

    public function coupon(): BelongsTo
    {
        return $this->belongsTo(Coupon::class);
    }

    public function artworkProofs(): HasMany
    {
        return $this->hasMany(ArtworkProof::class);
    }

    public function items(): HasMany
    {
        return $this->hasMany(OrderItem::class);
    }

    public function payments(): HasMany
    {
        return $this->hasMany(OrderPayment::class);
    }

    public function histories(): HasMany
    {
        return $this->hasMany(OrderStatusHistory::class)->orderByDesc('occurred_at');
    }

    public function shipments(): HasMany
    {
        return $this->hasMany(OrderShipment::class)->latest();
    }

    public function changeRequests(): HasMany
    {
        return $this->hasMany(OrderChangeRequest::class)->latest();
    }

    public function returnRequests(): HasMany
    {
        return $this->hasMany(OrderReturnRequest::class)->latest('requested_at');
    }

    public function refunds(): HasMany
    {
        return $this->hasMany(OrderRefund::class)->latest();
    }

    public function creditNotes(): HasMany
    {
        return $this->hasMany(OrderCreditNote::class)->latest('issued_at');
    }

    public function downloads(): HasMany
    {
        return $this->hasMany(OrderDownload::class)->latest();
    }

    public function statusLabel(): string
    {
        return config('commerce.order_statuses.'.$this->status, str($this->status)->headline()->toString());
    }

    public function paymentStatusLabel(): string
    {
        return config('commerce.payment_statuses.'.$this->payment_status, str($this->payment_status)->headline()->toString());
    }

    public function fulfillmentStatusLabel(): string
    {
        return config('commerce.fulfillment_statuses.'.$this->fulfillment_status, str($this->fulfillment_status)->headline()->toString());
    }

    public function canPay(): bool
    {
        return in_array($this->status, config('commerce.payable_statuses', []), true)
            && in_array($this->payment_status, ['pending', 'failed', 'processing'], true)
            && $this->grand_total > 0;
    }

    public function canApproveAfterPayment(): bool
    {
        return $this->payment_status === 'paid'
            && in_array($this->status, [
                'pending_payment',
                'payment_review',
                'payment_failed',
                'quote_invoice_requested',
                'on_hold',
            ], true);
    }

    public function canRequestCancellation(): bool
    {
        return in_array($this->status, config('commerce.cancellable_statuses', []), true)
            && ! $this->changeRequests()->where('type', 'cancel')->whereIn('status', ['pending', 'approved'])->exists();
    }

    public function canRequestChange(): bool
    {
        return in_array($this->status, config('commerce.changeable_statuses', []), true)
            && ! $this->changeRequests()->where('type', 'change')->whereIn('status', ['pending', 'approved'])->exists();
    }

    public function canRequestReturn(): bool
    {
        if (! in_array($this->status, ['delivered', 'completed'], true) || ! $this->delivered_at) {
            return false;
        }

        if (! $this->delivered_at->copy()->addDays((int) config('commerce.return_window_days', 30))->isFuture()) {
            return false;
        }

        $items = $this->relationLoaded('items')
            ? $this->items
            : $this->items()->with('returnItems.returnRequest')->get();

        return $items->contains(fn (OrderItem $item): bool => $item->returnableQuantity() > 0);
    }

    public function canRequestExchange(): bool
    {
        if (! $this->canRequestReturn()) {
            return false;
        }

        return $this->delivered_at->copy()->addDays((int) config('commerce.exchange_window_days', 30))->isFuture();
    }


    public function hasSeparatedFulfillmentTotals(): bool
    {
        return (bool) data_get($this->shipping_method, 'totals_separated', false);
    }

    public function displayCustomizationTotal(): float
    {
        $customization = (float) $this->customization_total;

        if ($this->hasSeparatedFulfillmentTotals()) {
            return round(max(0, $customization), 2);
        }

        return round(max(0, $customization - (float) ($this->product_shipping_total ?? 0)), 2);
    }

    public function displayShippingTotal(): float
    {
        $shipping = (float) $this->shipping_total;

        if ($this->hasSeparatedFulfillmentTotals()) {
            return round(max(0, $shipping), 2);
        }

        return round(max(0, $shipping + (float) ($this->product_shipping_total ?? 0)), 2);
    }

    public function outstandingAmount(): float
    {
        $paid = (float) $this->payments()->where('status', 'paid')->sum('amount');

        return max(0, round((float) $this->grand_total - $paid, 2));
    }

    public function formattedEstimatedDelivery(): ?string
    {
        if ($this->estimated_delivery_start_at && $this->estimated_delivery_end_at) {
            if ($this->estimated_delivery_start_at->equalTo($this->estimated_delivery_end_at)) {
                return $this->estimated_delivery_start_at->format('d M Y');
            }

            return $this->estimated_delivery_start_at->format('d M').' – '.$this->estimated_delivery_end_at->format('d M Y');
        }

        return data_get($this->shipping_method, 'eta');
    }

    protected function casts(): array
    {
        return [
            'information' => 'array',
            'shipping_address' => 'array',
            'billing_address' => 'array',
            'shipping_method' => 'array',
            'payment_method' => 'array',
            'coupon_snapshot' => 'array',
            'subtotal' => 'decimal:2',
            'customization_total' => 'decimal:2',
            'discount_total' => 'decimal:2',
            'shipping_total' => 'decimal:2',
            'rural_surcharge_total' => 'decimal:2',
            'product_shipping_total' => 'decimal:2',
            'tax_total' => 'decimal:2',
            'grand_total' => 'decimal:2',
            'placed_at' => 'datetime',
            'paid_at' => 'datetime',
            'cancelled_at' => 'datetime',
            'completed_at' => 'datetime',
            'delivered_at' => 'datetime',
            'estimated_delivery_start_at' => 'date',
            'estimated_delivery_end_at' => 'date',
            'holiday_adjustment_applied' => 'boolean',
            'holiday_adjustment_meta' => 'array',
            'flowtrack_sync_attempts' => 'integer',
            'flowtrack_order_id' => 'integer',
            'flowtrack_last_attempt_at' => 'datetime',
            'flowtrack_synced_at' => 'datetime',
            'flowtrack_operational_updated_at' => 'datetime',
            'flowtrack_operational_progress' => 'integer',
            'flowtrack_response' => 'array',
        ];
    }
}
