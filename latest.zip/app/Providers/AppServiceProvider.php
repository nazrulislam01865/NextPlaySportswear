<?php

namespace App\Providers;

use App\Listeners\Auth\SendWelcomeEmailAfterVerification;
use App\Services\Cart\CartService;
use App\Services\Catalog\NavigationService;
use App\Services\Storefront\AddressGeography;
use App\Services\Storefront\FooterPaymentMethodService;
use App\Services\Storefront\HomepageSliderService;
use App\Services\Storefront\HomepageSectionService;
use App\Services\Wishlist\WishlistHeaderService;
use Illuminate\Auth\Events\Login;
use Illuminate\Auth\Events\Verified;
use Illuminate\Cache\RateLimiting\Limit;
use Illuminate\Http\Request;
use Illuminate\Pagination\Paginator;
use Illuminate\Support\Facades\Event;
use Illuminate\Support\Facades\File;
use Illuminate\Support\Facades\RateLimiter;
use Illuminate\Support\Facades\View;
use Illuminate\Support\ServiceProvider;

class AppServiceProvider extends ServiceProvider
{
    public function register(): void
    {
        $this->app->scoped(AddressGeography::class);
        $this->app->singleton(NavigationService::class);
        $this->app->singleton(FooterPaymentMethodService::class);
        $this->app->singleton(HomepageSliderService::class);
        $this->app->singleton(HomepageSectionService::class);
    }

    public function boot(): void
    {
        \App\Models\BulkQuoteRequest::observe(\App\Observers\BulkQuoteFlowTrackObserver::class);
        \App\Models\BulkQuoteMessage::observe(\App\Observers\BulkQuoteMessageFlowTrackObserver::class);
        \App\Models\Product::observe(\App\Observers\FlowTrackCatalogObserver::class);
        \App\Models\Category::observe(\App\Observers\FlowTrackCategoryObserver::class);
        \App\Models\User::observe(\App\Observers\FlowTrackCatalogObserver::class);
        foreach ([
            \App\Models\ProductOptionGroup::class,
            \App\Models\ProductOptionValue::class,
            \App\Models\ProductSizeGroup::class,
            \App\Models\ProductSize::class,
            \App\Models\ProductImage::class,
            \App\Models\ProductPriceTier::class,
            \App\Models\ProductFabricPriceTable::class,
            \App\Models\ProductFabricPriceTier::class,
        ] as $productConfigurationModel) {
            $productConfigurationModel::observe(\App\Observers\FlowTrackProductConfigurationObserver::class);
        }


        Paginator::defaultView('pagination.nextplay');
        Paginator::defaultSimpleView('pagination.nextplay-simple');

        $compiledViewPath = config('view.compiled');

        if (is_string($compiledViewPath) && $compiledViewPath !== '') {
            File::ensureDirectoryExists($compiledViewPath, 0755, true);
        }


        Event::listen(Verified::class, SendWelcomeEmailAfterVerification::class);
        Event::listen(
            \App\Events\DeliveryEstimateUpdated::class,
            \App\Listeners\Order\SendDeliveryEstimateUpdatedNotification::class
        );

        Event::listen(Login::class, function (Login $event): void {
            if ($event->user instanceof \App\Models\User) {
                app(CartService::class)->claimSessionCart($event->user);
            }
        });

        View::composer('components.storefront.header', function ($view): void {
            // Checkout and cart pages already calculated authoritative amounts.
            // Share them with the mini-cart instead of reading stale snapshots
            // or repricing the same cart a second time during page rendering.
            $checkoutSummary = request()->routeIs('checkout.*') ? View::shared('npCheckoutCartSummary') : null;
            $cartPageSummary = request()->routeIs('cart.index') ? View::shared('npCurrentCartSummary') : null;
            $pricedSummary = is_array($checkoutSummary) ? $checkoutSummary : $cartPageSummary;
            if (is_array($pricedSummary) && ! empty($pricedSummary['items'])) {
                $accurateItems = collect($pricedSummary['items'])->map(static function (array $item): array {
                    $quantity = max(1, (int) ($item['quantity'] ?? 1));
                    $shipping = round((float) ($item['product_shipping_total'] ?? 0), 2);
                    $merchandise = round((float) ($item['line_subtotal'] ?? 0) + (float) ($item['customization_total'] ?? 0), 2);

                    return array_merge($item, [
                        'display_unit_price' => round($merchandise / $quantity, 2),
                        'line_total' => round($merchandise + $shipping, 2),
                        'display_shipping' => $shipping,
                    ]);
                });
                $headerCart = [
                    'items' => $accurateItems->take(4)->all(),
                    'total_items' => $accurateItems->count(),
                    'remaining_items' => max(0, $accurateItems->count() - 4),
                    'quantity' => (int) ($pricedSummary['quantity'] ?? 0),
                    'subtotal' => (float) ($pricedSummary['total'] ?? 0),
                    'total' => (float) ($pricedSummary['total'] ?? 0),
                    'is_empty' => $accurateItems->isEmpty(),
                    'checkout_ready' => (bool) ($pricedSummary['checkout_ready'] ?? true),
                ];
            } else {
                $headerCart = app(CartService::class)->headerSummary(4);
            }
            $customer = auth('web')->user();
            $headerWishlist = app(WishlistHeaderService::class)->summary($customer, 4);

            $view->with('cartItemCount', (int) ($headerCart['total_items'] ?? 0));
            $view->with('wishlistItemCount', (int) ($headerWishlist['total_items'] ?? 0));
            $view->with('wishlistAuthenticated', $customer?->isCustomer() ?? false);
            $view->with('headerWishlist', $headerWishlist);
            $view->with('headerCart', $headerCart);
            $view->with('storefrontMenus', app(NavigationService::class)->storefrontMenus());
        });

        View::composer('components.storefront.footer', function ($view): void {
            $view->with('storefrontMenus', app(NavigationService::class)->storefrontMenus());
            $view->with('footerPaymentMethods', app(FooterPaymentMethodService::class)->methods());
        });

        RateLimiter::for('admin-login', function (Request $request): array {
            $ip = (string) ($request->ip() ?: 'unknown');
            $email = strtolower(trim((string) $request->input('email')));
            $emailFingerprint = hash('sha256', substr($email, 0, 190));

            // Keep brute-force protection without blocking a legitimate admin
            // after a few accidental double-clicks or validation retries.
            return [
                Limit::perMinute(30)->by('admin-login-ip:'.$ip),
                Limit::perMinute(15)->by('admin-login-account:'.$ip.':'.$emailFingerprint),
            ];
        });

        RateLimiter::for('storefront-login', function (Request $request): array {
            $ip = (string) ($request->ip() ?: 'unknown');
            $email = strtolower(trim((string) $request->input('email')));
            $emailFingerprint = hash('sha256', substr($email, 0, 190));

            // Keep brute-force protection while avoiding false HTTP 429
            // responses from normal validation retries or accidental double
            // submissions. The account bucket is independent from the IP
            // bucket so users behind the same office/mobile network do not
            // block one another after only a few attempts.
            return [
                Limit::perMinute(60)->by('storefront-login-ip:'.$ip),
                Limit::perMinute(20)->by('storefront-login-account-minute:'.$emailFingerprint),
                Limit::perHour(100)->by('storefront-login-account-hour:'.$emailFingerprint),
            ];
        });

        // Email-first customer registration: isolate the send and verify actions
        // from other forms. The old throttle:3,1 was shared by every person on
        // an IP and counted both initial requests and resends, producing a raw
        // 429 screen during legitimate sign-up or local OTP testing.
        $registrationLimitResponse = static function (Request $request): \Illuminate\Http\RedirectResponse {
            $verifying = $request->routeIs('register.email.verify');
            $field = $verifying ? 'code' : 'email';
            $message = $verifying
                ? 'Too many verification attempts. Please wait a moment before trying again.'
                : 'Too many verification code requests. Please wait a moment before trying again.';

            return redirect()->route('register')
                ->withInput($verifying ? [] : $request->only('email'))
                ->withErrors([$field => $message]);
        };

        // Keep account-creation abuse protection, but validation retries must
        // not be blocked by the old shared 5-per-minute IP bucket. A named
        // limiter uses a browser-session bucket with a generous ceiling and
        // returns an inline form error instead of a raw HTTP 429 page.
        RateLimiter::for('registration-complete', static function (Request $request): array {
            $session = $request->hasSession() ? (string) $request->session()->getId() : '';
            $ip = (string) ($request->ip() ?: 'unknown');
            $browserKey = hash('sha256', $session !== '' ? $session : $ip);
            $respond = static fn (Request $request) => redirect()->route('register')
                ->withErrors(['password' => 'Too many account creation attempts. Please try again in a moment.']);

            return [
                Limit::perMinute(30)->by('registration-complete-session-minute:'.$browserKey)->response($respond),
                Limit::perHour(180)->by('registration-complete-ip-hour:'.$ip)->response($respond),
            ];
        });

        RateLimiter::for('registration-email-send', function (Request $request) use ($registrationLimitResponse): array {
            $ip = (string) ($request->ip() ?: 'unknown');
            $email = strtolower(trim((string) $request->input('email')));
            // The controller independently enforces a 45-second resend delay
            // per browser session. These buckets protect shared IPs and each
            // destination email without locking out ordinary retries.
            $limits = [
                Limit::perMinute(20)->by('registration-email-send-ip-minute:'.$ip)->response($registrationLimitResponse),
                Limit::perHour(120)->by('registration-email-send-ip-hour:'.$ip)->response($registrationLimitResponse),
            ];

            if (filter_var($email, FILTER_VALIDATE_EMAIL)) {
                $emailKey = hash('sha256', substr($email, 0, 190));
                $limits[] = Limit::perHour(12)
                    ->by('registration-email-send-email-hour:'.$emailKey)
                    ->response($registrationLimitResponse);
            }

            return $limits;
        });

        RateLimiter::for('registration-email-verify', function (Request $request) use ($registrationLimitResponse): array {
            $ip = (string) ($request->ip() ?: 'unknown');
            $sessionId = $request->hasSession() ? (string) $request->session()->getId() : '';
            $browserKey = hash('sha256', $sessionId !== '' ? $sessionId : $ip);

            // Five incorrect codes per challenge are still enforced by the
            // controller. This limiter handles automated traffic across
            // repeated challenges without penalizing shared-IP customers.
            return [
                Limit::perMinute(30)->by('registration-email-verify-session-minute:'.$browserKey)->response($registrationLimitResponse),
                Limit::perHour(90)->by('registration-email-verify-session-hour:'.$browserKey)->response($registrationLimitResponse),
                Limit::perHour(240)->by('registration-email-verify-ip-hour:'.$ip)->response($registrationLimitResponse),
            ];
        });

        RateLimiter::for('email-verification-send', function (Request $request): array {
            $ip = (string) ($request->ip() ?: 'unknown');
            $userId = (string) ($request->user('web')?->getAuthIdentifier() ?: 'guest');

            return [
                Limit::perMinute(max(1, (int) config('security.email_verification.resend.ip_per_minute', 6)))
                    ->by('email-verification-ip-minute:'.$ip),
                Limit::perMinute(max(1, (int) config('security.email_verification.resend.account_per_minute', 3)))
                    ->by('email-verification-account-minute:'.$userId),
                Limit::perHour(max(1, (int) config('security.email_verification.resend.account_per_hour', 10)))
                    ->by('email-verification-account-hour:'.$userId),
            ];
        });

        RateLimiter::for('password-reset-link', function (Request $request): array {
            $ip = (string) ($request->ip() ?: 'unknown');
            $email = strtolower(trim((string) $request->input('email')));
            $fingerprint = hash('sha256', substr($email, 0, 190));

            return [
                Limit::perMinute(max(1, (int) config('security.password_reset.request.ip_per_minute', 3)))
                    ->by('password-reset-link-ip-minute:'.$ip),
                Limit::perHour(max(1, (int) config('security.password_reset.request.ip_per_hour', 12)))
                    ->by('password-reset-link-ip-hour:'.$ip),
                Limit::perMinute(max(1, (int) config('security.password_reset.request.email_per_minute', 2)))
                    ->by('password-reset-link-email-minute:'.$fingerprint),
                Limit::perHour(max(1, (int) config('security.password_reset.request.email_per_hour', 5)))
                    ->by('password-reset-link-email-hour:'.$fingerprint),
            ];
        });

        RateLimiter::for('password-reset', function (Request $request): array {
            $ip = (string) ($request->ip() ?: 'unknown');
            $email = strtolower(trim((string) $request->input('email')));
            $fingerprint = hash('sha256', substr($email, 0, 190));

            return [
                Limit::perMinute(max(1, (int) config('security.password_reset.submit.ip_per_minute', 5)))
                    ->by('password-reset-submit-ip-minute:'.$ip),
                Limit::perHour(max(1, (int) config('security.password_reset.submit.ip_per_hour', 20)))
                    ->by('password-reset-submit-ip-hour:'.$ip),
                Limit::perMinute(max(1, (int) config('security.password_reset.submit.email_per_minute', 3)))
                    ->by('password-reset-submit-email-minute:'.$fingerprint),
                Limit::perHour(max(1, (int) config('security.password_reset.submit.email_per_hour', 10)))
                    ->by('password-reset-submit-email-hour:'.$fingerprint),
            ];
        });


        RateLimiter::for('contact', function (Request $request): array {
            $email = strtolower(trim((string) $request->input('email')));
            $emailFingerprint = hash('sha256', substr($email, 0, 190));
            $ip = (string) ($request->ip() ?: 'unknown');

            return [
                Limit::perMinute(3)->by('contact-ip-minute:'.$ip),
                Limit::perHour(20)->by('contact-ip-hour:'.$ip),
                Limit::perHour(10)->by('contact-email-hour:'.$emailFingerprint),
            ];
        });

        RateLimiter::for('bulk-quote', function (Request $request): array {
            $ip = (string) ($request->ip() ?: 'unknown');
            $email = strtolower(trim((string) $request->input('email')));
            $emailFingerprint = $email !== ''
                ? hash('sha256', substr($email, 0, 190))
                : null;

            $sessionId = $request->hasSession()
                ? (string) $request->session()->getId()
                : '';
            $customerId = (string) ($request->user('web')?->getAuthIdentifier() ?: '');
            $browserIdentity = $customerId !== ''
                ? 'user:'.$customerId
                : 'session:'.hash('sha256', $sessionId !== '' ? $sessionId : $ip);

            $tooManyRequestsResponse = static function (Request $request): \Illuminate\Http\RedirectResponse {
                return redirect()
                    ->back()
                    ->withInput($request->except(['_token', 'attachment', 'company']))
                    ->withErrors([
                        'bulk_quote_rate_limit' => 'You have submitted several quote requests in a short time. Please wait a moment and try again.',
                    ]);
            };

            // The old numeric throttle allowed only four POST requests per minute
            // and counted validation retries as attempts. That could lock a real
            // customer out while correcting the form and showed Laravel's raw
            // 429 page. These independent buckets keep abuse protection while
            // allowing normal validation retries and users behind shared networks.
            $limits = [
                Limit::perMinute(30)
                    ->by('bulk-quote-browser-minute:'.$browserIdentity)
                    ->response($tooManyRequestsResponse),
                Limit::perHour(120)
                    ->by('bulk-quote-browser-hour:'.$browserIdentity)
                    ->response($tooManyRequestsResponse),
                Limit::perHour(300)
                    ->by('bulk-quote-ip-hour:'.$ip)
                    ->response($tooManyRequestsResponse),
            ];

            if ($emailFingerprint !== null) {
                $limits[] = Limit::perHour(30)
                    ->by('bulk-quote-email-hour:'.$emailFingerprint)
                    ->response($tooManyRequestsResponse);
            }

            return $limits;
        });


        // Keep quotation conversations independent of unrelated guest forms and
        // other customers sharing an IP address. Preserve anti-spam limits, but
        // return a usable form error rather than a raw Laravel 429 page.
        RateLimiter::for('quote-message', function (Request $request): array {
            $reference = (string) ($request->route('reference') ?: 'unknown');
            $ip = (string) ($request->ip() ?: 'unknown');
            $customerId = $request->user('web')?->getAuthIdentifier();
            $sessionId = $request->hasSession() ? (string) $request->session()->getId() : '';
            $sender = $customerId !== null
                ? 'customer:'.$customerId
                : 'session:'.($sessionId !== '' ? $sessionId : $ip);
            $conversationKey = hash('sha256', $reference.'|'.$sender);

            $friendlyResponse = static function (Request $request): \Illuminate\Http\RedirectResponse {
                return redirect()->back()
                    ->withInput($request->except(['_token', 'files']))
                    ->withErrors(['body' => 'You have sent several messages in a short time. Please wait a moment before sending another message.']);
            };

            return [
                Limit::perMinute(24)->by('quote-message-minute:'.$conversationKey)->response($friendlyResponse),
                Limit::perHour(120)->by('quote-message-hour:'.$conversationKey)->response($friendlyResponse),
                Limit::perHour(240)->by('quote-message-ip-hour:'.$ip)->response($friendlyResponse),
            ];
        });

        // Guest quotation acceptance is an authenticated-session action, not a
        // general form submission. Do not share a 5/minute IP bucket across
        // all customers/quotes (e.g. during local testing or behind one NAT).
        RateLimiter::for('guest-quote-decision', function (Request $request): array {
            $ip = (string) ($request->ip() ?: 'unknown');
            $reference = (string) ($request->route('reference') ?: 'unknown');
            $friendlyResponse = static function (Request $request): \Illuminate\Http\RedirectResponse {
                return redirect()->back()->withErrors([
                    'quote' => 'Too many confirmation attempts. Please wait a moment, refresh the quotation status, and try again if it is not already confirmed.',
                ]);
            };

            return [
                Limit::perMinute(12)
                    ->by('guest-quote-decision:'.hash('sha256', $reference).':'.$ip)
                    ->response($friendlyResponse),
                // An independent IP cap still protects against trying many
                // arbitrary references to evade the per-quote limit.
                Limit::perHour(60)
                    ->by('guest-quote-decision-ip:'.$ip)
                    ->response($friendlyResponse),
            ];
        });

        RateLimiter::for('checkout-step', function (Request $request): Limit {
            $identity = (string) ($request->user('web')?->getAuthIdentifier() ?: $request->ip() ?: 'guest');
            $routeName = (string) ($request->route()?->getName() ?: $request->path());

            // Each checkout step gets an independent bucket. This avoids the
            // previous nested numeric throttles counting every request twice
            // and incorrectly returning HTTP 429 during a normal checkout.
            return Limit::perMinute(20)->by('checkout-step:'.$identity.':'.$routeName);
        });

        RateLimiter::for('checkout-place-order', function (Request $request): Limit {
            $identity = (string) ($request->user('web')?->getAuthIdentifier() ?: $request->ip() ?: 'guest');

            return Limit::perMinute(4)->by('checkout-place-order:'.$identity);
        });

        RateLimiter::for('order-reorder', function (Request $request): array {
            $identity = (string) ($request->user('web')?->getAuthIdentifier() ?: $request->ip() ?: 'guest');
            $routeOrder = $request->route('order');
            $orderId = is_object($routeOrder) && method_exists($routeOrder, 'getKey')
                ? (string) $routeOrder->getKey()
                : (string) ($routeOrder ?: 'unknown');

            // Reorders get their own bucket instead of sharing the generic
            // numeric account throttle with unrelated profile/address writes.
            return [
                Limit::perMinute(30)->by('order-reorder-minute:'.$identity.':'.$orderId),
                Limit::perHour(120)->by('order-reorder-hour:'.$identity),
            ];
        });
    }
}
