<?php

namespace App\Http\Controllers\Admin;

use App\Http\Controllers\Controller;
use App\Http\Requests\Admin\CategoryFormRequest;
use App\Models\CatalogAttribute;
use App\Models\CatalogPageSetting;
use App\Models\Category;
use App\Models\UrlRedirect;
use App\Services\Catalog\CategoryDeletionService;
use App\Services\Catalog\CategoryMediaService;
use App\Services\Catalog\CategoryProductCountService;
use App\Services\Catalog\CategoryTreeService;
use App\Services\Catalog\LeafCategoryAssignmentService;
use App\Services\Catalog\NavigationService;
use App\Services\Security\SafeHtmlService;
use App\Support\CatalogPageAppearance;
use App\Support\ProductTypeOptions;
use Illuminate\Http\RedirectResponse;
use Illuminate\Http\Request;
use Illuminate\Support\Arr;
use Illuminate\Support\Facades\DB;
use Illuminate\Support\Facades\Storage;
use Illuminate\Support\Str;
use Illuminate\View\View;

class CategoryController extends Controller
{
    public function __construct(
        private readonly CategoryTreeService $treeService,
        private readonly CategoryDeletionService $deletionService,
        private readonly CategoryProductCountService $productCountService,
        private readonly LeafCategoryAssignmentService $leafAssignmentService,
        private readonly CategoryMediaService $mediaService,
        private readonly NavigationService $navigationService,
        private readonly SafeHtmlService $safeHtml,
    ) {
    }

    public function index(Request $request): View
    {
        $allowedStatuses = ['draft', 'active', 'inactive', 'archived'];
        $allowedTypes = ['standard', 'sport', 'collection', 'apparel', 'accessory', 'promotional', 'sale', 'new-arrival', 'navigation-only'];

        $filters = [
            'q' => Str::limit(trim((string) $request->query('q')), 100, ''),
            'status' => in_array($request->query('status'), $allowedStatuses, true) ? (string) $request->query('status') : '',
            'type' => in_array($request->query('type'), $allowedTypes, true) ? (string) $request->query('type') : '',
            'empty' => $request->boolean('empty'),
        ];

        $categoryProductCounts = $this->productCountService->allCounts();
        $emptyCategoryIds = collect($categoryProductCounts)
            ->filter(fn (int $count): bool => $count === 0)
            ->keys()
            ->map(fn ($id): int => (int) $id)
            ->values();

        $query = Category::query()
            ->select([
                'id', 'parent_id', 'name', 'menu_label', 'slug', 'category_type', 'page_template',
                'status', 'depth', 'tree_path', 'is_active', 'is_visible_in_catalog', 'is_visible_in_menu',
                'is_featured', 'icon_path', 'icon_url', 'icon_alt', 'sort_order', 'updated_at', 'updated_by',
            ])
            ->with(['parent:id,name', 'updater:id,name'])
            ->withCount('children');

        if ($filters['q'] !== '') {
            $search = addcslashes($filters['q'], '\\%_');
            $query->where(function ($builder) use ($search): void {
                $builder->where('name', 'like', "%{$search}%")
                    ->orWhere('slug', 'like', "%{$search}%")
                    ->orWhere('menu_label', 'like', "%{$search}%");
            });
        }

        if ($filters['status'] !== '') {
            $query->where('status', $filters['status']);
        }

        if ($filters['type'] !== '') {
            $query->where('category_type', $filters['type']);
        }

        if ($filters['empty']) {
            if ($emptyCategoryIds->isEmpty()) {
                $query->whereRaw('1 = 0');
            } else {
                $query->whereIn('categories.id', $emptyCategoryIds->all());
            }
        }

        $categories = $query
            ->orderBy('tree_path')
            ->orderBy('sort_order')
            ->orderBy('name')
            ->paginate($this->adminPerPage(40))
            ->withQueryString();

        $categoryDeleteImpacts = $this->deletionService->impactsFor($categories->getCollection());

        $categories->getCollection()->each(function (Category $category) use ($categoryProductCounts): void {
            $category->setAttribute(
                'products_count',
                (int) ($categoryProductCounts[(int) $category->id] ?? 0)
            );
        });

        $emptyCategoryCount = $emptyCategoryIds->count();

        return view('admin.categories.index', [
            'categories' => $categories,
            'categoryDeleteImpacts' => $categoryDeleteImpacts,
            'filters' => $filters,
            'catalogBanner' => CatalogPageAppearance::productsBanner(),
            'analytics' => [
                'total' => Category::query()->count(),
                'active' => Category::query()->where('status', 'active')->where('is_active', true)->count(),
                'featured' => Category::query()->whereNull('parent_id')->where('is_featured', true)->count(),
                'empty' => $emptyCategoryCount,
                'max_depth' => (int) Category::query()->max('depth'),
            ],
        ]);
    }

    public function updateCatalogBanner(Request $request): RedirectResponse
    {
        $validated = $request->validate([
            'products_banner_file' => ['nullable', 'image', 'mimes:jpg,jpeg,png,webp,avif', 'max:8192'],
            'products_banner_color' => ['nullable', 'regex:/^#[0-9A-Fa-f]{6}$/'],
            'remove_products_banner' => ['nullable', 'boolean'],
        ]);

        $settings = CatalogPageSetting::query()->first() ?? new CatalogPageSetting();
        $uploaded = $request->file('products_banner_file');

        if ($uploaded) {
            if (filled($settings->products_banner_path)) {
                Storage::disk('public')->delete((string) $settings->products_banner_path);
            }

            $settings->products_banner_path = $uploaded->store('catalog/banners', 'public');
        } elseif ($request->boolean('remove_products_banner')) {
            if (filled($settings->products_banner_path)) {
                Storage::disk('public')->delete((string) $settings->products_banner_path);
            }

            $settings->products_banner_path = null;
        }

        $settings->products_banner_color = filled($validated['products_banner_color'] ?? null)
            ? strtolower((string) $validated['products_banner_color'])
            : null;
        $settings->save();

        CatalogPageAppearance::flush();

        return redirect()
            ->route('admin.categories.index')
            ->with('status', 'All Products banner updated successfully.');
    }

    public function create(Request $request): View
    {
        $parentId = $request->integer('parent_id');
        $parentId = $parentId && Category::query()->whereKey($parentId)->exists() ? $parentId : null;

        $category = new Category([
            'parent_id' => $parentId,
            'category_type' => 'standard',
            'page_template' => 'product_grid',
            'status' => 'draft',
            'cta_label' => 'View Category',
            'is_active' => false,
            'is_visible_in_catalog' => true,
            'is_visible_in_menu' => true,
            'show_product_count' => true,
            'include_descendant_products' => true,
            'robots_index' => true,
            'robots_follow' => true,
            'default_product_sort' => 'featured',
        ]);

        return $this->formView('admin.categories.create', $category);
    }

    public function store(CategoryFormRequest $request): RedirectResponse
    {
        $category = DB::transaction(function () use ($request): Category {
            $payload = $this->payload($request, null);
            $this->treeService->assertValidParent(new Category(), $payload['parent_id'] ?? null);
            $category = Category::query()->create($payload);
            $this->mediaService->sync($category, $request);
            if ($request->has('filter_settings')) {
                $this->syncFilters($category, $request->validated('filter_settings', []));
            }
            if ($request->has('content_blocks')) {
                $this->syncContentBlocks($category, $request);
            }
            if ($request->has('faqs')) {
                $this->syncFaqs($category, $request->validated('faqs', []));
            }
            $this->treeService->rebuildClosure();

            return $category;
        });

        $normalizedProducts = $this->leafAssignmentService->enforce();
        $this->navigationService->flushCache();

        $message = $normalizedProducts > 0
            ? "Category created successfully. {$normalizedProducts} product(s) were made categoryless or moved to another valid leaf assignment because their former category now has children."
            : 'Category created successfully.';

        return redirect()->route('admin.categories.edit', $category)->with('status', $message);
    }

    public function edit(Category $category): View
    {
        $category->load(['filters', 'contentBlocks', 'faqs']);

        return $this->formView('admin.categories.edit', $category);
    }

    public function update(CategoryFormRequest $request, Category $category): RedirectResponse
    {
        DB::transaction(function () use ($request, $category): void {
            $oldSlug = $category->slug;
            $payload = $this->payload($request, $category);
            $this->treeService->assertValidParent($category, $payload['parent_id'] ?? null);
            $category->update($payload);
            $this->mediaService->sync($category, $request);
            if ($request->has('filter_settings')) {
                $this->syncFilters($category, $request->validated('filter_settings', []));
            }
            if ($request->has('content_blocks')) {
                $this->syncContentBlocks($category, $request);
            }
            if ($request->has('faqs')) {
                $this->syncFaqs($category, $request->validated('faqs', []));
            }

            if ($oldSlug !== $category->slug) {
                UrlRedirect::query()->updateOrCreate(
                    ['old_path' => '/category/'.$oldSlug],
                    [
                        'new_path' => '/category/'.$category->slug,
                        'status_code' => 301,
                        'is_active' => true,
                        'redirectable_type' => Category::class,
                        'redirectable_id' => $category->id,
                    ]
                );
            }

            $this->treeService->rebuildClosure();
            $this->navigationService->flushCache();
        });

        $normalizedProducts = $this->leafAssignmentService->enforce();

        $message = $normalizedProducts > 0
            ? "Category updated successfully. {$normalizedProducts} product assignment(s) were normalized because products can only stay on last-level categories."
            : 'Category updated successfully.';

        return redirect()->route('admin.categories.edit', $category)->with('status', $message);
    }

    public function duplicate(Category $category): RedirectResponse
    {
        $category->load(['filters', 'contentBlocks', 'faqs']);

        $copy = DB::transaction(function () use ($category): Category {
            $copy = $category->replicate([
                'slug', 'status', 'is_active', 'is_featured', 'published_at',
                'created_by', 'updated_by', 'created_at', 'updated_at', 'deleted_at',
            ]);
            $copy->name = Str::limit($category->name.' Copy', 160, '');
            $baseSlug = Str::slug($copy->name);
            do {
                $copy->slug = Str::limit($baseSlug.'-'.Str::lower(Str::random(5)), 180, '');
            } while (Category::withTrashed()->where('slug', $copy->slug)->exists());
            $copy->status = 'draft';
            $copy->is_active = false;
            $copy->is_featured = false;
            $copy->published_at = null;
            $copy->created_by = auth()->id();
            $copy->updated_by = auth()->id();
            $copy->save();

            $this->mediaService->duplicate($category, $copy);
            $copy->filters()->sync($category->filters->mapWithKeys(fn ($attribute) => [
                $attribute->id => [
                    'label' => $attribute->pivot->label,
                    'is_expanded' => (bool) $attribute->pivot->is_expanded,
                    'sort_order' => (int) $attribute->pivot->sort_order,
                ],
            ])->all());

            foreach ($category->contentBlocks as $block) {
                $payload = Arr::except($block->toArray(), ['id', 'category_id', 'created_at', 'updated_at']);
                $payload['image_path'] = $this->mediaService->copyPath(
                    $block->image_path,
                    "categories/{$copy->id}/blocks"
                );
                $copy->contentBlocks()->create($payload);
            }

            foreach ($category->faqs as $faq) {
                $copy->faqs()->create(Arr::except($faq->toArray(), ['id', 'category_id', 'created_at', 'updated_at']));
            }

            $this->treeService->rebuildClosure();

            return $copy;
        });

        $this->navigationService->flushCache();

        return redirect()->route('admin.categories.edit', $copy)
            ->with('status', 'Category duplicated as a draft. Product assignments and child categories were intentionally not copied.');
    }

    public function destroy(Category $category): RedirectResponse
    {
        $categoryName = $category->name;
        $impact = $this->deletionService->deleteSubtree($category);

        return redirect()->route('admin.categories.index')->with(
            'status',
            sprintf(
                '%s deleted with %d child category record(s). %d affected product(s) were kept and made categoryless.',
                $categoryName,
                $impact['child_category_count'],
                $impact['product_count'],
            )
        );
    }

    private function formView(string $view, Category $category): View
    {
        return view($view, [
            'category' => $category,
            'parents' => $this->treeService->flatOptions($category->exists ? $category->id : null),
            'attributes' => CatalogAttribute::query()->with('values')->ordered()->get(),
            'productTypeOptions' => ProductTypeOptions::all(),
        ]);
    }

    /** @return array<string, mixed> */
    private function payload(CategoryFormRequest $request, ?Category $category): array
    {
        $data = $request->validated();
        $plainDescription = trim((string) ($data['description'] ?? ''));
        $sanitizedHtml = $this->safeHtml->sanitize($data['description_html'] ?? null);

        if ($plainDescription === '') {
            $plainDescription = trim(strip_tags((string) $sanitizedHtml));
        }
        if ($plainDescription === '') {
            $plainDescription = trim((string) ($data['short_description'] ?? $data['name']));
        }

        $payload = Arr::only($data, [
            'parent_id', 'name', 'menu_label', 'slug', 'category_type', 'page_template', 'status',
            'eyebrow', 'short_title', 'short_description', 'best_for', 'cta_label', 'icon', 'sort_order',
            'published_at', 'default_product_sort', 'image_alt', 'thumbnail_alt', 'icon_alt', 'banner_alt', 'banner_color',
            'mobile_banner_alt', 'is_visible_in_catalog', 'is_visible_in_menu', 'is_featured',
            'show_product_count', 'include_descendant_products', 'meta_title', 'meta_description',
            'meta_keywords', 'canonical_url', 'og_title', 'og_description', 'robots_index', 'robots_follow',
        ]);

        if (array_key_exists('filter_product_types', $data)) {
            $selectedProductTypes = collect($data['filter_product_types'] ?? [])
                ->map(fn ($value): string => trim((string) $value))
                ->filter()
                ->unique()
                ->values();
            $availableProductTypes = collect(ProductTypeOptions::all());

            $payload['filter_product_types'] = $selectedProductTypes->sort()->values()->all()
                === $availableProductTypes->sort()->values()->all()
                    ? null
                    : $selectedProductTypes->all();
        }

        $payload['slug'] = $this->uniqueSlug(
            trim((string) ($data['slug'] ?? '')) ?: (string) $data['name'],
            $category?->id,
        );
        $payload['description'] = Str::limit($plainDescription, 10000, '');
        $payload['description_html'] = $sanitizedHtml;
        $payload['display_type'] = $data['category_type'] === 'sport' ? 'sport' : 'collection';
        $payload['is_active'] = $data['status'] === 'active';
        $payload['is_featured'] = empty($payload['parent_id']) && (bool) ($payload['is_featured'] ?? false);
        $payload['image_url'] = $category?->image_url ?? (string) ($data['image_url'] ?? '');
        $payload['image_alt'] = filled($data['image_alt'] ?? null) ? $data['image_alt'] : $data['name'];
        $payload['thumbnail_alt'] = filled($data['thumbnail_alt'] ?? null) ? $data['thumbnail_alt'] : $data['name'];
        $payload['icon_alt'] = empty($payload['parent_id'])
            ? (filled($data['icon_alt'] ?? null) ? $data['icon_alt'] : $data['name'].' icon')
            : null;
        $payload['highlights'] = collect(preg_split('/\r\n|\r|\n/', (string) ($data['highlights_text'] ?? '')))
            ->map(fn ($value) => trim((string) $value))->filter()->values()->all();
        if (array_key_exists('schema_json_text', $data)) {
            $payload['schema_json'] = filled($data['schema_json_text'] ?? null)
                ? json_decode($data['schema_json_text'], true, 512, JSON_THROW_ON_ERROR)
                : null;
        }
        $payload['created_by'] = $category?->created_by ?? auth()->id();
        $payload['updated_by'] = auth()->id();

        return $payload;
    }

    private function uniqueSlug(string $value, ?int $ignoreId = null): string
    {
        $base = Str::limit(Str::slug($value) ?: 'category', 170, '');
        $slug = $base;
        $suffix = 2;

        while (Category::withTrashed()
            ->when($ignoreId, fn ($query) => $query->where('id', '!=', $ignoreId))
            ->where('slug', $slug)
            ->exists()) {
            $ending = '-'.$suffix++;
            $slug = Str::limit($base, 180 - strlen($ending), '').$ending;
        }

        return $slug;
    }

    /** @param array<int|string, mixed> $settings */
    private function syncFilters(Category $category, array $settings): void
    {
        $sync = [];
        foreach ($settings as $attributeId => $setting) {
            if (! is_array($setting) || ! ($setting['enabled'] ?? false)) {
                continue;
            }
            $sync[(int) $attributeId] = [
                'label' => filled($setting['label'] ?? null) ? trim((string) $setting['label']) : null,
                'is_expanded' => (bool) ($setting['is_expanded'] ?? true),
                'sort_order' => (int) ($setting['sort_order'] ?? 0),
            ];
        }
        $category->filters()->sync($sync);
    }

    private function syncContentBlocks(Category $category, CategoryFormRequest $request): void
    {
        $existingPaths = $category->contentBlocks()->pluck('image_path', 'id')->filter()->all();
        $retainedPaths = [];
        $category->contentBlocks()->delete();

        $sortOrder = 0;
        foreach ($request->validated('content_blocks', []) as $index => $block) {
            if (! filled($block['heading'] ?? null)
                && ! filled($block['content_html'] ?? null)
                && ! filled($block['image_url'] ?? null)
                && ! $request->hasFile("content_blocks.{$index}.image_file")
                && ! filled($block['button_label'] ?? null)) {
                continue;
            }
            $existingId = (int) ($block['existing_id'] ?? 0);
            $imagePath = $existingPaths[$existingId] ?? null;
            $imageUrl = filled($block['image_url'] ?? null) ? trim((string) $block['image_url']) : null;
            $uploaded = $request->file("content_blocks.{$index}.image_file");

            if ($uploaded) {
                if ($imagePath) {
                    Storage::disk('public')->delete($imagePath);
                }
                $imagePath = $uploaded->store("categories/{$category->id}/blocks", 'public');
                $imageUrl = null;
            } elseif ($imageUrl !== null) {
                if ($imagePath) {
                    Storage::disk('public')->delete($imagePath);
                }
                $imagePath = null;
            }

            if ($imagePath) {
                $retainedPaths[] = $imagePath;
            }

            $category->contentBlocks()->create([
                'block_type' => $block['block_type'] ?? 'rich_text',
                'heading' => $block['heading'] ?? null,
                'subheading' => $block['subheading'] ?? null,
                'content_html' => $this->safeHtml->sanitize($block['content_html'] ?? null),
                'image_path' => $imagePath,
                'image_url' => $imageUrl,
                'image_alt' => $block['image_alt'] ?? null,
                'button_label' => $block['button_label'] ?? null,
                'button_url' => $block['button_url'] ?? null,
                'settings' => filled($block['settings_json'] ?? null)
                    ? json_decode($block['settings_json'], true, 512, JSON_THROW_ON_ERROR)
                    : null,
                'is_active' => (bool) ($block['is_active'] ?? true),
                'sort_order' => $sortOrder++,
            ]);
        }

        foreach (array_diff($existingPaths, $retainedPaths) as $path) {
            Storage::disk('public')->delete($path);
        }
    }

    /** @param array<int, mixed> $faqs */
    private function syncFaqs(Category $category, array $faqs): void
    {
        $category->faqs()->delete();
        foreach (collect($faqs)->filter(fn ($faq) => filled($faq['question'] ?? null) && filled($faq['answer_html'] ?? null))->values() as $index => $faq) {
            $category->faqs()->create([
                'question' => trim((string) $faq['question']),
                'answer_html' => $this->safeHtml->sanitize($faq['answer_html']) ?: '',
                'is_active' => (bool) ($faq['is_active'] ?? true),
                'sort_order' => $index,
            ]);
        }
    }
}
