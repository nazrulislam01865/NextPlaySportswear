<?php

namespace App\Http\Controllers\Admin;

use App\Http\Controllers\Controller;
use App\Http\Requests\Admin\ShippingMethodRequest;
use App\Models\ShippingMethod;
use App\Services\Catalog\MasterMethodMediaService;
use Illuminate\Http\RedirectResponse;
use Illuminate\View\View;

class ShippingMethodController extends Controller
{
    public function __construct(private readonly MasterMethodMediaService $media)
    {
    }

    public function index(): View
    {
        return view('admin.shipping-methods.index', [
            'methods' => ShippingMethod::query()->orderBy('sort_order')->latest()->paginate($this->adminPerPage(20))->withQueryString(),
        ]);
    }

    public function create(): View
    {
        return view('admin.shipping-methods.create', [
            'method' => new ShippingMethod([
                'base_price' => 0,
                'per_item_price' => 0,
                'charge_amount' => 0,
                'charge_application' => 'per_order',
                'minimum_days' => 1,
                'maximum_days' => 7,
                'starts_after_artwork_approval' => true,
                'is_active' => true,
                'sort_order' => 0,
            ]),
        ]);
    }

    public function store(ShippingMethodRequest $request): RedirectResponse
    {
        $data = $request->validated();
        if (empty($data['sort_order'])) {
            $data['sort_order'] = ((int) ShippingMethod::query()->max('sort_order')) + 10;
        }
        unset($data['image_file'], $data['image_url'], $data['remove_image']);
        $method = ShippingMethod::create($data);
        $this->media->persist($method, $request, 'master-data/shipping-methods');
        $this->syncDefault($method);

        return redirect()->route('admin.shipping-methods.index')
            ->with('status', 'Shipping method created successfully.');
    }

    public function edit(ShippingMethod $shippingMethod): View
    {
        return view('admin.shipping-methods.edit', [
            'method' => $shippingMethod,
        ]);
    }

    public function update(ShippingMethodRequest $request, ShippingMethod $shippingMethod): RedirectResponse
    {
        $data = $request->validated();
        $data['sort_order'] = $shippingMethod->sort_order ?: (((int) ShippingMethod::query()->whereKeyNot($shippingMethod->id)->max('sort_order')) + 10);
        unset($data['image_file'], $data['image_url'], $data['remove_image']);
        $shippingMethod->update($data);
        $this->media->persist($shippingMethod, $request, 'master-data/shipping-methods');
        $this->syncDefault($shippingMethod);

        return redirect()->route('admin.shipping-methods.index')
            ->with('status', 'Shipping method updated successfully.');
    }

    public function destroy(ShippingMethod $shippingMethod): RedirectResponse
    {
        $this->media->deleteOwned($shippingMethod->image_path, 'master-data/shipping-methods');
        $shippingMethod->delete();

        if (! ShippingMethod::query()->where('is_default', true)->exists()) {
            ShippingMethod::query()->where('is_active', true)->orderBy('sort_order')->first()?->update(['is_default' => true]);
        }

        return redirect()->route('admin.shipping-methods.index')
            ->with('status', 'Shipping method removed.');
    }

    private function syncDefault(ShippingMethod $method): void
    {
        if (! $method->is_default) {
            return;
        }

        ShippingMethod::query()->whereKeyNot($method->id)->update(['is_default' => false]);
    }
}
