<?php

namespace App\Http\Controllers\Admin;

use App\Enums\JerseyCustomizationType;
use App\Enums\WorldCupCustomizationType;
use App\Http\Controllers\Controller;
use App\Http\Requests\Admin\ProductBulkRequest;
use App\Http\Requests\Admin\ProductFormRequest;
use App\Models\CatalogAttribute;
use App\Models\Category;
use App\Models\Faq;
use App\Models\Gender;
use App\Models\JerseyCustomizationOption;
use App\Models\WorldCupCustomizationOption;
use App\Models\MediaLibraryImage;
use App\Models\Product;
use App\Models\ProductionMethod;
use App\Models\SizeOptionGroup;
use App\Models\ShippingMethod;
use App\Services\Catalog\CategoryTreeService;
use App\Services\Catalog\ProductOptionFilterSyncService;
use App\Services\Catalog\ProductChangeSummaryService;
use App\Services\AdminNotificationService;
use App\Services\Security\SafeHtmlService;
use App\Services\Storefront\ProductCatalogCacheService;
use App\Support\ProductSizing;
use App\Support\WorldCupCustomizationRegistry;
use App\Support\ProductSizeExtraCharges;
use App\Support\ProductionTime;
use App\Support\PublicMedia;
use Illuminate\Http\JsonResponse;
use Illuminate\Http\RedirectResponse;
use Illuminate\Http\Request;
use Illuminate\Support\Arr;
use Illuminate\Support\Facades\DB;
use Illuminate\Support\Facades\Schema;
use Illuminate\Support\Facades\Storage;
use Illuminate\Support\Str;
use Illuminate\View\View;
use Illuminate\Validation\ValidationException;

class ProductController extends Controller
{
    public function __construct(
        private readonly SafeHtmlService $safeHtml,
        private readonly CategoryTreeService $categoryTreeService,
        private readonly ProductOptionFilterSyncService $productOptionFilterSyncService,
        private readonly ProductChangeSummaryService $productChangeSummaryService,
        private readonly AdminNotificationService $adminNotifications,
        private readonly ProductCatalogCacheService $productCatalogCache,
    ) {
    }

    public function index(Request $request): View
    {
        $query = Product::query()->with(['category', 'subcategory', 'categories', 'images', 'updater:id,name,email']);

        if ($search = trim((string) $request->query('q'))) {
            $query->where(fn ($builder) => $builder
                ->where('name', 'like', "%{$search}%")
                ->orWhere('sku', 'like', "%{$search}%")
                ->orWhere('slug', 'like', "%{$search}%"));
        }

        if ($status = $request->query('status')) {
            $query->where('status', $status);
        }

        if ($categoryId = (int) $request->query('category_id')) {
            $categoryIds = $this->categoryTreeService->descendantIds($categoryId, true);
            $categoryIds = $categoryIds === [] ? [$categoryId] : $categoryIds;

            $query->where(function ($builder) use ($categoryIds): void {
                $builder->whereIn('category_id', $categoryIds)
                    ->orWhereIn('subcategory_id', $categoryIds)
                    ->orWhereHas('categories', fn ($categoryQuery) => $categoryQuery->whereIn('categories.id', $categoryIds));
            });
        }

        if ($request->boolean('featured')) {
            $query->where('is_featured', true);
        }

        return view('admin.products.index', [
            'products' => $query->latest()->paginate($this->adminPerPage(25))->withQueryString(),
            'filters' => $request->only(['q', 'status', 'category_id', 'featured']),
            'categoryOptions' => $this->categoryTreeService->flatOptions(),
            'productStats' => $this->productStats(),
        ]);
    }

    public function suggestions(Request $request): JsonResponse
    {
        $search = trim((string) $request->query('q', ''));

        $query = Product::query()
            ->with(['category', 'subcategory', 'images'])
            ->select([
                'id',
                'name',
                'slug',
                'sku',
                'status',
                'category_id',
                'subcategory_id',
                'is_active',
                'is_customizable',
                'track_inventory',
                'updated_at',
            ])
            ->latest('updated_at')
            ->limit(8);

        if ($search !== '') {
            $query->where(function ($builder) use ($search): void {
                $builder->where('name', 'like', "%{$search}%")
                    ->orWhere('sku', 'like', "%{$search}%")
                    ->orWhere('slug', 'like', "%{$search}%");
            });
        }

        $suggestions = $query->get()->map(static function (Product $product) use ($search): array {
            $lowerSearch = Str::lower($search);
            $searchValue = $product->name;

            if ($lowerSearch !== '' && $product->sku && str_contains(Str::lower($product->sku), $lowerSearch)) {
                $searchValue = $product->sku;
            } elseif ($lowerSearch !== '' && $product->slug && str_contains(Str::lower($product->slug), $lowerSearch)) {
                $searchValue = $product->slug;
            }

            return [
                'id' => $product->id,
                'name' => $product->name,
                'sku' => $product->sku,
                'slug' => $product->slug,
                'status' => ucfirst((string) $product->status),
                'category' => $product->category?->name ?? $product->subcategory?->name ?? 'Uncategorized',
                'image_url' => $product->primaryImageUrl(),
                'search_value' => $searchValue,
            ];
        })->values();

        return response()->json([
            'data' => $suggestions,
            'query' => $search,
        ])->withHeaders([
            'Cache-Control' => 'no-store, no-cache, must-revalidate, max-age=0',
            'Pragma' => 'no-cache',
        ]);
    }


    public function stats(): JsonResponse
    {
        return response()->json([
            'data' => $this->productStats(),
            'updated_at' => now()->toIso8601String(),
        ])->withHeaders([
            'Cache-Control' => 'no-store, no-cache, must-revalidate, max-age=0',
            'Pragma' => 'no-cache',
        ]);
    }

    public function bulk(ProductBulkRequest $request): RedirectResponse
    {
        $ids = collect($request->validated('product_ids'))
            ->map(fn ($id): int => (int) $id)
            ->unique()
            ->values();
        $action = (string) $request->validated('action');
        $actor = auth('admin')->user();

        if ($action === 'delete' && ! $actor?->canDeleteAdminRecords()) {
            return back()->with('status', 'Delete permission is required. A Super Admin can grant it from Role Matrix.');
        }

        if ($action === 'delete') {
            $deletedProducts = DB::transaction(function () use ($ids) {
                $products = Product::query()
                    ->whereIn('id', $ids)
                    ->lockForUpdate()
                    ->get(['id', 'name', 'sku']);

                foreach ($products as $product) {
                    $product->delete();
                }

                return $products;
            });

            $count = $deletedProducts->count();
            $this->flushProductCaches();

            if ($count > 0) {
                $sampleNames = $deletedProducts
                    ->take(3)
                    ->map(fn (Product $product): string => $product->name ?: ($product->sku ?: '#'.$product->id))
                    ->implode(', ');

                $this->adminNotifications->adminActivity(
                    'deleted',
                    'Products',
                    $count === 1 ? $sampleNames : $count.' selected products'.($sampleNames !== '' ? ' including '.$sampleNames : ''),
                    $actor,
                    route('admin.products.index'),
                    [
                        'resource_id' => null,
                        'resource_code' => '',
                        'route_name' => 'admin.products.bulk',
                        'request_method' => 'POST',
                    ]
                );
            }

            return back()->with('status', "{$count} product records moved to trash.");
        }

        $payload = match ($action) {
            'activate' => ['status' => 'active', 'is_active' => true],
            'deactivate' => ['status' => 'draft', 'is_active' => false],
            'archive' => ['status' => 'archived', 'is_active' => false],
            'feature' => ['is_featured' => true],
            'unfeature' => ['is_featured' => false],
        };

        $bulkSummary = match ($action) {
            'activate' => 'Status changed to Active',
            'deactivate' => 'Status changed to Draft',
            'archive' => 'Status changed to Archived',
            'feature' => 'Featured flag enabled',
            'unfeature' => 'Featured flag removed',
        };

        $updated = DB::transaction(function () use ($ids, $payload, $bulkSummary): int {
            return Product::query()
                ->whereIn('id', $ids)
                ->lockForUpdate()
                ->update(array_merge($payload, [
                    'last_update_summary' => $bulkSummary,
                    'updated_by' => auth('admin')->id(),
                    'updated_at' => now(),
                ]));
        });

        $this->flushProductCaches();

        if ($updated > 0) {
            $label = match ($action) {
                'activate' => 'activated',
                'deactivate' => 'deactivated',
                'archive' => 'archived',
                'feature' => 'marked featured',
                'unfeature' => 'removed from featured',
            };

            $this->adminNotifications->adminActivity(
                'updated',
                'Products',
                $updated.' selected products '.$label,
                $actor,
                route('admin.products.index'),
                [
                    'resource_id' => null,
                    'resource_code' => '',
                    'route_name' => 'admin.products.bulk',
                    'request_method' => 'POST',
                ]
            );
        }

        return back()->with('status', "{$updated} product records updated.");
    }

    public function create(): View
    {
        $product = new Product([
            'status' => 'draft', 'currency' => 'USD', 'minimum_quantity' => 1, 'product_profile' => 'standard',
            'price_table_highlight_column' => 1,
            'is_active' => true, 'is_customizable' => true, 'robots_index' => true,
            'robots_follow' => true, 'low_stock_threshold' => 5,
            'sample_available' => false, 'sample_charge' => 0,
            'artwork_upload_enabled' => false, 'artwork_upload_required' => false,
            'artwork_upload_title' => 'Upload Custom Artwork',
            'artwork_upload_description' => 'Upload one or more artwork files for the production team.',
            'artwork_upload_max_files' => 5, 'artwork_upload_max_file_size_mb' => 15,
            'artwork_upload_accepted_types' => 'pdf,svg,png,jpg,jpeg,webp',
        ]);

        return $this->formView('admin.products.create', $product);
    }

    public function store(ProductFormRequest $request): RedirectResponse
    {
        $product = DB::transaction(function () use ($request): Product {
            $product = Product::query()->create($this->productPayload($request, null));
            $this->syncRelations($product, $request);
            $product->load($this->relations());
            $this->syncProductSpecifications($product, $request);
            $product->forceFill([
                'last_update_summary' => 'Product created',
                'updated_by' => auth('admin')->id(),
            ])->save();

            return $product;
        });

        $this->flushProductCaches();
        $this->adminNotifications->productChanged(
            $product,
            'created',
            auth('admin')->user(),
            route('admin.products.edit', $product)
        );

        return redirect()->route('admin.products.edit', $product)->with('status', 'Product created successfully.');
    }

    public function show(Product $product): View
    {
        $product->load($this->relations());

        return view('admin.products.show', compact('product'));
    }

    public function edit(Product $product): View
    {
        $product->load($this->relations());

        return $this->formView('admin.products.edit', $product);
    }

    public function update(ProductFormRequest $request, Product $product): RedirectResponse
    {
        $product->load($this->relations());
        $before = $this->productChangeSummaryService->snapshot($product);
        $changeDetails = [];

        DB::transaction(function () use ($request, $product, $before, &$changeDetails): void {
            $product->update($this->productPayload($request, $product));
            $this->syncRelations($product, $request);
            $product->load($this->relations());
            $this->syncProductSpecifications($product, $request);

            $product->refresh()->load($this->relations());
            $after = $this->productChangeSummaryService->snapshot($product);
            $changeDetails = $this->productChangeSummaryService->changeDetails($before, $after);

            $product->forceFill([
                'last_update_summary' => $this->productChangeSummaryService->summarize($before, $after),
                'updated_by' => auth('admin')->id(),
            ])->save();
        });

        $this->flushProductCaches();
        $this->adminNotifications->productChanged(
            $product->fresh() ?? $product,
            'updated',
            auth('admin')->user(),
            route('admin.products.edit', $product),
            $changeDetails
        );

        return redirect()->route('admin.products.edit', $product)->with('status', 'Product updated successfully.');
    }

    public function destroy(Product $product): RedirectResponse
    {
        $notificationProduct = $product->replicate();
        $notificationProduct->id = $product->id;

        $product->delete();
        $this->flushProductCaches();
        $this->adminNotifications->productChanged(
            $notificationProduct,
            'deleted',
            auth('admin')->user(),
            route('admin.products.index')
        );

        return redirect()->route('admin.products.index')->with('status', 'Product moved to trash.');
    }

    public function duplicate(Product $product): RedirectResponse
    {
        $product->load($this->relations());

        $copy = DB::transaction(function () use ($product): Product {
            $copy = $product->replicate();
            $copy->name = $product->name.' Copy';
            $copy->slug = Str::slug($copy->name).'-'.Str::lower(Str::random(5));
            $copy->sku = $product->sku.'-COPY-'.Str::upper(Str::random(4));
            $copy->status = 'draft';
            $copy->is_active = false;
            $copy->is_featured = false;
            $copy->published_at = null;
            $copy->created_by = auth('admin')->id();
            $copy->updated_by = auth('admin')->id();
            $copy->last_update_summary = 'Duplicated from '.($product->sku ?: $product->name);
            $copy->save();

            foreach ($product->images as $item) {
                $copy->images()->create(Arr::except($item->toArray(), ['id', 'product_id', 'created_at', 'updated_at']));
            }
            foreach ($product->optionGroups as $group) {
                $newGroup = $copy->optionGroups()->create(Arr::except($group->toArray(), ['id', 'product_id', 'created_at', 'updated_at']));
                foreach ($group->values as $value) {
                    $newGroup->values()->create(Arr::except($value->toArray(), ['id', 'product_option_group_id', 'created_at', 'updated_at']));
                }
            }
            foreach ($product->sizeGroups as $group) {
                $newGroup = $copy->sizeGroups()->create(Arr::except($group->toArray(), ['id', 'product_id', 'created_at', 'updated_at']));
                foreach ($group->sizes as $size) {
                    $newGroup->sizes()->create(Arr::except($size->toArray(), ['id', 'product_size_group_id', 'created_at', 'updated_at']));
                }
            }
            foreach (['priceTiers', 'productionSpeeds', 'shippingMethods'] as $relation) {
                foreach ($product->{$relation} as $item) {
                    $copy->{$relation}()->create(Arr::except($item->toArray(), ['id', 'product_id', 'created_at', 'updated_at']));
                }
            }
            $copy->faqs()->sync(
                $product->faqs
                    ->mapWithKeys(fn (Faq $faq, int $index): array => [$faq->id => [
                        'sort_order' => (int) ($faq->pivot->sort_order ?? $index),
                    ]])
                    ->all()
            );
            foreach ($product->fabricPriceTables as $table) {
                $newTable = $copy->fabricPriceTables()->create(Arr::except($table->toArray(), ['id', 'product_id', 'created_at', 'updated_at']));
                foreach ($table->tiers as $tier) {
                    $newTable->tiers()->create(Arr::except($tier->toArray(), ['id', 'product_fabric_price_table_id', 'created_at', 'updated_at']));
                }
            }
            $leafCategoryIds = Category::query()
                ->leaf()
                ->whereIn('id', $product->categories->pluck('id')->all())
                ->pluck('id')
                ->map(fn ($id): int => (int) $id)
                ->flip();
            $copiedCategoryAssignments = $product->categories
                ->filter(fn (Category $category): bool => $leafCategoryIds->has((int) $category->id))
                ->mapWithKeys(fn (Category $category): array => [$category->id => [
                    'is_primary' => (bool) $category->pivot->is_primary,
                    'is_featured' => (bool) $category->pivot->is_featured,
                    'sort_order' => (int) $category->pivot->sort_order,
                ]])
                ->all();
            $copy->categories()->sync($copiedCategoryAssignments);
            $this->syncLegacyCategoryColumnsFromLeafAssignments($copy, $copiedCategoryAssignments);
            $manualAttributeValueIds = $product->attributeValues->pluck('id')->all();
            $copy->attributeValues()->sync($manualAttributeValueIds);
            $this->productOptionFilterSyncService->sync($copy, $manualAttributeValueIds);

            return $copy;
        });

        $this->flushProductCaches();
        $this->adminNotifications->productChanged(
            $copy,
            'duplicated',
            auth('admin')->user(),
            route('admin.products.edit', $copy)
        );

        return redirect()->route('admin.products.edit', $copy)->with('status', 'Product duplicated as a draft.');
    }


    private function productStats(): array
    {
        return [
            'total' => Product::query()->count(),
            'active' => Product::query()->published()->count(),
            'draft_incomplete' => Product::query()
                ->where(function ($builder): void {
                    $builder->where('status', 'draft')
                        ->orWhere('is_active', false)
                        ->orWhereNull('base_price')
                        ->orWhere('base_price', '<=', 0);
                })
                ->count(),
            'customizable' => Product::query()->where('is_customizable', true)->count(),
            'inventory_not_tracked' => Product::query()->where('track_inventory', false)->count(),
        ];
    }

    private function formView(string $view, Product $product): View
    {
        $jerseyCustomizationOptions = JerseyCustomizationOption::query()
            ->active()
            ->whereIn('type', array_keys(JerseyCustomizationType::productConfigurationOptions()))
            ->with(['images:id,jersey_customization_option_id,name,image_path,image_url,is_primary,sort_order'])
            ->ordered()
            ->get(['id', 'type', 'name', 'slug', 'description', 'color_hex'])
            ->map(static fn (JerseyCustomizationOption $option): array => [
                'id' => $option->id,
                'type' => $option->type->value,
                'type_label' => $option->type->label(),
                'name' => $option->name,
                'slug' => $option->slug,
                'description' => $option->description,
                'color_hex' => $option->color_hex,
                'images' => $option->images
                    ->map(static fn ($image): array => [
                        'name' => $image->name,
                        'url' => $image->publicUrl(),
                        'is_primary' => (bool) $image->is_primary,
                    ])
                    ->filter(static fn (array $image): bool => filled($image['url']))
                    ->values()
                    ->all(),
            ])
            ->values()
            ->all();

        $worldCupCustomizationOptions = WorldCupCustomizationOption::query()
            ->active()
            ->whereIn('type', array_keys(WorldCupCustomizationRegistry::configurationOptions()))
            ->with(['images:id,world_cup_customization_option_id,name,image_path,image_url,is_primary,sort_order'])
            ->ordered()
            ->get(['id', 'category_key', 'type', 'name', 'slug', 'description'])
            ->map(static fn (WorldCupCustomizationOption $option): array => [
                'id' => $option->id,
                'source' => 'world_cup',
                'type' => $option->type->value,
                'type_label' => $option->type->label(),
                'name' => $option->name,
                'slug' => $option->slug,
                'description' => $option->description,
                'color_hex' => null,
                'images' => $option->images
                    ->map(static fn ($image): array => [
                        'name' => $image->name,
                        'url' => $image->publicUrl(),
                        'is_primary' => (bool) $image->is_primary,
                    ])
                    ->filter(static fn (array $image): bool => filled($image['url']))
                    ->values()
                    ->all(),
            ])
            ->values()
            ->all();

        $sizeOptionGroups = SizeOptionGroup::query()
            ->active()
            ->with(['sizes' => fn ($query) => $query->where('is_active', true)->orderBy('sort_order')])
            ->ordered()
            ->get()
            ->filter(static fn (SizeOptionGroup $group): bool => ProductSizing::supportsMasterDataSizeOptions($group->customization_group))
            ->map(static fn (SizeOptionGroup $group): array => [
                'id' => $group->id,
                'name' => $group->name,
                'slug' => $group->slug,
                'audience' => $group->audience->value,
                'audience_label' => $group->audience->label(),
                'customization_group' => $group->customization_group,
                'customization_group_label' => JerseyCustomizationType::menuGroups()[$group->customization_group]['label'] ?? 'Product Customization',
                'description_html' => $group->description_html,
                'sizes' => $group->sizes->pluck('label')->values()->all(),
                'size_codes' => $group->sizes->mapWithKeys(fn ($size) => [$size->label => $size->code])->all(),
                'chart_enabled' => filled($group->chart_html) || filled($group->chartImageUrl()),
                'chart_html' => $group->chart_html,
                'chart_title' => $group->chart_title,
                'chart_note' => $group->chart_note,
                'chart_columns' => $group->chart_columns ?? [],
                'chart_rows' => $group->chart_rows ?? [],
                'chart_image_preview' => $group->chartImageUrl(),
            ])
            ->values()
            ->all();

        $productionMethodOptions = ProductionMethod::query()
            ->orderBy('sort_order')
            ->orderBy('name')
            ->get();

        $shippingMethodOptions = ShippingMethod::query()
            ->orderBy('sort_order')
            ->orderBy('name')
            ->get();

        $faqOptions = Faq::query()
            ->ordered()
            ->get();

        $genderOptions = Gender::query()
            ->where(function ($query) use ($product): void {
                $query->where('is_active', true);

                if ($product->gender_id) {
                    $query->orWhere('id', $product->gender_id);
                }
            })
            ->ordered()
            ->get();

        return view($view, [
            'product' => $product,
            'categoryOptions' => $this->categoryTreeService->leafOptions(),
            'catalogAttributes' => CatalogAttribute::query()->active()->with(['values' => fn ($query) => $query->active()->orderBy('sort_order')])->ordered()->get(),
            'jerseyCustomizationTypes' => array_merge(
                JerseyCustomizationType::productConfigurationOptions(),
                WorldCupCustomizationRegistry::configurationOptions()
            ),
            'jerseyCustomizationOptions' => $jerseyCustomizationOptions,
            'worldCupCustomizationOptions' => $worldCupCustomizationOptions,
            'sizeOptionGroups' => $sizeOptionGroups,
            'productionMethodOptions' => $productionMethodOptions,
            'shippingMethodOptions' => $shippingMethodOptions,
            'faqOptions' => $faqOptions,
            'genderOptions' => $genderOptions,
        ]);
    }

    private function relations(): array
    {
        return [
            'category', 'subcategory', 'gender', 'categories', 'attributeValues.attribute', 'images', 'optionGroups.values', 'sizeGroups.sizes', 'sizeGroups.masterGroup',
            'priceTiers', 'fabricPriceTables.tiers', 'artworkMethods', 'productionSpeeds.productionMethod', 'shippingMethods', 'faqs',
        ];
    }

    private function flushProductCaches(): void
    {
        $this->categoryTreeService->flushCache();
        $this->productCatalogCache->flush();

        // Notify an already-open storefront tab immediately after the admin
        // creates, updates, deletes, or bulk-changes products. The storefront
        // also polls as a fallback for changes made from another browser.
        if (request()->hasSession()) {
            request()->session()->flash('storefront_catalog_changed_at', (string) now()->getTimestampMs());
        }
    }

    /**
     * @param array<string, mixed> $data
     * @return array<int, string>|null
     */
    private function normalizedTags(ProductFormRequest $request, array $data, ?Product $product): ?array
    {
        if ($request->exists('tags_text')) {
            $rawTags = $data['tags_text'] ?? '';
        } elseif ($request->exists('tags')) {
            $rawTags = $data['tags'] ?? $request->input('tags', '');
        } elseif ($request->exists('tag')) {
            $rawTags = $request->input('tag', '');
        } elseif ($product === null) {
            $rawTags = '';
        } else {
            return null;
        }

        if (is_array($rawTags)) {
            $items = $rawTags;
        } else {
            $rawText = trim((string) $rawTags);
            $decoded = json_decode($rawText, true);
            $items = is_array($decoded) ? $decoded : (preg_split('/[,;\r\n]+/', $rawText) ?: []);
        }

        return collect($items)
            ->map(fn ($tag): string => trim((string) $tag))
            ->map(fn (string $tag): string => ltrim(trim($tag), '#'))
            ->filter()
            ->unique(fn (string $tag): string => Str::lower($tag))
            ->values()
            ->all();
    }

    private function productPayload(ProductFormRequest $request, ?Product $product): array
    {
        $data = $request->validated();

        $payload = Arr::only($data, [
            'category_id', 'subcategory_id', 'name', 'slug', 'sku', 'status', 'product_type', 'gender_id', 'product_profile', 'brand',
            'badge_label', 'badge_color', 'short_description', 'base_price', 'compare_at_price',
            'cost_price', 'currency', 'rating_average', 'reviews_count', 'recent_viewers_count',
            'favorites_count', 'recent_orders_count', 'minimum_quantity', 'maximum_quantity', 'is_featured',
            'is_customizable', 'is_active', 'track_inventory', 'stock_quantity', 'low_stock_threshold',
            'allow_backorder', 'weight', 'shipping_class', 'production_methods_enabled', 'shipping_methods_enabled', 'jersey_roster_enabled',
            'jersey_roster_optional', 'jersey_roster_title', 'sample_available', 'sample_charge', 'artwork_upload_enabled',
            'artwork_upload_required', 'artwork_upload_title', 'artwork_upload_description',
            'artwork_upload_max_files', 'artwork_upload_max_file_size_mb',
            'artwork_upload_accepted_types', 'tax_class', 'price_table_highlight_column',
            'price_table_note', 'production_table_headers', 'production_table_rows', 'meta_title', 'meta_description', 'meta_keywords', 'canonical_url',
            'og_title', 'og_description', 'og_image_url', 'robots_index', 'robots_follow',
            'sort_order', 'published_at',
        ]);

        if (array_key_exists('badge_label', $payload)) {
            $badgeLabel = trim((string) ($payload['badge_label'] ?? ''));
            $payload['badge_label'] = $badgeLabel !== '' ? $badgeLabel : null;
        }

        foreach (['rating_average', 'reviews_count', 'recent_viewers_count', 'favorites_count', 'recent_orders_count'] as $metricField) {
            if (! Schema::hasColumn('products', $metricField)) {
                unset($payload[$metricField]);
                continue;
            }

            if (array_key_exists($metricField, $payload) && $payload[$metricField] === '') {
                $payload[$metricField] = null;
            }
        }

        $primaryCategoryId = (bool) ($data['show_in_category_page'] ?? true)
            ? ($data['primary_category_id'] ?? null)
            : null;
        $primaryCategory = $primaryCategoryId ? Category::query()->leaf()->find($primaryCategoryId) : null;
        $rootCategoryId = $primaryCategory
            ? (int) (DB::table('category_closure')
                ->where('descendant_id', $primaryCategory->id)
                ->orderByDesc('depth')
                ->value('ancestor_id') ?: $primaryCategory->id)
            : null;
        $payload['category_id'] = $rootCategoryId;
        $payload['subcategory_id'] = $primaryCategory && $rootCategoryId !== (int) $primaryCategory->id
            ? (int) $primaryCategory->id
            : null;

        $payload['description_html'] = $this->safeHtml->sanitize($data['description_html'] ?? null);
        $payload['customization_artwork_html'] = $this->safeHtml->sanitize($data['customization_artwork_html'] ?? null);
        $payload['fulfillment_html'] = $this->safeHtml->sanitize($data['fulfillment_html'] ?? null);
        $payload['detail_information_html'] = null;

        // The storefront-aligned editor intentionally omits legacy fields that are
        // not rendered on the product page. Preserve their existing values during
        // an update instead of silently clearing them.
        if ($request->exists('features')) {
            $payload['features'] = collect($data['features'] ?? [])->map(fn ($item) => trim((string) $item))->filter()->values()->all();
        } elseif ($product === null) {
            $payload['features'] = [];
        }

        if ($product === null) {
            $payload['specifications'] = [];
        }

        if ($request->exists('length') || $request->exists('width') || $request->exists('height')) {
            $payload['dimensions'] = array_filter([
                'length' => $data['length'] ?? null,
                'width' => $data['width'] ?? null,
                'height' => $data['height'] ?? null,
            ], fn ($value) => $value !== null && $value !== '');
        } elseif ($product === null) {
            $payload['dimensions'] = [];
        }

        $tags = $this->normalizedTags($request, $data, $product);
        if ($tags !== null) {
            $payload['tags'] = $tags;
        }
        $payload['sample_available'] = (bool) ($data['sample_available'] ?? false);
        $payload['sample_charge'] = max(0, round((float) ($data['sample_charge'] ?? 0), 2));

        if (! (bool) ($payload['artwork_upload_enabled'] ?? false)) {
            $payload['artwork_upload_required'] = false;
        }
        $payload['artwork_upload_title'] = filled($data['artwork_upload_title'] ?? null)
            ? trim((string) $data['artwork_upload_title'])
            : 'Upload Custom Artwork';
        $payload['artwork_upload_description'] = filled($data['artwork_upload_description'] ?? null)
            ? trim((string) $data['artwork_upload_description'])
            : 'Upload one or more artwork files for the production team.';
        $payload['artwork_upload_max_files'] = max(1, min(12, (int) ($data['artwork_upload_max_files'] ?? 5)));
        $payload['artwork_upload_max_file_size_mb'] = max(1, min(25, (int) ($data['artwork_upload_max_file_size_mb'] ?? 15)));
        $payload['artwork_upload_accepted_types'] = collect(explode(',', (string) ($data['artwork_upload_accepted_types'] ?? 'pdf,svg,png,jpg,jpeg,webp')))
            ->map(fn ($type) => Str::lower(ltrim(trim((string) $type), '.')))
            ->filter(fn ($type) => in_array($type, ['pdf', 'svg', 'png', 'jpg', 'jpeg', 'webp'], true))
            ->unique()->values()->implode(',');
        if ($payload['artwork_upload_accepted_types'] === '') {
            $payload['artwork_upload_accepted_types'] = 'pdf,svg,png,jpg,jpeg,webp';
        }
        $payload['price_table_headers'] = collect($data['price_table_headers'] ?? [])->map(fn ($value) => trim((string) $value))->filter()->values()->all();
        $headerCount = count($payload['price_table_headers']);
        $payload['price_table_rows'] = collect($data['price_table_rows'] ?? [])->map(function ($row) use ($headerCount) {
            $cells = collect($row)->take($headerCount ?: 20)->map(fn ($cell) => trim((string) $cell))->values()->all();
            return array_pad($cells, $headerCount, '');
        })->filter(fn ($row) => collect($row)->filter()->isNotEmpty())->values()->all();
        $payload['production_table_headers'] = collect($data['production_table_headers'] ?? [])
            ->map(fn ($value) => trim((string) $value))
            ->filter()
            ->take(12)
            ->values()
            ->all();
        $productionColumnCount = count($payload['production_table_headers']);
        $payload['production_table_rows'] = collect($data['production_table_rows'] ?? [])
            ->map(function ($row) use ($productionColumnCount): array {
                $row = is_array($row) ? $row : [];
                $cells = collect($row['cells'] ?? [])->take($productionColumnCount)->map(function ($cell): array {
                    $productionTime = ProductionTime::parse($cell['production_time'] ?? null);
                    if ($productionTime === null && (array_key_exists('minimum_days', $cell) || array_key_exists('maximum_days', $cell))) {
                        $productionTime = ProductionTime::parse(ProductionTime::format(
                            $cell['minimum_days'] ?? 0,
                            $cell['maximum_days'] ?? ($cell['minimum_days'] ?? 0)
                        ));
                    }

                    return [
                        'enabled' => (bool) ($cell['enabled'] ?? false),
                        'description' => filled($cell['description'] ?? null) ? trim((string) $cell['description']) : null,
                        'price_adjustment' => max(0, round((float) ($cell['price_adjustment'] ?? 0), 2)),
                        'production_time' => $productionTime['display'] ?? '',
                        'minimum_days' => $productionTime['minimum_days'] ?? 0,
                        'maximum_days' => $productionTime['maximum_days'] ?? 0,
                    ];
                })->values()->all();

                return [
                    'range' => trim((string) ($row['range'] ?? '')),
                    'cells' => array_pad($cells, $productionColumnCount, [
                        'enabled' => false,
                        'description' => null,
                        'price_adjustment' => 0,
                        'production_time' => '',
                        'minimum_days' => 0,
                        'maximum_days' => 0,
                    ]),
                ];
            })
            ->filter(fn (array $row): bool => $row['range'] !== '' || collect($row['cells'])->contains(fn (array $cell): bool => $cell['enabled']))
            ->take(100)
            ->values()
            ->all();
        $payload['jersey_roster_fields'] = collect($data['jersey_roster_fields'] ?? [])
            ->filter(fn ($field) => (bool) ($field['enabled'] ?? false) && filled($field['key'] ?? null) && filled($field['label'] ?? null))
            ->map(fn ($field) => [
                'key' => Str::slug((string) $field['key'], '_'),
                'label' => trim((string) $field['label']),
                'type' => in_array(($field['type'] ?? 'text'), ['text', 'number'], true) ? $field['type'] : 'text',
                'required' => (bool) ($field['required'] ?? false),
                'enabled' => true,
                'max_length' => max(1, min(120, (int) ($field['max_length'] ?? 60))),
            ])->unique('key')->values()->all();
        if ($request->exists('schema_json_text')) {
            $payload['schema_json'] = filled($data['schema_json_text'] ?? null)
                ? json_decode($data['schema_json_text'], true, 512, JSON_THROW_ON_ERROR)
                : null;
        } elseif ($product === null) {
            $payload['schema_json'] = null;
        }

        $payload['created_by'] = $product?->created_by ?? auth('admin')->id();
        $payload['updated_by'] = auth('admin')->id();

        return $payload;
    }

    private function syncProductSpecifications(Product $product, ProductFormRequest $request): void
    {
        $data = $request->validated();

        $product->forceFill([
            'specifications' => $this->buildProductSpecifications(
                $product,
                (string) ($data['product_specification_text'] ?? '')
            ),
            // Keep the frontend specification table driven by structured rows.
            // Old rich HTML is cleared so it cannot override the new Product Specification field.
            'detail_information_html' => null,
        ])->save();
    }

    private function buildProductSpecifications(Product $product, string $specificationText): array
    {
        $manualRows = $this->parseProductSpecificationText($specificationText);
        $autoRows = $this->productSpecificationAutoRows($product);
        $fabricLikeLabels = $this->fabricLikeSpecificationLabels();
        $fabricDisplayLabel = $this->preferredFabricSpecificationLabel($manualRows);
        $templateLabels = ['SKU', 'Product Type', $fabricDisplayLabel, 'Fit', 'Customization', 'Size Range', 'MOQ', 'Lead Time'];
        $result = [];

        foreach ($templateLabels as $label) {
            $manualValue = $this->specificationValueForLabel($manualRows, $label);
            $autoValue = $this->isFabricLikeSpecificationLabel($label)
                ? trim((string) ($autoRows['Fabric'] ?? ''))
                : trim((string) ($autoRows[$label] ?? ''));
            $finalValue = $manualValue !== '' ? $manualValue : $autoValue;

            if ($finalValue !== '') {
                $result[$label] = $finalValue;
            }
        }

        foreach ($manualRows as $label => $value) {
            $label = trim((string) $label);
            $value = trim((string) $value);

            if ($label === '' || $value === '') {
                continue;
            }

            if (in_array($label, $templateLabels, true)) {
                continue;
            }

            // Fabric, Material, Materials and common misspellings are the same specification slot.
            // Keep the user's chosen label, but never append another fabric-like row later.
            if ($this->isFabricLikeSpecificationLabel($label)) {
                continue;
            }

            $result[$label] = $value;
        }

        return collect($result)->take(100)->all();
    }

    private function fabricLikeSpecificationLabels(): array
    {
        return ['Fabric', 'Material', 'Materials', 'Metarial', 'Metarials', 'Meterial', 'Meterials'];
    }

    private function isFabricLikeSpecificationLabel(?string $label): bool
    {
        return in_array($this->normalizeSpecificationLabel($label), $this->fabricLikeSpecificationLabels(), true);
    }

    private function preferredFabricSpecificationLabel(array $rows): string
    {
        foreach ($this->fabricLikeSpecificationLabels() as $label) {
            if (trim((string) ($rows[$label] ?? '')) !== '') {
                return $label;
            }
        }

        return 'Fabric';
    }

    private function specificationValueForLabel(array $rows, string $label): string
    {
        $value = trim((string) ($rows[$label] ?? ''));

        if ($value !== '' || ! $this->isFabricLikeSpecificationLabel($label)) {
            return $value;
        }

        foreach ($this->fabricLikeSpecificationLabels() as $fabricLikeLabel) {
            $value = trim((string) ($rows[$fabricLikeLabel] ?? ''));
            if ($value !== '') {
                return $value;
            }
        }

        return '';
    }

    private function parseProductSpecificationText(string $specificationText): array
    {
        $knownLabels = ['SKU', 'Product Type', 'Fabric', 'Material', 'Materials', 'Metarial', 'Metarials', 'Meterial', 'Meterials', 'Fabric GSM', 'GSM', 'Width', 'Fit', 'Customization', 'Imprint Method', 'Attachment', 'Size Range', 'MOQ', 'Lead Time', 'Shipping Time', 'Usage', 'Standard Length'];
        $rows = collect();

        if (str_contains($specificationText, '<')) {
            $tableHtml = preg_replace('/<\/(tr|p|div|li)>/i', "\n", $specificationText) ?? $specificationText;
            $tableHtml = preg_replace('/<\/(td|th)>/i', "\t", $tableHtml) ?? $tableHtml;
            $specificationText = html_entity_decode(strip_tags($tableHtml), ENT_QUOTES | ENT_HTML5, 'UTF-8');
        }

        $lines = collect(preg_split('/\r\n|\r|\n/', $specificationText) ?: [])
            ->map(fn ($line) => $this->cleanSpecificationText($line))
            ->filter();

        foreach ($lines as $line) {
            if (preg_match('/^(detail|information|detail\s+information)$/i', $line)) {
                continue;
            }

            $flatRows = $this->parseFlatProductSpecificationText($line, $knownLabels);
            if (count($flatRows) > 1) {
                foreach ($flatRows as $label => $value) {
                    $rows->put($label, $value);
                }
                continue;
            }

            $tabParts = collect(preg_split('/\t+/', $line) ?: [])
                ->map(fn ($part) => $this->cleanSpecificationText($part))
                ->filter()
                ->values();

            if ($tabParts->count() >= 2) {
                $label = $this->normalizeSpecificationLabel($tabParts->first());
                $value = $this->cleanSpecificationText($tabParts->slice(1)->implode(' '));

                if ($label !== '' && ! in_array(Str::lower($label), ['detail', 'information'], true)) {
                    $rows->put($label, $value);
                    continue;
                }
            }

            if (str_contains($line, ':')) {
                [$label, $value] = array_pad(explode(':', $line, 2), 2, '');
                $label = $this->normalizeSpecificationLabel($label);
                $value = $this->cleanSpecificationText($value);

                if ($label !== '') {
                    $rows->put($label, $value);
                }

                continue;
            }

            foreach ($knownLabels as $knownLabel) {
                if (preg_match('/^'.preg_quote($knownLabel, '/').'\b\s*(.*)$/i', $line, $matches)) {
                    $rows->put($knownLabel, $this->cleanSpecificationText($matches[1] ?? ''));
                    continue 2;
                }
            }
        }

        if ($rows->isEmpty()) {
            foreach ($this->parseFlatProductSpecificationText($specificationText, $knownLabels) as $label => $value) {
                $rows->put($label, $value);
            }
        }

        return $rows
            ->filter(fn ($value, $label) => filled($label))
            ->map(fn ($value) => $this->cleanSpecificationText($value))
            ->all();
    }

    private function cleanSpecificationText(?string $value): string
    {
        return trim(preg_replace('/[ \t]+/', ' ', str_replace("\xc2\xa0", ' ', (string) $value)) ?? '');
    }

    /**
     * Splits compact pasted text such as
     * "SKU: ABCProduct Type: JerseyFabric: Polyester" back into rows.
     */
    private function parseFlatProductSpecificationText(string $text, array $knownLabels): array
    {
        $flatText = $this->cleanSpecificationText($text);
        if ($flatText === '') {
            return [];
        }

        $labelPattern = collect($knownLabels)->map(fn ($label) => preg_quote($label, '/'))->implode('|');
        if (! preg_match_all('/('.$labelPattern.')\s*:/i', $flatText, $matches, PREG_OFFSET_CAPTURE)) {
            return [];
        }

        $rows = [];
        $labelMatches = $matches[1];
        foreach ($labelMatches as $index => $match) {
            $label = $this->normalizeSpecificationLabel($match[0]);
            $start = $match[1] + strlen($match[0]);
            $end = isset($labelMatches[$index + 1]) ? $labelMatches[$index + 1][1] : strlen($flatText);
            $value = substr($flatText, $start, max(0, $end - $start));
            $value = preg_replace('/^\s*:\s*/', '', $value) ?? $value;

            if ($label !== '') {
                $rows[$label] = $this->cleanSpecificationText($value);
            }
        }

        return $rows;
    }

    private function normalizeSpecificationLabel(?string $label): string
    {
        $clean = Str::of($this->cleanSpecificationText($label))->rtrim(':')->trim()->toString();
        $lookup = Str::lower($clean);

        $aliases = [
            'sku' => 'SKU',
            'style no' => 'SKU',
            'style number' => 'SKU',
            'product type' => 'Product Type',
            'product' => 'Product Type',
            'fabric' => 'Fabric',
            'fabric gsm' => 'Fabric GSM',
            'fabric weight' => 'Fabric GSM',
            'gsm' => 'GSM',
            'material' => 'Material',
            'materials' => 'Materials',
            'metarial' => 'Metarial',
            'metarials' => 'Metarials',
            'meterial' => 'Meterial',
            'meterials' => 'Meterials',
            'fit' => 'Fit',
            'width' => 'Width',
            'customization' => 'Customization',
            'customisation' => 'Customization',
            'printing' => 'Customization',
            'print method' => 'Customization',
            'imprint method' => 'Imprint Method',
            'decoration' => 'Customization',
            'attachment' => 'Attachment',
            'size range' => 'Size Range',
            'sizes' => 'Size Range',
            'size' => 'Size Range',
            'moq' => 'MOQ',
            'minimum order' => 'MOQ',
            'minimum order quantity' => 'MOQ',
            'lead time' => 'Lead Time',
            'lead-time' => 'Lead Time',
            'production time' => 'Lead Time',
            'shipping time' => 'Shipping Time',
            'usage' => 'Usage',
            'standard length' => 'Standard Length',
        ];

        return $aliases[$lookup] ?? Str::headline($clean);
    }

    private function productSpecificationAutoRows(Product $product): array
    {
        return [
            'SKU' => $product->sku,
            'Product Type' => $product->product_type,
            'Fabric' => collect(JerseyCustomizationType::fabricTypeValues())
                ->map(fn (string $type): ?string => $this->optionValueSummary($product, $type))
                ->filter()
                ->implode(', '),
            'Fit' => collect([
                $this->optionValueSummary($product, JerseyCustomizationType::JerseyStyle->value),
                $this->optionValueSummary($product, JerseyCustomizationType::SleevesAndCuffs->value),
            ])->filter()->implode(', '),
            'Customization' => null,
            'Size Range' => $this->sizeRangeSummary($product),
            'MOQ' => $product->minimum_quantity
                ? number_format((int) $product->minimum_quantity).' '.((int) $product->minimum_quantity === 1 ? 'Piece' : 'Pieces')
                : null,
            'Lead Time' => $this->leadTimeSummary($product),
        ];
    }

    private function optionValueSummary(Product $product, string $type): ?string
    {
        if (! $product->relationLoaded('optionGroups')) {
            return null;
        }

        $values = $product->optionGroups
            ->where('jersey_customization_type', $type)
            ->where('is_active', true)
            ->flatMap(fn ($group) => $group->relationLoaded('values')
                ? $group->values->where('is_active', true)->pluck('label')
                : [])
            ->filter()
            ->unique()
            ->values();

        return $values->isNotEmpty() ? $values->implode(', ') : null;
    }

    private function sizeRangeSummary(Product $product): ?string
    {
        if (! $product->relationLoaded('sizeGroups')) {
            return null;
        }

        $group = $product->sizeGroups->where('is_active', true)->first();
        if (! $group || ! $group->relationLoaded('sizes')) {
            return null;
        }

        $sizes = $group->sizes->where('is_active', true)->pluck('label')->filter()->values();
        if ($sizes->isEmpty()) {
            return null;
        }

        return $sizes->first() === $sizes->last()
            ? $sizes->first()
            : $sizes->first().' – '.$sizes->last();
    }

    private function leadTimeSummary(Product $product): ?string
    {
        if ($product->relationLoaded('productionSpeeds')) {
            $speeds = $product->productionSpeeds->where('is_active', true);
            if ($speeds->isNotEmpty()) {
                $min = (int) $speeds->min('minimum_days');
                $max = (int) $speeds->max('maximum_days');

                if ($min > 0 || $max > 0) {
                    return $min === $max ? $min.' Business Days' : $min.'–'.$max.' Business Days';
                }
            }
        }

        $times = collect($product->production_table_rows ?? [])
            ->flatMap(fn ($row) => collect($row['cells'] ?? []))
            ->filter(fn ($cell) => (bool) ($cell['enabled'] ?? false))
            ->map(fn ($cell) => [
                'minimum_days' => (int) ($cell['minimum_days'] ?? 0),
                'maximum_days' => (int) ($cell['maximum_days'] ?? ($cell['minimum_days'] ?? 0)),
            ])
            ->filter(fn ($cell) => $cell['minimum_days'] > 0 || $cell['maximum_days'] > 0);

        if ($times->isEmpty()) {
            return null;
        }

        $min = (int) $times->min('minimum_days');
        $max = (int) $times->max('maximum_days');

        return $min === $max ? $min.' Business Days' : $min.'–'.$max.' Business Days';
    }

    private function syncRelations(Product $product, ProductFormRequest $request): void
    {
        $data = $request->validated();
        $this->syncCatalogAssignments($product, $data);
        $this->syncImages($product, $request, $data);

        $existingOptionMedia = $product->optionGroups()
            ->with('values:id,product_option_group_id,jersey_customization_option_id,world_cup_customization_option_id,image_path,image_url,image_gallery')
            ->get()
            ->flatMap(fn ($group) => $group->values)
            ->mapWithKeys(fn ($value) => [(int) $value->id => [
                'jersey_master_id' => $value->jersey_customization_option_id,
                'world_cup_master_id' => $value->world_cup_customization_option_id,
                'path' => $value->image_path,
                'url' => $value->image_url,
                'gallery' => $value->image_gallery ?? [],
            ]])
            ->all();

        $submittedMasterOptionIds = collect($data['option_groups'] ?? [])
            ->flatMap(static fn ($group): array => collect($group['values'] ?? [])
                ->pluck('jersey_customization_option_id')
                ->filter()
                ->map(static fn ($id): int => (int) $id)
                ->all())
            ->unique()
            ->values();

        $submittedWorldCupOptionIds = collect($data['option_groups'] ?? [])
            ->flatMap(static fn ($group): array => collect($group['values'] ?? [])
                ->pluck('world_cup_customization_option_id')
                ->filter()
                ->map(static fn ($id): int => (int) $id)
                ->all())
            ->unique()
            ->values();

        $worldCupMasterOptions = WorldCupCustomizationOption::query()
            ->active()
            ->with(['images:id,world_cup_customization_option_id,name,image_path,image_url,is_primary,sort_order'])
            ->whereIn('id', $submittedWorldCupOptionIds)
            ->get(['id', 'category_key', 'type', 'name', 'slug', 'description'])
            ->keyBy('id');

        $masterOptions = JerseyCustomizationOption::query()
            ->active()
            ->with(['images:id,jersey_customization_option_id,name,image_path,image_url,is_primary,sort_order'])
            ->whereIn('id', $submittedMasterOptionIds)
            ->get(['id', 'type', 'name', 'slug', 'description', 'color_hex'])
            ->keyBy('id');

        $product->optionGroups()->delete();
        $groupSortOrder = 0;

        foreach (collect($data['option_groups'] ?? [])->filter(fn ($group) => filled($group['name'] ?? null) && filled($group['code'] ?? null)) as $groupInputIndex => $groupData) {
            $group = $product->optionGroups()->create([
                'name' => trim((string) $groupData['name']),
                'code' => trim((string) $groupData['code']),
                'section' => $groupData['section'] ?? 'product',
                'type' => $groupData['type'] ?? 'select',
                'jersey_customization_type' => filled($groupData['jersey_customization_type'] ?? null) ? $groupData['jersey_customization_type'] : null,
                'display_mode' => $groupData['display_mode'] ?? 'customer',
                'fixed_value_code' => filled($groupData['fixed_value_code'] ?? null) ? trim((string) $groupData['fixed_value_code']) : null,
                'fixed_text_value' => filled($groupData['fixed_text_value'] ?? null) ? trim((string) $groupData['fixed_text_value']) : null,
                'show_in_summary' => (bool) ($groupData['show_in_summary'] ?? true),
                'use_as_filter' => (bool) ($groupData['use_as_filter'] ?? false),
                'catalog_attribute_id' => null,
                'description' => $groupData['description'] ?? null,
                'placeholder' => $groupData['placeholder'] ?? null,
                'is_required' => (bool) ($groupData['is_required'] ?? false),
                'minimum_selections' => $groupData['minimum_selections'] ?? null,
                'maximum_selections' => $groupData['maximum_selections'] ?? null,
                'accepted_file_types' => $groupData['accepted_file_types'] ?? null,
                'maximum_file_size_mb' => $groupData['maximum_file_size_mb'] ?? null,
                'is_active' => (bool) ($groupData['is_active'] ?? true),
                'sort_order' => $groupSortOrder++,
            ]);

            $valueSortOrder = 0;

            foreach (collect($groupData['values'] ?? [])->filter(fn ($value) => filled($value['label'] ?? null) && filled($value['code'] ?? null)) as $valueInputIndex => $valueData) {
                $masterOptionId = (int) ($valueData['jersey_customization_option_id'] ?? 0);
                $worldCupMasterOptionId = (int) ($valueData['world_cup_customization_option_id'] ?? 0);
                $legacyMasterOption = $masterOptionId > 0 ? $masterOptions->get($masterOptionId) : null;
                $worldCupMasterOption = $worldCupMasterOptionId > 0 ? $worldCupMasterOptions->get($worldCupMasterOptionId) : null;
                $masterOption = $worldCupMasterOption ?: $legacyMasterOption;
                $masterSource = $worldCupMasterOption ? 'world_cup' : ($legacyMasterOption ? 'jersey' : null);
                $existingId = (int) ($valueData['existing_id'] ?? 0);
                $existing = $existingOptionMedia[$existingId] ?? [
                    'jersey_master_id' => null,
                    'world_cup_master_id' => null,
                    'path' => null,
                    'url' => null,
                    'gallery' => [],
                ];

                if ($masterOption) {
                    $label = $masterOption->name;
                    $code = $masterOption->slug;
                    $description = $masterOption->description;
                    $colorHex = $masterSource === 'jersey' ? $masterOption->color_hex : null;

                    if (($masterSource === 'world_cup'
                        ? (int) ($existing['world_cup_master_id'] ?? 0)
                        : (int) ($existing['jersey_master_id'] ?? 0)) === (int) $masterOption->id && ! empty($existing['gallery'])) {
                        $gallery = collect($existing['gallery'])->filter(fn ($item) => is_array($item))->values()->all();
                    } else {
                        $gallery = $masterOption->images
                            ->map(function ($image) use ($product, $masterOption, $masterSource): array {
                                $path = null;
                                if (filled($image->image_path) && Storage::disk('public')->exists($image->image_path)) {
                                    $extension = pathinfo($image->image_path, PATHINFO_EXTENSION);
                                    $path = "products/{$product->id}/options/"
                                        .($masterSource === 'world_cup' ? "world-cup-master-{$masterOption->id}-" : "master-{$masterOption->id}-").Str::uuid()
                                        .($extension !== '' ? ".{$extension}" : '');
                                    Storage::disk('public')->copy($image->image_path, $path);
                                }

                                return [
                                    'path' => $path,
                                    'url' => $path ? null : $image->image_url,
                                    'alt' => $image->name ?: $masterOption->name,
                                ];
                            })
                            ->filter(fn (array $image): bool => filled($image['path']) || filled($image['url']))
                            ->values()
                            ->all();
                    }
                } else {
                    // Compatibility for products created before master-data assignment.
                    $label = trim((string) $valueData['label']);
                    $code = trim((string) $valueData['code']);
                    $description = $valueData['description'] ?? null;
                    $colorHex = $valueData['color_hex'] ?? null;
                    $gallery = (bool) ($valueData['clear_images'] ?? false)
                        ? []
                        : collect($existing['gallery'] ?? [])->filter(fn ($item) => is_array($item))->values()->all();

                    if ($gallery === []) {
                        if (filled($existing['path'] ?? null)) {
                            $gallery[] = ['path' => $existing['path'], 'url' => null, 'alt' => $label];
                        } elseif (filled($existing['url'] ?? null)) {
                            $gallery[] = ['path' => null, 'url' => $existing['url'], 'alt' => $label];
                        }
                    }

                    $imageUrl = filled($valueData['image_url'] ?? null) ? trim((string) $valueData['image_url']) : null;
                    if ($imageUrl && ! collect($gallery)->contains(fn ($item) => ($item['url'] ?? null) === $imageUrl)) {
                        $gallery[] = ['path' => null, 'url' => $imageUrl, 'alt' => $label];
                    }

                    $uploads = (array) $request->file("option_groups.{$groupInputIndex}.values.{$valueInputIndex}.image_files", []);
                    $legacyUpload = $request->file("option_groups.{$groupInputIndex}.values.{$valueInputIndex}.image_file");
                    if ($legacyUpload) {
                        $uploads[] = $legacyUpload;
                    }

                    foreach ($uploads as $uploadedImage) {
                        $gallery[] = [
                            'path' => $uploadedImage->store("products/{$product->id}/options", 'public'),
                            'url' => null,
                            'alt' => $label,
                        ];
                    }
                }

                $gallery = collect($gallery)->take(12)->values()->all();
                $firstImage = $gallery[0] ?? [];

                $group->values()->create([
                    'jersey_customization_option_id' => $masterSource === 'jersey' ? $masterOption?->id : null,
                    'world_cup_customization_option_id' => $masterSource === 'world_cup' ? $masterOption?->id : null,
                    'label' => $label,
                    'code' => $code,
                    'description' => $description,
                    'color_hex' => $colorHex,
                    'image_path' => $firstImage['path'] ?? null,
                    'image_url' => $firstImage['url'] ?? null,
                    'image_gallery' => $gallery,
                    'price_adjustment' => $valueData['price_adjustment'] ?? 0,
                    'charge_type' => $valueData['charge_type'] ?? 'per_unit',
                    'stock_quantity' => $valueData['stock_quantity'] ?? null,
                    'is_default' => (bool) ($valueData['is_default'] ?? false),
                    'is_active' => (bool) ($valueData['is_active'] ?? true),
                    'sort_order' => $valueSortOrder++,
                ]);
            }
        }

        $this->syncFabricPriceTables($product, $data);

        $this->productOptionFilterSyncService->sync(
            $product,
            collect($data['attribute_value_ids'] ?? [])->map(fn ($id) => (int) $id)->all()
        );

        $submittedSizeGroups = collect($data['size_groups'] ?? [])->values();
        $sizeMasters = SizeOptionGroup::query()
            ->with(['sizes' => fn ($query) => $query->where('is_active', true)->orderBy('sort_order')])
            ->whereIn('id', $submittedSizeGroups->pluck('size_option_group_id')->filter()->map(fn ($id) => (int) $id)->unique())
            ->get()
            ->keyBy('id');

        $existingSizeMedia = $product->sizeGroups()
            ->get(['id', 'chart_image_path', 'chart_image_url'])
            ->mapWithKeys(fn ($group) => [(int) $group->id => [
                'path' => $group->chart_image_path,
                'url' => $group->chart_image_url,
            ]])->all();

        $product->sizeGroups()->delete();
        $sizeSortOrder = 0;
        foreach ($submittedSizeGroups as $groupInputIndex => $groupData) {
            $masterId = (int) ($groupData['size_option_group_id'] ?? 0);
            $master = $masterId > 0 ? $sizeMasters->get($masterId) : null;

            if ($master) {
                $group = $product->sizeGroups()->create([
                    'size_option_group_id' => $master->id,
                    'name' => $master->name,
                    'code' => $master->slug,
                    'description_html' => $master->description_html,
                    'chart_enabled' => filled($master->chart_html) || filled($master->chartImageUrl()),
                    'chart_html' => $master->chart_html,
                    'chart_title' => $master->chart_title,
                    'chart_note' => $master->chart_note,
                    'chart_columns' => $master->chart_columns ?? [],
                    'chart_rows' => $master->chart_rows ?? [],
                    'chart_image_path' => null,
                    'chart_image_url' => $master->chartImageUrl(),
                    'is_active' => true,
                    'sort_order' => $sizeSortOrder++,
                ]);

                $sizePriceAdjustments = ProductSizeExtraCharges::adjustments($groupData);
                $hasSizeExtraCharges = ProductSizeExtraCharges::enabled($groupData);
                foreach ($master->sizes as $sizeIndex => $size) {
                    $group->sizes()->create([
                        'label' => $size->label,
                        'code' => $size->code,
                        'price_adjustment' => $hasSizeExtraCharges
                            ? ProductSizeExtraCharges::amountFor($sizePriceAdjustments, (string) $size->code, (string) $size->label)
                            : 0,
                        'sort_order' => $sizeIndex,
                        'is_active' => true,
                    ]);
                }

                continue;
            }

            // Backward compatibility for products that still contain a legacy
            // product-specific size group created before master data was added.
            if (! filled($groupData['name'] ?? null) || ! filled($groupData['code'] ?? null)) {
                continue;
            }

            $existingId = (int) ($groupData['existing_id'] ?? 0);
            $existingMedia = $existingSizeMedia[$existingId] ?? ['path' => null, 'url' => null];
            $chartImageUrl = filled($groupData['chart_image_url'] ?? null) ? trim((string) $groupData['chart_image_url']) : null;
            $chartImagePath = $chartImageUrl ? null : ($existingMedia['path'] ?? null);
            if ((bool) ($groupData['clear_chart_image'] ?? false)) {
                $chartImagePath = null;
                $chartImageUrl = null;
            }
            if ($chartImage = $request->file("size_groups.{$groupInputIndex}.chart_image")) {
                $chartImagePath = $chartImage->store("products/{$product->id}/size-charts", 'public');
                $chartImageUrl = null;
            } elseif (! $chartImageUrl && ! $chartImagePath && filled($existingMedia['url'] ?? null)) {
                $chartImageUrl = $existingMedia['url'];
            }

            $columns = collect(preg_split('/[,\r\n]+/', (string) ($groupData['chart_columns_text'] ?? '')))
                ->map(fn ($column) => trim((string) $column))->filter()->take(12)->values()->all();
            $rows = $this->parseChartRows((string) ($groupData['chart_rows_text'] ?? ''), count($columns));

            $group = $product->sizeGroups()->create([
                'size_option_group_id' => null,
                'name' => trim((string) $groupData['name']),
                'code' => trim((string) $groupData['code']),
                'description_html' => $this->safeHtml->sanitize($groupData['description_html'] ?? null),
                'chart_html' => $this->safeHtml->sanitize($groupData['chart_html'] ?? null),
                'chart_enabled' => (bool) ($groupData['chart_enabled'] ?? false),
                'chart_title' => $groupData['chart_title'] ?? null,
                'chart_note' => $groupData['chart_note'] ?? null,
                'chart_columns' => $columns,
                'chart_rows' => $rows,
                'chart_image_path' => $chartImagePath,
                'chart_image_url' => $chartImageUrl,
                'is_active' => (bool) ($groupData['is_active'] ?? true),
                'sort_order' => $sizeSortOrder++,
            ]);
            $sizes = collect(preg_split('/[,\r\n]+/', (string) ($groupData['sizes_text'] ?? '')))
                ->map(fn ($size) => trim((string) $size))->filter()->unique()->values();
            $sizePriceAdjustments = ProductSizeExtraCharges::adjustments($groupData);
            $hasSizeExtraCharges = ProductSizeExtraCharges::enabled($groupData);
            foreach ($sizes as $sizeIndex => $size) {
                $code = Str::slug($size);
                $group->sizes()->create([
                    'label' => $size,
                    'code' => $code,
                    'price_adjustment' => $hasSizeExtraCharges
                        ? ProductSizeExtraCharges::amountFor($sizePriceAdjustments, $code, (string) $size)
                        : 0,
                    'sort_order' => $sizeIndex,
                    'is_active' => true,
                ]);
            }
        }

        $this->replaceSimpleRelation($product, 'priceTiers', $data['price_tiers'] ?? [], ['minimum_quantity', 'unit_price'], [
            'label', 'minimum_quantity', 'maximum_quantity', 'unit_price', 'compare_at_price', 'savings_label',
        ]);
        // Artwork is now a single configurable multi-file upload section. Remove
        // legacy method cards so stale choices can never reappear on the storefront.
        $product->artworkMethods()->delete();
        $this->replaceSimpleRelation($product, 'productionSpeeds', $data['production_speeds'] ?? [], ['name', 'code'], [
            'production_method_id', 'name', 'code', 'description', 'price_adjustment', 'minimum_quantity', 'maximum_quantity',
            'minimum_days', 'maximum_days', 'is_active',
        ]);
        $this->replaceSimpleRelation($product, 'shippingMethods', $data['shipping_methods'] ?? [], ['name', 'code'], [
            'shipping_method_id', 'name', 'code', 'description', 'price_adjustment', 'charge_type', 'charge_application', 'base_price',
            'per_item_price', 'free_shipping_minimum', 'minimum_days', 'maximum_days',
            'starts_after_artwork_approval', 'is_quote_based', 'is_default', 'is_active',
        ]);
        $faqAssignments = collect($data['faq_ids'] ?? [])
            ->map(fn ($id): int => (int) $id)
            ->filter(fn (int $id): bool => $id > 0)
            ->unique()
            ->values()
            ->mapWithKeys(fn (int $id, int $index): array => [$id => ['sort_order' => $index]])
            ->all();
        $product->faqs()->sync($faqAssignments);
    }

    /**
     * @param array<string, mixed> $data
     */
    private function syncFabricPriceTables(Product $product, array $data): void
    {
        $product->fabricPriceTables()->delete();

        $submittedTables = collect($data['fabric_price_tables'] ?? [])->filter(fn ($table) => is_array($table))->values();
        if ($submittedTables->isEmpty()) {
            return;
        }

        $submittedFabricKeys = collect($data['option_groups'] ?? [])
            ->filter(fn ($group) => is_array($group) && in_array((string) ($group['jersey_customization_type'] ?? ''), JerseyCustomizationType::fabricTypeValues(), true))
            ->flatMap(fn ($group) => collect($group['values'] ?? [])->filter(fn ($value) => is_array($value))->map(fn ($value) => $this->fabricPriceKeyFromInput($value)))
            ->filter()
            ->unique()
            ->values()
            ->all();

        foreach ($submittedTables as $sortOrder => $tableData) {
            if (! filter_var($tableData['has_custom_pricing'] ?? false, FILTER_VALIDATE_BOOLEAN)) {
                continue;
            }

            $fabricKey = trim((string) ($tableData['fabric_key'] ?? '')) ?: $this->fabricPriceKeyFromInput($tableData);
            if ($fabricKey === '') {
                continue;
            }

            if ($submittedFabricKeys !== [] && ! in_array($fabricKey, $submittedFabricKeys, true)) {
                continue;
            }

            $normalized = $this->normalizeFabricPriceTableInput($tableData);
            if ($normalized['tiers'] === []) {
                continue;
            }

            $table = $product->fabricPriceTables()->create([
                'jersey_customization_option_id' => filled($tableData['jersey_customization_option_id'] ?? null) ? (int) $tableData['jersey_customization_option_id'] : null,
                'fabric_key' => $fabricKey,
                'fabric_code' => filled($tableData['fabric_code'] ?? null) ? trim((string) $tableData['fabric_code']) : null,
                'fabric_label' => filled($tableData['fabric_label'] ?? null) ? trim((string) $tableData['fabric_label']) : Str::headline(str_replace(['master:', 'code:'], '', $fabricKey)),
                'price_table_headers' => $normalized['headers'],
                'price_table_rows' => $normalized['rows'],
                'price_table_ranges' => $normalized['ranges'],
                'price_table_highlight_column' => $normalized['highlight_column'],
                'price_table_note' => filled($tableData['price_table_note'] ?? null) ? trim((string) $tableData['price_table_note']) : null,
                'is_active' => true,
                'sort_order' => $sortOrder,
            ]);

            foreach ($normalized['tiers'] as $tierSortOrder => $tierData) {
                $table->tiers()->create(array_merge($tierData, ['sort_order' => $tierSortOrder]));
            }
        }
    }

    /**
     * @param array<string, mixed> $value
     */
    private function fabricPriceKeyFromInput(array $value): string
    {
        $masterId = (int) ($value['jersey_customization_option_id'] ?? 0);
        if ($masterId > 0) {
            return 'master:'.$masterId;
        }

        $code = trim((string) ($value['fabric_code'] ?? $value['code'] ?? $value['fabric_key'] ?? ''));
        if ($code !== '') {
            return 'code:'.Str::slug($code);
        }

        $label = trim((string) ($value['fabric_label'] ?? $value['label'] ?? ''));

        return $label !== '' ? 'code:'.Str::slug($label) : '';
    }

    /**
     * @param array<string, mixed> $tableData
     * @return array{headers: array<int, string>, rows: array<int, array<int, string>>, ranges: array<int, array<string, int|null>>, highlight_column: int, tiers: array<int, array<string, mixed>>}
     */
    private function normalizeFabricPriceTableInput(array $tableData): array
    {
        $rawHeaders = collect($tableData['price_table_headers'] ?? [])
            ->map(fn ($header) => trim((string) $header))
            ->filter()
            ->values();

        if ($rawHeaders->isNotEmpty() && Str::lower((string) $rawHeaders->first()) === 'quantity') {
            $rawHeaders = $rawHeaders->slice(1)->values();
        }

        if ($rawHeaders->isEmpty()) {
            $rawHeaders = collect(['Unit Price ($)']);
        }

        $headers = $rawHeaders->prepend('Quantity')->values()->take(20)->all();
        $highlightColumn = max(1, min((int) ($tableData['price_table_highlight_column'] ?? 1), max(count($headers) - 1, 1)));
        $rawRows = collect($tableData['price_table_rows'] ?? [])->filter(fn ($row) => is_array($row))->values();
        $rangesInput = collect($tableData['price_table_ranges'] ?? [])->values();
        $rows = [];
        $ranges = [];
        $tiers = [];

        foreach ($rawRows as $index => $row) {
            $range = $rangesInput->get($index, []);
            $legacyRange = $this->parseQuantityRangeFromLabel((string) ($row[0] ?? ''));
            $minimum = (int) data_get($range, 'minimum_quantity', $legacyRange['minimum_quantity']);
            $minimum = max($minimum, 1);
            $maximumValue = data_get($range, 'maximum_quantity', $legacyRange['maximum_quantity']);
            $maximum = filled($maximumValue) ? max((int) $maximumValue, $minimum) : null;
            $cells = collect($row)->slice(1)->map(fn ($cell) => trim((string) $cell))->take(count($headers) - 1)->values()->all();
            $cells = array_pad($cells, count($headers) - 1, '');
            $displayRow = array_merge([$this->quantityRangeLabel($minimum, $maximum)], $cells);
            $unitPrice = $this->parseMoney($cells[$highlightColumn - 1] ?? null);

            if ($unitPrice === null) {
                $unitPrice = collect($cells)->map(fn ($cell) => $this->parseMoney($cell))->first(fn ($amount) => $amount !== null);
            }

            $rows[] = $displayRow;
            $ranges[] = ['minimum_quantity' => $minimum, 'maximum_quantity' => $maximum];

            if ($unitPrice !== null) {
                $tiers[] = [
                    'label' => $displayRow[0],
                    'minimum_quantity' => $minimum,
                    'maximum_quantity' => $maximum,
                    'unit_price' => $unitPrice,
                    'compare_at_price' => null,
                    'savings_label' => $cells[$highlightColumn] ?? null,
                ];
            }
        }

        return [
            'headers' => $headers,
            'rows' => $rows,
            'ranges' => $ranges,
            'highlight_column' => $highlightColumn,
            'tiers' => $tiers,
        ];
    }

    /**
     * @return array{minimum_quantity: int, maximum_quantity: int|null}
     */
    private function parseQuantityRangeFromLabel(string $value): array
    {
        preg_match_all('/\d+/', str_replace(',', '', $value), $matches);
        $numbers = collect($matches[0] ?? [])->map(fn ($number) => (int) $number)->values();

        return [
            'minimum_quantity' => $numbers->get(0) ?: 1,
            'maximum_quantity' => str_contains($value, '+') ? null : $numbers->get(1),
        ];
    }

    private function quantityRangeLabel(int $minimum, ?int $maximum): string
    {
        return $maximum ? number_format($minimum).'-'.number_format($maximum) : number_format($minimum).'+';
    }

    private function parseMoney(mixed $value): ?float
    {
        $clean = preg_replace('/[^0-9.\-]/', '', (string) $value);
        if ($clean === '' || $clean === '-' || $clean === '.') {
            return null;
        }

        return round((float) $clean, 2);
    }

    private function parseChartRows(string $value, int $columnCount): array
    {
        return collect(preg_split('/\r\n|\r|\n/', $value))
            ->map(function (string $line) use ($columnCount): array {
                $delimiter = str_contains($line, "\t") ? "\t" : (str_contains($line, '|') ? '|' : ',');
                $cells = collect(explode($delimiter, $line))->map(fn ($cell) => trim((string) $cell))->take($columnCount ?: 12)->values()->all();

                return $columnCount > 0 ? array_pad($cells, $columnCount, '') : $cells;
            })
            ->filter(fn ($row) => collect($row)->filter(fn ($cell) => $cell !== '')->isNotEmpty())
            ->take(100)
            ->values()
            ->all();
    }

    /** @param array<int, array{is_primary:bool,is_featured:bool,sort_order:int}> $assignments */
    private function syncLegacyCategoryColumnsFromLeafAssignments(Product $product, array $assignments): void
    {
        if ($assignments === []) {
            $product->forceFill([
                'category_id' => null,
                'subcategory_id' => null,
            ])->saveQuietly();

            return;
        }

        $primaryLeafId = collect($assignments)
            ->filter(fn (array $pivot): bool => (bool) ($pivot['is_primary'] ?? false))
            ->keys()
            ->map(fn ($id): int => (int) $id)
            ->first();
        $primaryLeafId = $primaryLeafId ?: (int) array_key_first($assignments);

        $rootCategoryId = (int) (DB::table('category_closure')
            ->where('descendant_id', $primaryLeafId)
            ->orderByDesc('depth')
            ->value('ancestor_id') ?: $primaryLeafId);

        $product->forceFill([
            'category_id' => $rootCategoryId,
            'subcategory_id' => $rootCategoryId === $primaryLeafId ? null : $primaryLeafId,
        ])->saveQuietly();
    }

    private function syncCatalogAssignments(Product $product, array $data): void
    {
        $showInCategoryPage = (bool) ($data['show_in_category_page'] ?? true);
        $primaryId = isset($data['primary_category_id']) ? (int) $data['primary_category_id'] : null;
        $requestedCategoryIds = collect($data['category_assignments'] ?? [])
            ->push($primaryId)
            ->map(fn ($id) => (int) $id)
            ->filter()
            ->unique()
            ->values();
        $leafCategoryIdSet = Category::query()
            ->leaf()
            ->whereIn('id', $requestedCategoryIds->all())
            ->pluck('id')
            ->map(fn ($id): int => (int) $id)
            ->flip();
        $categoryIds = $requestedCategoryIds
            ->filter(fn (int $id): bool => $leafCategoryIdSet->has($id))
            ->values();
        $primaryId = $primaryId && $leafCategoryIdSet->has($primaryId) ? $primaryId : null;

        if ($showInCategoryPage && $primaryId) {
            $categoryIds = $categoryIds->prepend($primaryId)->unique()->values();
        } elseif ($showInCategoryPage && $categoryIds->isNotEmpty()) {
            $primaryId = (int) $categoryIds->first();
        } elseif (! $showInCategoryPage) {
            $categoryIds = collect();
        }

        // Product editing must not erase category-specific merchandising choices
        // managed from the category product-assignment screen. Preserve existing
        // featured flags and ordering for retained category assignments.
        $existing = DB::table('category_product')
            ->where('product_id', $product->id)
            ->get()
            ->keyBy('category_id');

        $sync = $categoryIds->mapWithKeys(function (int $categoryId, int $index) use ($existing, $primaryId): array {
            $pivot = $existing->get($categoryId);

            return [$categoryId => [
                'is_primary' => $categoryId === $primaryId,
                'is_featured' => (bool) ($pivot->is_featured ?? false),
                'sort_order' => (int) ($pivot->sort_order ?? $index),
            ]];
        })->all();

        $product->categories()->sync($sync);
        $this->syncLegacyCategoryColumnsFromLeafAssignments($product, $sync);
        $product->attributeValues()->sync(
            collect($data['attribute_value_ids'] ?? [])->map(fn ($id) => (int) $id)->unique()->all()
        );
    }

    private function syncImages(Product $product, ProductFormRequest $request, array $data): void
    {
        $existingImages = $product->images()->get()->keyBy('id');
        $keptIds = [];
        $orderedImageIds = [];

        $urlRows = collect($data['image_urls'] ?? [])->values();
        $uploadedImages = collect($request->file('images', []))->values();
        $requestedUploadPrimary = filled($data['new_image_primary_index'] ?? null)
            ? (int) $data['new_image_primary_index']
            : null;
        $uploadPrimaryIsValid = $requestedUploadPrimary !== null
            && $uploadedImages->has($requestedUploadPrimary);
        $requestedUrlPrimary = $urlRows->search(fn ($item) => (bool) ($item['is_primary'] ?? false));
        $primaryImageId = null;

        foreach ($urlRows as $index => $item) {
            $existingId = (int) ($item['existing_id'] ?? 0);
            $url = trim((string) ($item['url'] ?? ''));
            $name = filled($item['name'] ?? null)
                ? trim((string) $item['name'])
                : (filled($item['alt'] ?? null) ? trim((string) $item['alt']) : $product->name);

            $image = $existingId > 0 ? $existingImages->get($existingId) : null;

            if ($existingId > 0 && ! $image) {
                throw ValidationException::withMessages([
                    "image_urls.{$index}.existing_id" => 'The selected product image does not belong to this product.',
                ]);
            }

            if ($image) {
                // A saved upload is preserved when the URL field stays blank.
                // Entering a URL intentionally replaces the saved upload.
                if ($url !== '') {
                    if (! $image->media_library_image_id) {
                        $this->deletePublicImage($image->path);
                    }
                    $image->media_library_image_id = null;
                    $image->path = null;
                    $image->url = $url;
                } elseif (! filled($image->path)) {
                    if ($image->media_library_image_id && filled($image->url)) {
                        // Media-library URL images keep their saved URL when the readonly URL field is blank.
                    } else {
                        $legacyStoredPath = PublicMedia::storedPathFromUrl($image->url);
                        if ($legacyStoredPath && Storage::disk('public')->exists($legacyStoredPath)) {
                            // Earlier versions converted uploaded images into absolute
                            // /storage URLs during an edit. Repair that record in place.
                            $image->path = $legacyStoredPath;
                            $image->url = null;
                        } else {
                            // A genuine remote image whose URL was cleared is removed.
                            continue;
                        }
                    }
                }

                $image->alt_text = $name;
                $image->is_primary = false;
                $image->sort_order = count($orderedImageIds);
                $image->save();
            } else {
                $mediaLibraryImageId = (int) ($item['media_library_image_id'] ?? 0);

                if ($mediaLibraryImageId > 0) {
                    $mediaImage = MediaLibraryImage::query()->find($mediaLibraryImageId);

                    if (! $mediaImage) {
                        throw ValidationException::withMessages([
                            "image_urls.{$index}.media_library_image_id" => 'The selected gallery image could not be found.',
                        ]);
                    }

                    $image = $product->images()->create([
                        'media_library_image_id' => $mediaImage->id,
                        'path' => $mediaImage->path,
                        'url' => $mediaImage->url,
                        'alt_text' => $name ?: ($mediaImage->alt_text ?: $mediaImage->name),
                        'is_primary' => false,
                        'sort_order' => count($orderedImageIds),
                    ]);
                } else {
                    if ($url === '') {
                        continue;
                    }

                    $image = $product->images()->create([
                        'url' => $url,
                        'alt_text' => $name,
                        'is_primary' => false,
                        'sort_order' => count($orderedImageIds),
                    ]);
                }
            }

            $keptIds[] = $image->id;
            $orderedImageIds[] = $image->id;

            if (! $uploadPrimaryIsValid && $requestedUrlPrimary !== false && (int) $requestedUrlPrimary === $index) {
                $primaryImageId = $image->id;
            }
        }

        foreach ($uploadedImages as $index => $uploadedImage) {
            $path = $uploadedImage->store('media-library/'.now()->format('Y/m'), 'public');
            $originalName = pathinfo($uploadedImage->getClientOriginalName(), PATHINFO_FILENAME) ?: $product->name;
            $dimensions = @getimagesize($uploadedImage->getRealPath()) ?: [];
            $mediaImage = MediaLibraryImage::query()->create([
                'path' => $path,
                'name' => Str::limit($originalName, 250, ''),
                'alt_text' => $originalName,
                'mime_type' => $uploadedImage->getMimeType(),
                'size_bytes' => $uploadedImage->getSize(),
                'width' => $dimensions[0] ?? null,
                'height' => $dimensions[1] ?? null,
                'source' => 'product',
                'created_by' => auth('admin')->id(),
            ]);

            $image = $product->images()->create([
                'media_library_image_id' => $mediaImage->id,
                'path' => $path,
                'url' => null,
                'alt_text' => $originalName,
                'is_primary' => false,
                'sort_order' => count($orderedImageIds),
            ]);

            $keptIds[] = $image->id;
            $orderedImageIds[] = $image->id;

            if ($uploadPrimaryIsValid && $requestedUploadPrimary === $index) {
                $primaryImageId = $image->id;
            }
        }

        $existingImages
            ->reject(fn ($image) => in_array($image->id, $keptIds, true))
            ->each(function ($image): void {
                if (! $image->media_library_image_id) {
                    $this->deletePublicImage($image->path);
                }
                $image->delete();
            });

        if ($primaryImageId === null) {
            $primaryImageId = $orderedImageIds[0] ?? null;
        }

        $product->images()->update(['is_primary' => false]);
        if ($primaryImageId !== null) {
            $product->images()->whereKey($primaryImageId)->update(['is_primary' => true]);
        }
    }

    private function deletePublicImage(?string $path): void
    {
        if (filled($path) && Storage::disk('public')->exists($path)) {
            Storage::disk('public')->delete($path);
        }
    }

    private function replaceSimpleRelation(Product $product, string $relation, array $rows, array $required, array $columns): void
    {
        $product->{$relation}()->delete();
        foreach (collect($rows)->filter(function ($row) use ($required) {
            foreach ($required as $key) {
                if (! filled($row[$key] ?? null)) {
                    return false;
                }
            }
            return true;
        })->values() as $index => $row) {
            $payload = Arr::only($row, $columns);
            foreach (['requires_upload', 'is_active', 'is_default'] as $boolean) {
                if (array_key_exists($boolean, $payload)) {
                    $payload[$boolean] = (bool) $payload[$boolean];
                }
            }
            $payload['sort_order'] = $index;
            $product->{$relation}()->create($payload);
        }
    }
}
