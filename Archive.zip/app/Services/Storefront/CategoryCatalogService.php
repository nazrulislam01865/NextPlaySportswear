<?php

namespace App\Services\Storefront;

use App\Models\CatalogAttribute;
use App\Models\Category;
use App\Models\Product;
use App\Services\Catalog\CategoryTreeService;
use Illuminate\Contracts\Pagination\LengthAwarePaginator;
use Illuminate\Database\Eloquent\Builder;
use Illuminate\Support\Collection;
use Illuminate\Support\Facades\Cache;
use Illuminate\Support\Facades\DB;
use Illuminate\Support\Str;

class CategoryCatalogService
{
    /** @var array<int, array<int>> */
    private array $runtimeListingCategoryIds = [];

    /** @var Collection<int, array{id:int,parent_id:int|null}>|null */
    private ?Collection $runtimeCategoryParentRows = null;

    public function __construct(
        private readonly ProductCatalogService $productCatalogService,
        private readonly CategoryTreeService $treeService,
    ) {
    }

    public function findBySlug(string $slug): ?Category
    {
        $category = Category::query()
            ->storefrontReachable()
            ->with([
                'parent',
                'children' => fn ($query) => $query->storefrontReachable(),
                'filters.values',
                'contentBlocks',
                'faqs',
            ])
            ->where('slug', $slug)
            ->first();

        if ($category) {
            $this->attachProductCounts(collect([$category]));
            $this->attachProductCounts($category->children);
        }

        return $category;
    }

    public function collections(): array
    {
        $categories = $this->topLevelQuery()
            ->where('category_type', '!=', 'sport')
            ->get();

        $this->attachProductCounts($categories);

        return $categories->map(fn (Category $category) => $this->categoryData($category))->all();
    }

    /**
     * Return every storefront-reachable product category in hierarchy order.
     *
     * Sport roots and their descendants are intentionally omitted because the
     * category landing page renders those separately in the Shop by Sport area.
     * This keeps the product category grid complete without duplicating sport
     * navigation cards.
     *
     * @return array<int, array<string, mixed>>
     */
    public function allProductCategories(): array
    {
        $categories = Category::query()
            ->storefrontReachable()
            ->with('parent:id,name,slug,parent_id')
            ->get();

        $childrenByParent = $categories
            ->groupBy(fn (Category $category): int => (int) ($category->parent_id ?? 0));

        $ordered = collect();

        $walk = function (int $parentId) use (&$walk, $childrenByParent, $ordered): void {
            $siblings = $childrenByParent->get($parentId, collect())
                ->sort(function (Category $left, Category $right): int {
                    $sortComparison = ((int) $left->sort_order) <=> ((int) $right->sort_order);

                    return $sortComparison !== 0
                        ? $sortComparison
                        : strcasecmp((string) $left->name, (string) $right->name);
                });

            foreach ($siblings as $category) {
                $ordered->push($category);
                $walk((int) $category->id);
            }
        };

        $productRoots = $childrenByParent->get(0, collect())
            ->reject(fn (Category $category): bool => $category->category_type === 'sport')
            ->sort(function (Category $left, Category $right): int {
                $sortComparison = ((int) $left->sort_order) <=> ((int) $right->sort_order);

                return $sortComparison !== 0
                    ? $sortComparison
                    : strcasecmp((string) $left->name, (string) $right->name);
            });

        foreach ($productRoots as $root) {
            $ordered->push($root);
            $walk((int) $root->id);
        }

        $this->attachProductCounts($ordered);

        return $ordered
            ->map(fn (Category $category) => $this->categoryData($category))
            ->values()
            ->all();
    }

    /**
     * Build the Shop by Category browser from leaf/product categories only.
     *
     * Parent and intermediate categories are navigation/grouping nodes. The
     * storefront card grid only needs the final category in each hierarchy,
     * because products are assigned to leaf categories. Counts are loaded in
     * one aggregate query for the full leaf set, avoiding per-card queries.
     *
     * @return array<int, array{parent:array<string,mixed>,children:array<int,array<string,mixed>>}>
     */
    public function categoryBrowser(): array
    {
        $categories = Category::query()
            ->storefrontReachable()
            ->withCount('children')
            ->get();

        if ($categories->isEmpty()) {
            return [];
        }

        $categoriesById = $categories->keyBy(fn (Category $category): int => (int) $category->id);

        // Resolve parents from the already-loaded collection so categoryData()
        // never lazily queries one parent per card.
        foreach ($categories as $category) {
            $category->setRelation(
                'parent',
                $category->parent_id ? $categoriesById->get((int) $category->parent_id) : null
            );
        }

        $leafCategories = $categories
            ->filter(fn (Category $category): bool => (int) ($category->children_count ?? 0) === 0)
            ->values();

        if ($leafCategories->isEmpty()) {
            return [];
        }

        $productCounts = $this->directProductCountsForCategoryIds(
            $leafCategories->pluck('id')->map(fn ($id): int => (int) $id)->all()
        );

        foreach ($leafCategories as $category) {
            $category->setAttribute(
                'products_count',
                (int) ($productCounts->get((int) $category->id, 0))
            );
        }

        $childrenByParent = $categories
            ->groupBy(fn (Category $category): int => (int) ($category->parent_id ?? 0));

        $sortCategories = static fn (Collection $items): Collection => $items
            ->sort(function (Category $left, Category $right): int {
                $sortComparison = ((int) $left->sort_order) <=> ((int) $right->sort_order);

                return $sortComparison !== 0
                    ? $sortComparison
                    : strcasecmp((string) $left->name, (string) $right->name);
            })
            ->values();

        $roots = $sortCategories($childrenByParent->get(0, collect()));
        $groups = collect();

        foreach ($roots as $root) {
            $cards = collect();

            $walk = function (Category $category, array $path) use (&$walk, $childrenByParent, $sortCategories, $cards): void {
                $path[] = $category;
                $children = $sortCategories($childrenByParent->get((int) $category->id, collect()));

                // children_count checks the real category tree, not only visible
                // children. A hidden child must not turn its parent into a fake
                // storefront leaf/product category.
                if ((int) ($category->children_count ?? 0) === 0) {
                    if ((int) ($category->products_count ?? 0) <= 0) {
                        return;
                    }

                    $data = $this->categoryData($category);
                    $hierarchy = collect($path)
                        ->map(fn (Category $node): string => (string) $node->name)
                        ->filter()
                        ->values();

                    $data['hierarchy'] = $hierarchy->all();
                    $data['hierarchy_label'] = $hierarchy->implode(' > ');
                    $data['link_label'] = 'View Products';
                    $cards->push($data);

                    return;
                }

                foreach ($children as $child) {
                    $walk($child, $path);
                }
            };

            $walk($root, []);

            if ($cards->isEmpty()) {
                continue;
            }

            $groups->push([
                'parent' => [
                    'id' => (int) $root->id,
                    'slug' => (string) $root->slug,
                    'title' => (string) $root->name,
                    'short_title' => (string) ($root->short_title ?: $root->name),
                    'url' => route('categories.show', $root->slug),
                ],
                'children' => $cards->values()->all(),
            ]);
        }

        return $groups->values()->all();
    }

    public function sports(): array
    {
        $categories = $this->topLevelQuery()
            ->where('category_type', 'sport')
            ->get();

        $this->attachProductCounts($categories);

        return $categories
            ->filter(fn (Category $category): bool => (int) ($category->products_count ?? 0) > 0)
            ->map(fn (Category $category) => $this->categoryData($category))
            ->values()
            ->all();
    }

    /** @param array<int, int|string> $ids */
    public function categoriesByIds(array $ids, int $limit = 12): array
    {
        $orderedIds = collect($ids)
            ->map(fn ($id): int => (int) $id)
            ->filter(fn (int $id): bool => $id > 0)
            ->unique()
            ->take(max(1, $limit))
            ->values();

        if ($orderedIds->isEmpty()) {
            return [];
        }

        $categories = Category::query()
            ->storefrontReachable()
            ->whereIn('id', $orderedIds->all())
            ->get()
            ->keyBy('id');

        $ordered = $orderedIds
            ->map(fn (int $id) => $categories->get($id))
            ->filter();

        $this->attachProductCounts($ordered);

        return $ordered->map(fn (Category $category) => $this->categoryData($category))->values()->all();
    }

    public function filterTags(): array
    {
        return [
            ['slug' => 'sport', 'name' => 'Sports'],
            ['slug' => 'collection', 'name' => 'Collections'],
            ['slug' => 'apparel', 'name' => 'Apparel'],
            ['slug' => 'accessory', 'name' => 'Accessories'],
            ['slug' => 'promotional', 'name' => 'Promotional'],
        ];
    }

    public function categoryData(Category $category): array
    {
        $count = $category->products_count ?? $this->productCount($category);

        return [
            'id' => $category->id,
            'slug' => $category->slug,
            'group' => $category->category_type,
            'parent_name' => $category->parent?->name,
            'parent_slug' => $category->parent?->slug,
            'depth' => (int) ($category->depth ?? ($category->parent_id ? 1 : 0)),
            'is_subcategory' => $category->parent_id !== null,
            'tags' => array_values(array_unique(array_filter([$category->category_type, $category->display_type]))),
            'eyebrow' => $category->eyebrow ?: 'Custom sportswear',
            'title' => $category->name,
            'short_title' => $category->short_title ?: $category->name,
            'description' => $category->short_description ?: $category->description,
            'description_html' => $category->description_html,
            'best_for' => $category->best_for,
            'meta_title' => $category->meta_title,
            'meta_description' => $category->meta_description ?: $category->short_description ?: $category->description,
            'image' => $category->thumbnailUrl(),
            'icon' => $category->iconUrl(),
            'banner' => $category->bannerUrl(),
            'mobile_banner' => $category->bannerUrl(true),
            'alt' => $category->thumbnail_alt ?: $category->image_alt ?: $category->name,
            'banner_alt' => $category->banner_alt ?: $category->name,
            'highlights' => $category->highlights ?? [],
            'link_label' => $category->cta_label ?: 'View Category',
            'product_count' => $count,
            'is_featured' => (bool) $category->is_featured,
            'url' => route('categories.show', $category->slug),
        ];
    }

    public function productsFor(Category $category, array $filters): LengthAwarePaginator
    {
        $categoryIds = $this->categoryIdsForListing($category);

        $query = $this->applyCategoryProductFilter(Product::query()->published(), $categoryIds)
            ->select('products.*')
            ->selectSub($this->categoryFeaturedSelect($categoryIds), 'category_featured')
            ->selectSub($this->categorySortSelect($categoryIds), 'category_sort')
            ->with($this->productCatalogService->listingRelations());

        if ($filters['q'] !== '') {
            $needle = $filters['q'];
            $query->where(function (Builder $builder) use ($needle): void {
                $builder->where('products.name', 'like', "%{$needle}%")
                    ->orWhere('products.sku', 'like', "%{$needle}%")
                    ->orWhere('products.brand', 'like', "%{$needle}%")
                    ->orWhere('products.product_type', 'like', "%{$needle}%");
            });
        }

        if ($filters['subcategory'] !== []) {
            // A crafted query string must not be able to use categories outside
            // the current category subtree to change the listing semantics.
            $selected = Category::query()
                ->storefrontReachable()
                ->whereIn('id', array_intersect($filters['subcategory'], $categoryIds))
                ->pluck('id')
                ->map(fn ($id) => (int) $id)
                ->all();

            if ($selected !== []) {
                $this->applyCategoryProductFilter($query, $selected);
            }
        }

        if (($filters['sports'] ?? []) !== []) {
            $this->productCatalogService->applyCategorySelection($query, $filters['sports']);
        }

        $allowedAttributeSlugs = $this->filterableAttributeSlugsForListing($category, $categoryIds);
        $this->productCatalogService->applyCommonCatalogFilters($query, $filters, $allowedAttributeSlugs);

        match ($filters['sort']) {
            'price-low' => $this->productCatalogService->applyListingPriceSort($query, 'asc'),
            'price-high' => $this->productCatalogService->applyListingPriceSort($query, 'desc'),
            'name-asc' => $query->orderBy('products.name')->orderByDesc('products.id'),
            'newest' => $query->orderByDesc('products.published_at')->orderByDesc('products.id'),
            'rating-high' => $query->orderByDesc('products.rating_average')->orderByDesc('products.reviews_count')->orderBy('products.name'),
            'best-selling' => $query->orderByDesc('products.recent_orders_count')->orderByDesc('products.is_featured')->orderBy('products.name'),
            default => $query
                ->orderByDesc('category_featured')
                ->orderByRaw('COALESCE(category_sort, products.sort_order, 999999) ASC')
                ->orderByDesc('products.is_featured')
                ->orderBy('products.sort_order')
                ->orderBy('products.name'),
        };

        $perPage = max(1, min((int) config('catalog.category_page_size', 24), 60));
        $paginator = $query->paginate($perPage)->withQueryString();
        $paginator->through(fn (Product $product): array => $this->productCatalogService->applySaleCampaignPricing($this->productCatalogService->fromListingModel($product)));

        return $paginator;
    }

    public function filterOptions(Category $category): array
    {
        $categoryIds = $this->categoryIdsForListing($category);
        $cacheVersion = (int) Cache::get('catalog.category-facets.version', 1);
        $cacheKey = 'catalog.category-facets.'.$category->id.'.'.$cacheVersion;

        return Cache::remember($cacheKey, config('catalog.facets_cache_seconds', 300), function () use ($category, $categoryIds): array {
            $this->attachProductCounts($category->children);
            $childCategories = $category->children->map(fn (Category $child) => [
                'id' => $child->id,
                'label' => $child->name,
                'slug' => $child->slug,
                'count' => (int) ($child->products_count ?? 0),
            ])->filter(fn (array $child) => $child['count'] > 0)->values()->all();

            $listing = $this->productListingSubquery($categoryIds);

            $valueCounts = DB::table('attribute_value_product as avp')
                ->joinSub($listing, 'category_listing', fn ($join) => $join->on('category_listing.product_id', '=', 'avp.product_id'))
                ->join('attribute_values as av', 'av.id', '=', 'avp.attribute_value_id')
                ->join('products as p', 'p.id', '=', 'avp.product_id')
                ->where('p.status', 'active')
                ->where('p.is_active', true)
                ->where(function ($query): void {
                    $query->whereNull('p.published_at')->orWhere('p.published_at', '<=', now());
                })
                ->where('av.is_active', true)
                ->selectRaw('avp.attribute_value_id, COUNT(DISTINCT p.id) AS aggregate')
                ->groupBy('avp.attribute_value_id')
                ->pluck('aggregate', 'avp.attribute_value_id');

            $configuredAttributes = $category->filters
                ->filter(fn (CatalogAttribute $attribute) => $attribute->is_active && $attribute->is_filterable)
                ->reject(function (CatalogAttribute $attribute): bool {
                    $slug = (string) $attribute->slug;
                    $label = Str::lower($attribute->name.' '.$slug);

                    return in_array($slug, ['production-time', 'shipping-time', 'free-shipping', 'free-setup', 'brand', 'color', 'size'], true)
                        || Str::contains($label, ['color', 'colour', 'fabric', 'material', 'metarial', 'meterial']);
                })
                ->values();

            $configuredAttributeIds = $configuredAttributes
                ->pluck('id')
                ->map(fn ($id): int => (int) $id)
                ->all();

            $attributeValueIds = $valueCounts->keys()
                ->map(fn ($id): int => (int) $id)
                ->filter(fn (int $id): bool => $id > 0)
                ->all();

            $attributeIdsWithProducts = $attributeValueIds === []
                ? collect()
                : DB::table('attribute_values as av')
                    ->join('attributes as a', 'a.id', '=', 'av.attribute_id')
                    ->whereIn('av.id', $attributeValueIds)
                    ->where('a.is_active', true)
                    ->where('a.is_filterable', true)
                    ->whereNull('a.deleted_at')
                    ->orderBy('a.sort_order')
                    ->orderBy('a.name')
                    ->pluck('av.attribute_id')
                    ->map(fn ($id): int => (int) $id)
                    ->unique()
                    ->values();

            $autoAttributes = CatalogAttribute::query()
                ->whereIn('id', $attributeIdsWithProducts->diff($configuredAttributeIds)->all())
                ->where('is_active', true)
                ->where('is_filterable', true)
                ->with('values')
                ->ordered()
                ->get();

            $attributes = $configuredAttributes
                ->concat($autoAttributes)
                ->unique('id')
                ->map(function (CatalogAttribute $attribute) use ($valueCounts): array {
                    $values = $attribute->values
                        ->where('is_active', true)
                        ->map(function ($value) use ($valueCounts): array {
                            return [
                                'id' => $value->id,
                                'label' => $value->label,
                                'slug' => $value->slug,
                                'color_hex' => $value->color_hex,
                                'image' => $value->publicImageUrl(),
                                'count' => (int) ($valueCounts[$value->id] ?? 0),
                            ];
                        })
                        ->filter(fn (array $value) => $value['count'] > 0)
                        ->values()
                        ->all();

                    return [
                        'id' => $attribute->id,
                        'name' => $attribute->pivot?->label ?: $attribute->name,
                        'slug' => $attribute->slug,
                        'display_type' => $attribute->display_type,
                        'is_expanded' => (bool) ($attribute->pivot?->is_expanded ?? true),
                        'values' => $values,
                    ];
                })
                ->filter(fn (array $attribute) => $attribute['values'] !== [])
                ->values()
                ->all();

            $baseQuery = $this->applyCategoryProductFilter(Product::query()->published(), $categoryIds);
            $shared = $this->productCatalogService->commonFilterOptions(clone $baseQuery);

            if ($category->filter_product_types !== null) {
                $enabledProductTypes = collect($category->filter_product_types)
                    ->map(fn ($value): string => trim((string) $value))
                    ->filter()
                    ->unique()
                    ->values()
                    ->all();

                $shared['product_types'] = collect($shared['product_types'] ?? [])
                    ->filter(fn (array $option): bool => in_array((string) ($option['value'] ?? ''), $enabledProductTypes, true))
                    ->values()
                    ->all();
            }

            $sharedAttributes = collect($shared['attributes'] ?? [])
                ->concat($attributes)
                ->unique('slug')
                ->values()
                ->all();

            $sports = $category->category_type === 'sport'
                ? []
                : $this->productCatalogService->sportFilterOptions(clone $baseQuery);

            return array_merge($shared, [
                'subcategories' => $childCategories,
                'sports' => count($sports) > 1 ? $sports : [],
                'attributes' => $sharedAttributes,
            ]);
        });
    }

    public function relatedCategories(Category $category, int $limit = 6): array
    {
        $query = Category::query()
            ->storefrontReachable()
            ->where('id', '!=', $category->id)
            ->withCount('products');

        if ($category->parent_id) {
            $query->where('parent_id', $category->parent_id);
        } else {
            $query->whereNull('parent_id');
        }

        $categories = $query->ordered()->limit($limit)->get();
        $this->attachProductCounts($categories);

        return $categories->map(fn (Category $item) => $this->categoryData($item))->all();
    }

    public function breadcrumbs(Category $category): Collection
    {
        return $this->treeService->breadcrumbs($category);
    }

    private function topLevelQuery(): Builder
    {
        return Category::query()
            ->storefrontReachable()
            ->whereNull('parent_id')
            ->ordered();
    }

    /** @return array<int> */
    private function categoryIdsForListing(Category $category): array
    {
        $categoryId = (int) $category->id;
        $cacheVersion = (int) Cache::get('catalog.category-facets.version', 1);
        $cacheKey = 'catalog.category-listing-ids.'.$categoryId.'.'.$cacheVersion;

        if (isset($this->runtimeListingCategoryIds[$categoryId])) {
            return $this->runtimeListingCategoryIds[$categoryId];
        }

        $ttl = max(60, (int) config('catalog.category_cache_seconds', 1800));

        return $this->runtimeListingCategoryIds[$categoryId] = Cache::remember($cacheKey, $ttl, function () use ($category, $categoryId): array {
            $closureIds = $this->treeService->descendantIds($categoryId, true);
            $fallbackIds = $this->descendantIdsFromParentTree($categoryId);

            $categoryIds = collect([$categoryId])
                ->merge($closureIds)
                ->merge($fallbackIds)
                ->map(fn ($id): int => (int) $id)
                ->filter(fn (int $id): bool => $id > 0)
                ->unique()
                ->values()
                ->all();

            /*
             * Menu clicks usually land on a parent category such as Bags,
             * Accessories, or Performance Apparel. Those parent rows often do not
             * have products assigned directly; products are assigned to child/leaf
             * categories. If we only use the parent id, the page looks empty from
             * the menu while the same products appear after entering through a
             * product's leaf-category link.
             *
             * Leaf categories still respect the Include child products setting.
             * Parent categories always include descendants so menu category pages
             * behave like real storefront landing pages.
             */
            if (! $category->include_descendant_products && count($categoryIds) <= 1) {
                $categoryIds = [$categoryId];
            }

            return Category::query()
                ->whereIn('id', $categoryIds)
                ->pluck('id')
                ->map(fn ($id) => (int) $id)
                ->whenEmpty(fn (Collection $ids): Collection => collect([$categoryId]))
                ->unique()
                ->values()
                ->all();
        });
    }

    /**
     * Fallback for imported/category-edited data when category_closure has not
     * been rebuilt yet. Category pages should still find products assigned by
     * category_id, subcategory_id, or category_product while the admin rebuilds
     * the closure table/cache.
     *
     * @return array<int>
     */
    private function descendantIdsFromParentTree(int $categoryId): array
    {
        $byParent = $this->categoryParentRows()
            ->groupBy(fn (array $category): int => (int) ($category['parent_id'] ?? 0));

        $ids = [];
        $visited = [];

        $walk = function (int $id) use (&$walk, &$ids, &$visited, $byParent): void {
            if (isset($visited[$id])) {
                return;
            }

            $visited[$id] = true;
            $ids[] = $id;

            foreach (($byParent->get($id) ?? collect()) as $child) {
                $walk((int) $child['id']);
            }
        };

        $walk($categoryId);

        return $ids;
    }

    /** @return Collection<int, array{id:int,parent_id:int|null}> */
    private function categoryParentRows(): Collection
    {
        if ($this->runtimeCategoryParentRows !== null) {
            return $this->runtimeCategoryParentRows;
        }

        $cacheVersion = (int) Cache::get('catalog.category-facets.version', 1);
        $cacheKey = 'catalog.category-parent-rows.'.$cacheVersion;
        $ttl = max(60, (int) config('catalog.category_cache_seconds', 1800));

        $rows = Cache::remember($cacheKey, $ttl, fn (): array => Category::query()
            ->get(['id', 'parent_id'])
            ->map(fn (Category $category): array => [
                'id' => (int) $category->id,
                'parent_id' => $category->parent_id === null ? null : (int) $category->parent_id,
            ])
            ->all());

        return $this->runtimeCategoryParentRows = collect($rows);
    }


    /**
     * Count published products directly assigned to each supplied category in
     * one query. The pivot is the current source of truth; legacy category_id
     * and subcategory_id fields remain as a safe compatibility fallback.
     *
     * @param  array<int>  $categoryIds
     * @return Collection<int, int>
     */
    private function directProductCountsForCategoryIds(array $categoryIds): Collection
    {
        $categoryIds = $this->normalizeCategoryIds($categoryIds);

        if ($categoryIds === []) {
            return collect();
        }

        $pivotAssignments = DB::table('category_product as cp')
            ->join('products as p', 'p.id', '=', 'cp.product_id')
            ->whereIn('cp.category_id', $categoryIds)
            ->whereNull('p.deleted_at')
            ->where('p.status', 'active')
            ->where('p.is_active', true)
            ->where(function ($query): void {
                $query->whereNull('p.published_at')->orWhere('p.published_at', '<=', now());
            })
            ->selectRaw('cp.category_id AS category_id, cp.product_id AS product_id');

        $legacyCategoryAssignments = DB::table('products as p')
            ->whereIn('p.category_id', $categoryIds)
            ->whereNull('p.deleted_at')
            ->where('p.status', 'active')
            ->where('p.is_active', true)
            ->where(function ($query): void {
                $query->whereNull('p.published_at')->orWhere('p.published_at', '<=', now());
            })
            ->selectRaw('p.category_id AS category_id, p.id AS product_id');

        $legacySubcategoryAssignments = DB::table('products as p')
            ->whereIn('p.subcategory_id', $categoryIds)
            ->whereNull('p.deleted_at')
            ->where('p.status', 'active')
            ->where('p.is_active', true)
            ->where(function ($query): void {
                $query->whereNull('p.published_at')->orWhere('p.published_at', '<=', now());
            })
            ->selectRaw('p.subcategory_id AS category_id, p.id AS product_id');

        $assignments = $pivotAssignments
            ->unionAll($legacyCategoryAssignments)
            ->unionAll($legacySubcategoryAssignments);

        return DB::query()
            ->fromSub($assignments, 'leaf_product_assignments')
            ->selectRaw('category_id, COUNT(DISTINCT product_id) AS aggregate')
            ->groupBy('category_id')
            ->pluck('aggregate', 'category_id')
            ->mapWithKeys(fn ($count, $categoryId): array => [(int) $categoryId => (int) $count]);
    }

    private function productCount(Category $category): int
    {
        $cacheVersion = (int) Cache::get('catalog.category-facets.version', 1);
        $cacheKey = 'catalog.category-product-count.'.$category->id.'.'.$cacheVersion;
        $ttl = max(60, (int) config('catalog.category_cache_seconds', 1800));

        return (int) Cache::remember($cacheKey, $ttl, fn (): int => $this->applyCategoryProductFilter(
            Product::query()->published(),
            $this->categoryIdsForListing($category)
        )->count());
    }

    /** @param Collection<int, Category> $categories */
    private function attachProductCounts(Collection $categories): void
    {
        foreach ($categories as $category) {
            $category->setAttribute('products_count', $this->productCount($category));
        }
    }

    /** @param array<int> $categoryIds */
    private function filterableAttributeSlugsForListing(Category $category, array $categoryIds): array
    {
        $cacheVersion = (int) Cache::get('catalog.category-facets.version', 1);
        $cacheKey = 'catalog.category-filterable-slugs.'.$category->id.'.'.$cacheVersion;
        $ttl = max(60, (int) config('catalog.facets_cache_seconds', 300));

        return Cache::remember($cacheKey, $ttl, function () use ($category, $categoryIds): array {
            $configured = $category->filters
                ->filter(fn (CatalogAttribute $attribute): bool => $attribute->is_active && $attribute->is_filterable)
                ->pluck('slug');

            $listing = $this->productListingSubquery($categoryIds);

            $dynamic = DB::table('attributes as a')
                ->join('attribute_values as av', 'av.attribute_id', '=', 'a.id')
                ->join('attribute_value_product as avp', 'avp.attribute_value_id', '=', 'av.id')
                ->joinSub($listing, 'category_listing', fn ($join) => $join->on('category_listing.product_id', '=', 'avp.product_id'))
                ->join('products as p', 'p.id', '=', 'avp.product_id')
                ->where('p.status', 'active')
                ->where('p.is_active', true)
                ->where(function ($query): void {
                    $query->whereNull('p.published_at')->orWhere('p.published_at', '<=', now());
                })
                ->where('a.is_active', true)
                ->where('a.is_filterable', true)
                ->whereNull('a.deleted_at')
                ->where('av.is_active', true)
                ->pluck('a.slug');

            return $configured
                ->merge($dynamic)
                ->map(fn ($slug): string => (string) $slug)
                ->filter()
                ->unique()
                ->values()
                ->all();
        });
    }

    /** @param array<int> $categoryIds */
    private function productListingSubquery(array $categoryIds)
    {
        $categoryIds = collect($categoryIds)
            ->map(fn ($id): int => (int) $id)
            ->filter(fn (int $id): bool => $id > 0)
            ->unique()
            ->values()
            ->all();

        $pivotListing = DB::table('category_product')
            ->selectRaw('product_id, MAX(CASE WHEN is_featured THEN 1 ELSE 0 END) AS category_featured, MIN(sort_order) AS category_sort')
            ->whereIn('category_id', $categoryIds)
            ->groupBy('product_id');

        $legacyListing = DB::table('products')
            ->selectRaw('id AS product_id, 0 AS category_featured, COALESCE(sort_order, 999999) AS category_sort')
            ->where(function ($query) use ($categoryIds): void {
                $query->whereIn('category_id', $categoryIds)
                    ->orWhereIn('subcategory_id', $categoryIds);
            });

        return DB::query()
            ->fromSub($pivotListing->unionAll($legacyListing), 'category_listing_source')
            ->selectRaw('product_id, MAX(category_featured) AS category_featured, MIN(category_sort) AS category_sort')
            ->groupBy('product_id');
    }

    /** @param array<int> $categoryIds */
    private function categoryFeaturedSelect(array $categoryIds)
    {
        $categoryIds = $this->normalizeCategoryIds($categoryIds);

        return DB::table('category_product')
            ->selectRaw('COALESCE(MAX(CASE WHEN is_featured THEN 1 ELSE 0 END), 0)')
            ->whereColumn('category_product.product_id', 'products.id')
            ->whereIn('category_product.category_id', $categoryIds);
    }

    /** @param array<int> $categoryIds */
    private function categorySortSelect(array $categoryIds)
    {
        $categoryIds = $this->normalizeCategoryIds($categoryIds);

        return DB::table('category_product')
            ->selectRaw('MIN(category_product.sort_order)')
            ->whereColumn('category_product.product_id', 'products.id')
            ->whereIn('category_product.category_id', $categoryIds);
    }

    /** @param array<int> $categoryIds */
    private function applyCategoryProductFilter(Builder $query, array $categoryIds): Builder
    {
        $categoryIds = $this->normalizeCategoryIds($categoryIds);

        if ($categoryIds === []) {
            return $query->whereRaw('1 = 0');
        }

        return $query->where(function (Builder $builder) use ($categoryIds): void {
            $builder->whereHas('categories', fn (Builder $categoryQuery) => $categoryQuery->whereIn('categories.id', $categoryIds))
                ->orWhereIn('products.category_id', $categoryIds)
                ->orWhereIn('products.subcategory_id', $categoryIds);
        });
    }

    /**
     * @param  array<int>  $categoryIds
     * @return array<int>
     */
    private function normalizeCategoryIds(array $categoryIds): array
    {
        return collect($categoryIds)
            ->map(fn ($id): int => (int) $id)
            ->filter(fn (int $id): bool => $id > 0)
            ->unique()
            ->values()
            ->all();
    }
}
