<?php return array (
  'Illuminate\\Foundation\\Support\\Providers\\EventServiceProvider' => 
  array (
    'Illuminate\\Auth\\Events\\Verified' => 
    array (
      0 => 'App\\Listeners\\Auth\\SendWelcomeEmailAfterVerification@handle',
    ),
  ),
);