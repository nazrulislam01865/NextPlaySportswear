<?php return array (
  'hashing' => 
  array (
    'driver' => 'bcrypt',
    'bcrypt' => 
    array (
      'rounds' => '12',
      'verify' => true,
      'limit' => NULL,
    ),
    'argon' => 
    array (
      'memory' => 65536,
      'threads' => 1,
      'time' => 4,
      'verify' => true,
    ),
    'rehash_on_login' => true,
  ),
  'concurrency' => 
  array (
    'default' => 'process',
  ),
  'broadcasting' => 
  array (
    'default' => 'log',
    'connections' => 
    array (
      'reverb' => 
      array (
        'driver' => 'reverb',
        'key' => NULL,
        'secret' => NULL,
        'app_id' => NULL,
        'options' => 
        array (
          'host' => NULL,
          'port' => 443,
          'scheme' => 'https',
          'useTLS' => true,
        ),
        'client_options' => 
        array (
        ),
      ),
      'pusher' => 
      array (
        'driver' => 'pusher',
        'key' => '473e69ba00b10ca805de',
        'secret' => '19bf81d482b42f7be129',
        'app_id' => '2173478',
        'options' => 
        array (
          'cluster' => 'ap2',
          'host' => 'api-ap2.pusher.com',
          'port' => 443,
          'scheme' => 'https',
          'encrypted' => true,
          'useTLS' => true,
        ),
        'client_options' => 
        array (
        ),
      ),
      'ably' => 
      array (
        'driver' => 'ably',
        'key' => NULL,
      ),
      'log' => 
      array (
        'driver' => 'log',
      ),
      'null' => 
      array (
        'driver' => 'null',
      ),
    ),
  ),
  'cors' => 
  array (
    'paths' => 
    array (
      0 => 'api/*',
      1 => 'sanctum/csrf-cookie',
    ),
    'allowed_methods' => 
    array (
      0 => '*',
    ),
    'allowed_origins' => 
    array (
      0 => '*',
    ),
    'allowed_origins_patterns' => 
    array (
    ),
    'allowed_headers' => 
    array (
      0 => '*',
    ),
    'exposed_headers' => 
    array (
    ),
    'max_age' => 0,
    'supports_credentials' => false,
  ),
  'app' => 
  array (
    'name' => 'NextPlay Sportswear',
    'env' => 'local',
    'debug' => true,
    'url' => 'http://127.0.0.1:8000',
    'frontend_url' => 'http://localhost:3000',
    'asset_url' => NULL,
    'timezone' => 'UTC',
    'locale' => 'en',
    'fallback_locale' => 'en',
    'faker_locale' => 'en_US',
    'cipher' => 'AES-256-CBC',
    'key' => 'base64:O1fASk3xzIX+swZi3habc2HKO7FwJTbyAbTgr74ckQw=',
    'previous_keys' => 
    array (
    ),
    'maintenance' => 
    array (
      'driver' => 'file',
      'store' => 'database',
    ),
    'providers' => 
    array (
      0 => 'Illuminate\\Auth\\AuthServiceProvider',
      1 => 'Illuminate\\Broadcasting\\BroadcastServiceProvider',
      2 => 'Illuminate\\Bus\\BusServiceProvider',
      3 => 'Illuminate\\Cache\\CacheServiceProvider',
      4 => 'Illuminate\\Foundation\\Providers\\ConsoleSupportServiceProvider',
      5 => 'Illuminate\\Concurrency\\ConcurrencyServiceProvider',
      6 => 'Illuminate\\Cookie\\CookieServiceProvider',
      7 => 'Illuminate\\Database\\DatabaseServiceProvider',
      8 => 'Illuminate\\Encryption\\EncryptionServiceProvider',
      9 => 'Illuminate\\Filesystem\\FilesystemServiceProvider',
      10 => 'Illuminate\\Foundation\\Providers\\FoundationServiceProvider',
      11 => 'Illuminate\\Hashing\\HashServiceProvider',
      12 => 'Illuminate\\Mail\\MailServiceProvider',
      13 => 'Illuminate\\Notifications\\NotificationServiceProvider',
      14 => 'Illuminate\\Pagination\\PaginationServiceProvider',
      15 => 'Illuminate\\Auth\\Passwords\\PasswordResetServiceProvider',
      16 => 'Illuminate\\Pipeline\\PipelineServiceProvider',
      17 => 'Illuminate\\Queue\\QueueServiceProvider',
      18 => 'Illuminate\\Redis\\RedisServiceProvider',
      19 => 'Illuminate\\Session\\SessionServiceProvider',
      20 => 'Illuminate\\Translation\\TranslationServiceProvider',
      21 => 'Illuminate\\Validation\\ValidationServiceProvider',
      22 => 'Illuminate\\View\\ViewServiceProvider',
      23 => 'App\\Providers\\AppServiceProvider',
      24 => 'App\\Providers\\EmailServiceProvider',
    ),
    'aliases' => 
    array (
      'App' => 'Illuminate\\Support\\Facades\\App',
      'Arr' => 'Illuminate\\Support\\Arr',
      'Artisan' => 'Illuminate\\Support\\Facades\\Artisan',
      'Auth' => 'Illuminate\\Support\\Facades\\Auth',
      'Benchmark' => 'Illuminate\\Support\\Benchmark',
      'Blade' => 'Illuminate\\Support\\Facades\\Blade',
      'Broadcast' => 'Illuminate\\Support\\Facades\\Broadcast',
      'Bus' => 'Illuminate\\Support\\Facades\\Bus',
      'Cache' => 'Illuminate\\Support\\Facades\\Cache',
      'Concurrency' => 'Illuminate\\Support\\Facades\\Concurrency',
      'Config' => 'Illuminate\\Support\\Facades\\Config',
      'Context' => 'Illuminate\\Support\\Facades\\Context',
      'Cookie' => 'Illuminate\\Support\\Facades\\Cookie',
      'Crypt' => 'Illuminate\\Support\\Facades\\Crypt',
      'Date' => 'Illuminate\\Support\\Facades\\Date',
      'DB' => 'Illuminate\\Support\\Facades\\DB',
      'Eloquent' => 'Illuminate\\Database\\Eloquent\\Model',
      'Event' => 'Illuminate\\Support\\Facades\\Event',
      'File' => 'Illuminate\\Support\\Facades\\File',
      'Gate' => 'Illuminate\\Support\\Facades\\Gate',
      'Hash' => 'Illuminate\\Support\\Facades\\Hash',
      'Http' => 'Illuminate\\Support\\Facades\\Http',
      'Js' => 'Illuminate\\Support\\Js',
      'Lang' => 'Illuminate\\Support\\Facades\\Lang',
      'Log' => 'Illuminate\\Support\\Facades\\Log',
      'Mail' => 'Illuminate\\Support\\Facades\\Mail',
      'Notification' => 'Illuminate\\Support\\Facades\\Notification',
      'Number' => 'Illuminate\\Support\\Number',
      'Password' => 'Illuminate\\Support\\Facades\\Password',
      'Process' => 'Illuminate\\Support\\Facades\\Process',
      'Queue' => 'Illuminate\\Support\\Facades\\Queue',
      'RateLimiter' => 'Illuminate\\Support\\Facades\\RateLimiter',
      'Redirect' => 'Illuminate\\Support\\Facades\\Redirect',
      'Request' => 'Illuminate\\Support\\Facades\\Request',
      'Response' => 'Illuminate\\Support\\Facades\\Response',
      'Route' => 'Illuminate\\Support\\Facades\\Route',
      'Schedule' => 'Illuminate\\Support\\Facades\\Schedule',
      'Schema' => 'Illuminate\\Support\\Facades\\Schema',
      'Session' => 'Illuminate\\Support\\Facades\\Session',
      'Storage' => 'Illuminate\\Support\\Facades\\Storage',
      'Str' => 'Illuminate\\Support\\Str',
      'Uri' => 'Illuminate\\Support\\Uri',
      'URL' => 'Illuminate\\Support\\Facades\\URL',
      'Validator' => 'Illuminate\\Support\\Facades\\Validator',
      'View' => 'Illuminate\\Support\\Facades\\View',
      'Vite' => 'Illuminate\\Support\\Facades\\Vite',
    ),
  ),
  'auth' => 
  array (
    'defaults' => 
    array (
      'guard' => 'web',
      'passwords' => 'users',
    ),
    'guards' => 
    array (
      'web' => 
      array (
        'driver' => 'session',
        'provider' => 'users',
      ),
      'admin' => 
      array (
        'driver' => 'session',
        'provider' => 'users',
      ),
    ),
    'providers' => 
    array (
      'users' => 
      array (
        'driver' => 'eloquent',
        'model' => 'App\\Models\\User',
      ),
    ),
    'passwords' => 
    array (
      'users' => 
      array (
        'provider' => 'users',
        'table' => 'password_reset_tokens',
        'expire' => 15,
        'throttle' => 60,
      ),
    ),
    'password_timeout' => 10800,
  ),
  'cache' => 
  array (
    'default' => 'file',
    'stores' => 
    array (
      'array' => 
      array (
        'driver' => 'array',
        'serialize' => false,
      ),
      'session' => 
      array (
        'driver' => 'session',
        'key' => '_cache',
      ),
      'database' => 
      array (
        'driver' => 'database',
        'connection' => NULL,
        'table' => 'cache',
        'lock_connection' => NULL,
        'lock_table' => NULL,
      ),
      'file' => 
      array (
        'driver' => 'file',
        'path' => '/Applications/XAMPP/xamppfiles/htdocs/laravel/NextPlaySportswear/storage/framework/cache/data',
        'lock_path' => '/Applications/XAMPP/xamppfiles/htdocs/laravel/NextPlaySportswear/storage/framework/cache/data',
      ),
      'storage' => 
      array (
        'driver' => 'storage',
        'disk' => NULL,
        'path' => 'framework/cache/data',
      ),
      'memcached' => 
      array (
        'driver' => 'memcached',
        'persistent_id' => NULL,
        'sasl' => 
        array (
          0 => NULL,
          1 => NULL,
        ),
        'options' => 
        array (
        ),
        'servers' => 
        array (
          0 => 
          array (
            'host' => '127.0.0.1',
            'port' => 11211,
            'weight' => 100,
          ),
        ),
      ),
      'redis' => 
      array (
        'driver' => 'redis',
        'connection' => 'cache',
        'lock_connection' => 'default',
      ),
      'dynamodb' => 
      array (
        'driver' => 'dynamodb',
        'key' => '',
        'secret' => '',
        'region' => 'us-east-1',
        'table' => 'cache',
        'endpoint' => NULL,
      ),
      'octane' => 
      array (
        'driver' => 'octane',
      ),
      'failover' => 
      array (
        'driver' => 'failover',
        'stores' => 
        array (
          0 => 'database',
          1 => 'array',
        ),
      ),
    ),
    'prefix' => 'nextplay-sportswear-cache-',
    'serializable_classes' => false,
  ),
  'catalog' => 
  array (
    'max_category_depth' => 5,
    'category_page_size' => 24,
    'products_page_size' => 24,
    'navigation_cache_seconds' => 3600,
    'category_cache_seconds' => 1800,
    'facets_cache_seconds' => 300,
  ),
  'commerce' => 
  array (
    'return_window_days' => 30,
    'exchange_window_days' => 30,
    'cancellable_statuses' => 
    array (
      0 => 'pending_payment',
      1 => 'payment_review',
      2 => 'design_review',
    ),
    'changeable_statuses' => 
    array (
      0 => 'pending_payment',
      1 => 'payment_review',
      2 => 'design_review',
    ),
    'payable_statuses' => 
    array (
      0 => 'pending_payment',
      1 => 'payment_review',
      2 => 'payment_failed',
      3 => 'quote_invoice_requested',
    ),
    'order_statuses' => 
    array (
      'pending_payment' => 'Pending Payment',
      'payment_review' => 'Payment Review',
      'payment_failed' => 'Payment Failed',
      'design_review' => 'Design Review',
      'proof_approval' => 'Proof Approval',
      'in_production' => 'In Production',
      'partially_shipped' => 'Partially Shipped',
      'shipped' => 'Shipped',
      'delivered' => 'Delivered',
      'completed' => 'Completed',
      'cancelled' => 'Cancelled',
      'on_hold' => 'On Hold',
      'quote_invoice_requested' => 'Invoice Requested',
    ),
    'payment_statuses' => 
    array (
      'pending' => 'Pending',
      'processing' => 'Processing',
      'paid' => 'Paid',
      'failed' => 'Failed',
      'partially_refunded' => 'Partially Refunded',
      'refunded' => 'Refunded',
    ),
    'fulfillment_statuses' => 
    array (
      'unfulfilled' => 'Unfulfilled',
      'partial' => 'Partially Fulfilled',
      'fulfilled' => 'Fulfilled',
      'returned' => 'Returned',
    ),
    'shipment_statuses' => 
    array (
      'preparing' => 'Preparing',
      'label_created' => 'Label Created',
      'in_transit' => 'In Transit',
      'out_for_delivery' => 'Out for Delivery',
      'delivered' => 'Delivered',
      'exception' => 'Exception',
    ),
    'shipment_status_transitions' => 
    array (
      'preparing' => 
      array (
        0 => 'preparing',
        1 => 'label_created',
        2 => 'in_transit',
        3 => 'exception',
      ),
      'label_created' => 
      array (
        0 => 'label_created',
        1 => 'in_transit',
        2 => 'exception',
      ),
      'in_transit' => 
      array (
        0 => 'in_transit',
        1 => 'out_for_delivery',
        2 => 'delivered',
        3 => 'exception',
      ),
      'out_for_delivery' => 
      array (
        0 => 'out_for_delivery',
        1 => 'in_transit',
        2 => 'delivered',
        3 => 'exception',
      ),
      'exception' => 
      array (
        0 => 'exception',
        1 => 'in_transit',
        2 => 'out_for_delivery',
        3 => 'delivered',
      ),
      'delivered' => 
      array (
        0 => 'delivered',
      ),
    ),
    'change_request_statuses' => 
    array (
      'pending' => 'Pending',
      'approved' => 'Approved',
      'rejected' => 'Rejected',
      'completed' => 'Completed',
    ),
    'return_statuses' => 
    array (
      'requested' => 'Requested',
      'under_review' => 'Under Review',
      'approved' => 'Approved',
      'label_issued' => 'Label Issued',
      'in_transit' => 'In Transit',
      'received' => 'Received',
      'completed' => 'Completed',
      'rejected' => 'Rejected',
      'cancelled' => 'Cancelled',
    ),
    'return_status_transitions' => 
    array (
      'requested' => 
      array (
        0 => 'requested',
        1 => 'under_review',
        2 => 'approved',
        3 => 'rejected',
        4 => 'cancelled',
      ),
      'under_review' => 
      array (
        0 => 'under_review',
        1 => 'approved',
        2 => 'rejected',
        3 => 'cancelled',
      ),
      'approved' => 
      array (
        0 => 'approved',
        1 => 'label_issued',
        2 => 'in_transit',
        3 => 'received',
        4 => 'completed',
        5 => 'cancelled',
      ),
      'label_issued' => 
      array (
        0 => 'label_issued',
        1 => 'in_transit',
        2 => 'received',
        3 => 'completed',
      ),
      'in_transit' => 
      array (
        0 => 'in_transit',
        1 => 'received',
      ),
      'received' => 
      array (
        0 => 'received',
        1 => 'completed',
      ),
      'completed' => 
      array (
        0 => 'completed',
      ),
      'rejected' => 
      array (
        0 => 'rejected',
      ),
      'cancelled' => 
      array (
        0 => 'cancelled',
      ),
    ),
    'refund_statuses' => 
    array (
      'pending' => 'Pending',
      'processing' => 'Processing',
      'issued' => 'Issued',
      'failed' => 'Failed',
      'cancelled' => 'Cancelled',
    ),
  ),
  'database' => 
  array (
    'default' => 'mysql',
    'connections' => 
    array (
      'sqlite' => 
      array (
        'driver' => 'sqlite',
        'url' => NULL,
        'database' => 'sportswear_ecommerce',
        'prefix' => '',
        'foreign_key_constraints' => true,
        'busy_timeout' => NULL,
        'journal_mode' => NULL,
        'synchronous' => NULL,
        'transaction_mode' => 'DEFERRED',
      ),
      'mysql' => 
      array (
        'driver' => 'mysql',
        'url' => NULL,
        'host' => '127.0.0.1',
        'port' => '3306',
        'database' => 'sportswear_ecommerce',
        'username' => 'root',
        'password' => '',
        'unix_socket' => '',
        'charset' => 'utf8mb4',
        'collation' => 'utf8mb4_unicode_ci',
        'prefix' => '',
        'prefix_indexes' => true,
        'strict' => true,
        'engine' => NULL,
        'options' => 
        array (
        ),
      ),
      'mariadb' => 
      array (
        'driver' => 'mariadb',
        'url' => NULL,
        'host' => '127.0.0.1',
        'port' => '3306',
        'database' => 'sportswear_ecommerce',
        'username' => 'root',
        'password' => '',
        'unix_socket' => '',
        'charset' => 'utf8mb4',
        'collation' => 'utf8mb4_unicode_ci',
        'prefix' => '',
        'prefix_indexes' => true,
        'strict' => true,
        'engine' => NULL,
        'options' => 
        array (
        ),
      ),
      'pgsql' => 
      array (
        'driver' => 'pgsql',
        'url' => NULL,
        'host' => '127.0.0.1',
        'port' => '3306',
        'database' => 'sportswear_ecommerce',
        'username' => 'root',
        'password' => '',
        'charset' => 'utf8',
        'prefix' => '',
        'prefix_indexes' => true,
        'search_path' => 'public',
        'sslmode' => 'prefer',
      ),
      'sqlsrv' => 
      array (
        'driver' => 'sqlsrv',
        'url' => NULL,
        'host' => '127.0.0.1',
        'port' => '3306',
        'database' => 'sportswear_ecommerce',
        'username' => 'root',
        'password' => '',
        'charset' => 'utf8',
        'prefix' => '',
        'prefix_indexes' => true,
      ),
    ),
    'migrations' => 
    array (
      'table' => 'migrations',
      'update_date_on_publish' => true,
    ),
    'redis' => 
    array (
      'client' => 'phpredis',
      'options' => 
      array (
        'cluster' => 'redis',
        'prefix' => 'nextplay-sportswear-database-',
        'persistent' => false,
      ),
      'default' => 
      array (
        'url' => NULL,
        'host' => '127.0.0.1',
        'username' => NULL,
        'password' => NULL,
        'port' => '6379',
        'database' => '0',
        'max_retries' => 3,
        'backoff_algorithm' => 'decorrelated_jitter',
        'backoff_base' => 100,
        'backoff_cap' => 1000,
      ),
      'cache' => 
      array (
        'url' => NULL,
        'host' => '127.0.0.1',
        'username' => NULL,
        'password' => NULL,
        'port' => '6379',
        'database' => '1',
        'max_retries' => 3,
        'backoff_algorithm' => 'decorrelated_jitter',
        'backoff_base' => 100,
        'backoff_cap' => 1000,
      ),
      'sessions' => 
      array (
        'url' => NULL,
        'host' => '127.0.0.1',
        'username' => NULL,
        'password' => NULL,
        'port' => '6379',
        'database' => '2',
        'max_retries' => 3,
        'backoff_algorithm' => 'decorrelated_jitter',
        'backoff_base' => 100,
        'backoff_cap' => 1000,
      ),
    ),
  ),
  'filesystems' => 
  array (
    'default' => 'local',
    'disks' => 
    array (
      'local' => 
      array (
        'driver' => 'local',
        'root' => '/Applications/XAMPP/xamppfiles/htdocs/laravel/NextPlaySportswear/storage/app/private',
        'serve' => true,
        'throw' => false,
        'report' => false,
      ),
      'public' => 
      array (
        'driver' => 'local',
        'root' => '/Applications/XAMPP/xamppfiles/htdocs/laravel/NextPlaySportswear/storage/app/public',
        'url' => '/media',
        'visibility' => 'public',
        'throw' => false,
        'report' => false,
      ),
      's3' => 
      array (
        'driver' => 's3',
        'key' => '',
        'secret' => '',
        'region' => 'us-east-1',
        'bucket' => '',
        'url' => NULL,
        'endpoint' => NULL,
        'use_path_style_endpoint' => false,
        'throw' => false,
        'report' => false,
      ),
    ),
    'links' => 
    array (
      '/Applications/XAMPP/xamppfiles/htdocs/laravel/NextPlaySportswear/public/storage' => '/Applications/XAMPP/xamppfiles/htdocs/laravel/NextPlaySportswear/storage/app/public',
    ),
  ),
  'logging' => 
  array (
    'default' => 'stack',
    'deprecations' => 
    array (
      'channel' => NULL,
      'trace' => false,
    ),
    'channels' => 
    array (
      'stack' => 
      array (
        'driver' => 'stack',
        'channels' => 
        array (
          0 => 'single',
        ),
        'ignore_exceptions' => false,
      ),
      'single' => 
      array (
        'driver' => 'single',
        'path' => '/Applications/XAMPP/xamppfiles/htdocs/laravel/NextPlaySportswear/storage/logs/laravel.log',
        'level' => 'debug',
        'replace_placeholders' => true,
      ),
      'daily' => 
      array (
        'driver' => 'daily',
        'path' => '/Applications/XAMPP/xamppfiles/htdocs/laravel/NextPlaySportswear/storage/logs/laravel.log',
        'level' => 'debug',
        'days' => 14,
        'replace_placeholders' => true,
      ),
      'slack' => 
      array (
        'driver' => 'slack',
        'url' => NULL,
        'username' => 'NextPlay Sportswear',
        'emoji' => ':boom:',
        'level' => 'debug',
        'replace_placeholders' => true,
      ),
      'papertrail' => 
      array (
        'driver' => 'monolog',
        'level' => 'debug',
        'handler' => 'Monolog\\Handler\\SyslogUdpHandler',
        'handler_with' => 
        array (
          'host' => NULL,
          'port' => NULL,
          'connectionString' => 'tls://:',
        ),
        'processors' => 
        array (
          0 => 'Monolog\\Processor\\PsrLogMessageProcessor',
        ),
      ),
      'stderr' => 
      array (
        'driver' => 'monolog',
        'level' => 'debug',
        'handler' => 'Monolog\\Handler\\StreamHandler',
        'handler_with' => 
        array (
          'stream' => 'php://stderr',
        ),
        'formatter' => NULL,
        'processors' => 
        array (
          0 => 'Monolog\\Processor\\PsrLogMessageProcessor',
        ),
      ),
      'syslog' => 
      array (
        'driver' => 'syslog',
        'level' => 'debug',
        'facility' => 8,
        'replace_placeholders' => true,
      ),
      'errorlog' => 
      array (
        'driver' => 'errorlog',
        'level' => 'debug',
        'replace_placeholders' => true,
      ),
      'null' => 
      array (
        'driver' => 'monolog',
        'handler' => 'Monolog\\Handler\\NullHandler',
      ),
      'emergency' => 
      array (
        'path' => '/Applications/XAMPP/xamppfiles/htdocs/laravel/NextPlaySportswear/storage/logs/laravel.log',
      ),
    ),
  ),
  'mail' => 
  array (
    'default' => 'smtp',
    'mailers' => 
    array (
      'smtp' => 
      array (
        'transport' => 'smtp',
        'scheme' => '',
        'url' => NULL,
        'host' => 'smtp.gmail.com',
        'port' => '587',
        'username' => 'saruarmunna17@gmail.com',
        'password' => 'krzk diev vswd xqvp',
        'timeout' => 10,
        'local_domain' => '127.0.0.1',
      ),
      'ses' => 
      array (
        'transport' => 'ses',
      ),
      'postmark' => 
      array (
        'transport' => 'postmark',
      ),
      'resend' => 
      array (
        'transport' => 'resend',
      ),
      'sendmail' => 
      array (
        'transport' => 'sendmail',
        'path' => '/usr/sbin/sendmail -bs -i',
      ),
      'log' => 
      array (
        'transport' => 'log',
        'channel' => NULL,
      ),
      'array' => 
      array (
        'transport' => 'array',
      ),
      'failover' => 
      array (
        'transport' => 'failover',
        'mailers' => 
        array (
          0 => 'smtp',
        ),
        'retry_after' => 60,
      ),
      'roundrobin' => 
      array (
        'transport' => 'roundrobin',
        'mailers' => 
        array (
          0 => 'ses',
          1 => 'postmark',
        ),
        'retry_after' => 60,
      ),
    ),
    'from' => 
    array (
      'address' => 'saruarmunna17@gmail.com',
      'name' => 'NextPlay Sportswear',
    ),
    'markdown' => 
    array (
      'theme' => 'default',
      'paths' => 
      array (
        0 => '/Applications/XAMPP/xamppfiles/htdocs/laravel/NextPlaySportswear/resources/views/vendor/mail',
      ),
      'extensions' => 
      array (
      ),
    ),
  ),
  'payments' => 
  array (
    'default' => 'stripe',
    'gateways' => 
    array (
      'manual' => 
      array (
        'driver' => 'App\\Payments\\Gateways\\ManualGateway',
        'enabled' => true,
      ),
      'stripe' => 
      array (
        'driver' => 'App\\Payments\\Gateways\\StripeGateway',
        'enabled' => true,
        'secret_key' => 'sk_test_YOUR_KEY',
        'publishable_key' => 'pk_test_YOUR_KEY',
        'webhook_secret' => 'whsec_YOUR_SECRET',
        'currency' => 'USD',
        'checkout_expires_minutes' => 30,
      ),
    ),
    'webhooks' => 
    array (
      'queue' => 'payments',
    ),
    'reconciliation' => 
    array (
      'pending_after_minutes' => 10,
      'batch_size' => 100,
    ),
  ),
  'queue' => 
  array (
    'default' => 'database',
    'connections' => 
    array (
      'sync' => 
      array (
        'driver' => 'sync',
      ),
      'database' => 
      array (
        'driver' => 'database',
        'connection' => NULL,
        'table' => 'jobs',
        'queue' => 'default',
        'retry_after' => 90,
        'after_commit' => false,
      ),
      'beanstalkd' => 
      array (
        'driver' => 'beanstalkd',
        'host' => 'localhost',
        'queue' => 'default',
        'retry_after' => 90,
        'block_for' => 0,
        'after_commit' => false,
      ),
      'sqs' => 
      array (
        'driver' => 'sqs',
        'key' => '',
        'secret' => '',
        'prefix' => 'https://sqs.us-east-1.amazonaws.com/your-account-id',
        'queue' => 'default',
        'suffix' => NULL,
        'region' => 'us-east-1',
        'after_commit' => false,
      ),
      'redis' => 
      array (
        'driver' => 'redis',
        'connection' => 'default',
        'queue' => 'default',
        'retry_after' => 90,
        'block_for' => NULL,
        'after_commit' => false,
      ),
      'deferred' => 
      array (
        'driver' => 'deferred',
      ),
      'failover' => 
      array (
        'driver' => 'failover',
        'connections' => 
        array (
          0 => 'database',
          1 => 'deferred',
        ),
      ),
      'background' => 
      array (
        'driver' => 'background',
      ),
    ),
    'batching' => 
    array (
      'database' => 'mysql',
      'table' => 'job_batches',
    ),
    'failed' => 
    array (
      'driver' => 'database-uuids',
      'database' => 'mysql',
      'table' => 'failed_jobs',
    ),
  ),
  'security' => 
  array (
    'email_verification' => 
    array (
      'expire_minutes' => 60,
      'resend' => 
      array (
        'ip_per_minute' => 6,
        'account_per_minute' => 3,
        'account_per_hour' => 10,
      ),
    ),
    'password_reset' => 
    array (
      'request' => 
      array (
        'ip_per_minute' => 3,
        'ip_per_hour' => 12,
        'email_per_minute' => 2,
        'email_per_hour' => 5,
      ),
      'submit' => 
      array (
        'ip_per_minute' => 5,
        'ip_per_hour' => 20,
        'email_per_minute' => 3,
        'email_per_hour' => 10,
      ),
    ),
  ),
  'services' => 
  array (
    'postmark' => 
    array (
      'key' => NULL,
    ),
    'resend' => 
    array (
      'key' => NULL,
    ),
    'ses' => 
    array (
      'key' => '',
      'secret' => '',
      'region' => 'us-east-1',
    ),
    'slack' => 
    array (
      'notifications' => 
      array (
        'bot_user_oauth_token' => NULL,
        'channel' => NULL,
      ),
    ),
    'pusher' => 
    array (
      'key' => '473e69ba00b10ca805de',
      'secret' => '19bf81d482b42f7be129',
      'app_id' => '2173478',
      'cluster' => 'ap2',
      'host' => '',
    ),
  ),
  'session' => 
  array (
    'driver' => 'file',
    'lifetime' => 120,
    'expire_on_close' => false,
    'encrypt' => false,
    'files' => '/Applications/XAMPP/xamppfiles/htdocs/laravel/NextPlaySportswear/storage/framework/sessions',
    'connection' => NULL,
    'table' => 'sessions',
    'store' => NULL,
    'lottery' => 
    array (
      0 => 2,
      1 => 100,
    ),
    'cookie' => 'nextplay-sportswear-session',
    'path' => '/',
    'domain' => NULL,
    'secure' => NULL,
    'http_only' => true,
    'same_site' => 'lax',
    'partitioned' => false,
    'serialization' => 'json',
  ),
  'storefront' => 
  array (
    'name' => 'NextPlay Sportswear',
    'tagline' => 'Custom sportswear, team uniforms, jerseys, hoodies, caps, bags, and promotional products.',
    'email' => 'support@example.com',
    'whatsapp' => '+1 000 000 0000',
    'whatsapp_url' => NULL,
    'social' => 
    array (
      'instagram' => 'https://www.instagram.com/nextplaysportswear/',
      'facebook' => 'https://www.facebook.com/nextplaysportswear',
      'tiktok' => 'https://www.tiktok.com/@nextplaysportswear',
      'youtube' => 'https://www.youtube.com/@nextplaysportswear',
    ),
    'url' => 'http://127.0.0.1:8000',
    'logo' => '/images/logo.png',
    'og_image' => 'images/og-default.jpg',
    'area_served' => 'Worldwide',
    'available_languages' => 
    array (
      0 => 'English',
    ),
    'slider_cache_seconds' => 600,
    'product_cards' => 
    array (
      'show_default_rating' => true,
      'default_rating' => 4.8,
      'default_reviews_count' => 23,
      'live_viewer_window_minutes' => 5,
    ),
  ),
  'transactional_email' => 
  array (
    'enabled' => true,
    'mailer' => 'smtp',
    'critical' => 
    array (
      'password_reset_sync' => false,
    ),
    'queue' => 
    array (
      'enabled' => true,
      'connection' => 'database',
      'name' => '',
      'tries' => 3,
      'timeout' => 30,
      'backoff' => 
      array (
        0 => 60,
        1 => 300,
        2 => 900,
      ),
    ),
    'recipients' => 
    array (
      'support' => 'saruarmunna17@gmail.com',
      'sales' => 'saruarmunna17@gmail.com',
      'orders' => 'saruarmunna17@gmail.com',
      'returns' => 'saruarmunna17@gmail.com',
    ),
    'brand' => 
    array (
      'name' => 'NextPlay Sportswear',
      'support_email' => 'saruarmunna17@gmail.com',
    ),
  ),
  'view' => 
  array (
    'paths' => 
    array (
      0 => '/Applications/XAMPP/xamppfiles/htdocs/laravel/NextPlaySportswear/resources/views',
    ),
    'compiled' => '/Applications/XAMPP/xamppfiles/htdocs/laravel/NextPlaySportswear/storage/framework/views',
  ),
  'tinker' => 
  array (
    'commands' => 
    array (
    ),
    'alias' => 
    array (
    ),
    'dont_alias' => 
    array (
      0 => 'App\\Nova',
    ),
    'trust_project' => 'always',
  ),
);
