@php
    $isEdit = $product->exists;
    $pivotPrimaryCategoryId = $product->relationLoaded('categories')
        ? optional($product->categories->firstWhere('pivot.is_primary', true) ?? $product->categories->first())->id
        : null;
    $legacyPrimaryCategoryId = $product->subcategory_id ?: $product->category_id;
    $primaryCategoryId = old('primary_category_id', $pivotPrimaryCategoryId ?: $legacyPrimaryCategoryId);
    $assignedCategoryIds = $product->relationLoaded('categories')
        ? $product->categories->pluck('id')->map(fn ($id) => (int) $id)->all()
        : [];
    if ($assignedCategoryIds === []) {
        $assignedCategoryIds = collect([$product->category_id, $product->subcategory_id])->filter()->map(fn ($id) => (int) $id)->unique()->values()->all();
    }
    $showInCategoryPageValue = old(
        'show_in_category_page',
        $isEdit ? ($primaryCategoryId && in_array((int) $primaryCategoryId, $assignedCategoryIds, true)) : true
    );
    $showInCategoryPage = filter_var($showInCategoryPageValue, FILTER_VALIDATE_BOOLEAN);
    $isFeaturedProduct = filter_var(old('is_featured', (int) ($product->is_featured ?? false)), FILTER_VALIDATE_BOOLEAN);
    $dynamicCatalogAttributeIds = $product->relationLoaded('optionGroups')
        ? $product->optionGroups->where('use_as_filter', true)->pluck('catalog_attribute_id')->filter()->map(fn($id)=>(int)$id)
        : collect();
    $persistedManualAttributeValueIds = $product->relationLoaded('attributeValues')
        ? $product->attributeValues->reject(fn($value) => $dynamicCatalogAttributeIds->contains((int) $value->attribute_id))->pluck('id')->all()
        : [];
    $selectedAttributeValueIds = collect(old('attribute_value_ids', $persistedManualAttributeValueIds))->map(fn($id)=>(int)$id)->all();
    $storedSpecificationRows = collect($product->specifications ?? [])
        ->mapWithKeys(function ($value, $label) {
            if (is_array($value)) {
                $rowLabel = $value['label'] ?? $value['name'] ?? $label;
                $rowValue = $value['value'] ?? $value['information'] ?? null;

                return filled($rowLabel) && filled($rowValue) ? [(string) $rowLabel => (string) $rowValue] : [];
            }

            return filled($label) && filled($value) ? [(string) $label => (string) $value] : [];
        });
    $fabricLikeSpecificationLabels = ['Fabric', 'Material', 'Materials', 'Metarial', 'Metarials', 'Meterial', 'Meterials'];
    $fabricSpecificationLabel = collect($fabricLikeSpecificationLabels)
        ->first(fn ($label) => filled($storedSpecificationRows->get($label))) ?: 'Fabric';
    $productSpecificationLabels = ['SKU', 'Product Type', $fabricSpecificationLabel, 'Fit', 'Customization', 'Size Range', 'MOQ', 'Lead Time'];
    $productSpecificationText = old('product_specification_text');
    if ($productSpecificationText === null) {
        $knownSpecificationRows = collect($productSpecificationLabels)
            ->map(fn ($label) => $label.': '.($storedSpecificationRows->get($label) ?: ''));
        $extraSpecificationRows = $storedSpecificationRows
            ->reject(fn ($value, $label) => in_array((string) $label, $productSpecificationLabels, true))
            ->map(fn ($value, $label) => $label.': '.$value)
            ->values();
        $productSpecificationText = $knownSpecificationRows
            ->merge($extraSpecificationRows)
            ->implode(PHP_EOL);
    }
    $specificationOptionSummary = static function (string $type) use ($product): string {
        if (! $product->relationLoaded('optionGroups')) {
            return '';
        }

        return $product->optionGroups
            ->where('jersey_customization_type', $type)
            ->where('is_active', true)
            ->flatMap(fn ($group) => $group->relationLoaded('values') ? $group->values->where('is_active', true)->pluck('label') : [])
            ->filter()
            ->unique()
            ->values()
            ->implode(', ');
    };
    $specificationSizeRange = '';
    if ($product->relationLoaded('sizeGroups')) {
        $firstSizeGroup = $product->sizeGroups->where('is_active', true)->first();
        $sizeLabels = $firstSizeGroup && $firstSizeGroup->relationLoaded('sizes')
            ? $firstSizeGroup->sizes->where('is_active', true)->pluck('label')->filter()->values()
            : collect();
        $specificationSizeRange = $sizeLabels->isEmpty()
            ? ''
            : ($sizeLabels->first() === $sizeLabels->last() ? $sizeLabels->first() : $sizeLabels->first().' – '.$sizeLabels->last());
    }
    $specificationLeadTime = '';
    if ($product->relationLoaded('productionSpeeds')) {
        $activeSpeeds = $product->productionSpeeds->where('is_active', true);
        if ($activeSpeeds->isNotEmpty()) {
            $minDays = (int) $activeSpeeds->min('minimum_days');
            $maxDays = (int) $activeSpeeds->max('maximum_days');
            $specificationLeadTime = $minDays === $maxDays ? $minDays.' Business Days' : $minDays.'–'.$maxDays.' Business Days';
        }
    }
    $productSpecificationAutoValues = [
        'SKU' => old('sku', $storedSpecificationRows->get('SKU') ?: $product->sku),
        'Product Type' => old('product_type', $product->product_type),
        'Fabric' => collect(\App\Enums\JerseyCustomizationType::fabricTypeValues())->map(fn ($type) => $specificationOptionSummary($type))->filter()->implode(', '),
        'Fit' => collect([$specificationOptionSummary('jersey_style'), $specificationOptionSummary('sleeves_and_cuffs')])->filter()->implode(', '),
        'Customization' => '',
        'Size Range' => $specificationSizeRange,
        'MOQ' => $product->minimum_quantity ? number_format((int) $product->minimum_quantity).' '.((int) $product->minimum_quantity === 1 ? 'Piece' : 'Pieces') : '',
        'Lead Time' => $specificationLeadTime,
    ];
    $existingProductImages = $product->relationLoaded('images') ? $product->images->keyBy('id') : collect();
    $submittedImageValues = old('image_urls');
    $imageValues = $submittedImageValues !== null
        ? collect($submittedImageValues)->map(function ($image, $index) use ($existingProductImages) {
            $existing = $existingProductImages->get((int) ($image['existing_id'] ?? 0));

            return [
                'client_key' => filled($image['existing_id'] ?? null) ? 'existing-'.$image['existing_id'] : 'old-'.$index,
                'existing_id' => $image['existing_id'] ?? '',
                'media_library_image_id' => $image['media_library_image_id'] ?? ($existing?->media_library_image_id ?? ''),
                'url' => $image['url'] ?? '',
                'preview' => $existing?->publicUrl() ?: ($image['url'] ?? ''),
                'name' => $image['name'] ?? ($image['alt'] ?? ''),
                'is_primary' => filter_var($image['is_primary'] ?? false, FILTER_VALIDATE_BOOL),
            ];
        })->values()->all()
        : $existingProductImages->values()->map(fn ($image) => [
            'client_key' => 'existing-'.$image->id,
            'existing_id' => $image->id,
            'media_library_image_id' => $image->media_library_image_id ?: '',
            'url' => $image->media_library_image_id ? '' : (\App\Support\PublicMedia::storedPathFromUrl($image->url) ? '' : ($image->url ?: '')),
            'preview' => $image->publicUrl(),
            'name' => $image->alt_text,
            'is_primary' => $image->is_primary,
        ])->all();
    $storedPriceHeaders = collect(old('price_table_headers', $product->price_table_headers ?? []))->values();
    if ($storedPriceHeaders->isEmpty()) {
        $storedPriceHeaders = collect(['Quantity', 'Unit Price ($)', 'Setup Fee ($)']);
    }
    $priceHeaderValues = $storedPriceHeaders->slice(1)->values()->all();
    $storedPriceRows = collect(old('price_table_rows', $product->price_table_rows ?? []))->values();
    $storedPriceRanges = collect(old('price_table_ranges', []))->values();
    $storedPriceTiers = $product->relationLoaded('priceTiers') ? $product->priceTiers->values() : collect();
    if ($storedPriceRows->isEmpty() && $storedPriceTiers->isNotEmpty()) {
        $storedPriceRows = $storedPriceTiers->map(fn ($tier) => [
            (string) $tier->minimum_quantity,
            '$'.number_format((float) $tier->unit_price, 2),
            $tier->savings_label ?: '—',
        ])->values();
    }
    $parseLegacyQuantityRange = static function ($value): array {
        preg_match_all('/\d+/', str_replace(',', '', (string) $value), $matches);
        $numbers = collect($matches[0] ?? [])->map(fn ($number) => (int) $number)->values();

        return [
            'minimum_quantity' => $numbers->get(0) ?: 1,
            'maximum_quantity' => str_contains((string) $value, '+') ? null : $numbers->get(1),
        ];
    };
    $priceRowValues = $storedPriceRows->map(function ($row, $index) use ($storedPriceRanges, $storedPriceTiers, $parseLegacyQuantityRange, $priceHeaderValues) {
        $range = $storedPriceRanges->get($index);
        $tier = $storedPriceTiers->get($index);
        $legacyRange = $parseLegacyQuantityRange($row[0] ?? '');
        $minimum = data_get($range, 'minimum_quantity', $tier?->minimum_quantity ?? $legacyRange['minimum_quantity']);
        $maximum = data_get($range, 'maximum_quantity', $tier?->maximum_quantity ?? $legacyRange['maximum_quantity']);
        $cells = collect($row)->slice(1)->values()->take(count($priceHeaderValues))->all();

        return [
            'minimum_quantity' => $minimum,
            'maximum_quantity' => $maximum,
            'cells' => array_pad($cells, count($priceHeaderValues), ''),
        ];
    })->values()->all();
    if ($priceRowValues === []) {
        $priceRowValues = [[
            'minimum_quantity' => 1,
            'maximum_quantity' => null,
            'cells' => array_pad([], count($priceHeaderValues), ''),
        ]];
    }
    $optionValues = old('option_groups', $product->relationLoaded('optionGroups') ? $product->optionGroups->where('is_active', true)->filter(fn($group) => ($group->display_mode ?: 'customer') !== 'hidden')->map(fn($group) => [
        'name' => $group->name, 'code' => $group->code, 'section' => $group->section, 'type' => $group->type,
        'jersey_customization_type' => $group->jersey_customization_type,
        'display_mode' => $group->display_mode ?: 'customer', 'fixed_value_code' => $group->fixed_value_code,
        'fixed_text_value' => $group->fixed_text_value, 'show_in_summary' => $group->show_in_summary,
        'use_as_filter' => $group->use_as_filter, 'catalog_attribute_id' => $group->catalog_attribute_id, 'description' => $group->description,
        'placeholder' => $group->placeholder, 'is_required' => $group->is_required,
        'minimum_selections' => $group->minimum_selections, 'maximum_selections' => $group->maximum_selections,
        'accepted_file_types' => $group->accepted_file_types, 'maximum_file_size_mb' => $group->maximum_file_size_mb,
        'is_active' => true,
        'values' => $group->values->where('is_active', true)->map(fn($value) => [
            'existing_id' => $value->id, 'jersey_customization_option_id' => $value->jersey_customization_option_id, 'world_cup_customization_option_id' => $value->world_cup_customization_option_id,
            'label' => $value->label, 'code' => $value->code, 'description' => $value->description,
            'color_hex' => $value->color_hex ?: '', 'image_url' => $value->image_url,
            'image_previews' => collect($value->publicImages())->pluck('url')->values()->all(),
            'price_adjustment' => $value->price_adjustment, 'charge_type' => $value->charge_type ?: 'per_unit',
            'stock_quantity' => $value->stock_quantity, 'clear_images' => false,
            'is_default' => $value->is_default, 'is_active' => true,
        ])->values()->all(),
    ])->values()->all() : []);
    $fabricPriceTableValues = [];
    $submittedFabricPriceTables = old('fabric_price_tables');
    if (is_array($submittedFabricPriceTables)) {
        $fabricPriceTableValues = collect($submittedFabricPriceTables)
            ->filter(fn ($table) => is_array($table))
            ->mapWithKeys(function ($table) use ($priceHeaderValues, $priceRowValues) {
                $fabricKey = trim((string) ($table['fabric_key'] ?? ''));
                if ($fabricKey === '') {
                    return [];
                }

                $headers = collect($table['price_table_headers'] ?? [])->values();
                if ($headers->isNotEmpty() && trim((string) $headers->first()) === 'Quantity') {
                    $headers = $headers->slice(1)->values();
                }
                $headers = $headers->map(fn ($header) => trim((string) $header))->filter()->values()->all() ?: $priceHeaderValues;
                $rows = collect($table['price_table_rows'] ?? [])->values();
                $ranges = collect($table['price_table_ranges'] ?? [])->values();
                $rowValues = $rows->map(function ($row, $index) use ($ranges, $headers) {
                    $row = is_array($row) ? $row : [];
                    $range = $ranges->get($index, []);
                    $cells = collect($row)->slice(1)->values()->take(count($headers))->all();

                    return [
                        'minimum_quantity' => data_get($range, 'minimum_quantity', 1),
                        'maximum_quantity' => data_get($range, 'maximum_quantity'),
                        'cells' => array_pad($cells, count($headers), ''),
                    ];
                })->values()->all() ?: $priceRowValues;

                return [$fabricKey => [
                    'fabric_key' => $fabricKey,
                    'jersey_customization_option_id' => $table['jersey_customization_option_id'] ?? '',
                    'fabric_code' => $table['fabric_code'] ?? '',
                    'fabric_label' => $table['fabric_label'] ?? '',
                    'has_custom_pricing' => filter_var($table['has_custom_pricing'] ?? false, FILTER_VALIDATE_BOOLEAN),
                    'headers' => $headers,
                    'rows' => $rowValues,
                    'highlight_column' => (int) ($table['price_table_highlight_column'] ?? 1),
                    'note' => $table['price_table_note'] ?? '',
                ]];
            })
            ->all();
    } elseif ($product->relationLoaded('fabricPriceTables')) {
        $fabricPriceTableValues = $product->fabricPriceTables
            ->where('is_active', true)
            ->mapWithKeys(function ($table) use ($parseLegacyQuantityRange, $priceHeaderValues, $priceRowValues) {
                $headers = collect($table->price_table_headers ?? [])->values();
                if ($headers->isNotEmpty() && trim((string) $headers->first()) === 'Quantity') {
                    $headers = $headers->slice(1)->values();
                }
                $headers = $headers->map(fn ($header) => trim((string) $header))->filter()->values()->all() ?: $priceHeaderValues;
                $storedRows = collect($table->price_table_rows ?? [])->values();
                $storedRanges = collect($table->price_table_ranges ?? [])->values();
                $tiers = $table->relationLoaded('tiers') ? $table->tiers->values() : collect();
                if ($storedRows->isEmpty() && $tiers->isNotEmpty()) {
                    $storedRows = $tiers->map(fn ($tier) => [
                        $tier->maximum_quantity ? $tier->minimum_quantity.'-'.$tier->maximum_quantity : $tier->minimum_quantity.'+',
                        '$'.number_format((float) $tier->unit_price, 2),
                        $tier->savings_label ?: '',
                    ])->values();
                }
                $rows = $storedRows->map(function ($row, $index) use ($storedRanges, $tiers, $parseLegacyQuantityRange, $headers) {
                    $row = is_array($row) ? $row : [];
                    $range = $storedRanges->get($index);
                    $tier = $tiers->get($index);
                    $legacyRange = $parseLegacyQuantityRange($row[0] ?? '');
                    $cells = collect($row)->slice(1)->values()->take(count($headers))->all();

                    return [
                        'minimum_quantity' => data_get($range, 'minimum_quantity', $tier?->minimum_quantity ?? $legacyRange['minimum_quantity']),
                        'maximum_quantity' => data_get($range, 'maximum_quantity', $tier?->maximum_quantity ?? $legacyRange['maximum_quantity']),
                        'cells' => array_pad($cells, count($headers), ''),
                    ];
                })->values()->all() ?: $priceRowValues;

                return [$table->fabric_key => [
                    'fabric_key' => $table->fabric_key,
                    'jersey_customization_option_id' => $table->jersey_customization_option_id,
                    'fabric_code' => $table->fabric_code,
                    'fabric_label' => $table->fabric_label,
                    'has_custom_pricing' => true,
                    'headers' => $headers,
                    'rows' => $rows,
                    'highlight_column' => (int) ($table->price_table_highlight_column ?: 1),
                    'note' => $table->price_table_note ?: '',
                ]];
            })
            ->all();
    }
    $submittedSizeValues = old('size_groups');
    $sizeValues = is_array($submittedSizeValues)
        ? collect($submittedSizeValues)->map(fn ($group) => array_merge([
            'existing_id' => '', 'size_option_group_id' => '', 'name' => '', 'code' => '',
            'audience_label' => '', 'description_html' => '', 'sizes' => [], 'sizes_text' => '',
            'size_codes' => [], 'size_price_adjustments' => [], 'has_size_extra_charges' => false,
            'chart_enabled' => false, 'chart_html' => '', 'chart_title' => '', 'chart_note' => '',
            'chart_columns' => [], 'chart_rows' => [], 'chart_columns_text' => '', 'chart_rows_text' => '',
            'chart_image_url' => '', 'chart_image_preview' => '', 'is_active' => true,
        ], is_array($group) ? $group : []))->values()->all()
        : ($product->relationLoaded('sizeGroups') ? $product->sizeGroups->where('is_active', true)->map(fn($group) => [
            'existing_id' => $group->id,
            'size_option_group_id' => $group->size_option_group_id,
            'name' => $group->name,
            'code' => $group->code,
            'audience_label' => $group->masterGroup?->audience?->label() ?? 'Legacy',
            'description_html' => $group->description_html,
            'chart_html' => $group->chart_html,
            'sizes' => $group->sizes->pluck('label')->values()->all(),
            'sizes_text' => $group->sizes->pluck('label')->implode(', '),
            'size_codes' => $group->sizes->mapWithKeys(fn($size) => [$size->label => $size->code])->all(),
            'size_price_adjustments' => $group->sizes->flatMap(
                fn($size) => \App\Support\ProductSizeExtraCharges::editorAdjustmentAliases(
                    (string) $size->code,
                    (string) $size->label,
                    $size->price_adjustment
                )
            )->all(),
            'has_size_extra_charges' => $group->sizes->contains(fn($size) => (float) $size->price_adjustment > 0),
            'chart_enabled' => $group->chart_enabled,
            'chart_title' => $group->chart_title,
            'chart_note' => $group->chart_note,
            'chart_columns' => $group->chart_columns ?? [],
            'chart_rows' => $group->chart_rows ?? [],
            'chart_columns_text' => collect($group->chart_columns ?? [])->implode(', '),
            'chart_rows_text' => collect($group->chart_rows ?? [])->map(fn($row) => collect($row)->implode(' | '))->implode("\n"),
            'chart_image_url' => $group->chart_image_url,
            'chart_image_preview' => $group->chartImageUrl(),
            'is_active' => true,
        ])->values()->all() : []);
    $storedSpeedValues = collect($product->relationLoaded('productionSpeeds')
        ? $product->productionSpeeds->where('is_active', true)->map(fn($speed) => $speed->only([
            'name', 'code', 'description', 'price_adjustment', 'minimum_quantity', 'maximum_quantity',
            'minimum_days', 'maximum_days', 'is_active',
        ]))->values()->all()
        : [])->values();

    $productionHeaderValues = collect(old('production_table_headers', $product->production_table_headers ?? []))
        ->map(fn ($header) => trim((string) $header))
        ->filter()
        ->values();
    $productionRowValues = collect(old('production_table_rows', $product->production_table_rows ?? []))->values();

    // Preserve existing products created by the previous quantity-linked editor.
    // This fallback only reads this product's saved production options; it never
    // copies ranges from the price table or any master data.
    if ($productionHeaderValues->isEmpty() && $storedSpeedValues->isNotEmpty()) {
        $productionHeaderValues = $storedSpeedValues->pluck('name')->filter()->unique()->values();
        $productionRowValues = $storedSpeedValues
            ->groupBy(fn ($speed) => (int) data_get($speed, 'minimum_quantity', 1).'|'.(filled(data_get($speed, 'maximum_quantity')) ? (int) data_get($speed, 'maximum_quantity') : ''))
            ->map(function ($speeds) use ($productionHeaderValues) {
                $first = $speeds->first();
                $minimum = max(1, (int) data_get($first, 'minimum_quantity', 1));
                $maximum = filled(data_get($first, 'maximum_quantity')) ? (int) data_get($first, 'maximum_quantity') : null;
                $range = $maximum === null ? $minimum.'+' : $minimum.'-'.$maximum;

                return [
                    'range' => $range,
                    'cells' => $productionHeaderValues->map(function ($header) use ($speeds) {
                        $speed = $speeds->firstWhere('name', $header);

                        return [
                            'enabled' => (bool) $speed,
                            'description' => data_get($speed, 'description', ''),
                            'price_adjustment' => data_get($speed, 'price_adjustment', 0),
                            'production_time' => ((int) data_get($speed, 'minimum_days', 1) === 0 && (int) data_get($speed, 'maximum_days', data_get($speed, 'minimum_days', 1)) === 0)
                                ? 'To be confirmed'
                                : \App\Support\ProductionTime::format(
                                    data_get($speed, 'minimum_days', 1),
                                    data_get($speed, 'maximum_days', data_get($speed, 'minimum_days', 1))
                                ),
                            'minimum_days' => data_get($speed, 'minimum_days', 1),
                            'maximum_days' => data_get($speed, 'maximum_days', data_get($speed, 'minimum_days', 1)),
                        ];
                    })->values()->all(),
                ];
            })->values();
    }

    if ($productionHeaderValues->isEmpty()) {
        $productionHeaderValues = collect(['Standard Production']);
    }
    if ($productionRowValues->isEmpty()) {
        $productionRowValues = collect([[
            'range' => '1+',
            'cells' => [[
                'enabled' => false,
                'description' => '',
                'price_adjustment' => 0,
                'production_time' => '1 day',
                'minimum_days' => 1,
                'maximum_days' => 1,
            ]],
        ]]);
    }
    $productionRowValues = $productionRowValues->map(function ($row) use ($productionHeaderValues) {
        $row = is_array($row) ? $row : [];
        $cells = collect($row['cells'] ?? [])->values();

        return [
            'range' => (string) ($row['range'] ?? ''),
            'cells' => $productionHeaderValues->map(function ($header, $index) use ($cells) {
                $cell = (array) $cells->get($index, []);

                return [
                    'enabled' => (bool) ($cell['enabled'] ?? false),
                    'description' => (string) ($cell['description'] ?? ''),
                    'price_adjustment' => $cell['price_adjustment'] ?? 0,
                    'production_time' => $cell['production_time'] ?? \App\Support\ProductionTime::format(
                        $cell['minimum_days'] ?? 1,
                        $cell['maximum_days'] ?? ($cell['minimum_days'] ?? 1)
                    ),
                    'minimum_days' => $cell['minimum_days'] ?? 1,
                    'maximum_days' => $cell['maximum_days'] ?? ($cell['minimum_days'] ?? 1),
                ];
            })->values()->all(),
        ];
    })->values();
    $hasOldProductionInput = session()->hasOldInput();
    $selectedProductionCodes = collect($hasOldProductionInput
        ? old('production_method_codes', [])
        : ($product->relationLoaded('productionSpeeds') ? $product->productionSpeeds->pluck('code')->all() : []))
        ->map(fn ($code) => \Illuminate\Support\Str::slug((string) $code))
        ->filter()
        ->unique()
        ->values();
    $savedProductionMethodCharges = $product->relationLoaded('productionSpeeds')
        ? $product->productionSpeeds
            ->mapWithKeys(fn ($speed) => [
                \Illuminate\Support\Str::slug((string) $speed->code) => max(0, round((float) $speed->price_adjustment, 2)),
            ])
            ->all()
        : [];
    $productionMethodChargeValues = collect(old('production_method_price_adjustments', $savedProductionMethodCharges))
        ->mapWithKeys(fn ($value, $code) => [
            \Illuminate\Support\Str::slug((string) $code) => max(0, round((float) $value, 2)),
        ]);
    if (! $hasOldProductionInput && isset($productionMethodOptions) && $productionMethodOptions->isNotEmpty()) {
        $availableProductionCodes = $productionMethodOptions
            ->pluck('code')
            ->map(fn ($code) => \Illuminate\Support\Str::slug((string) $code))
            ->filter()
            ->values();

        $hasMatchingMasterProduction = $selectedProductionCodes
            ->intersect($availableProductionCodes)
            ->isNotEmpty();

        if ((! $product->exists && $selectedProductionCodes->isEmpty()) || (! $hasMatchingMasterProduction && $selectedProductionCodes->isNotEmpty())) {
            $defaultProductionCodes = $productionMethodOptions
                ->where('is_default', true)
                ->pluck('code')
                ->map(fn ($code) => \Illuminate\Support\Str::slug((string) $code))
                ->filter()
                ->values();
            $selectedProductionCodes = $defaultProductionCodes->isNotEmpty()
                ? $defaultProductionCodes
                : $productionMethodOptions->where('is_active', true)->take(1)->pluck('code')->map(fn ($code) => \Illuminate\Support\Str::slug((string) $code))->values();
        }
    }

    $hasOldShippingInput = session()->hasOldInput();
    $selectedShippingCodes = collect($hasOldShippingInput
        ? old('shipping_method_codes', [])
        : ($product->relationLoaded('shippingMethods') ? $product->shippingMethods->pluck('code')->all() : []))
        ->map(fn ($code) => \Illuminate\Support\Str::slug((string) $code))
        ->filter()
        ->unique()
        ->values();
    $defaultShippingCode = \Illuminate\Support\Str::slug((string) ($hasOldShippingInput
        ? old('shipping_method_default_code')
        : optional($product->relationLoaded('shippingMethods') ? $product->shippingMethods->firstWhere('is_default', true) : null)->code));
    if ($defaultShippingCode === '' && $selectedShippingCodes->isNotEmpty()) {
        $defaultShippingCode = (string) $selectedShippingCodes->first();
    }
    $shippingValues = $selectedShippingCodes
        ->map(fn ($code) => ['code' => $code, 'is_default' => $code === $defaultShippingCode])
        ->values()
        ->all();
    $defaultRosterFields = \App\Support\ProductRoster::defaultFields();
    $rosterFieldValues = old('jersey_roster_fields', $product->jersey_roster_fields ?: $defaultRosterFields);
    $selectedFaqIds = collect(session()->hasOldInput()
        ? old('faq_ids', [])
        : ($product->relationLoaded('faqs') ? $product->faqs->pluck('id')->all() : []))
        ->map(fn ($id) => (int) $id)
        ->filter()
        ->unique()
        ->values();
    $optionGroupValidationErrors = collect($errors->getMessages())
        ->reduce(function (array $grouped, array $messages, string $key): array {
            if (preg_match('/^option_groups\.(\d+)\./', $key, $matches) !== 1) {
                return $grouped;
            }

            $index = (int) $matches[1];
            $grouped[$index] = array_values(array_unique(array_merge($grouped[$index] ?? [], $messages)));

            return $grouped;
        }, []);
    $primaryCategoryName = optional(collect($categoryOptions)->firstWhere('id', (int) $primaryCategoryId))->indented_name;
    $categorySearchOptions = collect($categoryOptions)->map(fn ($category) => [
        'id' => (int) $category->id,
        'name' => $category->name,
        'label' => $category->indented_name,
        'slug' => $category->slug,
        'depth' => (int) ($category->depth ?? 0),
        'parent_id' => $category->parent_id ? (int) $category->parent_id : null,
    ])->values()->all();
    $initial = [
        'productName' => old('name', $product->name),
        'productSku' => old('sku', $storedSpecificationRows->get('SKU') ?: $product->sku),
        'shortDescription' => old('short_description', $product->short_description),
        'descriptionHtml' => old('description_html', $product->description_html),
        'fulfillmentHtml' => old('fulfillment_html', $product->fulfillment_html),
        'slug' => old('slug', $product->slug),
        'primaryCategoryId' => $primaryCategoryId ? (int) $primaryCategoryId : '',
        'primaryCategoryName' => $primaryCategoryName,
        'isFeatured' => $isFeaturedProduct,
        'showInCategoryPage' => $showInCategoryPage,
        'categoryOptions' => $categorySearchOptions,
        'imageUrls' => $imageValues,
        'mediaLibraryIndexUrl' => \Illuminate\Support\Facades\Route::has('admin.media-library.index') ? route('admin.media-library.index') : url('/admin/media-library'),
        'mediaLibraryStoreUrl' => \Illuminate\Support\Facades\Route::has('admin.media-library.store') ? route('admin.media-library.store') : url('/admin/media-library'),
        'priceHeaders' => $priceHeaderValues,
        'pricingMode' => old('pricing_mode', 'standard'),
        'priceRows' => $priceRowValues,
        'priceHighlightColumn' => (int) old('price_table_highlight_column', $product->price_table_highlight_column ?? 1),
        'fabricPriceTables' => $fabricPriceTableValues,
        'fabricCustomizationTypes' => \App\Enums\JerseyCustomizationType::fabricTypeValues(),
        'optionGroups' => $optionValues,
        'optionGroupErrors' => $optionGroupValidationErrors,
        'jerseyCustomizationTypes' => $jerseyCustomizationTypes,
        'customizationTypeGroups' => collect(\App\Enums\JerseyCustomizationType::menuGroups())
            ->map(fn ($group, $groupKey) => [
                'key' => $groupKey,
                'number' => $group['number'],
                'label' => $group['label'],
                'size_options_enabled' => \App\Support\ProductSizing::supportsMasterDataSizeOptions($groupKey),
                'types' => collect(\App\Enums\JerseyCustomizationType::productConfigurationTypesForGroup($groupKey))->map(fn ($type) => [
                    'value' => $type->value,
                    'label' => $type->label(),
                    'group' => $type->group(),
                ])->values()->all(),
            ])
            ->concat(collect(\App\Support\WorldCupCustomizationRegistry::menuCategories())->map(fn ($category, $categoryKey) => [
                'key' => 'world_cup:'.$categoryKey,
                'number' => $category['number'],
                'label' => 'World Cup / '.$category['label'],
                'size_options_enabled' => false,
                'types' => collect($category['types'])->map(fn ($type) => [
                    'value' => $type->value,
                    'label' => $type->label(),
                    'group' => 'world_cup:'.$type->categoryKey(),
                ])->values()->all(),
            ]))
            ->values()
            ->all(),
        'jerseyCustomizationOptions' => $jerseyCustomizationOptions,
        'worldCupCustomizationOptions' => $worldCupCustomizationOptions,
        'sizeOptionGroups' => $sizeOptionGroups,
        'sizeGroups' => $sizeValues,
        'productionHeaders' => $productionHeaderValues->all(),
        'productionRows' => $productionRowValues->all(),
        'shippingMethods' => $shippingValues,
        'rosterFields' => $rosterFieldValues,
        'productProfile' => old('product_profile', $product->product_profile ?: 'standard'),
        'productionMethodsEnabled' => (bool) old('production_methods_enabled', $product->production_methods_enabled ?? false),
        'shippingMethodsEnabled' => (bool) old('shipping_methods_enabled', $product->shipping_methods_enabled ?? false),
        'rosterEnabled' => (bool) old('jersey_roster_enabled', $product->jersey_roster_enabled ?? false),
        'rosterPanelOpen' => true,
        'rosterOptional' => (bool) old('jersey_roster_optional', $product->jersey_roster_optional ?? true),
        'artworkUploadEnabled' => (bool) old('artwork_upload_enabled', $product->artwork_upload_enabled ?? false),
        'artworkUploadRequired' => (bool) old('artwork_upload_required', $product->artwork_upload_required ?? false),
        'artworkUploadTitle' => old('artwork_upload_title', $product->artwork_upload_title ?: 'Upload Custom Artwork'),
        'artworkUploadDescription' => old('artwork_upload_description', $product->artwork_upload_description ?: 'Upload one or more artwork files for the production team.'),
        'artworkUploadMaxFiles' => (int) old('artwork_upload_max_files', $product->artwork_upload_max_files ?: 5),
        'artworkUploadMaxFileSizeMb' => (int) old('artwork_upload_max_file_size_mb', $product->artwork_upload_max_file_size_mb ?: 15),
        'artworkUploadAcceptedTypes' => old('artwork_upload_accepted_types', $product->artwork_upload_accepted_types ?: 'pdf,svg,png,jpg,jpeg,webp'),
    ];
    $currentProductStatus = old('status', $product->status ?: 'draft');
    $validationErrorMessages = collect($errors->getMessages())->map(fn ($messages) => $messages[0] ?? 'Please review this field.')->all();
    $validationFieldAliases = [
        'sku' => 'product_specification_text',
        'slug' => 'name',
        'category_id' => 'primary_category_id',
        'subcategory_id' => 'primary_category_id',
        'base_price' => 'price_table_rows.0.1',
        'minimum_quantity' => 'price_table_ranges.0.minimum_quantity',
        'maximum_quantity' => 'price_table_ranges.0.maximum_quantity',
        'price_tiers.0.unit_price' => 'price_table_rows.0.1',
        'fabric_price_tables' => 'option_groups',
    ];
@endphp

@once
<script>
window.adminProductFormFabric = function (initial = {}) {
    const baseFactory = window.adminProductForm;
    const form = baseFactory ? baseFactory(initial) : {};
    const baseInit = form.init || function () {};
    const baseSelectMasterItem = form.selectMasterItem || null;
    const baseAddOptionValue = form.addOptionValue || null;
    const baseImportPriceTable = form.importPriceTable || null;
    const basePreparePriceImportMapping = form.preparePriceImportMapping || null;
    const baseClosePriceImportMapping = form.closePriceImportMapping || null;
    const baseApplyPriceImportMapping = form.applyPriceImportMapping || null;
    const baseConfirmNewFeature = form.confirmNewFeature || null;
    const baseOpenSizeGroupPicker = form.openSizeGroupPicker || null;

    return Object.assign(form, {
        confirmNewFeature() {
            const type = String(this.newFeatureType || '');
            if (type.startsWith('__size_options__:')) {
                const context = type.slice('__size_options__:'.length);
                if (!context) {
                    this.newFeatureNameError = 'Choose a valid size option section before continuing.';
                    return;
                }

                this.closeNewFeatureDialog();
                this.$nextTick(() => this.openSizeGroupPicker(context));
                return;
            }

            if (baseConfirmNewFeature) {
                return baseConfirmNewFeature.call(this);
            }
        },
        openSizeGroupPicker(preferredContext = '') {
            const explicitContext = String(preferredContext || '').trim();
            if (!explicitContext && baseOpenSizeGroupPicker) {
                return baseOpenSizeGroupPicker.call(this);
            }

            this.sizeGroupPickerSearch = '';
            const validContexts = new Set((this.customizationTypeGroups || [])
                .map(group => String(group.key || group.types?.[0]?.group || '').trim())
                .filter(Boolean));
            this.sizeGroupPickerContext = validContexts.has(explicitContext) ? explicitContext : '';
            this.sizeGroupPickerOpen = true;
            document.documentElement.classList.add('overflow-hidden');
        },
        fabricPriceTables: initial.fabricPriceTables || {},
        fabricCustomizationTypes: initial.fabricCustomizationTypes || [],
        priceImportTargetTable: null,
        priceImportTargetLabel: '',
        priceImportTargetMode: 'product',
        fabricPriceImportTargetKey: '',
        fabricPriceImportTargetGroupIndex: null,
        fabricPriceImportTargetValueIndex: null,
        init() {
            baseInit.call(this);
            (this.optionGroups || []).forEach((group) => {
                (group.values || []).forEach((value) => this.ensureFabricPricing(value, group));
            });
        },
        isFabricGroup(group) {
            return this.fabricCustomizationTypes.includes(group?.jersey_customization_type || '');
        },
        priceImportDialogTitle() {
            return this.priceImportTargetTable
                ? `Map the ${this.priceImportTargetLabel || 'fabric'} price table`
                : 'Map the uploaded price table';
        },
        priceImportDialogDescription() {
            return this.priceImportTargetTable
                ? 'Import this spreadsheet into the selected fabric only. It will replace this fabric price table, not the default product price table.'
                : 'No predefined Excel structure is required. Select how this spreadsheet should become the customer-visible price table.';
        },
        isImportingFabricTable(table) {
            const activeTable = this.resolvePriceImportTargetTable();
            return Boolean(this.priceImportBusy && activeTable && activeTable === table);
        },
        resolveFabricPriceTableByKey(fabricKey) {
            const key = String(fabricKey || '').trim();
            if (key === '') {
                return null;
            }

            for (const group of (this.optionGroups || [])) {
                for (const value of (group.values || [])) {
                    if (! value?.fabric_price_table) {
                        continue;
                    }

                    const valueKey = String(value.fabric_price_table.fabric_key || this.fabricPriceKey(value) || '').trim();
                    if (valueKey === key) {
                        return value.fabric_price_table;
                    }
                }
            }

            return null;
        },
        resolveFabricPriceTableByPosition(groupIndex, valueIndex) {
            const gIndex = Number(groupIndex);
            const vIndex = Number(valueIndex);
            if (! Number.isInteger(gIndex) || ! Number.isInteger(vIndex)) {
                return null;
            }
            return this.optionGroups?.[gIndex]?.values?.[vIndex]?.fabric_price_table || null;
        },
        hasRememberedFabricImportTarget() {
            return this.priceImportTargetMode === 'fabric'
                || String(this.fabricPriceImportTargetKey || '').trim() !== ''
                || this.fabricPriceImportTargetGroupIndex !== null
                || this.fabricPriceImportTargetValueIndex !== null;
        },
        resolvePriceImportTargetTable() {
            if (! this.hasRememberedFabricImportTarget()) {
                return null;
            }

            const positionedTarget = this.resolveFabricPriceTableByPosition(
                this.fabricPriceImportTargetGroupIndex,
                this.fabricPriceImportTargetValueIndex,
            );
            const keyTarget = this.resolveFabricPriceTableByKey(this.fabricPriceImportTargetKey);

            return positionedTarget || keyTarget || this.priceImportTargetTable || null;
        },
        rememberPriceImportTarget(targetTable = null, targetLabel = '', fabricKey = '', groupIndex = null, valueIndex = null) {
            this.priceImportTargetTable = targetTable || null;
            this.priceImportTargetLabel = targetLabel || '';
            this.priceImportTargetMode = targetTable ? 'fabric' : 'product';
            this.fabricPriceImportTargetKey = targetTable ? String(fabricKey || targetTable.fabric_key || '').trim() : '';
            this.fabricPriceImportTargetGroupIndex = targetTable && groupIndex !== null ? Number(groupIndex) : null;
            this.fabricPriceImportTargetValueIndex = targetTable && valueIndex !== null ? Number(valueIndex) : null;
        },
        preparePriceImportMapping(matrix, fileName, targetTable = null, targetLabel = '') {
            const rememberedFabricTarget = this.hasRememberedFabricImportTarget()
                ? {
                    table: this.resolvePriceImportTargetTable(),
                    label: this.priceImportTargetLabel,
                    key: this.fabricPriceImportTargetKey,
                    groupIndex: this.fabricPriceImportTargetGroupIndex,
                    valueIndex: this.fabricPriceImportTargetValueIndex,
                }
                : null;

            if (targetTable) {
                this.rememberPriceImportTarget(targetTable, targetLabel, targetTable.fabric_key || '', this.fabricPriceImportTargetGroupIndex, this.fabricPriceImportTargetValueIndex);
            } else if (! rememberedFabricTarget) {
                this.rememberPriceImportTarget(null, '');
            }

            const activeTarget = this.resolvePriceImportTargetTable();
            const activeLabel = activeTarget ? (this.priceImportTargetLabel || targetLabel || 'fabric') : '';

            if (basePreparePriceImportMapping) {
                const result = basePreparePriceImportMapping.call(this, matrix, fileName, activeTarget, activeLabel);

                // Older compiled admin.js builds ignore the target arguments and reset the import target.
                // Restore the fabric target immediately so Generate can never fall back to the main table.
                if (activeTarget) {
                    this.rememberPriceImportTarget(
                        activeTarget,
                        activeLabel,
                        this.fabricPriceImportTargetKey || activeTarget.fabric_key || '',
                        this.fabricPriceImportTargetGroupIndex,
                        this.fabricPriceImportTargetValueIndex,
                    );
                }

                return result;
            }
        },
        closePriceImportMapping() {
            if (baseClosePriceImportMapping) {
                baseClosePriceImportMapping.call(this);
            } else {
                this.priceImportMappingOpen = false;
                this.priceImportMappingError = '';
            }
            this.rememberPriceImportTarget(null, '');
        },
        importPriceTable(event, targetTable = null, targetLabel = '') {
            if (targetTable) {
                this.rememberPriceImportTarget(
                    targetTable,
                    targetLabel,
                    this.fabricPriceImportTargetKey || targetTable.fabric_key || '',
                    this.fabricPriceImportTargetGroupIndex,
                    this.fabricPriceImportTargetValueIndex,
                );
                targetTable.import_status = '';
                targetTable.import_error = '';
            } else {
                this.rememberPriceImportTarget(null, '');
            }
            if (baseImportPriceTable) {
                return baseImportPriceTable.call(this, event, targetTable, targetLabel);
            }
        },
        importFabricPriceTable(event, table, label = '', fabricKey = '', groupIndex = null, valueIndex = null) {
            if (! table) {
                return;
            }
            const resolvedKey = String(fabricKey || table.fabric_key || '').trim();
            if (resolvedKey !== '') {
                table.fabric_key = resolvedKey;
            }
            table.has_custom_pricing = true;
            this.rememberPriceImportTarget(table, label, resolvedKey, groupIndex, valueIndex);
            return this.importPriceTable(event, table, label);
        },
        applyPriceImportMapping() {
            const targetTable = this.resolvePriceImportTargetTable();
            if (! targetTable) {
                if (this.hasRememberedFabricImportTarget()) {
                    this.priceImportMappingError = 'The selected fabric price table could not be found. Close this import window and click Import Excel from the fabric row again.';
                    return;
                }
                if (baseApplyPriceImportMapping) {
                    return baseApplyPriceImportMapping.call(this);
                }
                return;
            }

            this.priceImportMappingError = '';
            try {
                const dataRows = this.priceImportMatrix
                    .slice(Number(this.priceImportHeaderRowIndex) + 1)
                    .filter(row => row.some(cell => String(cell ?? '').trim() !== ''));
                if (!dataRows.length) throw new Error('No data rows were found below the selected header row.');

                let rangeColumn = null;
                let minColumn = null;
                let maxColumn = null;
                if (this.priceImportQuantityMode === 'range') {
                    rangeColumn = Number(this.priceImportQuantityColumn);
                    if (!Number.isInteger(rangeColumn)) throw new Error('Choose the column that contains quantity ranges.');
                } else {
                    minColumn = Number(this.priceImportMinColumn);
                    maxColumn = this.priceImportMaxColumn === '' ? null : Number(this.priceImportMaxColumn);
                    if (!Number.isInteger(minColumn)) throw new Error('Choose the minimum quantity column.');
                    if (maxColumn !== null && !Number.isInteger(maxColumn)) throw new Error('Choose a valid maximum quantity column.');
                    if (maxColumn !== null && maxColumn === minColumn) throw new Error('Minimum and maximum quantity must use different columns.');
                }

                const mappedQuantity = new Set(
                    this.priceImportQuantityMode === 'range'
                        ? [String(rangeColumn)]
                        : [String(minColumn), ...(maxColumn === null ? [] : [String(maxColumn)])],
                );
                const valueIndexes = this.priceImportIncludedColumns
                    .map(Number)
                    .filter(index => Number.isInteger(index) && !mappedQuantity.has(String(index)));
                if (!valueIndexes.length) throw new Error('Select at least one storefront price-table column.');
                if (valueIndexes.length > 19) throw new Error('A maximum of 19 storefront columns can be imported.');

                const primaryIndex = Number(this.priceImportPrimaryPriceColumn);
                if (!valueIndexes.includes(primaryIndex)) throw new Error('Choose a primary live price column from the selected storefront columns.');

                const importedRows = [];
                dataRows.forEach((row, sourceIndex) => {
                    const values = valueIndexes.map(index => String(row[index] ?? '').trim());
                    const quantityRaw = this.priceImportQuantityMode === 'range'
                        ? String(row[rangeColumn] ?? '').trim()
                        : String(row[minColumn] ?? '').trim();
                    if (quantityRaw === '' && values.every(value => value === '')) return;

                    let range;
                    if (this.priceImportQuantityMode === 'range') {
                        range = this.parseQuantityRange(row[rangeColumn]);
                    } else {
                        const minimum = this.spreadsheetInteger(row[minColumn]);
                        const maximum = maxColumn === null ? '' : this.spreadsheetInteger(row[maxColumn], { allowBlank: true });
                        if (!Number.isInteger(minimum)) throw new Error(`Spreadsheet row ${Number(this.priceImportHeaderRowIndex) + sourceIndex + 2} has an invalid minimum quantity.`);
                        if (maximum !== '' && (!Number.isInteger(maximum) || maximum < minimum)) {
                            throw new Error(`Spreadsheet row ${Number(this.priceImportHeaderRowIndex) + sourceIndex + 2} has an invalid maximum quantity.`);
                        }
                        range = { minimum_quantity: minimum, maximum_quantity: maximum };
                    }

                    if (values.every(value => value === '')) {
                        throw new Error(`Spreadsheet row ${Number(this.priceImportHeaderRowIndex) + sourceIndex + 2} has a quantity but no selected storefront values.`);
                    }
                    importedRows.push({ ...range, cells: values });
                });

                if (!importedRows.length) throw new Error('No usable price rows were found using the selected mapping.');
                if (importedRows.length > 200) throw new Error('A maximum of 200 price rows can be imported.');

                importedRows.forEach((row, index) => {
                    const minimum = Number(row.minimum_quantity);
                    if (!Number.isInteger(minimum) || minimum < 1) {
                        row.minimum_quantity = '';
                        row.maximum_quantity = '';
                        return;
                    }

                    const nextMinimum = Number(importedRows[index + 1]?.minimum_quantity);
                    if (Number.isInteger(nextMinimum) && nextMinimum > minimum && String(row.maximum_quantity ?? '').trim() === '') {
                        row.maximum_quantity = nextMinimum - 1;
                        return;
                    }

                    const maximum = Number(row.maximum_quantity);
                    if (String(row.maximum_quantity ?? '').trim() !== '' && (!Number.isInteger(maximum) || maximum < minimum)) {
                        row.maximum_quantity = '';
                    }
                });

                const importedHeaders = valueIndexes.map(index => this.priceImportHeaders[index]);
                const importedHighlightColumn = valueIndexes.indexOf(primaryIndex) + 1;
                const statusMessage = `${importedRows.length} row${importedRows.length === 1 ? '' : 's'} and ${importedHeaders.length} column${importedHeaders.length === 1 ? '' : 's'} generated from ${this.priceImportFileName}. Quantity maximums were completed automatically from the next row's starting quantity.`;

                targetTable.headers = importedHeaders;
                targetTable.rows = importedRows.map(row => ({
                    minimum_quantity: row.minimum_quantity,
                    maximum_quantity: row.maximum_quantity,
                    maximum_quantity_auto: String(row.maximum_quantity ?? '').trim() === '',
                    cells: Array.isArray(row.cells) ? row.cells.slice() : [],
                }));
                targetTable.highlight_column = importedHighlightColumn;
                targetTable.has_custom_pricing = true;
                targetTable.import_status = statusMessage;
                targetTable.import_error = '';
                this.normalizeFabricPriceTable(targetTable);
                this.closePriceImportMapping();
            } catch (error) {
                this.priceImportMappingError = error instanceof Error ? error.message : 'The selected spreadsheet mapping could not be applied.';
                const failedTargetTable = this.resolvePriceImportTargetTable();
                if (failedTargetTable) {
                    failedTargetTable.import_error = this.priceImportMappingError;
                }
            }
        },
        fabricPriceKey(value) {
            const masterId = Number(value?.jersey_customization_option_id || 0);
            if (masterId > 0) {
                return `master:${masterId}`;
            }
            const code = String(value?.code || value?.label || '').trim().toLowerCase()
                .replace(/[^a-z0-9]+/g, '-')
                .replace(/^-+|-+$/g, '');
            return code ? `code:${code}` : '';
        },
        cloneDefaultFabricRows(headers = null) {
            const sourceHeaders = Array.isArray(headers) && headers.length ? headers : (this.priceHeaders || []);
            return (this.priceRows || []).map((row, index) => {
                const copiedCells = Array.isArray(row.cells) ? row.cells.slice(0, sourceHeaders.length) : [];
                return {
                    minimum_quantity: row.minimum_quantity || (index === 0 ? 1 : ''),
                    maximum_quantity: row.maximum_quantity || '',
                    maximum_quantity_auto: true,
                    cells: copiedCells.concat(Array(Math.max(sourceHeaders.length - copiedCells.length, 0)).fill('')),
                };
            });
        },
        fabricPriceTableTemplate(value) {
            const key = this.fabricPriceKey(value);
            const saved = key && this.fabricPriceTables ? this.fabricPriceTables[key] : null;
            const headers = Array.isArray(saved?.headers) && saved.headers.length ? saved.headers.slice() : (this.priceHeaders || []).slice();
            const rows = Array.isArray(saved?.rows) && saved.rows.length
                ? saved.rows.map((row, index) => ({
                    minimum_quantity: row.minimum_quantity || (index === 0 ? 1 : ''),
                    maximum_quantity: row.maximum_quantity || '',
                    maximum_quantity_auto: true,
                    cells: Array.isArray(row.cells) ? row.cells.slice(0, headers.length).concat(Array(Math.max(headers.length - row.cells.length, 0)).fill('')) : Array(headers.length).fill(''),
                }))
                : this.cloneDefaultFabricRows(headers);

            return {
                fabric_key: key,
                has_custom_pricing: Boolean(saved?.has_custom_pricing),
                headers: headers.length ? headers : ['Unit Price ($)'],
                rows: rows.length ? rows : [{minimum_quantity: 1, maximum_quantity: '', maximum_quantity_auto: true, cells: Array(headers.length || 1).fill('')}],
                highlight_column: Number(saved?.highlight_column || this.priceHighlightColumn || 1),
                note: saved?.note || '',
                import_status: '',
                import_error: '',
            };
        },
        ensureFabricPricing(value, group) {
            if (! this.isFabricGroup(group)) {
                return;
            }
            const key = this.fabricPriceKey(value);
            if (! value.fabric_price_table || value.fabric_price_table.fabric_key !== key) {
                value.fabric_price_table = this.fabricPriceTableTemplate(value);
            }
            value.fabric_price_table.fabric_key = key;
            this.normalizeFabricPriceTable(value.fabric_price_table);
        },
        normalizeFabricPriceTable(table) {
            table.headers = Array.isArray(table.headers) && table.headers.length ? table.headers : ['Unit Price ($)'];
            table.rows = Array.isArray(table.rows) && table.rows.length ? table.rows : [{minimum_quantity: 1, maximum_quantity: '', maximum_quantity_auto: true, cells: []}];
            table.import_status = table.import_status || '';
            table.import_error = table.import_error || '';
            table.rows.forEach((row, index) => {
                row.minimum_quantity = row.minimum_quantity || (index === 0 ? 1 : '');
                row.maximum_quantity = row.maximum_quantity || '';
                row.maximum_quantity_auto = row.maximum_quantity_auto !== false;
                row.cells = Array.isArray(row.cells) ? row.cells : [];
                while (row.cells.length < table.headers.length) { row.cells.push(''); }
                if (row.cells.length > table.headers.length) { row.cells.splice(table.headers.length); }
            });
            this.recalculateFabricPriceMaximums(table);
        },
        addFabricPriceHeader(table) {
            table.headers.push('Extra Fee ($)');
            table.rows.forEach((row) => row.cells.push(''));
        },
        removeFabricPriceHeader(table, index) {
            if (table.headers.length <= 1) {
                return;
            }
            table.headers.splice(index, 1);
            table.rows.forEach((row) => row.cells.splice(index, 1));
            table.highlight_column = Math.min(Number(table.highlight_column || 1), table.headers.length);
        },
        addFabricPriceRow(table) {
            const previous = table.rows[table.rows.length - 1] || {minimum_quantity: 1};
            const nextMinimum = Math.max(Number(previous.maximum_quantity || previous.minimum_quantity || 0) + 1, 1);
            table.rows.push({minimum_quantity: nextMinimum, maximum_quantity: '', maximum_quantity_auto: true, cells: Array(table.headers.length).fill('')});
            this.recalculateFabricPriceMaximums(table);
        },
        removeFabricPriceRow(table, index) {
            if (table.rows.length <= 1) {
                return;
            }
            table.rows.splice(index, 1);
            this.recalculateFabricPriceMaximums(table);
        },
        recalculateFabricPriceMaximums(table) {
            table.rows.forEach((row, index) => {
                if (row.maximum_quantity_auto === false) {
                    return;
                }
                const next = table.rows[index + 1];
                row.maximum_quantity = next && Number(next.minimum_quantity) > 1 ? Number(next.minimum_quantity) - 1 : '';
            });
        },
        markFabricPriceMaximumManual(row) {
            row.maximum_quantity_auto = false;
        },
        selectMasterItem(item) {
            if (baseSelectMasterItem) {
                const group = this.activeMasterItemGroup();
                baseSelectMasterItem.call(this, item);
                if (group) {
                    const added = (group.values || []).find((value) => Number(value.jersey_customization_option_id || 0) === Number(item.id || 0));
                    if (added) { this.ensureFabricPricing(added, group); }
                }
                return;
            }
        },
        addOptionValue(group) {
            if (baseAddOptionValue) {
                baseAddOptionValue.call(this, group);
                const added = group.values?.[group.values.length - 1];
                if (added) { this.ensureFabricPricing(added, group); }
            }
        },
    });
};

window.productFaqSelector = function (initial = {}) {
    return {
        faqOptions: Array.isArray(initial.options) ? initial.options : [],
        selectedFaqIds: Array.isArray(initial.selected)
            ? [...new Set(initial.selected.map(id => Number(id)).filter(id => id > 0))]
            : [],
        faqPickerOpen: false,
        faqPickerSearch: '',
        openFaqPicker() {
            this.faqPickerSearch = '';
            this.faqPickerOpen = true;
            document.documentElement.classList.add('overflow-hidden');
        },
        closeFaqPicker() {
            this.faqPickerOpen = false;
            document.documentElement.classList.remove('overflow-hidden');
        },
        filteredFaqOptions() {
            const query = String(this.faqPickerSearch || '').trim().toLowerCase();
            return this.faqOptions.filter(faq => !query
                || String(faq.question || '').toLowerCase().includes(query)
                || String(faq.answer || '').toLowerCase().includes(query));
        },
        selectedFaqOptions() {
            const selected = new Set(this.selectedFaqIds.map(id => Number(id)));
            return this.faqOptions.filter(faq => selected.has(Number(faq.id)));
        },
        isFaqSelected(id) {
            return this.selectedFaqIds.some(selectedId => Number(selectedId) === Number(id));
        },
        toggleFaq(id) {
            const normalizedId = Number(id);
            if (!normalizedId) return;
            this.selectedFaqIds = this.isFaqSelected(normalizedId)
                ? this.selectedFaqIds.filter(selectedId => Number(selectedId) !== normalizedId)
                : [...this.selectedFaqIds, normalizedId];
        },
        removeFaq(id) {
            const normalizedId = Number(id);
            this.selectedFaqIds = this.selectedFaqIds.filter(selectedId => Number(selectedId) !== normalizedId);
        },
    };
};
</script>
@endonce


<form method="POST" enctype="multipart/form-data" action="{{ $isEdit ? route('admin.products.update', $product) : route('admin.products.store') }}" class="np-product-form{{ $isEdit ? '' : ' np-product-form--compact' }}" data-validation-errors='@json($validationErrorMessages)' data-validation-field-aliases='@json($validationFieldAliases)' x-data="adminProductFormFabric(@js($initial))" x-init="init()" @submit="syncProductImageInput()" @dragover.window="preventFileDropNavigation($event)" @drop.window="preventFileDropNavigation($event)" @input.debounce.300ms="handleProgressChange(false)" @change.debounce.300ms="handleProgressChange(false)" @admin-rich-editor-updated.window="if ($event.detail.name === 'description_html') { descriptionHtml = $event.detail.value; } handleProgressChange(false);">
    @csrf
    @if($isEdit) @method('PUT') @endif


    <input type="hidden" name="slug" x-model="slug">
    <input type="hidden" name="currency" value="{{ old('currency', $product->currency ?: 'USD') }}">
    <input type="hidden" name="product_profile" :value="productProfile">
    <input type="hidden" name="is_active" value="1">
    <input type="hidden" name="is_customizable" value="1">
    <input type="hidden" name="track_inventory" value="{{ old('track_inventory', (int) ($product->track_inventory ?? false)) }}">
    <input type="hidden" name="allow_backorder" value="{{ old('allow_backorder', (int) ($product->allow_backorder ?? false)) }}">
    <input type="hidden" name="robots_index" value="{{ old('robots_index', (int) ($product->robots_index ?? true)) }}">
    <input type="hidden" name="robots_follow" value="{{ old('robots_follow', (int) ($product->robots_follow ?? true)) }}">
    @foreach($selectedAttributeValueIds as $attributeValueId)
        <input type="hidden" name="attribute_value_ids[]" value="{{ $attributeValueId }}">
    @endforeach

    <div class="np-product-builder">
        <section class="np-product-builder__main">
            <div class="np-stepper" aria-label="Add product steps" :style="{ '--np-step-count': steps.length }">
                <template x-for="(step, index) in steps" :key="step.id">
                    <a :href="`#${step.id}`" class="np-stepper__item" :class="{ 'is-active': isStepActive(step.id), 'is-complete': isStepComplete(step.id) }" :aria-current="isStepActive(step.id) ? 'step' : null" @click="goToStep(step.id, $event)">
                        <span>
                            <template x-if="isStepComplete(step.id)"><em>✓</em></template>
                            <template x-if="!isStepComplete(step.id)"><b x-text="index + 1"></b></template>
                        </span>
                        <strong x-text="step.label"></strong>
                    </a>
                </template>
            </div>

            <section id="header" class="np-card">
                <header class="np-card__header">
                    <div>
                        <h2>1. Product Basics &amp; Gallery</h2>
                        <p>Add the basic information, category, tags, and product images.</p>
                    </div>
                </header>

                <div class="np-field-stack">
                    <label class="admin-label np-emphasis-label">Product title <span class="text-brand-red">*</span>
                        <input class="admin-input" name="name" x-model="productName" @input="updateSlug()" required maxlength="220" placeholder="e.g., Custom Baseball Jersey">
                    </label>

                    <label class="admin-label np-emphasis-label">Short product summary <span class="text-brand-red">*</span>
                        <textarea class="admin-textarea np-textarea-sm" name="short_description" maxlength="1500" x-model="shortDescription" placeholder="Describe your product in a few words..."></textarea>
                    </label>

                    <div class="np-product-spec-card rounded-2xl border border-slate-200 bg-slate-50 p-4 shadow-sm" data-field-name="product_specification_text" x-data="productSpecificationEditor(@js($productSpecificationText), @js($productSpecificationAutoValues))" x-init="init()">
                        <div class="mb-4 flex items-center justify-between gap-3">
                            <label class="admin-label np-emphasis-label mb-0 text-base">Product Specification</label>
                            <button type="button" class="np-link-button" @click="resetTemplate()">Reset template</button>
                        </div>

                        <div class="grid gap-4 lg:grid-cols-[minmax(0,1fr)_minmax(340px,.82fr)] lg:items-stretch">
                            <div class="np-product-spec-panel flex min-w-0 flex-col overflow-hidden rounded-2xl border border-slate-300 bg-white">
                                <div class="np-product-spec-toolbar flex flex-wrap gap-1.5 border-b border-slate-200 bg-slate-50 p-2">
                                    <button type="button" class="admin-editor-button" @click="command('formatBlock', 'h2')">H2</button>
                                    <button type="button" class="admin-editor-button" @click="command('formatBlock', 'h3')">H3</button>
                                    <button type="button" class="admin-editor-button font-black" aria-label="Bold" title="Bold" @click="command('bold')">B</button>
                                    <button type="button" class="admin-editor-button italic" aria-label="Italic" title="Italic" @click="command('italic')">I</button>
                                    <button type="button" class="admin-editor-button underline" aria-label="Underline" title="Underline" @click="command('underline')">U</button>
                                    <button type="button" class="admin-editor-button" @click="command('insertUnorderedList')">• List</button>
                                    <button type="button" class="admin-editor-button" @click="command('insertOrderedList')">1. List</button>
                                    <button type="button" class="admin-editor-button" @click="command('formatBlock', 'blockquote')">Quote</button>
                                    <button type="button" class="admin-editor-button" @click="createLink()">Link</button>
                                    <button type="button" class="admin-editor-button" @click="clearFormat()">Clear</button>
                                </div>
                                <div x-ref="editor" contenteditable="true" @input="sync()" @paste="handlePaste($event)" class="admin-rich-editor np-product-spec-editor min-h-[260px] flex-1 whitespace-pre-wrap p-4 text-[13px] leading-6 text-slate-700" role="textbox" aria-multiline="true" data-field-name="product_specification_text" data-placeholder="SKU:
Product Type:
Fabric:
Fit:
Customization:
Size Range:
MOQ:
Lead Time:"></div>
                                <textarea name="product_specification_text" x-model="value" hidden></textarea>
                            </div>

                            <div class="np-product-spec-preview flex min-w-0 flex-col overflow-hidden rounded-2xl border border-slate-200 bg-white">
                                <div class="border-b border-slate-200 bg-white px-4 py-3 text-sm font-black text-slate-800">Storefront specification preview</div>
                                <div class="min-h-[260px] flex-1 overflow-auto">
                                    <table class="w-full table-fixed border-collapse text-[13px]">
                                        <thead>
                                            <tr class="bg-slate-50 text-left text-[11px] font-black uppercase tracking-[.04em] text-slate-500">
                                                <th class="w-[34%] border-b border-slate-200 px-4 py-2.5">Detail</th>
                                                <th class="border-b border-slate-200 px-4 py-2.5">Information</th>
                                            </tr>
                                        </thead>
                                        <tbody x-show="previewRows().length" x-cloak>
                                            <template x-for="row in previewRows()" :key="row.label">
                                                <tr class="border-b border-slate-100 last:border-b-0">
                                                    <th class="break-words px-4 py-2.5 text-left align-top font-semibold text-slate-700" x-text="row.label"></th>
                                                    <td class="break-words px-4 py-2.5 align-top text-slate-600" x-text="row.value"></td>
                                                </tr>
                                            </template>
                                        </tbody>
                                        <tbody x-show="!previewRows().length" x-cloak>
                                            <tr>
                                                <td colspan="2" class="px-4 py-8 text-center text-sm font-medium text-slate-400">No specification information yet.</td>
                                            </tr>
                                        </tbody>
                                    </table>
                                </div>
                            </div>
                        </div>
                    </div>

                    <div class="grid gap-4 md:grid-cols-[minmax(0,1.1fr)_minmax(0,.9fr)]">
                        <div class="admin-label np-category-field np-category-field--plain" data-field-name="primary_category_id" @click.outside="closeCategoryDropdown()">
                            <span class="np-emphasis-label">Category <span class="text-brand-red">*</span></span>
                            <input type="hidden" name="primary_category_id" x-model="categoryId" required>

                            {{-- Keep the dropdown anchored to the trigger itself. The help text below must not affect its top position. --}}
                            <div class="np-searchable-control">
                                <button type="button" class="np-searchable-trigger" :class="categoryDropdownOpen ? 'is-open' : ''" @click="toggleCategoryDropdown()" @keydown.enter.prevent="toggleCategoryDropdown()" @keydown.space.prevent="toggleCategoryDropdown()">
                                    <span x-text="selectedCategoryName() || 'Select a last-level category'"></span>
                                    <svg width="18" height="18" viewBox="0 0 20 20" fill="none" aria-hidden="true"><path d="M5 7.5L10 12.5L15 7.5" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"/></svg>
                                </button>
                                <div x-show="categoryDropdownOpen" x-cloak x-transition class="np-searchable-panel">
                                    <div class="np-searchable-panel__head">
                                        <strong>Select last-level category</strong>
                                        <button type="button" @click="closeCategoryDropdown()" aria-label="Close category dropdown">×</button>
                                    </div>
                                    <label class="np-searchable-search" aria-label="Search category">
                                        <span>⌕</span>
                                        <input x-ref="categorySearchInput" type="search" x-model="categorySearch" placeholder="Search last-level category..." @keydown.escape.prevent="closeCategoryDropdown()">
                                    </label>
                                    <div class="np-searchable-list" role="listbox">
                                        <button type="button" class="np-searchable-option" :class="!categoryId ? 'is-selected' : ''" @click="selectCategory('', '')">
                                            <span class="np-searchable-option__title">Select a last-level category</span>
                                            <small>Clear current selection</small>
                                        </button>
                                        <template x-for="category in filteredCategories()" :key="category.id">
                                            <button type="button" class="np-searchable-option" :class="String(categoryId) === String(category.id) ? 'is-selected' : ''" @click="selectCategory(category.id, category.label)">
                                                <span class="np-searchable-option__title" x-text="category.label"></span>
                                                <small x-text="category.slug ? `/${category.slug}` : 'Product category'"></small>
                                                <em x-show="String(categoryId) === String(category.id)">✓</em>
                                            </button>
                                        </template>
                                    </div>
                                    <p class="np-searchable-empty" x-show="filteredCategories().length === 0">No matching last-level category found.</p>
                                </div>
                            </div>

                            <small class="np-field-help">Only a category without child categories can hold products. Parent categories are used for grouping and storefront filtering.</small>
                        </div>

                        <label class="admin-label np-emphasis-label">Tags
                            <textarea class="admin-textarea np-tags-textarea" name="tags_text" rows="3" placeholder="Add tags separated by commas">{{ old('tags_text',implode(', ',$product->tags ?? [])) }}</textarea>
                            <small class="np-field-help">Separate multiple tags with commas. The field wraps to new lines automatically.</small>
                        </label>
                    </div>

                    <label class="admin-label np-emphasis-label">Gallery badge label <span class="text-xs font-bold text-slate-400">(optional)</span>
                        <input class="admin-input" name="badge_label" value="{{ old('badge_label',$product->badge_label) }}" maxlength="80" placeholder="Customizable, New, Best Seller">
                    </label>

                    <input type="hidden" name="new_image_primary_index" :value="newImagePrimaryIndex()">
                    <div>
                        <div class="mb-3 flex flex-wrap items-center justify-between gap-3">
                            <label class="admin-label np-emphasis-label mb-0">Gallery images <span class="text-brand-red">*</span></label>
                            <div class="np-gallery-source-actions">
                                <button type="button" class="np-secondary-button" @click="chooseProductImages()">Upload from device</button>
                                <button type="button" class="np-secondary-button" @click="openMediaLibrary()">Choose from image gallery</button>
                                <button type="button" class="np-link-button" @click="addImageUrl()">↗ Add image URL</button>
                            </div>
                        </div>

                        <input x-ref="productImageInput" class="sr-only" type="file" name="images[]" multiple accept="image/jpeg,image/png,image/webp,image/avif" @change="previewProductImages($event)">
                        <div
                            class="np-upload-zone"
                            :class="productImageDragging ? 'is-dragging' : ''"
                            role="button"
                            tabindex="0"
                            aria-label="Upload product images"
                            @click="chooseProductImages()"
                            @keydown.enter.prevent="chooseProductImages()"
                            @keydown.space.prevent="chooseProductImages()"
                            @dragenter.stop.prevent="startProductImageDrag($event)"
                            @dragover.stop.prevent="productImageDragging = isFileDrag($event)"
                            @dragleave.stop.prevent="endProductImageDrag($event)"
                            @drop.stop.prevent="dropProductImages($event)"
                        >
                            <span class="np-upload-zone__icon">⇧</span>
                            <strong x-text="productImageDragging ? 'Drop images to attach them' : 'Drag and drop device images here'"></strong>
                            <small>Or click “Choose from image gallery” to reuse global gallery images. New device uploads are also saved to the gallery.</small>
                        </div>
                        <p class="np-media-alert np-media-alert--error mt-2" x-show="productImageUploadError" x-text="productImageUploadError" x-cloak></p>
                    </div>

                    <div class="np-image-grid" x-show="newImagePreviews.length" x-cloak>
                        <template x-for="(image, index) in newImagePreviews" :key="image.client_key">
                            <article class="np-thumb" :class="isNewImagePrimary(index) ? 'is-primary' : ''">
                                <img :src="image.url" :alt="image.name">
                                <button type="button" class="np-thumb__remove" @click="removeProductImage(index)" aria-label="Remove image">×</button>
                                <button type="button" class="np-thumb__primary" @click="setPrimaryUploadedImage(index)" x-text="isNewImagePrimary(index) ? 'Primary' : 'Make primary'"></button>
                            </article>
                        </template>
                    </div>

                    <div class="np-image-grid np-linked-image-grid" x-show="imageUrls.length" x-cloak>
                        <template x-for="(image, index) in imageUrls" :key="image.client_key || index">
                            <article class="np-linked-image">
                                <input type="hidden" :name="`image_urls[${index}][existing_id]`" x-model="image.existing_id">
                                <input type="hidden" :name="`image_urls[${index}][media_library_image_id]`" x-model="image.media_library_image_id">
                                <input type="hidden" :name="`image_urls[${index}][is_primary]`" :value="image.is_primary ? 1 : 0">
                                <div class="np-linked-image__preview">
                                    <img x-show="image.url || image.preview" :src="image.url || image.preview" :alt="image.name || productName" x-on:error="$el.classList.add('hidden')" x-on:load="$el.classList.remove('hidden')">
                                    <span x-show="!image.url && !image.preview">URL</span>
                                </div>
                                <div class="np-linked-image__fields">
                                    <input class="admin-input !mt-0" :name="`image_urls[${index}][name]`" x-model="image.name" placeholder="Image name">
                                    <input class="admin-input !mt-2" type="url" :name="`image_urls[${index}][url]`" x-model="image.url" :readonly="Boolean(image.media_library_image_id)" :placeholder="image.media_library_image_id ? 'Selected from global image gallery' : 'https://example.com/product-image.jpg'">
                                    <div class="np-linked-image__actions">
                                        <button type="button" class="np-linked-image__primary" @click="setPrimaryImage(index)" x-text="image.is_primary ? 'Primary image' : 'Make primary'"></button>
                                        <button type="button" class="np-linked-image__remove" @click="removeImageUrl(index)">Remove</button>
                                    </div>
                                </div>
                            </article>
                        </template>
                    </div>

                    <div class="np-media-modal" x-show="mediaLibraryOpen" x-cloak @keydown.escape.window="closeMediaLibrary()">
                        <div class="np-media-modal__backdrop" @click="closeMediaLibrary()"></div>
                        <section class="np-media-modal__panel" role="dialog" aria-modal="true" aria-label="Global image gallery">
                            <header class="np-media-modal__header">
                                <div>
                                    <h3>Global Image Gallery</h3>
                                    <p>Select existing images or upload new reusable gallery images.</p>
                                </div>
                                <button type="button" class="np-media-modal__close" @click="closeMediaLibrary()" aria-label="Close image gallery">×</button>
                            </header>

                            <div class="np-media-modal__tools">
                                <label class="np-media-search">
                                    <span>⌕</span>
                                    <input type="search" x-model="mediaLibrarySearch" @input.debounce.450ms="loadMediaLibrary(false)" placeholder="Search images...">
                                </label>
                                <input x-ref="mediaLibraryUploadInput" class="sr-only" type="file" multiple accept="image/jpeg,image/png,image/webp,image/avif" @change="uploadMediaLibraryFiles($event.target.files)">
                                <div
                                    class="np-media-upload"
                                    :class="mediaLibraryDragging ? 'is-dragging' : ''"
                                    role="button"
                                    tabindex="0"
                                    aria-label="Upload images to gallery"
                                    @click="$refs.mediaLibraryUploadInput?.click()"
                                    @keydown.enter.prevent="$refs.mediaLibraryUploadInput?.click()"
                                    @keydown.space.prevent="$refs.mediaLibraryUploadInput?.click()"
                                    @dragenter.stop.prevent="startMediaLibraryDrag($event)"
                                    @dragover.stop.prevent="mediaLibraryDragging = isFileDrag($event)"
                                    @dragleave.stop.prevent="endMediaLibraryDrag($event)"
                                    @drop.stop.prevent="dropMediaLibraryImages($event)"
                                >
                                    <strong x-text="mediaLibraryUploadBusy ? 'Uploading…' : (mediaLibraryDragging ? 'Drop images to upload' : 'Upload to gallery')"></strong>
                                    <small>Drag or select reusable images</small>
                                </div>
                            </div>

                            <div class="np-media-modal__body">
                                <p class="np-media-alert np-media-alert--error" x-show="mediaLibraryError" x-text="mediaLibraryError"></p>
                                <p class="np-media-alert np-media-alert--error" x-show="mediaLibraryUploadError" x-text="mediaLibraryUploadError"></p>

                                <div class="np-media-grid" x-ref="mediaLibraryScroller" x-show="mediaLibraryItems.length" @wheel.stop @touchmove.stop @scroll.passive="handleMediaLibraryScroll($event)">
                                    <template x-for="image in mediaLibraryItems" :key="image.id">
                                        <button type="button" class="np-media-card" :data-media-id="image.id" x-show="!image.broken" :class="isMediaLibrarySelected(image.id) ? 'is-selected' : ''" @click="toggleMediaLibrarySelection(image.id)">
                                            <img :src="image.url" :alt="image.alt_text || image.name" loading="lazy" x-on:error="image.broken = true">
                                            <span class="np-media-card__check">✓</span>
                                            <strong x-text="image.name || 'Gallery image'"></strong>
                                            <small x-text="image.size_label || image.created_at || 'Gallery image'"></small>
                                        </button>
                                    </template>
                                </div>

                                <div class="np-media-empty" x-show="!mediaLibraryLoading && !mediaLibraryItems.length">
                                    No gallery images found. Upload images above to start the global gallery.
                                </div>

                                <div class="np-media-loading" x-show="mediaLibraryLoading">Loading images…</div>
                            </div>

                            <footer class="np-media-modal__footer">
                                <span class="np-media-scroll-hint" x-show="mediaLibraryHasMore && !mediaLibraryLoading">Scroll inside the gallery or click Load more to show the next images</span>
                                <button type="button" class="np-secondary-button" x-show="mediaLibraryHasMore && !mediaLibraryLoading" @click="loadMediaLibrary(true, { scrollToNew: true })">Load more</button>
                                <span x-text="`${mediaLibrarySelectedIds.length} selected`"></span>
                                <button type="button" class="np-primary-button" @click="addSelectedMediaLibraryImages()" :disabled="mediaLibrarySelectedIds.length === 0">Add selected images</button>
                            </footer>
                        </section>
                    </div>
                </div>
            </section>

            <section id="pricing" class="np-card">
                <header class="np-card__header">
                    <div>
                        <h2>2. Pricing &amp; Quantity Tiers</h2>
                    </div>
                    <label class="np-import-button">
                        <input x-ref="priceTableImportInput" type="file" accept=".xlsx,.csv" @change="importPriceTable($event)">
                        <span x-text="priceImportBusy ? 'Importing…' : 'Import Excel'">Import Excel</span>
                    </label>
                </header>

                <input type="hidden" name="price_table_headers[0]" value="Quantity">
                <input type="hidden" name="pricing_mode" x-model="pricingMode">
                <div class="np-price-mode" role="group" aria-label="Price mode">
                    <button type="button" :class="pricingMode === 'standard' ? 'is-selected' : ''" @click="pricingMode = 'standard'">
                        <span x-text="pricingMode === 'standard' ? '▣' : '▢'"></span> Standard pricing
                    </button>
                    <button type="button" :class="pricingMode === 'bulk' ? 'is-selected' : ''" @click="pricingMode = 'bulk'">
                        <span x-text="pricingMode === 'bulk' ? '▣' : '▢'"></span> Bulk pricing
                    </button>
                </div>
                <p x-show="priceImportStatus" x-cloak class="mt-3 rounded-xl bg-emerald-50 px-3 py-2 text-xs font-bold text-emerald-700" x-text="priceImportStatus"></p>
                <p x-show="priceImportError" x-cloak class="mt-3 rounded-xl bg-red-50 px-3 py-2 text-xs font-bold text-red-700" x-text="priceImportError"></p>

                <div class="mt-4 grid gap-4 md:grid-cols-2">
                    <label class="admin-label">Discount unit price
                        <div class="relative mt-2">
                            <span class="pointer-events-none absolute inset-y-0 left-3 flex items-center text-sm font-black text-slate-400">$</span>
                            <input
                                class="admin-input mt-0"
                                style="padding-left: 2rem;"
                                type="number"
                                name="compare_at_price"
                                min="0"
                                max="999999999.99"
                                step="0.01"
                                inputmode="decimal"
                                value="{{ old('compare_at_price', $product->compare_at_price) }}"
                                placeholder="4.20"
                            >
                        </div>
                        <small class="np-field-help">Optional. Enter a price lower than the card's current “From” price. The storefront shows this as the new discounted price, crosses out the original/current price, and calculates the discount percentage automatically.</small>
                    </label>
                </div>

                <div class="np-table-wrap mt-4">
                    <table class="np-simple-table">
                        <thead>
                            <tr>
                                <th>Qty From</th>
                                <th>Qty To</th>
                                <template x-for="(header,hIndex) in priceHeaders" :key="hIndex">
                                    <th>
                                        <input class="np-table-input font-black" :name="`price_table_headers[${hIndex + 1}]`" x-model="priceHeaders[hIndex]">
                                    </th>
                                </template>
                                <th>Actions</th>
                            </tr>
                        </thead>
                        <tbody>
                            <template x-for="(row,rIndex) in priceRows" :key="rIndex">
                                <tr>
                                    <td>
                                        <input type="hidden" :name="`price_table_rows[${rIndex}][0]`" :value="row.minimum_quantity || ''">
                                        <input class="np-table-input" type="number" min="1" :name="`price_table_ranges[${rIndex}][minimum_quantity]`" x-model.number="row.minimum_quantity" @input.debounce.250ms="recalculatePriceMaximums()" @blur="recalculatePriceMaximums()">
                                    </td>
                                    <td>
                                        <input class="np-table-input" type="number" min="1" :name="`price_table_ranges[${rIndex}][maximum_quantity]`" x-model.number="row.maximum_quantity" @input.debounce.250ms="markPriceMaximumManual(row); recalculatePriceMaximums()" @blur="markPriceMaximumManual(row); recalculatePriceMaximums()" placeholder="Auto">
                                    </td>
                                    <template x-for="(cell,cIndex) in row.cells" :key="cIndex">
                                        <td><input class="np-table-input" :name="`price_table_rows[${rIndex}][${cIndex + 1}]`" x-model="row.cells[cIndex]" placeholder="0.00"></td>
                                    </template>
                                    <td><button type="button" class="np-icon-button" @click="removePriceRow(rIndex)" aria-label="Remove price tier">⌫</button></td>
                                </tr>
                            </template>
                        </tbody>
                    </table>
                </div>

                <div class="np-price-tier-actions mt-4 flex flex-wrap items-end gap-3">
                    <button type="button" class="np-secondary-button np-price-tier-action" @click="addPriceRow()">＋ Add tier</button>
                    <button type="button" class="np-secondary-button np-price-tier-action" @click="addPriceHeader()">＋ Add price column</button>
                    <label class="admin-label max-w-[190px]">Highlight column
                        <input class="admin-input" type="number" min="1" name="price_table_highlight_column" x-model.number="priceHighlightColumn">
                    </label>
                </div>
                <label class="admin-label mt-4">Price table note
                    <textarea class="admin-textarea np-textarea-sm" name="price_table_note" placeholder="Optional note shown under the price table.">{{ old('price_table_note',$product->price_table_note) }}</textarea>
                </label>
            </section>

            <section id="options" class="np-card">
                <header class="np-card__header"><div><h2>3. Product Options</h2></div></header>
                <div class="grid gap-3">
                    {{-- Keep every option editor directly under the option that owns it. --}}
                    <div class="grid gap-3">
                        <div class="np-option-tiles">
                            <article><span class="np-option-tiles__icon purple">✦</span><div><strong>Customizable Features</strong><small>Add features customers can personalize.</small></div><button type="button" class="np-secondary-button" @click="openNewFeatureDialog()">＋ Add feature</button></article>
                        </div>

                        <details class="np-config-panel" open x-show="optionGroups.length > 0" x-cloak>
                    <summary>Customizable feature setup</summary>
                    <div class="mt-4 space-y-4">
                        <template x-for="(group,gIndex) in optionGroups" :key="group.client_key || gIndex">
                            <article class="np-nested-card" :class="optionGroupHasError(gIndex) ? 'border-red-400 bg-red-50/60 ring-2 ring-red-100' : ''" :data-option-group-key="group.client_key" :data-option-group-error="optionGroupHasError(gIndex) ? 'true' : 'false'">
                                <input type="hidden" :name="`option_groups[${gIndex}][name]`" :value="group.name"><input type="hidden" :name="`option_groups[${gIndex}][code]`" :value="group.code"><input type="hidden" :name="`option_groups[${gIndex}][jersey_customization_type]`" :value="group.jersey_customization_type || ''"><input type="hidden" :name="`option_groups[${gIndex}][section]`" value="product"><input type="hidden" :name="`option_groups[${gIndex}][display_mode]`" value="customer"><input type="hidden" :name="`option_groups[${gIndex}][fixed_value_code]`" value=""><input type="hidden" :name="`option_groups[${gIndex}][fixed_text_value]`" value=""><input type="hidden" :name="`option_groups[${gIndex}][show_in_summary]`" value="1"><input type="hidden" :name="`option_groups[${gIndex}][use_as_filter]`" value="0"><input type="hidden" :name="`option_groups[${gIndex}][description]`" value=""><input type="hidden" :name="`option_groups[${gIndex}][placeholder]`" value=""><input type="hidden" :name="`option_groups[${gIndex}][is_required]`" value="0"><input type="hidden" :name="`option_groups[${gIndex}][minimum_selections]`" value=""><input type="hidden" :name="`option_groups[${gIndex}][maximum_selections]`" value=""><input type="hidden" :name="`option_groups[${gIndex}][accepted_file_types]`" value=""><input type="hidden" :name="`option_groups[${gIndex}][maximum_file_size_mb]`" value="15"><input type="hidden" :name="`option_groups[${gIndex}][is_active]`" value="1">
                                <div class="flex flex-wrap items-start justify-between gap-3"><div><p class="text-[10px] font-black uppercase tracking-[.14em] text-brand-blue">Feature <span x-text="gIndex + 1"></span></p><h3 class="mt-1 text-lg font-black text-brand-ink" x-text="group.name"></h3></div><button type="button" class="np-danger-link" @click="removeOptionGroup(gIndex)">Remove feature</button></div>
                                <div x-show="optionGroupHasError(gIndex)" x-cloak class="mt-4 rounded-2xl border border-red-200 bg-white px-4 py-3 text-sm text-red-800" role="alert"><strong class="block font-black">Fix this customization feature</strong><template x-for="message in optionGroupErrorMessages(gIndex)" :key="message"><p class="mt-1" x-text="message"></p></template></div>
                                <div class="mt-4 grid gap-4 md:grid-cols-[260px_minmax(0,1fr)]"><label class="admin-label">Customer input style<select class="admin-input" :name="`option_groups[${gIndex}][type]`" x-model="group.type"><option value="image">Image choices</option><option value="swatch">Color swatches</option><option value="buttons">Buttons</option><option value="select">Dropdown</option><option value="checkbox">Checkboxes</option></select></label><div class="rounded-2xl border border-slate-200 bg-white p-4"><div class="flex flex-wrap items-center justify-between gap-3"><div><h4 class="font-black">Selected items</h4><p class="text-xs text-slate-500">Add reusable items available under <strong x-text="group.name"></strong>. Each selected item can have its own additional charge.</p></div><button type="button" class="np-secondary-button" @click="openMasterItemPicker(gIndex)">＋ Add item</button></div><div class="mt-4 space-y-4"><template x-for="(value,vIndex) in group.values" :key="value.client_key || vIndex">@include('admin.products.partials._selected-customization-option-item')</template><div x-show="group.values.length === 0" class="rounded-2xl border-2 border-dashed border-slate-200 p-7 text-center text-sm text-slate-500">No item selected. Choose <strong>+ Add Item</strong> to view available items.</div></div></div></div>
                            </article>
                        </template>
                        <div x-show="optionGroups.length === 0" class="rounded-2xl border-2 border-dashed border-slate-300 p-8 text-center"><p class="font-black text-brand-ink">No customizable feature has been added.</p><button type="button" class="np-primary-button mt-4" @click="openNewFeatureDialog()">＋ Add New Feature</button></div>
                    </div>
                        </details>
                    </div>

                    <div class="grid gap-3">
                        <div class="np-option-tiles">
                            <article><span class="np-option-tiles__icon amber">✎</span><div><strong>Sizes &amp; Quantities</strong><small>Define available sizes and quantity rules.</small></div><button type="button" class="np-secondary-button" @click="openSizeGroupPicker()">＋ Add size option</button></article>
                        </div>

                        <details class="np-config-panel" open x-show="sizeGroups.length > 0" x-cloak>
                    <summary>Sizes &amp; quantities setup</summary>
                    <div class="mt-4 space-y-4">
                        <template x-for="(group,index) in sizeGroups" :key="group.client_key || index">
                            <x-admin.product-size-group-card />
                        </template>
                        <div x-show="sizeGroups.length === 0" class="rounded-2xl border-2 border-dashed border-slate-300 p-8 text-center"><p class="font-black text-brand-ink">No size option has been added.</p><button type="button" class="np-secondary-button mt-4" @click="openSizeGroupPicker()">Add Size Option</button></div>
                    </div>
                        </details>
                    </div>

                    <x-admin.product-roster-fields :product="$product" />

                    <div class="np-option-tiles">
                        <x-admin.product-sample-settings :product="$product" />
                    </div>
                </div>

            </section>

            <section id="artwork" class="np-card"><header class="np-card__header"><div><h2>4. Custom Artwork Upload</h2><p>Allow customers to upload custom artwork for this product.</p></div></header><div class="grid gap-5 lg:grid-cols-[minmax(0,1fr)_minmax(280px,.7fr)]"><div class="np-field-stack"><div class="grid gap-4 sm:grid-cols-2"><label class="flex items-center gap-3 rounded-2xl border border-slate-200 p-4"><input type="hidden" name="artwork_upload_enabled" :value="artworkUploadEnabled ? 1 : 0"><input type="checkbox" x-model="artworkUploadEnabled"><span><strong class="block text-sm">Show artwork upload step</strong><small class="text-xs text-slate-500">The section disappears when disabled.</small></span></label><label class="flex items-center gap-3 rounded-2xl border border-slate-200 p-4" :class="!artworkUploadEnabled && 'opacity-50'"><input type="hidden" name="artwork_upload_required" :value="artworkUploadRequired ? 1 : 0"><input type="checkbox" x-model="artworkUploadRequired" :disabled="!artworkUploadEnabled"><span><strong class="block text-sm">Artwork is required</strong><small class="text-xs text-slate-500">At least one file must be selected.</small></span></label></div><div x-show="artworkUploadEnabled" class="grid gap-4 sm:grid-cols-2"><label class="admin-label np-emphasis-label sm:col-span-2">Section title<input class="admin-input" name="artwork_upload_title" x-model="artworkUploadTitle" maxlength="180"></label><label class="admin-label np-emphasis-label sm:col-span-2">Upload instructions<textarea class="admin-textarea np-textarea-sm" name="artwork_upload_description" x-model="artworkUploadDescription" maxlength="3000"></textarea></label><label class="admin-label np-emphasis-label">Accepted extensions<input class="admin-input font-mono" name="artwork_upload_accepted_types" x-model="artworkUploadAcceptedTypes" placeholder="pdf,ai,png,jpg,jpeg,eps"></label><label class="admin-label">Maximum file size (MB)<input class="admin-input" type="number" min="1" max="25" name="artwork_upload_max_file_size_mb" x-model.number="artworkUploadMaxFileSizeMb"></label><label class="admin-label sm:col-span-2">Maximum files<input class="admin-input" type="number" min="1" max="12" name="artwork_upload_max_files" x-model.number="artworkUploadMaxFiles"></label></div></div><div x-show="artworkUploadEnabled" class="np-artwork-preview"><span>☁</span><strong>Upload area will appear on product page</strong><small>Drag &amp; drop or click to upload</small></div></div></section>

            <section id="fulfillment" class="np-card">
                <header class="np-card__header">
                    <div>
                        <h2>5. Production &amp; Shipping</h2>
                        <p>Set production times and available shipping methods.</p>
                    </div>
                </header>
                <div class="space-y-4">
                    <details class="np-config-panel" open>
                        <summary>Production methods</summary>
                        <input type="hidden" name="production_methods_from_master" value="1">
                        <div class="mt-4 flex flex-col gap-3 md:flex-row md:items-center md:justify-between">
                            <label class="inline-flex min-w-0 items-center gap-3 rounded-xl border border-slate-200 bg-white px-4 py-3 text-sm font-semibold text-slate-700">
                                <input type="hidden" name="production_methods_enabled" :value="productionMethodsEnabled ? 1 : 0">
                                <input type="checkbox" x-model="productionMethodsEnabled" class="h-4 w-4 rounded border-slate-300 text-brand-red">
                                <span>Show production methods on product page</span>
                            </label>
                            <div class="min-w-0 text-xs font-medium leading-5 text-slate-500 md:text-right">
                                <p>Select reusable production methods from <strong>Master Data → Production Methods</strong>. Names, descriptions, and timelines stay controlled from master data; the extra charge is configured separately for this product.</p>
                                <a href="{{ route('admin.production-methods.index') }}" target="_blank" class="mt-2 inline-flex font-black text-brand-blue hover:text-brand-red">Manage Production Methods ↗</a>
                            </div>
                        </div>

                        <div x-show="productionMethodsEnabled" class="mt-4" x-cloak>
                            @if(isset($productionMethodOptions) && $productionMethodOptions->isNotEmpty())
                                <div class="grid items-stretch gap-3 xl:grid-cols-2">
                                    @foreach($productionMethodOptions as $productionMethod)
                                        @php
                                            $normalizedProductionCode = \Illuminate\Support\Str::slug((string) $productionMethod->code);
                                            $isSelectedProduction = $selectedProductionCodes->contains($normalizedProductionCode);
                                            $productionMethodCharge = (float) $productionMethodChargeValues->get($normalizedProductionCode, 0);
                                        @endphp
                                        <article
                                            x-data="{ selected: @js($isSelectedProduction) }"
                                            @class([
                                            'flex h-full flex-col justify-between rounded-2xl border bg-white p-4 transition',
                                            'border-slate-300 bg-slate-50' => $isSelectedProduction,
                                            'border-slate-200' => ! $isSelectedProduction,
                                            ])
                                            :class="selected ? 'border-brand-blue bg-blue-50 shadow-sm' : 'border-slate-200 bg-white'"
                                        >
                                            <label class="grid min-w-0 cursor-pointer grid-cols-[auto_minmax(0,1fr)] gap-3">
                                                <input type="checkbox" name="production_method_codes[]" value="{{ $productionMethod->code }}" x-model="selected" @checked($isSelectedProduction) class="mt-1 h-4 w-4 rounded border-slate-300 text-brand-red">
                                                <span class="min-w-0">
                                                    <span class="block truncate text-sm font-black text-brand-ink">{{ $productionMethod->name }}</span>
                                                    <span class="mt-1 block text-xs font-medium leading-5 text-slate-500">{{ $productionMethod->minimum_days }}–{{ $productionMethod->maximum_days }} working days</span>
                                                    @if($productionMethod->description)
                                                        <span class="mt-2 block text-sm font-normal leading-6 text-slate-500">{{ $productionMethod->description }}</span>
                                                    @endif
                                                </span>
                                            </label>
                                            <label class="mt-4 block rounded-xl border border-slate-200 bg-slate-50 p-3" :class="!selected && 'opacity-50'">
                                                <span class="flex flex-wrap items-center justify-between gap-2 text-xs font-black text-slate-700">
                                                    <span>Extra production charge</span>
                                                    <span class="font-semibold text-slate-500">Per piece</span>
                                                </span>
                                                <div class="relative mt-2">
                                                    <span class="pointer-events-none absolute inset-y-0 left-3 flex items-center text-sm font-black text-slate-400">$</span>
                                                    <input
                                                        type="number"
                                                        min="0"
                                                        max="999999999.99"
                                                        step="0.01"
                                                        inputmode="decimal"
                                                        name="production_method_price_adjustments[{{ $productionMethod->code }}]"
                                                        value="{{ number_format($productionMethodCharge, 2, '.', '') }}"
                                                        :disabled="!selected"
                                                        class="admin-input mt-0"
                                                        style="padding-left: 2rem;"
                                                        aria-label="Extra charge per piece for {{ $productionMethod->name }}"
                                                    >
                                                </div>
                                                <span class="mt-2 block text-[11px] font-medium leading-5 text-slate-500">Use 0.00 when this production method is included. Express and rush charges are added to every configured piece.</span>
                                            </label>
                                            <div class="mt-4 flex flex-wrap gap-2 text-xs font-medium">
                                                <span @class(["rounded-full px-3 py-1.5 font-medium", "bg-emerald-50 text-emerald-700" => $productionMethod->is_active, "bg-slate-50 text-slate-500" => ! $productionMethod->is_active])>{{ $productionMethod->is_active ? 'Active' : 'Inactive' }}</span>
                                                @if($productionMethod->is_default)<span class="rounded-full bg-amber-50 px-3 py-1.5 font-medium text-amber-700">Default</span>@endif
                                            </div>
                                        </article>
                                    @endforeach
                                </div>
                            @else
                                <div class="rounded-2xl border border-dashed border-slate-300 p-7 text-center text-sm text-slate-500">
                                    No production methods found. Add production methods from <strong>Master Data → Production Methods</strong> first.
                                </div>
                            @endif
                        </div>
                    </details>

                    <details class="np-config-panel" open>
                        <summary>Shipping methods</summary>
                        <div class="mt-4 flex flex-col gap-3 md:flex-row md:items-center md:justify-between">
                            <label class="inline-flex min-w-0 items-center gap-3 rounded-xl border border-slate-200 bg-white px-4 py-3 text-sm font-semibold text-slate-700">
                                <input type="hidden" name="shipping_methods_enabled" :value="shippingMethodsEnabled ? 1 : 0">
                                <input type="checkbox" x-model="shippingMethodsEnabled" class="h-4 w-4 rounded border-slate-300 text-brand-red">
                                <span>Show shipping methods on product page</span>
                            </label>
                            <p class="min-w-0 text-xs font-medium leading-5 text-slate-500 md:text-right">Select reusable shipping methods from Master Data. Names and days come from master data; prices come from this product price table shipping columns.</p>
                        </div>

                        <div x-show="shippingMethodsEnabled" class="mt-4" x-cloak>
                            @if($shippingMethodOptions->isNotEmpty())
                                <div class="grid items-stretch gap-3 xl:grid-cols-2">
                                    @foreach($shippingMethodOptions as $shippingMethod)
                                        <article @class([
                                            'flex h-full flex-col justify-between rounded-2xl border bg-white p-4 transition',
                                            'border-slate-300 bg-slate-50' => $selectedShippingCodes->contains($shippingMethod->code),
                                            'border-slate-200' => ! $selectedShippingCodes->contains($shippingMethod->code),
                                        ])>
                                            <div class="grid min-w-0 gap-3 sm:grid-cols-[minmax(0,1fr)_auto] sm:items-start">
                                                <label class="grid min-w-0 cursor-pointer grid-cols-[auto_minmax(0,1fr)] gap-3">
                                                    <input type="checkbox" name="shipping_method_codes[]" value="{{ $shippingMethod->code }}" @checked($selectedShippingCodes->contains($shippingMethod->code)) class="mt-1 h-4 w-4 rounded border-slate-300 text-brand-red">
                                                    <span class="min-w-0">
                                                        <span class="block text-sm font-semibold leading-5 text-slate-900">{{ $shippingMethod->name }}</span>
                                                        <span class="mt-1 block text-xs font-medium leading-5 text-slate-500">Price from product price table</span>
                                                        @if($shippingMethod->description)
                                                            <span class="mt-2 block text-sm font-normal leading-6 text-slate-500">{{ $shippingMethod->description }}</span>
                                                        @endif
                                                    </span>
                                                </label>
                                                <label class="inline-flex w-max items-center gap-2 rounded-full border border-slate-200 bg-slate-50 px-3 py-1.5 text-xs font-semibold text-slate-600">
                                                    <input type="radio" name="shipping_method_default_code" value="{{ $shippingMethod->code }}" @checked($defaultShippingCode === $shippingMethod->code) onclick="this.closest('article').querySelector('input[type=checkbox]').checked = true" class="h-3.5 w-3.5 border-slate-300 text-brand-red">
                                                    Default
                                                </label>
                                            </div>
                                            <div class="mt-4 flex flex-wrap gap-2 text-xs font-medium">
                                                <span class="rounded-full bg-slate-50 px-3 py-1.5 text-slate-600">{{ $shippingMethod->minimum_days }}–{{ $shippingMethod->maximum_days }} business days</span>
                                                <span class="rounded-full bg-slate-50 px-3 py-1.5 text-slate-500">{{ $shippingMethod->starts_after_artwork_approval ? 'After artwork approval' : 'After order placement' }}</span>
                                                <span @class(["rounded-full px-3 py-1.5 font-medium", "bg-emerald-50 text-emerald-700" => $shippingMethod->is_active, "bg-slate-50 text-slate-500" => ! $shippingMethod->is_active])>{{ $shippingMethod->is_active ? 'Active' : 'Inactive' }}</span>
                                            </div>
                                        </article>
                                    @endforeach
                                </div>
                            @else
                                <div class="rounded-2xl border border-dashed border-slate-300 p-7 text-center text-sm text-slate-500">
                                    No shipping methods found. Add shipping methods from <strong>Master Data → Shipping Methods</strong> first.
                                </div>
                            @endif
                        </div>
                    </details>
                </div>
            </section>

            <section id="description" class="np-card">
                <header class="np-card__header">
                    <div>
                        <h2>6. Product Content</h2>
                        <p>Write the description, customization / artwork guidance, and fulfillment content shown in the product tabs.</p>
                    </div>
                </header>
                <x-admin.tabbed-rich-editor
                    :description-value="$product->description_html"
                    :customization-value="$product->customization_artwork_html"
                    :fulfillment-value="$product->fulfillment_html"
                />
            </section>

            <section
                id="faq"
                class="np-card"
                x-data="productFaqSelector({
                    options: @js(collect($faqOptions)->map(fn ($faq) => [
                        'id' => (int) $faq->id,
                        'question' => (string) $faq->question,
                        'answer' => (string) $faq->answer,
                        'is_active' => (bool) $faq->is_active,
                    ])->values()->all()),
                    selected: @js($selectedFaqIds->all()),
                })"
            >
                <header class="np-card__header">
                    <div>
                        <h2>7. Product FAQs</h2>
                        <p>Add only the reusable FAQs that should appear on this product.</p>
                    </div>
                    <div class="flex flex-wrap items-center gap-3">
                        <a class="np-secondary-button" href="{{ route('admin.faqs.index') }}">Manage FAQs</a>
                        @if($faqOptions->isNotEmpty())
                            <button type="button" class="np-secondary-button" @click="openFaqPicker()">＋ Add FAQs</button>
                        @endif
                    </div>
                </header>

                <template x-for="faqId in selectedFaqIds" :key="`faq-input-${faqId}`">
                    <input type="hidden" name="faq_ids[]" :value="faqId">
                </template>

                @if($faqOptions->isEmpty())
                    <div class="rounded-2xl border border-dashed border-slate-300 bg-slate-50 p-6 text-center">
                        <p class="font-black text-brand-ink">No FAQ master data is available.</p>
                        <p class="mt-2 text-sm text-slate-500">Create FAQs first, then return here to assign them to this product.</p>
                        <a class="btn btn-white mt-4" href="{{ route('admin.faqs.create') }}">Create FAQ</a>
                    </div>
                @else
                    <div x-show="selectedFaqOptions().length > 0" class="grid gap-3 lg:grid-cols-2">
                        <template x-for="faq in selectedFaqOptions()" :key="faq.id">
                            <article class="flex items-start gap-3 rounded-2xl border border-slate-200 bg-white p-4">
                                <span class="mt-0.5 grid h-8 w-8 shrink-0 place-items-center rounded-full bg-blue-50 text-sm font-black text-brand-blue">?</span>
                                <div class="min-w-0 flex-1">
                                    <div class="flex flex-wrap items-start justify-between gap-3">
                                        <div class="min-w-0">
                                            <div class="flex flex-wrap items-center gap-2">
                                                <strong class="text-sm font-black leading-5 text-brand-ink" x-text="faq.question"></strong>
                                                <span x-show="!faq.is_active" class="rounded-full bg-slate-100 px-2 py-1 text-[9px] font-black uppercase tracking-wide text-slate-500">Inactive</span>
                                            </div>
                                            <p class="mt-2 line-clamp-3 text-xs leading-5 text-slate-500" x-text="faq.answer"></p>
                                        </div>
                                        <button type="button" class="grid h-8 w-8 shrink-0 place-items-center rounded-lg border border-slate-200 text-lg leading-none text-slate-500 hover:border-red-200 hover:bg-red-50 hover:text-red-600" @click="removeFaq(faq.id)" :aria-label="`Remove ${faq.question}`">×</button>
                                    </div>
                                </div>
                            </article>
                        </template>
                    </div>

                    <div x-show="selectedFaqOptions().length === 0" class="rounded-2xl border-2 border-dashed border-slate-200 p-8 text-center">
                        <p class="font-black text-brand-ink">No FAQ has been added to this product.</p>
                        <p class="mt-2 text-sm text-slate-500">Choose <strong>Add FAQs</strong> to select reusable questions from Master Data.</p>
                        <button type="button" class="np-secondary-button mt-4" @click="openFaqPicker()">＋ Add FAQs</button>
                    </div>

                    @error('faq_ids')<p class="mt-3 text-xs font-bold text-red-600">{{ $message }}</p>@enderror
                    @error('faq_ids.*')<p class="mt-3 text-xs font-bold text-red-600">{{ $message }}</p>@enderror
                @endif

    <div x-cloak x-show="faqPickerOpen" x-transition.opacity class="fixed inset-0 z-[115] grid place-items-center bg-slate-950/65 p-4" role="dialog" aria-modal="true" aria-labelledby="faq-picker-title" @click.self="closeFaqPicker()" @keydown.escape.window="closeFaqPicker()">
        <div x-show="faqPickerOpen" x-transition class="flex max-h-[88vh] w-full max-w-4xl flex-col overflow-hidden rounded-3xl border border-slate-200 bg-white shadow-2xl">
            <div class="flex items-start justify-between gap-4 border-b border-slate-200 p-5 sm:p-7">
                <div>
                    <p class="text-[10px] font-black uppercase tracking-[.14em] text-brand-blue">Master Data</p>
                    <h2 id="faq-picker-title" class="mt-2 text-2xl font-black text-brand-ink">Add Product FAQs</h2>
                    <p class="mt-2 text-sm text-slate-500">Check the FAQs that should be shown with this product. You can select more than one.</p>
                </div>
                <button type="button" class="grid h-10 w-10 shrink-0 place-items-center rounded-xl border border-slate-200 text-xl text-slate-500 hover:bg-slate-50" @click="closeFaqPicker()" aria-label="Close">×</button>
            </div>

            <div class="border-b border-slate-200 p-4 sm:px-7">
                <input class="admin-input mt-0" type="search" x-model.debounce.150ms="faqPickerSearch" placeholder="Search FAQ questions or answers">
            </div>

            <div class="min-h-0 flex-1 overflow-y-auto p-5 sm:p-7">
                <div class="grid gap-3 lg:grid-cols-2">
                    <template x-for="faq in filteredFaqOptions()" :key="faq.id">
                        <label class="flex cursor-pointer items-start gap-3 rounded-2xl border p-4 transition" :class="isFaqSelected(faq.id) ? 'border-brand-blue bg-blue-50/30' : 'border-slate-200 bg-white hover:border-brand-blue/40'">
                            <input
                                class="mt-1 h-5 w-5 shrink-0 rounded border-slate-300 text-brand-blue focus:ring-brand-blue"
                                type="checkbox"
                                :checked="isFaqSelected(faq.id)"
                                @change="toggleFaq(faq.id)"
                            >
                            <span class="min-w-0 flex-1">
                                <span class="flex flex-wrap items-center gap-2">
                                    <strong class="text-sm font-black leading-5 text-brand-ink" x-text="faq.question"></strong>
                                    <span x-show="!faq.is_active" class="rounded-full bg-slate-100 px-2 py-1 text-[9px] font-black uppercase tracking-wide text-slate-500">Inactive</span>
                                </span>
                                <span class="mt-2 block text-xs leading-5 text-slate-500" x-text="faq.answer"></span>
                            </span>
                        </label>
                    </template>
                </div>

                <div x-show="filteredFaqOptions().length === 0" class="rounded-2xl border-2 border-dashed border-slate-200 p-10 text-center">
                    <p class="font-black text-brand-ink">No matching FAQ was found.</p>
                    <p class="mt-2 text-sm text-slate-500">Try another search or create a new FAQ in Master Data.</p>
                    <a href="{{ route('admin.faqs.create') }}" class="btn btn-white mt-5">Create FAQ</a>
                </div>
            </div>

            <div class="flex flex-wrap items-center justify-between gap-3 border-t border-slate-200 bg-slate-50 p-4 sm:px-7">
                <span class="text-sm font-bold text-slate-500"><strong class="text-brand-ink" x-text="selectedFaqIds.length"></strong> selected</span>
                <button type="button" class="btn btn-white" @click="closeFaqPicker()">Done</button>
            </div>
        </div>
    </div>
            </section>
        </section>

        <aside class="np-product-builder__aside">
            <section class="np-side-card">
                <div class="np-publish-heading">
                    <h3>Publish</h3>
                </div>
                <span class="np-publish-sku np-publish-sku--below" data-publish-sku-badge style="{{ trim((string) ($productSpecificationAutoValues['SKU'] ?? '')) === '' ? 'display:none' : '' }}">SKU: <strong data-publish-sku-value>{{ trim((string) ($productSpecificationAutoValues['SKU'] ?? '')) }}</strong></span>
                <label class="admin-label mt-4">Product status <span class="text-brand-red">*</span>
                    <select x-ref="productStatus" class="admin-input" name="status">
                        <option value="draft" @selected($currentProductStatus === 'draft')>Draft</option>
                        <option value="active" @selected($currentProductStatus === 'active')>Active</option>
                        <option value="archived" @selected($currentProductStatus === 'archived')>Archived</option>
                    </select>
                </label>
                <p class="mt-3 text-xs leading-5 text-slate-500">Only published products are visible on your storefront.</p>
                <div class="np-side-divider"></div>
                <p class="np-side-label">Categories</p>
                <div class="mt-2 flex flex-wrap gap-2">
                    <span class="np-chip" x-text="selectedCategoryName() || 'Select a last-level category'"></span>
                    <span class="np-chip is-primary" x-show="categoryId" x-cloak>Primary</span>
                </div>
                <div class="np-side-divider"></div>
                <p class="np-side-label">Product visibility</p>
                <div class="np-visibility-options">
                    <label class="np-visibility-option">
                        <input type="hidden" name="is_featured" value="0">
                        <input type="checkbox" name="is_featured" value="1" x-model="isFeatured">
                        <span>
                            <strong>Feature product on homepage</strong>
                            <small>Show this product inside the Featured Products section.</small>
                        </span>
                    </label>
                    <label class="np-visibility-option" :class="!categoryId ? 'is-disabled' : ''">
                        <input type="hidden" name="show_in_category_page" value="0">
                        <input type="checkbox" name="show_in_category_page" value="1" x-model="showInCategoryPage" :disabled="!categoryId">
                        <span>
                            <strong>Show on selected category page</strong>
                            <small x-text="categoryId ? `List it under ${selectedCategoryName()}` : 'Select a last-level category first to enable this option.'"></small>
                        </span>
                    </label>
                </div>
                <p class="mt-3 flex items-center gap-2 text-xs font-bold text-emerald-600">⊙ Visible on storefront when status is Active.</p>
                <div class="mt-5 grid gap-3">
                    <button type="submit" class="np-primary-button">{{ $isEdit ? 'Update Product' : 'Create Product' }}</button>
                    @if($isEdit)
                        <a href="{{ route('products.show',$product->slug) }}" target="_blank" class="np-secondary-button justify-center">Preview</a>
                    @else
                        <button type="button" class="np-secondary-button justify-center" disabled>Preview</button>
                    @endif
                    <button type="submit" class="np-secondary-button justify-center" @click="$refs.productStatus.value = 'draft'">Save Draft</button>
                </div>
            </section>
            <section class="np-side-card">
                <h3>Completion checklist</h3>
                <p class="mt-1 text-xs leading-5 text-slate-500">Complete the following to publish your product.</p>
                <ul class="np-checklist">
                    <template x-for="item in checklistItems" :key="item.key">
                        <li :class="checklistDone(item.key) ? 'is-complete' : ''">
                            <span class="np-checklist__mark" x-text="checklistDone(item.key) ? '✓' : ''"></span>
                            <span x-text="item.label"></span>
                        </li>
                    </template>
                </ul>
            </section>
        </aside>
    </div>

    <div class="np-bottom-bar"><a href="{{ route('admin.products.index') }}" class="np-secondary-button">Cancel</a><div class="ml-auto flex flex-wrap gap-3"><button type="submit" class="np-secondary-button" @click="$refs.productStatus.value = 'draft'">Save Draft</button><button type="submit" class="np-primary-button">{{ $isEdit ? 'Update Product' : 'Create Product' }}</button></div></div>
    <div x-cloak x-show="priceImportMappingOpen" x-transition.opacity class="fixed inset-0 z-[120] flex items-center justify-center bg-slate-950/65 p-3 sm:p-5" role="dialog" aria-modal="true" aria-labelledby="price-import-mapping-title" @keydown.escape.window="closePriceImportMapping()">
        <div x-show="priceImportMappingOpen" x-transition class="flex max-h-[94vh] w-full max-w-6xl flex-col overflow-hidden rounded-[28px] bg-white shadow-2xl" @click.outside="closePriceImportMapping()">
            <div class="flex items-start justify-between gap-4 border-b border-slate-200 px-5 py-5 sm:px-7">
                <div>
                    <p class="text-[10px] font-black uppercase tracking-[.14em] text-brand-blue">Flexible spreadsheet import</p>
                    <h2 id="price-import-mapping-title" class="mt-1 text-2xl font-black text-brand-ink" x-text="priceImportDialogTitle()">Map the uploaded price table</h2>
                    <p class="mt-2 text-sm leading-6 text-slate-500" x-text="priceImportDialogDescription()">No predefined Excel structure is required. Select how this spreadsheet should become the customer-visible price table.</p>
                    <p class="mt-1 text-xs font-bold text-slate-400" x-text="priceImportFileName"></p>
                </div>
                <button type="button" class="grid h-10 w-10 shrink-0 place-items-center rounded-full border border-slate-200 text-xl text-slate-500 hover:bg-slate-50" @click="closePriceImportMapping()" aria-label="Close">×</button>
            </div>

            <div class="overflow-y-auto px-5 py-5 sm:px-7">
                <div class="grid gap-5 lg:grid-cols-2">
                    <section class="rounded-2xl border border-slate-200 bg-slate-50 p-4 sm:p-5">
                        <h3 class="font-black text-brand-ink">1. Locate the table</h3>
                        <label class="admin-label mt-4">Header row
                            <select class="admin-input" x-model.number="priceImportHeaderRowIndex" @change="setupPriceImportMapping(priceImportHeaderRowIndex)">
                                <template x-for="rowIndex in priceImportHeaderRowChoices()" :key="rowIndex">
                                    <option :value="rowIndex" x-text="`Row ${rowIndex + 1}`"></option>
                                </template>
                            </select>
                            <small class="font-normal text-slate-500">The selected row becomes the storefront column headings.</small>
                        </label>
                    </section>

                    <section class="rounded-2xl border border-slate-200 bg-slate-50 p-4 sm:p-5">
                        <h3 class="font-black text-brand-ink">2. Map quantity ranges</h3>
                        <label class="admin-label mt-4">Quantity layout
                            <select class="admin-input" x-model="priceImportQuantityMode" @change="refreshPriceImportQuantityMapping()">
                                <option value="range">One quantity or range column</option>
                                <option value="split">Separate minimum and maximum columns</option>
                            </select>
                        </label>

                        <div x-show="priceImportQuantityMode === 'range'" class="mt-4">
                            <label class="admin-label">Quantity / range column
                                <select class="admin-input" x-model="priceImportQuantityColumn" @change="refreshPriceImportQuantityMapping()">
                                    <option value="">Select column</option>
                                    <template x-for="column in priceImportColumnOptions()" :key="column.index">
                                        <option :value="column.index" x-text="column.label"></option>
                                    </template>
                                </select>
                                <small class="font-normal text-slate-500">A cell may contain a starting value such as 1, 5, or 12, or an explicit range such as 1-4 or 5-11. Single values use the next row's starting quantity minus one as their maximum.</small>
                            </label>
                        </div>

                        <div x-show="priceImportQuantityMode === 'split'" class="mt-4 grid gap-3 sm:grid-cols-2">
                            <label class="admin-label">Minimum quantity column
                                <select class="admin-input" x-model="priceImportMinColumn" @change="refreshPriceImportQuantityMapping()">
                                    <option value="">Select column</option>
                                    <template x-for="column in priceImportColumnOptions()" :key="`min-${column.index}`">
                                        <option :value="column.index" x-text="column.label"></option>
                                    </template>
                                </select>
                            </label>
                            <label class="admin-label">Maximum quantity column
                                <select class="admin-input" x-model="priceImportMaxColumn" @change="refreshPriceImportQuantityMapping()">
                                    <option value="">No maximum column</option>
                                    <template x-for="column in priceImportColumnOptions()" :key="`max-${column.index}`">
                                        <option :value="column.index" x-text="column.label"></option>
                                    </template>
                                </select>
                                <small class="font-normal text-slate-500">When maximums leave gaps or overlaps, they are normalized from the next row's minimum quantity. A blank final maximum means no upper limit.</small>
                            </label>
                        </div>
                    </section>
                </div>

                <section class="mt-5 rounded-2xl border border-slate-200 p-4 sm:p-5">
                    <div class="flex flex-col gap-2 sm:flex-row sm:items-start sm:justify-between">
                        <div>
                            <h3 class="font-black text-brand-ink">3. Choose storefront columns</h3>
                            <p class="mt-1 text-xs leading-5 text-slate-500">Checked columns are generated exactly with their spreadsheet headings. Uncheck internal cost, supplier, notes, or any column customers should not see.</p>
                        </div>
                        <span class="rounded-full bg-blue-50 px-3 py-1 text-xs font-black text-brand-blue" x-text="`${priceImportIncludedColumns.length} selected`"></span>
                    </div>

                    <div class="mt-4 grid gap-2 sm:grid-cols-2 lg:grid-cols-3">
                        <template x-for="column in priceImportColumnOptions()" :key="`visible-${column.index}`">
                            <label class="flex items-center gap-3 rounded-xl border border-slate-200 px-3 py-3 text-sm font-bold" :class="isMappedQuantityColumn(column.index) ? 'bg-slate-100 text-slate-400' : 'bg-white text-slate-700'">
                                <input type="checkbox" :checked="priceImportIncludedColumns.includes(column.index)" :disabled="isMappedQuantityColumn(column.index)" @change="togglePriceImportColumn(column.index, $event.target.checked)">
                                <span class="min-w-0 truncate" x-text="column.label"></span>
                            </label>
                        </template>
                    </div>

                    <label class="admin-label mt-5 max-w-xl">Primary live-price column
                        <select class="admin-input" x-model="priceImportPrimaryPriceColumn">
                            <option value="">Select the price used for live calculations</option>
                            <template x-for="column in priceImportSelectedColumnOptions()" :key="`primary-${column.index}`">
                                <option :value="column.index" x-text="column.label"></option>
                            </template>
                        </select>
                        <small class="font-normal text-slate-500">This column is highlighted and supplies the product unit price for cart calculations.</small>
                    </label>
                </section>

                <section class="mt-5 overflow-hidden rounded-2xl border border-slate-200">
                    <div class="border-b border-slate-200 bg-slate-50 px-4 py-3">
                        <h3 class="font-black text-brand-ink">Spreadsheet preview</h3>
                        <p class="mt-1 text-xs text-slate-500">The first rows below help confirm the mapping before the current table is replaced.</p>
                    </div>
                    <div class="overflow-x-auto">
                        <table class="min-w-full border-collapse text-xs">
                            <thead>
                                <tr>
                                    <template x-for="(header,index) in priceImportHeaders" :key="`preview-header-${index}`">
                                        <th class="min-w-[150px] border-b border-r border-slate-200 bg-white p-3 text-left font-black text-slate-700">
                                            <span x-text="header"></span>
                                            <small class="mt-1 block font-normal text-slate-400" x-text="`Column ${spreadsheetColumnLetter(index)}`"></small>
                                        </th>
                                    </template>
                                </tr>
                            </thead>
                            <tbody>
                                <template x-for="(row,rowIndex) in priceImportPreviewRows" :key="`preview-row-${rowIndex}`">
                                    <tr>
                                        <template x-for="(cell,cellIndex) in row" :key="`preview-cell-${rowIndex}-${cellIndex}`">
                                            <td class="max-w-[260px] border-r border-t border-slate-200 p-3 text-slate-600"><span class="block truncate" x-text="cell || '—'"></span></td>
                                        </template>
                                    </tr>
                                </template>
                            </tbody>
                        </table>
                    </div>
                </section>

                <p x-show="priceImportMappingError" x-text="priceImportMappingError" class="mt-4 rounded-xl border border-red-200 bg-red-50 p-3 text-sm font-bold text-red-700"></p>
            </div>

            <div class="flex flex-col-reverse gap-3 border-t border-slate-200 bg-slate-50 px-5 py-4 sm:flex-row sm:justify-end sm:px-7">
                <button type="button" class="btn btn-white" @click="closePriceImportMapping()">Cancel</button>
                <button type="button" class="btn btn-red" @click="applyPriceImportMapping()" x-text="priceImportTargetTable ? 'Generate Fabric Price Table' : 'Generate Price Table'">Generate Price Table</button>
            </div>
        </div>
    </div>


    <div x-cloak x-show="newFeatureDialogOpen" x-transition.opacity class="fixed inset-0 z-[110] grid place-items-center bg-slate-950/65 p-4" role="dialog" aria-modal="true" aria-labelledby="new-feature-dialog-title" @click.self="closeNewFeatureDialog()" @keydown.escape.window="closeNewFeatureDialog()">
        <div x-show="newFeatureDialogOpen" x-transition class="w-full max-w-lg rounded-3xl border border-slate-200 bg-white p-5 shadow-2xl sm:p-7">
            <div class="flex items-start justify-between gap-4">
                <div>
                    <p class="text-[10px] font-black uppercase tracking-[.14em] text-brand-red">New product feature</p>
                    <h2 id="new-feature-dialog-title" class="mt-2 text-2xl font-black text-brand-ink">Choose the feature name</h2>
                    <p class="mt-2 text-sm leading-6 text-slate-500">The selected name determines which matching master-data items are available.</p>
                </div>
                <button type="button" class="grid h-10 w-10 shrink-0 place-items-center rounded-xl border border-slate-200 text-xl text-slate-500 hover:bg-slate-50" @click="closeNewFeatureDialog()" aria-label="Close">×</button>
            </div>

            <label class="admin-label mt-6">Feature name
                <select x-ref="newFeatureNameInput" class="admin-input" x-model="newFeatureType" @change="newFeatureNameError = ''">
                    <option value="">Select a feature</option>
                    <template x-for="group in customizationTypeGroups" :key="group.label">
                        <optgroup :label="group.label">
                            <template x-for="feature in group.types" :key="feature.value">
                                <option :value="feature.value" x-text="feature.label"></option>
                            </template>
                            <template x-if="group.size_options_enabled">
                                <option :value="`__size_options__:${group.key}`">Size Options</option>
                            </template>
                        </optgroup>
                    </template>
                </select>
            </label>
            <p x-show="newFeatureNameError" x-text="newFeatureNameError" class="mt-2 text-sm font-bold text-red-700"></p>

            <div class="mt-6 flex flex-col-reverse gap-3 sm:flex-row sm:justify-end">
                <button type="button" class="btn btn-white" @click="closeNewFeatureDialog()">Cancel</button>
                <button type="button" class="btn btn-red" @click="confirmNewFeature()">Add Feature</button>
            </div>
        </div>
    </div>

    <div x-cloak x-show="masterItemPickerOpen" x-transition.opacity class="fixed inset-0 z-[115] grid place-items-center bg-slate-950/65 p-4" role="dialog" aria-modal="true" aria-labelledby="master-item-picker-title" @click.self="closeMasterItemPicker()" @keydown.escape.window="closeMasterItemPicker()">
        <div x-show="masterItemPickerOpen" x-transition class="flex max-h-[88vh] w-full max-w-4xl flex-col overflow-hidden rounded-3xl border border-slate-200 bg-white shadow-2xl">
            <div class="flex items-start justify-between gap-4 border-b border-slate-200 p-5 sm:p-7">
                <div>
                    <p class="text-[10px] font-black uppercase tracking-[.14em] text-brand-blue">Product customization master data</p>
                    <h2 id="master-item-picker-title" class="mt-2 text-2xl font-black text-brand-ink">Add <span x-text="activeMasterItemGroup()?.name || 'item'"></span></h2>
                    <p class="mt-2 text-sm text-slate-500">Only active items matching this feature type are shown. Already selected items cannot be added twice.</p>
                </div>
                <button type="button" class="grid h-10 w-10 shrink-0 place-items-center rounded-xl border border-slate-200 text-xl text-slate-500 hover:bg-slate-50" @click="closeMasterItemPicker()" aria-label="Close">×</button>
            </div>

            <div class="overflow-y-auto p-5 sm:p-7">
                <div class="grid gap-3 sm:grid-cols-2 lg:grid-cols-3">
                    <template x-for="item in availableMasterItems()" :key="item.id">
                        <article class="rounded-2xl border border-slate-200 p-4" :class="isMasterItemSelected(item) ? 'bg-slate-50 opacity-60' : 'bg-white'">
                            <div class="flex items-start gap-3">
                                <div class="grid h-16 w-16 shrink-0 place-items-center overflow-hidden rounded-xl border border-slate-200 bg-slate-100">
                                    <img x-show="masterItemPrimaryImage(item)" :src="masterItemPrimaryImage(item)" :alt="item.name" class="h-full w-full object-cover">
                                    <span x-show="!masterItemPrimaryImage(item) && item.color_hex" class="h-10 w-10 rounded-full border border-slate-300" :style="`background:${item.color_hex}`"></span>
                                    <span x-show="!masterItemPrimaryImage(item) && !item.color_hex" class="text-[9px] font-black uppercase text-slate-400">No image</span>
                                </div>
                                <div class="min-w-0">
                                    <h3 class="truncate font-black text-brand-ink" x-text="item.name"></h3>
                                    <p x-show="item.description" class="mt-1 line-clamp-2 text-xs leading-5 text-slate-500" x-text="item.description"></p>
                                    <span x-show="item.color_hex" class="mt-2 inline-flex rounded-full border border-slate-200 px-2 py-1 font-mono text-[10px]" x-text="item.color_hex"></span>
                                </div>
                            </div>
                            <button type="button" class="btn btn-white mt-4 w-full" :disabled="isMasterItemSelected(item)" @click="selectMasterItem(item)" x-text="isMasterItemSelected(item) ? 'Already selected' : 'Add item'"></button>
                        </article>
                    </template>
                </div>

                <div x-show="availableMasterItems().length === 0" class="rounded-2xl border-2 border-dashed border-slate-200 p-10 text-center">
                    <p class="font-black text-brand-ink">No master-data item is available for this feature.</p>
                    <p class="mt-2 text-sm text-slate-500">Create an item under Master Data → Product Customization first.</p>
                    <a href="{{ route('admin.jersey-customization-options.index') }}" class="btn btn-white mt-5">Open Product Customization</a>
                </div>
            </div>

            <div class="flex justify-end border-t border-slate-200 bg-slate-50 p-4 sm:px-7">
                <button type="button" class="btn btn-white" @click="closeMasterItemPicker()">Done</button>
            </div>
        </div>
    </div>





        <div x-cloak x-show="sizeGroupPickerOpen" x-transition.opacity class="fixed inset-0 z-[100] flex items-center justify-center bg-slate-950/55 p-4" @keydown.escape.window="closeSizeGroupPicker()">
            <div class="flex max-h-[88vh] w-full max-w-5xl flex-col overflow-hidden rounded-[28px] bg-white shadow-2xl" @click.outside="closeSizeGroupPicker()">
                <div class="flex items-start justify-between gap-4 border-b border-slate-200 px-5 py-5 sm:px-7">
                    <div>
                        <p class="text-[10px] font-black uppercase tracking-[.14em] text-brand-blue">Master Data</p>
                        <h3 class="mt-1 text-xl font-black text-brand-ink">Add Size Option</h3>
                        <p class="mt-2 text-sm text-slate-500">Choose one or more reusable size groups. A group cannot be selected twice.</p>
                    </div>
                    <button type="button" class="grid h-10 w-10 place-items-center rounded-full border border-slate-200 text-xl text-slate-500" @click="closeSizeGroupPicker()" aria-label="Close">×</button>
                </div>

                <div class="grid gap-3 border-b border-slate-200 p-4 sm:grid-cols-[220px_minmax(0,1fr)] sm:px-7">
                    <select class="admin-input mt-0" x-model="sizeGroupPickerContext">
                        <option value="">All clothing sections</option>
                        <template x-for="group in customizationTypeGroups" :key="group.label">
                            <option :value="group.key || (group.types[0] && group.types[0].group) || ''" x-text="group.label"></option>
                        </template>
                    </select>
                    <input class="admin-input mt-0" x-model="sizeGroupPickerSearch" placeholder="Search by group, type, or size">
                </div>

                <div class="min-h-0 flex-1 overflow-y-auto p-4 sm:p-7">
                    <div class="grid gap-4 md:grid-cols-2 xl:grid-cols-3">
                        <template x-for="master in filteredSizeOptionGroups()" :key="master.id">
                            <article class="rounded-2xl border border-slate-200 p-4">
                                <div class="flex items-start justify-between gap-3">
                                    <div class="min-w-0">
                                        <h4 class="truncate font-black text-brand-ink" x-text="master.name"></h4>
                                        <p class="mt-1 text-xs font-bold text-brand-blue" x-text="master.customization_group_label"></p>
                                        <p class="mt-1 text-[11px] font-semibold text-slate-500" x-text="master.audience_label"></p>
                                    </div>
                                    <span x-show="master.chart_enabled" class="rounded-full bg-emerald-50 px-2 py-1 text-[10px] font-black text-emerald-700">Chart</span>
                                </div>
                                <div class="mt-3 flex flex-wrap gap-1.5">
                                    <template x-for="size in master.sizes" :key="size"><span class="rounded-full bg-slate-100 px-2 py-1 text-[10px] font-bold text-slate-600" x-text="size"></span></template>
                                </div>
                                <button type="button" class="btn btn-white mt-4 w-full" :disabled="isSizeGroupSelected(master.id)" @click="selectSizeGroup(master)" x-text="isSizeGroupSelected(master.id) ? 'Already selected' : 'Add size option'"></button>
                            </article>
                        </template>
                    </div>

                    <div x-show="filteredSizeOptionGroups().length === 0" class="rounded-2xl border-2 border-dashed border-slate-200 p-10 text-center">
                        <p class="font-black text-brand-ink">No size option is available.</p>
                        <p class="mt-2 text-sm text-slate-500">Create one under Master Data → the required clothing section → Size Options first.</p>
                        <a href="{{ route('admin.size-option-groups.index', ['customization' => 'jersey']) }}" class="btn btn-white mt-5">Open Size Options</a>
                    </div>
                </div>

                <div class="flex justify-end border-t border-slate-200 bg-slate-50 p-4 sm:px-7">
                    <button type="button" class="btn btn-white" @click="closeSizeGroupPicker()">Done</button>
                </div>
            </div>
        </div>

    @if($errors->any())
        <script>
            document.addEventListener('DOMContentLoaded', function () {
                const form = document.querySelector('.np-product-form[data-validation-errors]');
                if (! form) return;

                const parseJson = (value, fallback) => {
                    try { return value ? JSON.parse(value) : fallback; } catch (error) { return fallback; }
                };

                const errors = parseJson(form.dataset.validationErrors, {});
                const aliases = parseJson(form.dataset.validationFieldAliases, {});
                const escapeSelector = (value) => {
                    if (window.CSS && typeof window.CSS.escape === 'function') return window.CSS.escape(value);
                    return String(value).replace(/([ #;&,.+*~\':"!^$[\]()=>|\/@])/g, '\\$1');
                };
                const bracketName = (key) => {
                    const parts = String(key).split('.');
                    return parts.shift() + parts.map((part) => `[${part}]`).join('');
                };
                const baseArrayName = (key) => {
                    const parts = String(key).split('.');
                    if (parts.length > 1 && /^\d+$/.test(parts[parts.length - 1])) {
                        return parts.slice(0, -1).join('.') + '[]';
                    }
                    return null;
                };
                const fieldCandidates = (key) => {
                    const alias = aliases[key] || key;
                    const candidates = [alias, bracketName(alias)];
                    const arrayName = baseArrayName(alias);
                    if (arrayName) candidates.push(arrayName, bracketName(arrayName));

                    const priceRow = String(alias).match(/^price_table_rows\.(\d+)$/);
                    if (priceRow) {
                        candidates.push(`price_table_rows[${priceRow[1]}][1]`);
                        candidates.push(`price_table_ranges[${priceRow[1]}][minimum_quantity]`);
                    }

                    const imageRow = String(alias).match(/^images\.(\d+)$/);
                    if (imageRow) {
                        candidates.push('images[]');
                    }

                    if (alias.includes('.')) {
                        const parent = alias.split('.').slice(0, -1).join('.');
                        candidates.push(parent, bracketName(parent));
                    }
                    return [...new Set(candidates.filter(Boolean))];
                };
                const findField = (key) => {
                    for (const name of fieldCandidates(key)) {
                        const dataTarget = form.querySelector(`[data-field-name="${escapeSelector(name)}"]`);
                        if (dataTarget) return dataTarget;
                        const field = form.querySelector(`[name="${escapeSelector(name)}"]`);
                        if (field) return field;
                    }
                    return null;
                };
                const revealField = (field) => {
                    if (! field) return;
                    let node = field.parentElement;
                    while (node && node !== form) {
                        if (node.tagName === 'DETAILS') node.open = true;
                        node = node.parentElement;
                    }
                };
                const visibleTarget = (field) => {
                    if (!field) return null;
                    if (field.matches('[data-field-name="product_specification_text"]')) {
                        return field.closest('.np-product-spec-card')?.querySelector('[contenteditable="true"]') || field;
                    }
                    if (field.matches('[data-field-name="primary_category_id"]')) {
                        return field.querySelector('.np-searchable-trigger') || field;
                    }
                    if (field.type === 'hidden') {
                        return field.closest('[data-field-name]')?.querySelector('button, [contenteditable="true"], input:not([type="hidden"]), textarea:not([hidden]), select')
                            || field.closest('[data-field-name]')
                            || field.closest('td, th, .admin-label, .np-nested-card, .np-config-panel')
                            || field;
                    }
                    return field;
                };
                const holderFor = (field) => {
                    return field.closest('.admin-label, .np-product-spec-card, .np-category-field, .np-nested-card, .np-config-panel, td, th, .np-upload-zone') || field.parentElement;
                };
                const addMessage = (field, message) => {
                    const holder = holderFor(field);
                    if (!holder || holder.querySelector(':scope > .np-field-error-message')) return;
                    const note = document.createElement('p');
                    note.className = 'np-field-error-message';
                    note.textContent = message || 'Please check this field and try again.';
                    holder.appendChild(note);
                };
                const applyErrors = () => {
                    let first = null;
                    Object.entries(errors).forEach(([key, messages]) => {
                        const field = findField(key);
                        const target = visibleTarget(field);
                        if (!target) return;

                        revealField(target);
                        target.classList.add('np-field-invalid');
                        target.setAttribute('aria-invalid', 'true');
                        if (!first) first = target;
                        addMessage(target, Array.isArray(messages) ? messages[0] : messages);
                    });

                    if (first) {
                        const section = first.closest('.np-card[id]');
                        if (section && history.replaceState) {
                            history.replaceState(null, '', '#' + section.id);
                        }
                        setTimeout(function () {
                            first.scrollIntoView({ behavior: 'smooth', block: 'center' });
                            if (typeof first.focus === 'function') first.focus({ preventScroll: true });
                        }, 120);
                    }
                };

                setTimeout(applyErrors, 180);
                setTimeout(applyErrors, 650);
            });
        </script>
    @endif
</form>

<script>
document.addEventListener('DOMContentLoaded', function () {
    document.querySelectorAll('.np-product-form').forEach(function (form) {
        const editor = form.querySelector('[data-field-name="product_specification_text"] [contenteditable="true"]');
        const badge = form.querySelector('[data-publish-sku-badge]');
        const output = form.querySelector('[data-publish-sku-value]');

        if (!editor || !badge || !output) return;

        const syncPublishSku = function () {
            const lines = String(editor.innerText || '').split(/\r?\n/);
            let sku = '';

            for (const line of lines) {
                const match = line.match(/^\s*(?:SKU|Style No|Style Number)\s*:\s*(.*?)\s*$/i);
                if (match) {
                    sku = String(match[1] || '').trim();
                    break;
                }
            }

            output.textContent = sku;
            badge.style.display = sku ? '' : 'none';
        };

        editor.addEventListener('input', syncPublishSku);
        new MutationObserver(syncPublishSku).observe(editor, {
            childList: true,
            subtree: true,
            characterData: true,
        });

        syncPublishSku();
        window.setTimeout(syncPublishSku, 250);
    });
});
</script>

