<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Builder;
use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;
use Illuminate\Database\Eloquent\Relations\BelongsTo;
use Illuminate\Database\Eloquent\Relations\HasMany;
use Illuminate\Database\Eloquent\Relations\BelongsToMany;
use Illuminate\Database\Eloquent\SoftDeletes;

class Product extends Model
{
    use HasFactory, SoftDeletes;

    protected $fillable = [
        'category_id', 'subcategory_id', 'name', 'slug', 'sku', 'status', 'product_type', 'product_profile', 'brand',
        'badge_label', 'badge_color', 'short_description', 'description_html', 'detail_information_html',
        'customization_artwork_html', 'fulfillment_html', 'features',
        'specifications', 'base_price', 'compare_at_price', 'cost_price', 'currency',
        'rating_average', 'reviews_count', 'recent_viewers_count', 'favorites_count', 'recent_orders_count',
        'minimum_quantity', 'maximum_quantity', 'is_featured', 'is_customizable', 'is_active',
        'track_inventory', 'stock_quantity', 'low_stock_threshold', 'allow_backorder', 'weight',
        'dimensions', 'shipping_class', 'production_methods_enabled', 'shipping_methods_enabled', 'jersey_roster_enabled',
        'jersey_roster_optional', 'jersey_roster_title', 'jersey_roster_fields',
        'sample_available', 'sample_charge',
        'artwork_upload_enabled', 'artwork_upload_required', 'artwork_upload_title',
        'artwork_upload_description', 'artwork_upload_max_files', 'artwork_upload_max_file_size_mb',
        'artwork_upload_accepted_types', 'tax_class', 'tags',
        'price_table_headers', 'price_table_rows',
        'price_table_highlight_column', 'price_table_note', 'production_table_headers', 'production_table_rows', 'meta_title', 'meta_description',
        'meta_keywords', 'canonical_url', 'og_title', 'og_description', 'og_image_url',
        'robots_index', 'robots_follow', 'schema_json', 'sort_order', 'published_at',
        'created_by', 'updated_by', 'last_update_summary',
    ];

    protected function casts(): array
    {
        return [
            'features' => 'array',
            'specifications' => 'array',
            'dimensions' => 'array',
            'tags' => 'array',
            'price_table_headers' => 'array',
            'price_table_rows' => 'array',
            'production_table_headers' => 'array',
            'production_table_rows' => 'array',
            'schema_json' => 'array',
            'jersey_roster_fields' => 'array',
            'base_price' => 'decimal:2',
            'compare_at_price' => 'decimal:2',
            'cost_price' => 'decimal:2',
            'rating_average' => 'decimal:2',
            'reviews_count' => 'integer',
            'recent_viewers_count' => 'integer',
            'favorites_count' => 'integer',
            'recent_orders_count' => 'integer',
            'weight' => 'decimal:3',
            'is_featured' => 'boolean',
            'is_customizable' => 'boolean',
            'is_active' => 'boolean',
            'track_inventory' => 'boolean',
            'allow_backorder' => 'boolean',
            'production_methods_enabled' => 'boolean',
            'shipping_methods_enabled' => 'boolean',
            'jersey_roster_enabled' => 'boolean',
            'jersey_roster_optional' => 'boolean',
            'sample_available' => 'boolean',
            'sample_charge' => 'decimal:2',
            'artwork_upload_enabled' => 'boolean',
            'artwork_upload_required' => 'boolean',
            'artwork_upload_max_files' => 'integer',
            'artwork_upload_max_file_size_mb' => 'integer',
            'robots_index' => 'boolean',
            'robots_follow' => 'boolean',
            'published_at' => 'datetime',
        ];
    }

    public function scopePublished(Builder $query): Builder
    {
        return $query->where('status', 'active')
            ->where('is_active', true)
            ->where(function (Builder $builder): void {
                $builder->whereNull('published_at')->orWhere('published_at', '<=', now());
            });
    }

    public function scopeFeatured(Builder $query): Builder
    {
        return $query->where('is_featured', true);
    }

    public function category(): BelongsTo
    {
        return $this->belongsTo(Category::class, 'category_id');
    }

    public function subcategory(): BelongsTo
    {
        return $this->belongsTo(Category::class, 'subcategory_id');
    }


    public function categories(): BelongsToMany
    {
        return $this->belongsToMany(Category::class)
            ->withPivot(['is_primary', 'is_featured', 'sort_order'])
            ->withTimestamps()
            ->orderBy('category_product.sort_order');
    }

    public function primaryCategory(): BelongsToMany
    {
        return $this->categories()->wherePivot('is_primary', true);
    }

    public function attributeValues(): BelongsToMany
    {
        return $this->belongsToMany(
            CatalogAttributeValue::class,
            'attribute_value_product',
            'product_id',
            'attribute_value_id'
        )->withPivot('sort_order')->with('attribute');
    }

    public function creator(): BelongsTo
    {
        return $this->belongsTo(User::class, 'created_by');
    }

    public function updater(): BelongsTo
    {
        return $this->belongsTo(User::class, 'updated_by');
    }

    public function wishlists(): HasMany
    {
        return $this->hasMany(ProductWishlist::class);
    }

    public function images(): HasMany
    {
        return $this->hasMany(ProductImage::class)->orderByDesc('is_primary')->orderBy('sort_order');
    }

    public function optionGroups(): HasMany
    {
        return $this->hasMany(ProductOptionGroup::class)->orderBy('sort_order');
    }

    public function sizeGroups(): HasMany
    {
        return $this->hasMany(ProductSizeGroup::class)->orderBy('sort_order');
    }

    public function priceTiers(): HasMany
    {
        return $this->hasMany(ProductPriceTier::class)->orderBy('minimum_quantity');
    }

    public function fabricPriceTables(): HasMany
    {
        return $this->hasMany(ProductFabricPriceTable::class)->orderBy('sort_order')->orderBy('fabric_label');
    }

    public function artworkMethods(): HasMany
    {
        return $this->hasMany(ProductArtworkMethod::class)->orderBy('sort_order');
    }

    public function productionSpeeds(): HasMany
    {
        return $this->hasMany(ProductProductionSpeed::class)->orderBy('sort_order');
    }

    public function shippingMethods(): HasMany
    {
        return $this->hasMany(ProductShippingMethod::class)->orderBy('sort_order');
    }

    public function faqs(): BelongsToMany
    {
        return $this->belongsToMany(Faq::class)
            ->withPivot('sort_order')
            ->withTimestamps()
            ->orderByPivot('sort_order')
            ->orderBy('faqs.sort_order')
            ->orderBy('faqs.question');
    }

    public function primaryImageUrl(): string
    {
        $image = $this->images->firstWhere('is_primary', true) ?? $this->images->first();

        if (! $image) {
            return asset('images/product-placeholder.svg');
        }

        return $image->publicUrl();
    }
}
