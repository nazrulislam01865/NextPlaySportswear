<?php

namespace App\Http\Requests\Admin;

use App\Enums\JerseyCustomizationType;
use App\Enums\WorldCupCustomizationType;
use App\Models\Category;
use App\Models\JerseyCustomizationOption;
use App\Models\WorldCupCustomizationOption;
use App\Models\Product;
use App\Models\ProductionMethod;
use App\Models\ShippingMethod;
use App\Support\ProductionTime;
use App\Support\ProductSizing;
use App\Support\ProductSizeExtraCharges;
use Illuminate\Foundation\Http\FormRequest;
use Illuminate\Support\Str;
use Illuminate\Validation\Rule;
use Illuminate\Validation\Validator;

class ProductFormRequest extends FormRequest
{
    public function authorize(): bool
    {
        return $this->user()?->isAdmin() ?? false;
    }

    public function rules(): array
    {
        $productId = $this->route('product')?->id;

        return [
            'name' => ['required', 'string', 'max:220'],
            'slug' => ['required', 'string', 'max:240', 'regex:/^[a-z0-9]+(?:-[a-z0-9]+)*$/', Rule::unique('products', 'slug')->ignore($productId)],
            'sku' => ['required', 'string', 'max:120', Rule::unique('products', 'sku')->ignore($productId)],
            'status' => ['required', Rule::in(['draft', 'active', 'archived'])],
            'primary_category_id' => ['nullable', 'integer', 'exists:categories,id'],
            'category_assignments' => ['nullable', 'array', 'max:100'],
            'category_assignments.*' => ['integer', 'distinct', 'exists:categories,id'],
            'show_in_category_page' => ['nullable', 'boolean'],
            'attribute_value_ids' => ['nullable', 'array', 'max:500'],
            'attribute_value_ids.*' => ['integer', 'distinct', 'exists:attribute_values,id'],
            // Legacy columns remain supported during the compatibility period.
            'category_id' => ['nullable', 'integer', 'exists:categories,id'],
            'subcategory_id' => ['nullable', 'integer', 'exists:categories,id', 'different:category_id'],
            'product_type' => ['nullable', 'string', 'max:100'],
            'product_profile' => ['required', Rule::in(array_values(array_unique(array_merge(['standard', 'other'], array_keys(JerseyCustomizationType::menuGroups())))))],
            'brand' => ['nullable', 'string', 'max:120'],
            'badge_label' => ['nullable', 'string', 'max:80'],
            'badge_color' => ['nullable', 'string', 'max:30'],
            'short_description' => ['nullable', 'string', 'max:1500'],
            'description_html' => ['nullable', 'string'],
            'product_specification_text' => ['nullable', 'string'],
            'detail_information_html' => ['nullable', 'string'],
            'customization_artwork_html' => ['nullable', 'string'],
            'fulfillment_html' => ['nullable', 'string'],
            'base_price' => ['required', 'numeric', 'min:0', 'max:999999999.99'],
            'compare_at_price' => ['nullable', 'numeric', 'min:0', 'max:999999999.99'],
            'cost_price' => ['nullable', 'numeric', 'min:0', 'max:999999999.99'],
            'rating_average' => ['nullable', 'numeric', 'min:0', 'max:5'],
            'reviews_count' => ['nullable', 'integer', 'min:0', 'max:100000000'],
            'recent_viewers_count' => ['nullable', 'integer', 'min:0', 'max:100000000'],
            'favorites_count' => ['nullable', 'integer', 'min:0', 'max:100000000'],
            'recent_orders_count' => ['nullable', 'integer', 'min:0', 'max:100000000'],
            'currency' => ['required', 'string', 'size:3'],
            'minimum_quantity' => ['required', 'integer', 'min:1', 'max:1000000'],
            'maximum_quantity' => ['nullable', 'integer', 'gte:minimum_quantity', 'max:1000000'],
            'is_featured' => ['nullable', 'boolean'],
            'is_customizable' => ['nullable', 'boolean'],
            'is_active' => ['nullable', 'boolean'],
            'track_inventory' => ['nullable', 'boolean'],
            'stock_quantity' => ['nullable', 'integer', 'min:-1000000', 'max:100000000'],
            'low_stock_threshold' => ['nullable', 'integer', 'min:0', 'max:1000000'],
            'allow_backorder' => ['nullable', 'boolean'],
            'weight' => ['nullable', 'numeric', 'min:0', 'max:999999.999'],
            'length' => ['nullable', 'numeric', 'min:0', 'max:999999.999'],
            'width' => ['nullable', 'numeric', 'min:0', 'max:999999.999'],
            'height' => ['nullable', 'numeric', 'min:0', 'max:999999.999'],
            'shipping_class' => ['nullable', 'string', 'max:100'],
            'production_methods_enabled' => ['nullable', 'boolean'],
            'shipping_methods_enabled' => ['nullable', 'boolean'],
            'jersey_roster_enabled' => ['nullable', 'boolean'],
            'jersey_roster_optional' => ['nullable', 'boolean'],
            'jersey_roster_title' => ['nullable', 'string', 'max:180'],
            'jersey_roster_fields' => ['nullable', 'array', 'max:20'],
            'jersey_roster_fields.*.key' => ['nullable', 'string', 'max:80', 'regex:/^[a-z0-9_\-]+$/', 'distinct'],
            'jersey_roster_fields.*.label' => ['nullable', 'string', 'max:120'],
            'jersey_roster_fields.*.type' => ['nullable', Rule::in(['text', 'number'])],
            'jersey_roster_fields.*.max_length' => ['nullable', 'integer', 'min:1', 'max:120'],
            'jersey_roster_fields.*.required' => ['nullable', 'boolean'],
            'jersey_roster_fields.*.enabled' => ['nullable', 'boolean'],
            'sample_available' => ['nullable', 'boolean'],
            'sample_charge' => ['nullable', 'numeric', 'min:0', 'max:999999999.99'],
            'artwork_upload_enabled' => ['nullable', 'boolean'],
            'artwork_upload_required' => ['nullable', 'boolean'],
            'artwork_upload_title' => ['nullable', 'string', 'max:180'],
            'artwork_upload_description' => ['nullable', 'string', 'max:3000'],
            'artwork_upload_max_files' => ['nullable', 'integer', 'min:1', 'max:12'],
            'artwork_upload_max_file_size_mb' => ['nullable', 'integer', 'min:1', 'max:25'],
            'artwork_upload_accepted_types' => ['nullable', 'string', 'max:500', 'regex:/^[a-z0-9,\s]+$/i'],
            'tax_class' => ['nullable', 'string', 'max:100'],
            'tags_text' => ['nullable', 'string', 'max:5000'],
            'tags' => ['nullable'],
            'tags.*' => ['nullable', 'string', 'max:250'],
            'published_at' => ['nullable', 'date'],
            'sort_order' => ['nullable', 'integer', 'min:0', 'max:1000000'],

            'features' => ['nullable', 'array', 'max:50'],
            'features.*' => ['nullable', 'string', 'max:500'],
            'specifications' => ['nullable', 'array', 'max:100'],
            'specifications.*.name' => ['nullable', 'string', 'max:150'],
            'specifications.*.value' => ['nullable', 'string', 'max:1000'],

            'image_urls' => ['nullable', 'array', 'max:30'],
            'image_urls.*.existing_id' => ['nullable', 'integer', 'min:1'],
            'image_urls.*.media_library_image_id' => ['nullable', 'integer', 'exists:media_library_images,id'],
            'image_urls.*.url' => ['nullable', 'url', 'max:2048'],
            'image_urls.*.name' => ['nullable', 'string', 'max:255'],
            'image_urls.*.alt' => ['nullable', 'string', 'max:255'],
            'image_urls.*.is_primary' => ['nullable', 'boolean'],
            'images' => ['nullable', 'array', 'max:20'],
            'images.*' => ['nullable', 'file', 'mimes:jpg,jpeg,png,webp,avif', 'mimetypes:image/jpeg,image/png,image/webp,image/avif', 'max:5120'],
            'new_image_primary_index' => ['nullable', 'integer', 'min:0', 'max:19'],

            'price_tiers' => ['nullable', 'array', 'max:100'],
            'price_tiers.*.label' => ['nullable', 'string', 'max:120'],
            'price_tiers.*.minimum_quantity' => ['required_with:price_tiers.*.unit_price', 'nullable', 'integer', 'min:1'],
            'price_tiers.*.maximum_quantity' => ['nullable', 'integer', 'gte:price_tiers.*.minimum_quantity'],
            'price_tiers.*.unit_price' => ['nullable', 'numeric', 'min:0'],
            'price_tiers.*.compare_at_price' => ['nullable', 'numeric', 'min:0'],
            'price_tiers.*.savings_label' => ['nullable', 'string', 'max:120'],

            'price_table_headers' => ['required', 'array', 'min:2', 'max:20'],
            'price_table_headers.0' => ['required', 'string', Rule::in(['Quantity'])],
            'price_table_headers.*' => ['required', 'string', 'max:150'],
            'price_table_rows' => ['required', 'array', 'min:1', 'max:200'],
            'price_table_rows.*' => ['required', 'array', 'max:20'],
            'price_table_rows.*.*' => ['nullable', 'string', 'max:500'],
            'price_table_ranges' => ['required', 'array', 'min:1', 'max:200'],
            'price_table_ranges.*' => ['required', 'array'],
            'price_table_ranges.*.minimum_quantity' => ['nullable', 'integer', 'min:1', 'max:1000000'],
            'price_table_ranges.*.maximum_quantity' => ['nullable', 'integer', 'min:1', 'max:1000000'],
            'price_table_highlight_column' => ['required', 'integer', 'min:1', 'max:19'],
            'price_table_note' => ['nullable', 'string', 'max:3000'],

            'fabric_price_tables' => ['nullable', 'array', 'max:200'],
            'fabric_price_tables.*.fabric_key' => ['nullable', 'string', 'max:220'],
            'fabric_price_tables.*.jersey_customization_option_id' => ['nullable', 'integer', 'exists:jersey_customization_options,id'],
            'fabric_price_tables.*.fabric_code' => ['nullable', 'string', 'max:180'],
            'fabric_price_tables.*.fabric_label' => ['nullable', 'string', 'max:180'],
            'fabric_price_tables.*.has_custom_pricing' => ['nullable', 'boolean'],
            'fabric_price_tables.*.price_table_headers' => ['nullable', 'array', 'max:20'],
            'fabric_price_tables.*.price_table_headers.*' => ['nullable', 'string', 'max:150'],
            'fabric_price_tables.*.price_table_rows' => ['nullable', 'array', 'max:200'],
            'fabric_price_tables.*.price_table_rows.*' => ['nullable', 'array', 'max:20'],
            'fabric_price_tables.*.price_table_rows.*.*' => ['nullable', 'string', 'max:500'],
            'fabric_price_tables.*.price_table_ranges' => ['nullable', 'array', 'max:200'],
            'fabric_price_tables.*.price_table_ranges.*.minimum_quantity' => ['nullable', 'integer', 'min:1', 'max:1000000'],
            'fabric_price_tables.*.price_table_ranges.*.maximum_quantity' => ['nullable', 'integer', 'min:1', 'max:1000000'],
            'fabric_price_tables.*.price_table_highlight_column' => ['nullable', 'integer', 'min:1', 'max:19'],
            'fabric_price_tables.*.price_table_note' => ['nullable', 'string', 'max:3000'],

            'option_groups' => ['nullable', 'array', 'max:100'],
            'option_groups.*.name' => ['nullable', 'string', 'max:160'],
            'option_groups.*.code' => ['nullable', 'string', 'max:160', 'regex:/^[a-z0-9]+(?:-[a-z0-9]+)*$/', 'distinct'],
            'option_groups.*.section' => ['nullable', Rule::in(['product', 'decoration'])],
            'option_groups.*.type' => ['nullable', Rule::in(['image', 'swatch', 'buttons', 'select', 'checkbox', 'text', 'textarea', 'number', 'file', 'date'])],
            'option_groups.*.jersey_customization_type' => ['nullable', Rule::in(array_keys(array_merge(JerseyCustomizationType::options(), WorldCupCustomizationType::options())))],
            'option_groups.*.display_mode' => ['nullable', Rule::in(['hidden', 'fixed', 'customer'])],
            'option_groups.*.fixed_value_code' => ['nullable', 'string', 'max:180'],
            'option_groups.*.fixed_text_value' => ['nullable', 'string', 'max:2000'],
            'option_groups.*.show_in_summary' => ['nullable', 'boolean'],
            'option_groups.*.use_as_filter' => ['nullable', 'boolean'],
            'option_groups.*.description' => ['nullable', 'string', 'max:2000'],
            'option_groups.*.placeholder' => ['nullable', 'string', 'max:255'],
            'option_groups.*.is_required' => ['nullable', 'boolean'],
            'option_groups.*.minimum_selections' => ['nullable', 'integer', 'min:0', 'max:1000'],
            'option_groups.*.maximum_selections' => ['nullable', 'integer', 'min:1', 'max:1000'],
            'option_groups.*.accepted_file_types' => ['nullable', 'string', 'max:500'],
            'option_groups.*.maximum_file_size_mb' => ['nullable', 'integer', 'min:1', 'max:100'],
            'option_groups.*.is_active' => ['nullable', 'boolean'],
            'option_groups.*.values' => ['nullable', 'array', 'max:200'],
            'option_groups.*.values.*.label' => ['nullable', 'string', 'max:180'],
            'option_groups.*.values.*.code' => ['nullable', 'string', 'max:180', 'regex:/^[a-z0-9]+(?:-[a-z0-9]+)*$/'],
            'option_groups.*.values.*.existing_id' => ['nullable', 'integer', 'min:1'],
            'option_groups.*.values.*.jersey_customization_option_id' => ['nullable', 'integer', 'distinct', 'exists:jersey_customization_options,id'],
            'option_groups.*.values.*.world_cup_customization_option_id' => ['nullable', 'integer', 'distinct', 'exists:world_cup_customization_options,id'],
            'option_groups.*.values.*.description' => ['nullable', 'string', 'max:2000'],
            'option_groups.*.values.*.color_hex' => ['nullable', 'regex:/^#[0-9A-F]{6}$/'],
            'option_groups.*.values.*.image_url' => ['nullable', 'url', 'max:2048'],
            'option_groups.*.values.*.image_file' => ['nullable', 'file', 'mimes:jpg,jpeg,png,webp,avif', 'mimetypes:image/jpeg,image/png,image/webp,image/avif', 'max:5120'],
            'option_groups.*.values.*.image_files' => ['nullable', 'array', 'max:12'],
            'option_groups.*.values.*.image_files.*' => ['nullable', 'file', 'mimes:jpg,jpeg,png,webp,avif', 'mimetypes:image/jpeg,image/png,image/webp,image/avif', 'max:5120'],
            'option_groups.*.values.*.clear_images' => ['nullable', 'boolean'],
            'option_groups.*.values.*.price_adjustment' => ['nullable', 'numeric', 'min:0', 'max:999999999.99'],
            'option_groups.*.values.*.charge_type' => ['nullable', Rule::in(['included', 'per_unit', 'fixed_order'])],
            'option_groups.*.values.*.stock_quantity' => ['nullable', 'integer', 'min:0'],
            'option_groups.*.values.*.is_default' => ['nullable', 'boolean'],
            'option_groups.*.values.*.is_active' => ['nullable', 'boolean'],

            'size_groups' => ['nullable', 'array', 'max:50'],
            'size_groups.*.existing_id' => ['nullable', 'integer', 'min:1'],
            'size_groups.*.size_option_group_id' => ['nullable', 'integer', 'distinct', 'exists:size_option_groups,id'],
            'size_groups.*.name' => ['nullable', 'string', 'max:120'],
            'size_groups.*.code' => ['nullable', 'string', 'max:120', 'regex:/^[a-z0-9]+(?:-[a-z0-9]+)*$/', 'distinct'],
            'size_groups.*.description_html' => ['nullable', 'string', 'max:100000'],
            'size_groups.*.chart_html' => ['nullable', 'string', 'max:100000'],
            'size_groups.*.sizes_text' => ['nullable', 'string', 'max:5000'],
            'size_groups.*.is_active' => ['nullable', 'boolean'],
            'size_groups.*.chart_enabled' => ['nullable', 'boolean'],
            'size_groups.*.chart_title' => ['nullable', 'string', 'max:180'],
            'size_groups.*.chart_note' => ['nullable', 'string', 'max:2000'],
            'size_groups.*.chart_columns_text' => ['nullable', 'string', 'max:2000'],
            'size_groups.*.chart_rows_text' => ['nullable', 'string', 'max:30000'],
            'size_groups.*.chart_image_url' => ['nullable', 'url', 'max:2048'],
            'size_groups.*.chart_image' => ['nullable', 'file', 'mimes:jpg,jpeg,png,webp,avif', 'mimetypes:image/jpeg,image/png,image/webp,image/avif', 'max:5120'],
            'size_groups.*.clear_chart_image' => ['nullable', 'boolean'],
            'size_groups.*.has_size_extra_charges' => ['nullable', 'boolean'],
            'size_groups.*.size_price_adjustments' => ['nullable', 'array', 'max:100'],
            'size_groups.*.size_price_adjustments.*' => ['nullable', 'numeric', 'min:0', 'max:999999999.99'],
            'size_groups.*.size_charges' => ['nullable', 'array', 'max:100'],
            'size_groups.*.size_charges.*.code' => ['nullable', 'string', 'max:80'],
            'size_groups.*.size_charges.*.label' => ['nullable', 'string', 'max:80'],
            'size_groups.*.size_charges.*.amount' => ['nullable', 'numeric', 'min:0', 'max:999999999.99'],

            'artwork_methods' => ['nullable', 'array', 'max:50'],
            'artwork_methods.*.name' => ['nullable', 'string', 'max:160'],
            'artwork_methods.*.code' => ['nullable', 'string', 'max:160', 'regex:/^[a-z0-9]+(?:-[a-z0-9]+)*$/', 'distinct'],
            'artwork_methods.*.icon' => ['nullable', 'string', 'max:40'],
            'artwork_methods.*.description' => ['nullable', 'string', 'max:2000'],
            'artwork_methods.*.price_adjustment' => ['nullable', 'numeric', 'min:-999999999.99', 'max:999999999.99'],
            'artwork_methods.*.requires_upload' => ['nullable', 'boolean'],
            'artwork_methods.*.is_active' => ['nullable', 'boolean'],

            'production_table_headers' => ['nullable', 'array', 'max:12'],
            'production_table_headers.*' => ['required', 'string', 'max:160', 'distinct'],
            'production_table_rows' => ['nullable', 'array', 'max:100'],
            'production_table_rows.*.range' => ['required', 'string', 'max:50'],
            'production_table_rows.*.cells' => ['nullable', 'array', 'max:12'],
            'production_table_rows.*.cells.*.enabled' => ['nullable', 'boolean'],
            'production_table_rows.*.cells.*.description' => ['nullable', 'string', 'max:2000'],
            'production_table_rows.*.cells.*.price_adjustment' => ['nullable', 'numeric', 'min:0', 'max:999999999.99'],
            'production_table_rows.*.cells.*.production_time' => ['nullable', 'string', 'max:60'],

            // Flattened by prepareForValidation for the existing persistence layer.
            'production_speeds' => ['nullable', 'array', 'max:150'],
            'production_speeds.*.name' => ['nullable', 'string', 'max:160'],
            'production_speeds.*.code' => ['nullable', 'string', 'max:160', 'regex:/^[a-z0-9]+(?:-[a-z0-9]+)*$/', 'distinct'],
            'production_speeds.*.description' => ['nullable', 'string', 'max:2000'],
            'production_speeds.*.price_adjustment' => ['nullable', 'numeric', 'min:0', 'max:999999999.99'],
            'production_speeds.*.minimum_quantity' => ['required', 'integer', 'min:1', 'max:1000000'],
            'production_speeds.*.maximum_quantity' => ['nullable', 'integer', 'gte:production_speeds.*.minimum_quantity', 'max:1000000'],
            'production_speeds.*.minimum_days' => ['required', 'integer', 'min:0', 'max:3650'],
            'production_speeds.*.maximum_days' => ['required', 'integer', 'gte:production_speeds.*.minimum_days', 'max:3650'],
            'production_speeds.*.production_method_id' => ['nullable', 'integer', 'exists:production_methods,id'],
            'production_speeds.*.is_active' => ['nullable', 'boolean'],

            'production_methods_from_master' => ['nullable', 'boolean'],
            'production_method_codes' => ['nullable', 'array', 'max:30'],
            'production_method_codes.*' => ['nullable', 'string', 'max:160', 'distinct', Rule::exists('production_methods', 'code')],
            'production_method_price_adjustments' => ['nullable', 'array', 'max:30'],
            'production_method_price_adjustments.*' => ['nullable', 'numeric', 'min:0', 'max:999999999.99'],

            'shipping_method_codes' => ['nullable', 'array', 'max:30'],
            'shipping_method_codes.*' => ['nullable', 'string', 'max:160', 'distinct', Rule::exists('shipping_methods', 'code')],
            'shipping_method_default_code' => ['nullable', 'string', 'max:160', Rule::exists('shipping_methods', 'code')],
            'shipping_methods' => ['nullable', 'array', 'max:30'],
            'shipping_methods.*.shipping_method_id' => ['nullable', 'integer', 'exists:shipping_methods,id'],
            'shipping_methods.*.name' => ['nullable', 'string', 'max:160'],
            'shipping_methods.*.code' => ['nullable', 'string', 'max:160', 'regex:/^[a-z0-9]+(?:-[a-z0-9]+)*$/', 'distinct'],
            'shipping_methods.*.description' => ['nullable', 'string', 'max:2000'],
            'shipping_methods.*.price_adjustment' => ['nullable', 'numeric', 'min:0', 'max:999999999.99'],
            'shipping_methods.*.base_price' => ['nullable', 'numeric', 'min:0', 'max:999999999.99'],
            'shipping_methods.*.per_item_price' => ['nullable', 'numeric', 'min:0', 'max:999999999.99'],
            'shipping_methods.*.free_shipping_minimum' => ['nullable', 'numeric', 'min:0', 'max:999999999.99'],
            'shipping_methods.*.charge_type' => ['nullable', Rule::in(['included', 'per_unit', 'fixed_order', 'master_method', 'price_table'])],
            'shipping_methods.*.charge_application' => ['nullable', Rule::in(array_keys(ShippingMethod::chargeApplicationOptions()))],
            'shipping_methods.*.minimum_days' => ['nullable', 'integer', 'min:0', 'max:3650'],
            'shipping_methods.*.maximum_days' => ['nullable', 'integer', 'gte:shipping_methods.*.minimum_days', 'max:3650'],
            'shipping_methods.*.starts_after_artwork_approval' => ['nullable', 'boolean'],
            'shipping_methods.*.is_quote_based' => ['nullable', 'boolean'],
            'shipping_methods.*.is_default' => ['nullable', 'boolean'],
            'shipping_methods.*.is_active' => ['nullable', 'boolean'],

            'faq_ids' => ['nullable', 'array', 'max:100'],
            'faq_ids.*' => ['integer', 'distinct', Rule::exists('faqs', 'id')],

            'meta_title' => ['nullable', 'string', 'max:255'],
            'meta_description' => ['nullable', 'string', 'max:1000'],
            'meta_keywords' => ['nullable', 'string', 'max:2000'],
            'canonical_url' => ['nullable', 'url', 'max:2048'],
            'og_title' => ['nullable', 'string', 'max:255'],
            'og_description' => ['nullable', 'string', 'max:1000'],
            'og_image_url' => ['nullable', 'url', 'max:2048'],
            'robots_index' => ['nullable', 'boolean'],
            'robots_follow' => ['nullable', 'boolean'],
            'schema_json_text' => ['nullable', 'json', 'max:50000'],
        ];
    }

    protected function prepareForValidation(): void
    {
        $routeProduct = $this->route('product');
        $submittedSku = trim((string) $this->input('sku', ''));
        $specificationSku = $this->extractSkuFromSpecificationText($this->input('product_specification_text'));
        $sku = $submittedSku !== '' ? $submittedSku : ($specificationSku ?: ($routeProduct?->sku ?: $this->generateSku((string) $this->input('name', 'Product'))));
        $this->merge(['sku' => $sku]);

        $showInCategoryPage = $this->boolean('show_in_category_page');
        $assignments = collect($this->input('category_assignments', []))
            ->filter(fn ($id) => filter_var($id, FILTER_VALIDATE_INT) !== false)
            ->map(fn ($id) => (int) $id)->unique()->values();
        $primary = $this->input('primary_category_id');
        if (filled($primary)) {
            $primary = (int) $primary;
            if ($showInCategoryPage) {
                $assignments->prepend($primary);
            }
        } elseif ($assignments->isNotEmpty()) {
            // Every categorized product has one deterministic primary placement for
            // breadcrumbs, canonical grouping, exports, and legacy compatibility.
            $primary = (int) $assignments->first();
        } else {
            $primary = null;
        }

        if (! $showInCategoryPage) {
            $assignments = collect();
        }

        $this->merge([
            'primary_category_id' => $primary,
            'category_assignments' => $assignments->unique()->values()->all(),
            'show_in_category_page' => $showInCategoryPage,
            'attribute_value_ids' => collect($this->input('attribute_value_ids', []))->map(fn ($id) => (int) $id)->filter()->unique()->values()->all(),
        ]);

        $pricing = $this->normalizeVisiblePricing();
        $this->merge($pricing);

        $submittedMasterOptionIds = collect($this->input('option_groups', []))
            ->flatMap(static fn ($group) => collect(is_array($group) ? ($group['values'] ?? []) : [])
                ->pluck('jersey_customization_option_id'))
            ->filter()
            ->map(static fn ($id): int => (int) $id)
            ->unique()
            ->values();
        $masterOptionLookup = JerseyCustomizationOption::query()
            ->active()
            ->whereIn('id', $submittedMasterOptionIds)
            ->get()
            ->keyBy('id');

        $submittedWorldCupOptionIds = collect($this->input('option_groups', []))
            ->flatMap(static fn ($group) => collect(is_array($group) ? ($group['values'] ?? []) : [])
                ->pluck('world_cup_customization_option_id'))
            ->filter()
            ->map(static fn ($id): int => (int) $id)
            ->unique()
            ->values();
        $worldCupMasterOptionLookup = WorldCupCustomizationOption::query()
            ->active()
            ->whereIn('id', $submittedWorldCupOptionIds)
            ->get()
            ->keyBy('id');

        $usedGroupCodes = [];
        $optionGroups = collect($this->input('option_groups', []))
            ->map(function ($group, int $groupIndex) use (&$usedGroupCodes, $masterOptionLookup, $worldCupMasterOptionLookup): array {
                if (! is_array($group)) {
                    return [];
                }

                $choiceTypes = ['image', 'swatch', 'buttons', 'select', 'checkbox'];
                $baseGroupCode = Str::slug((string) ($group['code'] ?? $group['name'] ?? '')) ?: 'feature-'.($groupIndex + 1);
                $groupCode = $baseGroupCode;
                $suffix = 2;
                while (in_array($groupCode, $usedGroupCodes, true)) {
                    $groupCode = $baseGroupCode.'-'.$suffix++;
                }
                $masterTypeValue = (string) ($group['jersey_customization_type'] ?? '');
                $legacyMasterType = JerseyCustomizationType::tryFrom($masterTypeValue);
                $worldCupMasterType = WorldCupCustomizationType::tryFrom($masterTypeValue);
                $masterType = $legacyMasterType ?: $worldCupMasterType;
                if ($masterType) {
                    $group['name'] = $masterType->label();
                    // Customization type values are stable database identifiers; the
                    // customer-facing option-group code remains a URL-style slug.
                    $baseGroupCode = $masterType->productCode() ?: 'feature-'.($groupIndex + 1);
                    $groupCode = $baseGroupCode;
                    $suffix = 2;
                    while (in_array($groupCode, $usedGroupCodes, true)) {
                        $groupCode = $baseGroupCode.'-'.$suffix++;
                    }
                }

                $usedGroupCodes[] = $groupCode;
                $group['code'] = $groupCode;
                $group['jersey_customization_type'] = $masterType?->value;
                // The simplified product-feature editor only creates storefront-selectable
                // features. The server enforces the same behavior rather than trusting a
                // modified hidden form value.
                $group['section'] = 'product';
                $group['display_mode'] = 'customer';
                $group['fixed_value_code'] = null;
                $group['fixed_text_value'] = null;
                $group['show_in_summary'] = filter_var($group['show_in_summary'] ?? true, FILTER_VALIDATE_BOOL);
                $group['is_required'] = filter_var($group['is_required'] ?? false, FILTER_VALIDATE_BOOL);
                $group['is_active'] = true;
                $group['use_as_filter'] = filter_var($group['use_as_filter'] ?? false, FILTER_VALIDATE_BOOL)
                    && in_array(($group['type'] ?? 'select'), $choiceTypes, true)
                    && ($group['display_mode'] ?? 'customer') !== 'hidden';

                $group['values'] = collect($group['values'] ?? [])
                    ->map(function ($value, int $valueIndex) use ($masterOptionLookup, $worldCupMasterOptionLookup): array {
                        if (! is_array($value)) {
                            return [];
                        }
                        $masterOptionId = filter_var($value['jersey_customization_option_id'] ?? null, FILTER_VALIDATE_INT);
                        $worldCupMasterOptionId = filter_var($value['world_cup_customization_option_id'] ?? null, FILTER_VALIDATE_INT);
                        $value['jersey_customization_option_id'] = $masterOptionId !== false ? $masterOptionId : null;
                        $value['world_cup_customization_option_id'] = $worldCupMasterOptionId !== false ? $worldCupMasterOptionId : null;
                        $legacyMasterOption = $masterOptionId !== false ? $masterOptionLookup->get((int) $masterOptionId) : null;
                        $worldCupMasterOption = $worldCupMasterOptionId !== false ? $worldCupMasterOptionLookup->get((int) $worldCupMasterOptionId) : null;
                        $masterOption = $worldCupMasterOption ?: $legacyMasterOption;
                        if ($masterOption) {
                            $value['jersey_customization_option_id'] = $worldCupMasterOption ? null : $legacyMasterOption?->id;
                            $value['world_cup_customization_option_id'] = $worldCupMasterOption?->id;
                            $value['label'] = $masterOption->name;
                            $value['code'] = $masterOption->slug;
                            $value['description'] = $masterOption->description;
                            $value['color_hex'] = $worldCupMasterOption ? null : $legacyMasterOption?->color_hex;
                            $value['image_url'] = null;
                        } else {
                            $value['code'] = Str::slug((string) ($value['code'] ?? $value['label'] ?? '')) ?: 'value-'.($valueIndex + 1);
                        }
                        $hex = trim((string) ($value['color_hex'] ?? ''));

                        if ($hex !== '') {
                            $hex = ltrim($hex, '#');

                            if (preg_match('/^[0-9a-fA-F]{3}$/', $hex) === 1) {
                                $hex = implode('', array_map(
                                    static fn (string $character): string => $character.$character,
                                    str_split($hex)
                                ));
                            }

                            $value['color_hex'] = '#'.strtoupper($hex);
                        } else {
                            $value['color_hex'] = null;
                        }

                        $value['image_url'] = filled($value['image_url'] ?? null)
                            ? trim((string) $value['image_url'])
                            : null;

                        return $value;
                    })
                    ->values()
                    ->all();

                return $group;
            })
            ->values()
            ->all();

        $normalizeRowsWithCodes = static function (array $rows, string $nameKey = 'name'): array {
            $used = [];

            return collect($rows)->map(function ($row, int $index) use (&$used, $nameKey): array {
                if (! is_array($row)) {
                    return [];
                }

                $base = Str::slug((string) ($row['code'] ?? $row[$nameKey] ?? '')) ?: 'item-'.($index + 1);
                $code = $base;
                $suffix = 2;
                while (in_array($code, $used, true)) {
                    $code = $base.'-'.$suffix++;
                }
                $used[] = $code;
                $row['code'] = $code;
                $row['is_active'] = true;

                return $row;
            })->values()->all();
        };

        $production = $this->normalizeProductionTable();
        $productionSpeeds = $this->boolean('production_methods_enabled')
            ? ($this->boolean('production_methods_from_master')
                ? $this->productionMethodsFromMaster()
                : $normalizeRowsWithCodes($production['production_speeds']))
            : [];

        $rosterFields = collect($this->input('jersey_roster_fields', []))
            ->map(function ($field, int $index): array {
                if (! is_array($field)) {
                    return [];
                }

                $field['key'] = Str::slug((string) ($field['key'] ?? $field['label'] ?? ''), '_') ?: 'field_'.($index + 1);
                $field['enabled'] = true;

                return $field;
            })->values()->all();

        $productProfile = $this->input('product_profile', 'standard');
        $sizeGroups = ProductSizing::supports($productProfile)
            ? $normalizeRowsWithCodes((array) $this->input('size_groups', []))
            : [];
        $sizeGroups = collect($sizeGroups)->map(static function (array $group): array {
            $group['size_price_adjustments'] = ProductSizeExtraCharges::adjustments($group);
            $group['has_size_extra_charges'] = ProductSizeExtraCharges::enabled($group);

            return $group;
        })->values()->all();

        $this->merge([
            'option_groups' => $optionGroups,
            'size_groups' => $sizeGroups,
            'production_table_headers' => $production['production_table_headers'],
            'production_table_rows' => $production['production_table_rows'],
            'production_speeds' => $productionSpeeds,
            'shipping_methods' => $this->shippingMethodsFromMaster(),
            'jersey_roster_fields' => $rosterFields,
            'product_profile' => $productProfile,
            'production_methods_enabled' => $this->boolean('production_methods_enabled'),
            'shipping_methods_enabled' => $this->boolean('shipping_methods_enabled'),
            'jersey_roster_enabled' => $this->boolean('jersey_roster_enabled'),
            'jersey_roster_optional' => $this->boolean('jersey_roster_optional'),
            'artwork_upload_enabled' => $this->boolean('artwork_upload_enabled'),
            'artwork_upload_required' => $this->boolean('artwork_upload_required'),
            'is_featured' => $this->boolean('is_featured'),
            'is_customizable' => $this->boolean('is_customizable'),
            'is_active' => $this->boolean('is_active'),
            'track_inventory' => $this->boolean('track_inventory'),
            'allow_backorder' => $this->boolean('allow_backorder'),
            'robots_index' => $this->boolean('robots_index'),
            'robots_follow' => $this->boolean('robots_follow'),
        ]);
    }

    private function extractSkuFromSpecificationText(mixed $value): ?string
    {
        $text = (string) $value;
        if (trim($text) === '') {
            return null;
        }

        if (str_contains($text, '<')) {
            $text = preg_replace('/<\/(tr|p|div|li)>/i', "\n", $text) ?? $text;
            $text = preg_replace('/<\/(td|th)>/i', "\t", $text) ?? $text;
            $text = html_entity_decode(strip_tags($text), ENT_QUOTES | ENT_HTML5, 'UTF-8');
        }

        $text = str_replace("\xc2\xa0", ' ', $text);
        $knownNextLabels = ['Product Type', 'Fabric', 'Fit', 'Customization', 'Customisation', 'Size Range', 'MOQ', 'Minimum Order', 'Lead Time', 'Production Time'];
        $nextLabelPattern = collect($knownNextLabels)->map(fn ($label) => preg_quote($label, '/'))->implode('|');

        foreach (preg_split('/\r\n|\r|\n/', $text) ?: [] as $line) {
            $line = trim(preg_replace('/[ \t]+/', ' ', (string) $line) ?? '');
            if ($line === '') {
                continue;
            }

            if (preg_match('/^SKU\s*[:\t]\s*(.+)$/i', $line, $matches) === 1
                || preg_match('/^SKU\s+(.+)$/i', $line, $matches) === 1) {
                return $this->cleanSkuValue($matches[1], $nextLabelPattern);
            }
        }

        $flatText = trim(preg_replace('/[ \t]+/', ' ', $text) ?? '');
        if ($flatText !== '' && preg_match('/\bSKU\s*:\s*(.+?)(?=\b(?:'.$nextLabelPattern.')\s*:|$)/i', $flatText, $matches) === 1) {
            return $this->cleanSkuValue($matches[1], $nextLabelPattern);
        }

        return null;
    }

    private function cleanSkuValue(string $value, string $nextLabelPattern): ?string
    {
        $sku = trim(preg_replace('/[ \t]+/', ' ', str_replace("\xc2\xa0", ' ', $value)) ?? '');
        $sku = preg_replace('/\b(?:'.$nextLabelPattern.')\s*:.*$/i', '', $sku) ?? $sku;
        $sku = trim($sku, " \t\n\r\0\x0B:-");

        return $sku !== '' ? Str::limit($sku, 120, '') : null;
    }

    private function generateSku(string $name): string
    {
        $stem = Str::upper(Str::substr((string) preg_replace('/[^a-z0-9]+/i', '', $name), 0, 12));
        $stem = $stem !== '' ? $stem : 'PRODUCT';

        do {
            $candidate = 'NPS-'.$stem.'-'.Str::upper(Str::random(6));
        } while (Product::query()->where('sku', $candidate)->exists());

        return $candidate;
    }

    public function withValidator(Validator $validator): void
    {
        $validator->after(function (Validator $validator): void {
            $discountPrice = $this->input('compare_at_price');
            if (is_numeric($discountPrice) && (float) $discountPrice > 0) {
                $lastVisibleTier = collect($this->input('price_tiers', []))
                    ->filter(fn ($tier): bool => is_array($tier)
                        && is_numeric($tier['unit_price'] ?? null)
                        && is_numeric($tier['minimum_quantity'] ?? null))
                    ->sortBy(fn (array $tier): int => (int) $tier['minimum_quantity'])
                    ->last();
                $originalCardPrice = is_array($lastVisibleTier)
                    ? ($lastVisibleTier['unit_price'] ?? $this->input('base_price'))
                    : $this->input('base_price');

                if (is_numeric($originalCardPrice)
                    && (float) $originalCardPrice > 0
                    && (float) $discountPrice >= (float) $originalCardPrice) {
                    $validator->errors()->add(
                        'compare_at_price',
                        'The discount unit price must be lower than the current storefront “From” price of $'.number_format((float) $originalCardPrice, 2).'.'
                    );
                }
            }

            $submittedCategoryIds = collect([$this->input('primary_category_id')])
                ->merge((array) $this->input('category_assignments', []))
                ->filter(fn ($id): bool => filter_var($id, FILTER_VALIDATE_INT) !== false)
                ->map(fn ($id): int => (int) $id)
                ->filter()
                ->unique()
                ->values();

            if ($submittedCategoryIds->isNotEmpty()) {
                $nonLeafCategoryNames = Category::query()
                    ->whereIn('id', $submittedCategoryIds->all())
                    ->whereHas('children')
                    ->pluck('name');

                if ($nonLeafCategoryNames->isNotEmpty()) {
                    $validator->errors()->add(
                        'primary_category_id',
                        'Products can only be assigned to last-level categories. Choose a category with no child categories. Invalid selection: '.$nonLeafCategoryNames->join(', ').'.'
                    );
                }
            }

            $groups = collect($this->input('option_groups', []))->values();
            $masterIds = $groups
                ->flatMap(static fn ($group) => collect($group['values'] ?? [])->pluck('jersey_customization_option_id'))
                ->filter()->map(static fn ($id): int => (int) $id)->unique()->values();
            $worldCupMasterIds = $groups
                ->flatMap(static fn ($group) => collect($group['values'] ?? [])->pluck('world_cup_customization_option_id'))
                ->filter()->map(static fn ($id): int => (int) $id)->unique()->values();
            $masterOptions = JerseyCustomizationOption::query()
                ->whereIn('id', $masterIds)
                ->get(['id', 'type', 'is_active'])
                ->keyBy('id');
            $worldCupMasterOptions = WorldCupCustomizationOption::query()
                ->whereIn('id', $worldCupMasterIds)
                ->get(['id', 'category_key', 'type', 'is_active'])
                ->keyBy('id');

            foreach ($groups as $groupIndex => $group) {
                $typeValue = (string) data_get($group, 'jersey_customization_type', '');
                $legacyType = JerseyCustomizationType::tryFrom($typeValue);
                $worldCupType = WorldCupCustomizationType::tryFrom($typeValue);
                $values = collect(data_get($group, 'values', []))->values();
                $legacySelectedIds = $values->pluck('jersey_customization_option_id')->filter()->map(static fn ($id): int => (int) $id)->values();
                $worldCupSelectedIds = $values->pluck('world_cup_customization_option_id')->filter()->map(static fn ($id): int => (int) $id)->values();

                if ($legacySelectedIds->duplicates()->isNotEmpty() || $worldCupSelectedIds->duplicates()->isNotEmpty()) {
                    $validator->errors()->add("option_groups.{$groupIndex}.values", 'The same customization item cannot be selected more than once.');
                }

                foreach ($values as $valueIndex => $value) {
                    $legacyId = (int) data_get($value, 'jersey_customization_option_id', 0);
                    $worldCupId = (int) data_get($value, 'world_cup_customization_option_id', 0);
                    if ($legacyId > 0 && $worldCupId > 0) {
                        $validator->errors()->add("option_groups.{$groupIndex}.values.{$valueIndex}.world_cup_customization_option_id", 'A customization value cannot use two master-data sources.');
                        continue;
                    }
                    if ($legacyId > 0) {
                        $masterOption = $masterOptions->get($legacyId);
                        if (! $masterOption || ! $masterOption->is_active) {
                            $validator->errors()->add("option_groups.{$groupIndex}.values.{$valueIndex}.jersey_customization_option_id", 'The selected customization item is unavailable.');
                        } elseif (! $legacyType || $masterOption->type !== $legacyType) {
                            $validator->errors()->add("option_groups.{$groupIndex}.values.{$valueIndex}.jersey_customization_option_id", 'The selected customization item does not belong to this feature type.');
                        }
                    }
                    if ($worldCupId > 0) {
                        $masterOption = $worldCupMasterOptions->get($worldCupId);
                        if (! $masterOption || ! $masterOption->is_active) {
                            $validator->errors()->add("option_groups.{$groupIndex}.values.{$valueIndex}.world_cup_customization_option_id", 'The selected World Cup customization item is unavailable.');
                        } elseif (! $worldCupType || $masterOption->type !== $worldCupType || $masterOption->category_key !== $worldCupType->categoryKey()) {
                            $validator->errors()->add("option_groups.{$groupIndex}.values.{$valueIndex}.world_cup_customization_option_id", 'The selected World Cup item does not belong to this product customization type.');
                        }
                    }
                }
            }

            $ranges = collect($this->input('price_table_ranges', []))->values();
            $rows = collect($this->input('price_table_rows', []))->values();
            $tiers = collect($this->input('price_tiers', []))->values();

            if ($ranges->count() !== $rows->count()) {
                $validator->errors()->add('price_table_ranges', 'Every visible price row must have one minimum and maximum quantity range.');
            }

            // Visible price tables may be imported from the old website and can contain
            // repeated, non-continuous, or display-only quantity rows. Do not block the
            // whole product form because of that table structure; admins can clean it later.
            // The storefront price table is still preserved, and live pricing is derived
            // only from rows where a usable minimum quantity and price can be parsed.

            $productionHeaders = collect($this->input('production_table_headers', []))->values();
            $productionRows = collect($this->input('production_table_rows', []))->values();
            foreach ($productionRows as $rowIndex => $row) {
                $rangeText = trim((string) data_get($row, 'range', ''));
                $parsed = $this->parseProductionRange($rangeText);
                if ($parsed === null) {
                    $validator->errors()->add("production_table_rows.{$rowIndex}.range", 'Enter a valid quantity range such as 1-40 pairs, 100-500 pairs, >100 pairs, 41+, or 25.');
                    continue;
                }

                foreach ((array) data_get($row, 'cells', []) as $columnIndex => $cell) {
                    if (! filter_var(data_get($cell, 'enabled', false), FILTER_VALIDATE_BOOL)) {
                        continue;
                    }

                    if (! filled($productionHeaders->get($columnIndex))) {
                        $validator->errors()->add("production_table_headers.{$columnIndex}", 'Enter a production option name for every enabled column.');
                    }

                    $productionTime = ProductionTime::parse(data_get($cell, 'production_time'));
                    if ($productionTime === null) {
                        $validator->errors()->add(
                            "production_table_rows.{$rowIndex}.cells.{$columnIndex}.production_time",
                            'Enter a valid production time such as 5 days, 5-15 days, or To be confirmed.'
                        );
                    }
                }

                // Production rows can come from legacy/imported product pages and may
                // intentionally contain display-style labels or broad quantity bands.
                // Keep them editable and saveable; parsed values are still used only
                // to create selectable production-speed records.
            }
        });
    }

    /**
     * Normalize the independent production table and flatten enabled cells into
     * the existing product_production_speeds persistence model.
     */
    private function productionMethodsFromMaster(): array
    {
        $codes = collect((array) $this->input('production_method_codes', []))
            ->map(fn ($code) => Str::slug((string) $code))
            ->filter()
            ->unique()
            ->take(30)
            ->values();

        $priceAdjustments = collect((array) $this->input('production_method_price_adjustments', []))
            ->mapWithKeys(function ($value, $code): array {
                $normalizedCode = Str::slug((string) $code);

                if ($normalizedCode === '') {
                    return [];
                }

                return [$normalizedCode => max(0, round((float) $value, 2))];
            });

        if ($codes->isEmpty()) {
            return [];
        }

        $methods = ProductionMethod::query()
            ->whereIn('code', $codes->all())
            ->get()
            ->keyBy('code');

        return $codes->map(function (string $code) use ($methods, $priceAdjustments): ?array {
            /** @var ProductionMethod|null $method */
            $method = $methods->get($code);
            if (! $method instanceof ProductionMethod) {
                return null;
            }

            return [
                'production_method_id' => $method->id,
                'name' => $method->name,
                'code' => $method->code,
                'description' => $method->description,
                'price_adjustment' => (float) $priceAdjustments->get($code, 0),
                'minimum_quantity' => 1,
                'maximum_quantity' => null,
                'minimum_days' => (int) ($method->minimum_days ?? 1),
                'maximum_days' => (int) ($method->maximum_days ?? ($method->minimum_days ?? 1)),
                'is_active' => (bool) ($method->is_active ?? true),
            ];
        })->filter()->values()->all();
    }

    private function shippingMethodsFromMaster(): array
    {
        $codes = collect((array) $this->input('shipping_method_codes', []))
            ->map(fn ($code) => Str::slug((string) $code))
            ->filter()
            ->unique()
            ->take(30)
            ->values();

        if ($codes->isEmpty()) {
            return [];
        }

        $defaultCode = Str::slug((string) $this->input('shipping_method_default_code', ''));
        if ($defaultCode === '' || ! $codes->contains($defaultCode)) {
            $defaultCode = (string) $codes->first();
        }

        $methods = ShippingMethod::query()
            ->whereIn('code', $codes->all())
            ->get()
            ->keyBy('code');

        return $codes->map(function (string $code) use ($methods, $defaultCode): ?array {
            /** @var ShippingMethod|null $method */
            $method = $methods->get($code);
            if (! $method instanceof ShippingMethod) {
                return null;
            }

            return [
                'shipping_method_id' => $method->id,
                'name' => $method->name,
                'code' => $method->code,
                'description' => $method->description,
                // Shipping master data now controls only the customer-facing method
                // name and transit days. The live charge comes from matching product
                // price-table columns such as Standard/Normal Shipping or Urgent/Express Shipping.
                'price_adjustment' => 0,
                'base_price' => 0,
                'per_item_price' => 0,
                'free_shipping_minimum' => null,
                'charge_type' => 'price_table',
                'charge_application' => 'per_item',
                'minimum_days' => (int) ($method->minimum_days ?? 1),
                'maximum_days' => (int) ($method->maximum_days ?? ($method->minimum_days ?? 1)),
                'starts_after_artwork_approval' => (bool) ($method->starts_after_artwork_approval ?? true),
                'is_quote_based' => false,
                'is_default' => $method->code === $defaultCode,
                'is_active' => (bool) ($method->is_active ?? true),
            ];
        })->filter()->values()->all();
    }

    private function normalizeProductionTable(): array
    {
        $submittedHeaders = collect($this->input('production_table_headers', []))->values();
        $headerIndexes = $submittedHeaders
            ->map(fn ($header, int $index): array => ['index' => $index, 'label' => trim((string) $header)])
            ->filter(fn (array $header): bool => $header['label'] !== '')
            ->take(12)
            ->values();
        $headers = $headerIndexes->pluck('label')->all();
        $rows = [];
        $speeds = [];

        foreach (collect($this->input('production_table_rows', []))->values()->take(100) as $rowIndex => $row) {
            if (! is_array($row)) {
                continue;
            }

            $rangeText = trim((string) ($row['range'] ?? ''));
            $parsedRange = $this->parseProductionRange($rangeText);
            $submittedCells = collect($row['cells'] ?? [])->values();
            $cells = [];

            foreach ($headerIndexes as $columnIndex => $header) {
                $cell = (array) $submittedCells->get($header['index'], []);
                $productionTime = ProductionTime::parse($cell['production_time'] ?? null);
                if ($productionTime === null && (array_key_exists('minimum_days', $cell) || array_key_exists('maximum_days', $cell))) {
                    $productionTime = ProductionTime::parse(ProductionTime::format(
                        $cell['minimum_days'] ?? 0,
                        $cell['maximum_days'] ?? ($cell['minimum_days'] ?? 0)
                    ));
                }
                $minimumDays = $productionTime['minimum_days'] ?? 0;
                $maximumDays = $productionTime['maximum_days'] ?? $minimumDays;
                $enabled = filter_var($cell['enabled'] ?? false, FILTER_VALIDATE_BOOL);
                $normalizedCell = [
                    'enabled' => $enabled,
                    'description' => filled($cell['description'] ?? null) ? trim((string) $cell['description']) : null,
                    'price_adjustment' => max(0, round((float) ($cell['price_adjustment'] ?? 0), 2)),
                    'production_time' => $productionTime['display'] ?? '',
                    'minimum_days' => $minimumDays,
                    'maximum_days' => $maximumDays,
                ];
                $cells[] = $normalizedCell;

                if ($enabled && $parsedRange !== null) {
                    $speeds[] = [
                        'name' => $header['label'],
                        'code' => null,
                        'description' => $normalizedCell['description'],
                        'price_adjustment' => $normalizedCell['price_adjustment'],
                        'minimum_quantity' => $parsedRange['minimum_quantity'],
                        'maximum_quantity' => $parsedRange['maximum_quantity'],
                        'minimum_days' => $minimumDays,
                        'maximum_days' => $maximumDays,
                        'is_active' => true,
                    ];
                }
            }

            if ($rangeText !== '' || collect($cells)->contains(fn (array $cell): bool => $cell['enabled'])) {
                $rows[] = ['range' => $rangeText, 'cells' => $cells];
            }
        }

        return [
            'production_table_headers' => $headers,
            'production_table_rows' => $rows,
            'production_speeds' => $speeds,
        ];
    }

    /** @return array{minimum_quantity:int, maximum_quantity:?int}|null */
    private function parseProductionRange(string $value): ?array
    {
        $value = html_entity_decode(trim($value), ENT_QUOTES | ENT_HTML5, 'UTF-8');
        $value = str_replace(["\xc2\xa0", ',', '–', '—', '−'], [' ', '', '-', '-', '-'], $value);
        $value = preg_replace('/\b(?:pcs?|pieces?|units?|qty|quantity|pairs?|sets?|items?|products?|garments?|shirts?|jerseys?)\b\.?/i', '', $value) ?? $value;
        $value = trim((string) preg_replace('/\s+/', ' ', $value));
        $value = trim($value, " \t\n\r\0\x0B:-");

        if ($value === '') {
            return null;
        }

        if (preg_match('/^(?:less\s+than|under|below)\s*(\d+)$/i', $value, $match) === 1) {
            $maximum = (int) $match[1] - 1;

            return $maximum >= 1
                ? ['minimum_quantity' => 1, 'maximum_quantity' => $maximum]
                : null;
        }

        if (preg_match('/^(?:up\s*to|upto|max(?:imum)?|<=|=<|≤)\s*(\d+)$/i', $value, $match) === 1) {
            $maximum = (int) $match[1];

            return $maximum >= 1
                ? ['minimum_quantity' => 1, 'maximum_quantity' => $maximum]
                : null;
        }

        if (preg_match('/^(?:at\s+least|min(?:imum)?|>=|=>|≥)\s*(\d+)$/i', $value, $match) === 1) {
            $minimum = (int) $match[1];

            return $minimum >= 1
                ? ['minimum_quantity' => $minimum, 'maximum_quantity' => null]
                : null;
        }

        if (preg_match('/^(?:more\s+than|greater\s+than|over|above|>)\s*(\d+)$/i', $value, $match) === 1) {
            $minimum = (int) $match[1] + 1;

            return $minimum >= 1
                ? ['minimum_quantity' => $minimum, 'maximum_quantity' => null]
                : null;
        }

        if (preg_match('/^(\d+)\s*(?:-|to)\s*(\d+)$/i', $value, $match) === 1) {
            $minimum = (int) $match[1];
            $maximum = (int) $match[2];

            return $minimum >= 1 && $maximum >= $minimum
                ? ['minimum_quantity' => $minimum, 'maximum_quantity' => $maximum]
                : null;
        }

        if (preg_match('/^(?:from\s*)?(\d+)\s*(?:\+|plus|and\s+(?:above|up)|or\s+more|or\s+above)$/i', $value, $match) === 1) {
            $minimum = (int) $match[1];

            return $minimum >= 1
                ? ['minimum_quantity' => $minimum, 'maximum_quantity' => null]
                : null;
        }

        if (preg_match('/^(\d+)$/', $value, $match) === 1) {
            $quantity = (int) $match[1];

            return $quantity >= 1
                ? ['minimum_quantity' => $quantity, 'maximum_quantity' => $quantity]
                : null;
        }

        return null;
    }

    private function normalizeVisiblePricing(): array
    {
        $headers = collect($this->input('price_table_headers', []))
            ->map(fn ($header) => trim((string) $header))
            ->values();

        if ($headers->isEmpty()) {
            $headers = collect(['Quantity', 'Unit Price']);
        }
        $headers[0] = 'Quantity';
        if ($headers->count() === 1) {
            $headers->push('Unit Price');
        }

        $highlightColumn = filter_var($this->input('price_table_highlight_column', 1), FILTER_VALIDATE_INT);
        $highlightColumn = $highlightColumn === false ? 1 : max(1, min($headers->count() - 1, $highlightColumn));
        $ranges = $this->normalizeQuantityRanges($this->input('price_table_ranges', []));
        $rows = collect($this->input('price_table_rows', []))->values();
        $normalizedRows = [];
        $priceTiers = [];

        foreach ($rows as $index => $row) {
            if (! is_array($row)) {
                continue;
            }

            $range = $ranges->get($index, []);
            $minimum = filter_var(data_get($range, 'minimum_quantity'), FILTER_VALIDATE_INT);
            $minimum = $minimum !== false && $minimum >= 1 ? $minimum : null;
            $maximumRaw = data_get($range, 'maximum_quantity');
            $maximum = filled($maximumRaw) ? filter_var($maximumRaw, FILTER_VALIDATE_INT) : null;
            $maximum = $maximum === false ? null : $maximum;

            $cells = collect($row)
                ->take($headers->count())
                ->map(fn ($cell) => trim((string) $cell))
                ->values()
                ->all();
            $cells = array_pad($cells, $headers->count(), '');
            $quantityLabel = $this->formatQuantityRangeLabel($minimum, $maximum);
            $cells[0] = $quantityLabel;
            $unitPriceColumn = $this->resolveLivePriceColumn($headers->all(), $cells, $highlightColumn);
            $unitPrice = $unitPriceColumn === null ? null : $this->parseMoney($cells[$unitPriceColumn] ?? null);
            $savingsLabel = $this->findSavingsLabel($headers->all(), $cells);

            $normalizedRows[] = $cells;
            $priceTiers[] = [
                'label' => $quantityLabel !== '' ? $quantityLabel : null,
                'minimum_quantity' => $minimum,
                'maximum_quantity' => $maximum,
                'unit_price' => $unitPrice,
                'compare_at_price' => null,
                'savings_label' => $savingsLabel,
            ];
        }

        $usableTiers = collect($priceTiers)
            ->filter(fn ($tier) => is_int($tier['minimum_quantity']) && is_numeric($tier['unit_price']))
            ->values();
        $firstTier = $usableTiers->sortBy('minimum_quantity')->first();
        $basePrice = $firstTier['unit_price'] ?? null;
        $minimumQuantity = $firstTier['minimum_quantity'] ?? null;
        $maximumQuantity = null;
        if ($usableTiers->isNotEmpty() && $usableTiers->every(fn ($tier) => $tier['maximum_quantity'] !== null)) {
            $maximumQuantity = $usableTiers->max('maximum_quantity');
        }

        return [
            'price_table_headers' => $headers->all(),
            'price_table_rows' => $normalizedRows,
            'price_table_ranges' => $ranges->all(),
            'price_table_highlight_column' => $highlightColumn,
            'price_tiers' => $priceTiers,
            'base_price' => $basePrice ?? $this->input('base_price', 0),
            'minimum_quantity' => $minimumQuantity ?? $this->input('minimum_quantity', 1),
            'maximum_quantity' => $usableTiers->isNotEmpty() ? $maximumQuantity : $this->input('maximum_quantity'),
        ];
    }

    /**
     * Normalize the manually entered quantity ranges and auto-complete empty
     * Qty To values. A blank Qty To uses the next Qty From minus one; the last
     * row falls back to the same quantity as its Qty From value.
     */
    private function normalizeQuantityRanges(mixed $submittedRanges): \Illuminate\Support\Collection
    {
        $ranges = collect(is_array($submittedRanges) ? $submittedRanges : [])
            ->values()
            ->map(function ($range): array {
                $range = is_array($range) ? $range : [];
                $minimum = filter_var(data_get($range, 'minimum_quantity'), FILTER_VALIDATE_INT);
                $maximumRaw = data_get($range, 'maximum_quantity');
                $maximum = filled($maximumRaw) ? filter_var($maximumRaw, FILTER_VALIDATE_INT) : null;

                return [
                    'minimum_quantity' => $minimum !== false ? $minimum : data_get($range, 'minimum_quantity'),
                    'maximum_quantity' => $maximum === false ? $maximumRaw : $maximum,
                ];
            });

        return $this->autoCompleteQuantityRangeMaximums($ranges);
    }

    private function autoCompleteQuantityRangeMaximums(\Illuminate\Support\Collection $ranges): \Illuminate\Support\Collection
    {
        return $ranges->values()->map(function (array $range, int $index) use ($ranges): array {
            $minimum = filter_var(data_get($range, 'minimum_quantity'), FILTER_VALIDATE_INT);
            if ($minimum === false || $minimum < 1 || filled(data_get($range, 'maximum_quantity'))) {
                return $range;
            }

            $nextMinimum = $ranges->slice($index + 1)
                ->map(fn ($nextRange) => filter_var(data_get($nextRange, 'minimum_quantity'), FILTER_VALIDATE_INT))
                ->first(fn ($value) => $value !== false && $value >= 1);

            $range['maximum_quantity'] = $nextMinimum !== null && $nextMinimum !== false && $nextMinimum > $minimum
                ? $nextMinimum - 1
                : $minimum;

            return $range;
        });
    }

    private function formatQuantityRangeLabel(?int $minimum, ?int $maximum): string
    {
        if ($minimum === null) {
            return '';
        }

        if ($maximum === null) {
            return (string) $minimum;
        }

        return $minimum === $maximum
            ? (string) $minimum
            : $minimum.'-'.$maximum;
    }

    private function resolveLivePriceColumn(array $headers, array $row, int $highlightColumn): ?int
    {
        if ($highlightColumn > 0 && $this->parseMoney($row[$highlightColumn] ?? null) !== null) {
            return $highlightColumn;
        }

        foreach ($headers as $index => $header) {
            if ($index === 0 || preg_match('/saving|discount|shipping|total|quantity|qty|percent/i', (string) $header)) {
                continue;
            }
            if (preg_match('/unit|price|each|custom|blank/i', (string) $header) && $this->parseMoney($row[$index] ?? null) !== null) {
                return $index;
            }
        }

        foreach ($row as $index => $cell) {
            if ($index > 0 && ! preg_match('/%/', (string) $cell) && $this->parseMoney($cell) !== null) {
                return $index;
            }
        }

        return null;
    }

    private function parseMoney(mixed $value): ?float
    {
        $value = trim((string) $value);
        if ($value === '') {
            return null;
        }
        if (preg_match('/^free$/i', $value) === 1) {
            return 0.0;
        }
        if (preg_match('/-?\d[\d,]*(?:\.\d+)?/', $value, $match) !== 1) {
            return null;
        }

        return round((float) str_replace(',', '', $match[0]), 2);
    }

    private function findSavingsLabel(array $headers, array $row): ?string
    {
        foreach ($headers as $index => $header) {
            if (preg_match('/saving|discount/i', (string) $header) === 1 && filled($row[$index] ?? null)) {
                return trim((string) $row[$index]);
            }
        }

        return null;
    }

    public function messages(): array
    {
        return [
            'name.required' => 'Enter the product title.',
            'name.max' => 'Keep the product title within 220 characters.',
            'slug.required' => 'Enter the product title so the product link can be created.',
            'slug.regex' => 'Use only lowercase letters, numbers, and hyphens in the product link.',
            'slug.unique' => 'Another product already uses this product link. Change the title slightly or edit the link.',
            'sku.required' => 'Add the SKU in the Product Specification table.',
            'sku.unique' => 'This SKU is already used by another product. Update the SKU in the Product Specification table.',
            'sku.max' => 'Keep the SKU within 120 characters.',
            'status.required' => 'Choose whether this product should be draft, active, or archived.',
            'status.in' => 'Choose a valid product status.',
            'primary_category_id.required' => 'Choose the category where this product should appear.',
            'primary_category_id.exists' => 'Choose a valid category from the category list.',
            'base_price.required' => 'Enter the base price for this product.',
            'base_price.numeric' => 'Enter the base price as a number.',
            'base_price.min' => 'The base price cannot be negative.',
            'minimum_quantity.required' => 'Add at least one price tier with a starting quantity.',
            'minimum_quantity.integer' => 'Enter the quantity as a whole number.',
            'minimum_quantity.min' => 'The first quantity must be at least 1.',
            'maximum_quantity.gte' => 'The maximum quantity must be greater than or equal to the minimum quantity.',
            'product_specification_text.max' => 'The product specification section is too long. Please shorten it.',
            'description_html.max' => 'The product description is too long. Please shorten it.',
            'customization_artwork_html.max' => 'The customization and artwork guideline section is too long. Please shorten it.',
            'fulfillment_html.max' => 'The fulfillment section is too long. Please shorten it.',
            'price_table_headers.required' => 'Add at least one visible price-table column after Quantity.',
            'price_table_headers.min' => 'Add at least one visible price-table column after Quantity.',
            'price_table_headers.0.in' => 'The first storefront price-table column must stay as Quantity.',
            'price_table_headers.*.required' => 'Every price-table column needs a heading.',
            'price_table_headers.*.max' => 'Keep each price-table heading within 160 characters.',
            'price_table_headers.*.distinct' => 'Each price-table heading must be unique.',
            'price_table_rows.required' => 'Add at least one price row.',
            'price_table_rows.min' => 'Add at least one price row.',
            'price_table_rows.*.required' => 'Enter a valid price for this quantity row.',
            'price_table_rows.*.*.required' => 'Enter a price-table value or remove the empty column.',
            'price_table_rows.*.*.max' => 'Keep this price-table value short and readable.',
            'price_table_ranges.required' => 'Add the quantity range for each price row.',
            'price_table_ranges.*.minimum_quantity.required' => 'Enter the starting quantity for this price row.',
            'price_table_ranges.*.minimum_quantity.integer' => 'Enter the starting quantity as a whole number.',
            'price_table_ranges.*.minimum_quantity.min' => 'The starting quantity must be at least 1.',
            'price_table_ranges.*.maximum_quantity.integer' => 'Enter the ending quantity as a whole number, or leave it empty for the final open-ended row.',
            'price_table_ranges.*.maximum_quantity.gte' => 'The ending quantity must be greater than or equal to the starting quantity.',
            'price_table_highlight_column.required' => 'Choose the price column used for live product calculations.',
            'price_table_highlight_column.integer' => 'Choose a valid price column for live product calculations.',
            'price_tiers.*.unit_price.required_with' => 'Enter a valid unit price in the highlighted price column for every quantity row.',
            'price_tiers.*.unit_price.numeric' => 'Enter a numeric unit price for this row.',
            'option_groups.*.code.regex' => 'This customization feature has an invalid internal identifier. Refresh the page and try saving again.',
            'option_groups.*.code.distinct' => 'The same customization feature cannot be added more than once.',
            'option_groups.*.values.*.color_hex.regex' => 'Enter a valid HEX color such as #15345D or 15345D.',
            'option_groups.*.values.*.price_adjustment.numeric' => 'Enter the customization additional charge as a valid number.',
            'option_groups.*.values.*.price_adjustment.min' => 'The customization additional charge cannot be negative.',
            'size_groups.*.size_charges.*.amount.numeric' => 'Enter the size extra charge as a valid number.',
            'size_groups.*.size_charges.*.amount.min' => 'The size extra charge cannot be negative.',
            'option_groups.*.values.*.image_file.image' => 'Each option image must be a valid image file.',
            'option_groups.*.values.*.image_file.mimes' => 'Option images must be JPG, PNG, WebP, or AVIF files.',
            'option_groups.*.values.*.image_file.max' => 'Each option image must not exceed 5 MB.',
            'images.*.file' => 'Each uploaded product image must be a valid file.',
            'images.*.mimes' => 'Product images must be JPG, PNG, WebP, or AVIF files.',
            'images.*.mimetypes' => 'Product images must be JPG, PNG, WebP, or AVIF files.',
            'images.*.max' => 'Each uploaded product image must not exceed 5 MB.',
            'image_urls.*.url.url' => 'Enter a valid product image URL.',
            'artwork_upload_accepted_types.regex' => 'Enter file extensions only, separated by commas, for example: pdf, ai, png, jpg.',
            'artwork_upload_title.max' => 'Keep the artwork upload title within 180 characters.',
            'artwork_upload_description.max' => 'Keep the artwork upload instructions within 3000 characters.',
            'artwork_upload_max_files.integer' => 'Enter the maximum artwork files as a whole number.',
            'artwork_upload_max_files.min' => 'Allow at least 1 artwork file.',
            'artwork_upload_max_files.max' => 'Allow no more than 12 artwork files.',
            'artwork_upload_max_file_size_mb.integer' => 'Enter the artwork file size as a whole number.',
            'artwork_upload_max_file_size_mb.min' => 'Artwork file size must be at least 1 MB.',
            'artwork_upload_max_file_size_mb.max' => 'Artwork file size must not exceed 25 MB.',
            'shipping_method_codes.*.exists' => 'Choose a valid shipping method from Master Data.',
            'shipping_method_default_code.exists' => 'Choose a valid default shipping method from Master Data.',
            'shipping_methods.*.name.max' => 'Keep the shipping method name within 160 characters.',
            'shipping_methods.*.price_adjustment.numeric' => 'Enter the shipping charge as a number.',
            'shipping_methods.*.price_adjustment.min' => 'The shipping charge cannot be negative.',
            'shipping_methods.*.minimum_days.integer' => 'Enter shipping days as a whole number.',
            'shipping_methods.*.minimum_days.min' => 'Shipping days cannot be negative.',
            'shipping_methods.*.maximum_days.gte' => 'The shipping maximum days must be greater than or equal to the minimum days.',
            'production_table_headers.*.required' => 'Enter a name for this production option.',
            'production_table_headers.*.distinct' => 'Each production option name must be unique.',
            'production_table_rows.*.range.required' => 'Enter the production quantity range.',
            'production_table_rows.*.range.max' => 'Keep the production quantity range within 50 characters.',
            'production_table_rows.*.cells.*.price_adjustment.numeric' => 'Enter the production charge as a number.',
            'production_table_rows.*.cells.*.price_adjustment.min' => 'The production charge cannot be negative.',
            'production_method_price_adjustments.*.numeric' => 'Enter each production method charge as a valid number.',
            'production_method_price_adjustments.*.min' => 'A production method charge cannot be negative.',
            'production_table_rows.*.cells.*.production_time.max' => 'Keep the production time within 60 characters, for example 5-15 days or To be confirmed.',
            'production_speeds.*.maximum_quantity.gte' => 'The production quantity maximum must be greater than or equal to the minimum quantity.',
            'production_speeds.*.maximum_days.gte' => 'The production maximum days must be greater than or equal to the minimum days.',
            'faq_ids.*.exists' => 'Choose a valid FAQ from Master Data.',
            'schema_json_text.json' => 'Enter valid JSON-LD schema or leave this field blank.',
        ];
    }

    public function attributes(): array
    {
        return [
            'name' => 'product title',
            'slug' => 'product link',
            'sku' => 'SKU',
            'status' => 'product status',
            'primary_category_id' => 'category',
            'short_description' => 'short product summary',
            'product_specification_text' => 'product specification',
            'description_html' => 'product description',
            'customization_artwork_html' => 'customization and artwork guideline',
            'fulfillment_html' => 'fulfillment tab content',
            'base_price' => 'base price',
            'compare_at_price' => 'discount unit price',
            'minimum_quantity' => 'minimum order quantity',
            'maximum_quantity' => 'maximum quantity',
            'price_table_headers.*' => 'price-table column heading',
            'price_table_ranges.*.minimum_quantity' => 'price row starting quantity',
            'price_table_ranges.*.maximum_quantity' => 'price row ending quantity',
            'price_table_highlight_column' => 'live price column',
            'images.*' => 'product image',
            'image_urls.*.url' => 'product image URL',
            'option_groups.*.values.*.jersey_customization_option_id' => 'customization item',
            'option_groups.*.values.*.world_cup_customization_option_id' => 'World Cup customization item',
            'faq_ids.*' => 'FAQ',
        ];
    }
}
